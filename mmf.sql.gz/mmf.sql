--
-- PostgreSQL database dump
--

-- Dumped from database version 12.15 (Ubuntu 12.15-0ubuntu0.20.04.1)
-- Dumped by pg_dump version 12.15 (Ubuntu 12.15-0ubuntu0.20.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: bjrp_bjrp_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bjrp_bjrp_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bjrp_bjrp_id_seq OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bjrp; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bjrp (
    bjrp_id integer DEFAULT nextval('public.bjrp_bjrp_id_seq'::regclass) NOT NULL,
    status integer,
    rest_menfess integer,
    max_menfess integer,
    laporan integer[]
);


ALTER TABLE public.bjrp OWNER TO postgres;

--
-- Name: blacklist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blacklist (
    chat_id character varying(14) NOT NULL,
    reason text,
    name text
);


ALTER TABLE public.blacklist OWNER TO postgres;

--
-- Name: commentfess; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.commentfess (
    comment_id character varying NOT NULL,
    sender character varying,
    jumfess integer
);


ALTER TABLE public.commentfess OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    user_id character varying(14) NOT NULL,
    pesan integer,
    name text,
    status integer,
    menfess integer,
    peringatan integer,
    mediafess integer,
    coin double precision,
    comment integer,
    kado integer,
    lock integer
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: bjrp; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bjrp (bjrp_id, status, rest_menfess, max_menfess, laporan) FROM stdin;
1	1	1716732562	\N	{16606707,16607614}
\.


--
-- Data for Name: blacklist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blacklist (chat_id, reason, name) FROM stdin;
1167004328	bukan lapak sangean bdh	Renss
1197799120	blacklist	blacklist
1226698268	blacklist	blacklist
1285658386	kontol homo	zoroe.
1330073600	blacklist	blacklist
1343129658	salpak	deukie
1378836445	blacklist	blacklist
1396735751	bukan lapak sagne	Antares |• aldiinata
1410720880	spam	tfrfg
1422822447	salah lapak	Ꮶᴮ_Kojo
1453326216	blacklist	blacklist
1487689122	blacklist	blacklist
1507025425	mainan keep	Glen marko
1512293521	keep yg ga penting	hidan
1527112391	blacklist	blacklist
1538585623	blacklist	blacklist
1539738969	blacklist	blacklist
1577894572	fitnah	arsen
1587141968	blacklist	blacklist
1597277050	porn	Nowite
1606779715	blacklist	blacklist
1610435593	blacklist	blacklist
1612556134	blacklist	blacklist
1614373573	nyampah + spam	𖥔 εїз 𖥔
1620192240	blacklist	blacklist
1624846518	spam	joe (?) yes'sir
1640635997		₊˚ ᦒ🌷 : Pavyliaz Eloquence ꒰ ⸝⸝´ ˆ ` ⸝⸝ ꒱ ·.· #ANAKBARUWPL
1642781987	hate and keep gaje	au
1645153499	autis	Liyyy || Pat
1655446297	blacklist	blacklist
1661034759	spam	.
1665083634	miskin	molyyyy
1665880359	blacklist	blacklist
1670559681	keep gapenting	Grey.
1690317332	jualan	f
1699554625	blacklist	blacklist
1700811983	blacklist	blacklist
1704985763	spam	bocaah_sadboy
1707139590	yg spill ig td	-
1707732999	blacklist	blacklist
1708183800	sangean tp gk modal + salpak	Lucifer
1708788049	blacklist	blacklist
1724356296	spam	𝟓𝟏𝟎. Kiana Cyb⁴
1727868917	blacklist	blacklist
1731327252	blacklist	blacklist
1733128178	bukam trmpat promosi, salpak berkali2	rabel
1736994290	fitnah	p
1740730926	blacklist	blacklist
1742164212	blacklist	blacklist
1749627130	blacklist	blacklist
1750644741	pap memek	idk #nicki
1752772844	blacklist	blacklist
1756305624	blacklist	blacklist
1757979910	klon ke 5 jay faker	Libie
1759691287	blacklist	blacklist
1769119534	blacklist	blacklist
1772505989	blacklist	blacklist
1776121198	faker	.
1778808491	blacklist	blacklist
1785846501	blacklist	blacklist
1790443026	blacklist	blacklist
1794626339	autis	Marcell horny
1799585512	blacklist	blacklist
1801131233	keep yg gapenting	k
1802701415	blacklist	blacklist
1803552147	bukan tempat jualan	sit slowresp, tidur.
1809139567	mainan keep	tae
1811642995	keep yg gapenting	?
1827818985	klonenyaaa	-
1832203592	gabisa di warn ya malah berulah lg	patricia
1838236717	blacklist	blacklist
1841709748	blacklist	blacklist
1849895197	blacklist	blacklist
1855762033	pesan kosong	lυtfitα
1858233540		bich wtf
1862747672	blacklist	blacklist
1871139093	blacklist	blacklist
1891239805	blacklist	blacklist
1895562094	blacklist	blacklist
1908910380	spam	pio
1910484222	blacklist	blacklist
1911059680	blacklist	blacklist
1911317730	spam	askara
1922262648	blacklist	blacklist
1922412508	blacklist	blacklist
1923289284	blacklist	blacklist
1925874575	blacklist	blacklist
1925913926	blacklist	blacklist
1927287326	blacklist	blacklist
1931590921	pelecehan	.
1931649914	blacklist	blacklist
1933843599	pelecehan idol, gasopan.	renjana
1947595071	blacklist	blacklist
1954274741	blacklist	blacklist
1955952853	blacklist	blacklist
1961197934	blacklist	blacklist
1966619900	faker klon jay	Matt
1966712533	blacklist	blacklist
1970684906	blacklist	blacklist
1971419246	blacklist	blacklist
1971430044	blacklist	blacklist
1972283929	hmf keep	y
1977300790	blacklist	blacklist
1980584541	another klon ke 4, jay faker	Jrv. Matthew
1980989770	blacklist	blacklist
1983184380	blacklist	blacklist
1986800058	blacklist	blacklist
1987811627	blacklist	blacklist
1988422421	spam	ceel
1988623647	kang pitnah	Rizki.
1998003422	blacklist	blacklist
1998080217	spam	.
1998482041	spam	.
2008590622	blacklist	blacklist
2010530250	salpak mbak	yang clear cht lagi clsi tabok ye ajg
2011161994	blacklist	blacklist
2014881819	faker	Jeanne
2022775342	blacklist	blacklist
2028670603	blacklist	blacklist
2029963785	blacklist	blacklist
2033415734	blacklist	blacklist
2035986241	blacklist	blacklist
2038898279	spam	Keep 5
2039005838	sokab, ngejelekin tp msuk ch	♪
2041643152	blacklist	blacklist
2042268338	blacklist	blacklist
2046766554	spam	lonely
2047042378	faker	louvge mau jadi kucing
2047748313	blacklist	blacklist
2048624847	blacklist	blacklist
2052158162	blacklist	blacklist
2053034938	blacklist	blacklist
2054530235	sokap anjng	farararraaaa O_o
2054686178	blacklist	blacklist
2056037471	blacklist	blacklist
2060567493	blacklist	blacklist
2064073194	blacklist	blacklist
2066027019	blacklist	blacklist
2066811463	blacklist	blacklist
2073931026	blacklist	blacklist
2075880805	blacklist	blacklist
2082738472	salah lapak	jen
2085044377	porn	bokep soft
2086880016	bukan tempat promot grup	.
2091171516	blacklist	blacklist
2101864084	pap tai	p
2102345378	blacklist	blacklist
2109878304	fitnah	Azhar🦖˖ֹ 𖧵` #Jelasberbeda
2110020541	spam	نا نا#s4i #badrailopers #ryanstan #wsamer #kumbotcilstan #kaylaa
2111766122	blacklist	blacklist
2112014911	blacklist	blacklist
2113067369	blacklist	blacklist
2124202964	salah lapak	𝖗𝖆𝖕𝖑𝖎
2126953197	pap tai	p
2133327176	blacklist	blacklist
2137257374	blacklist	blacklist
2137562832	blacklist	blacklist
2138445743	blacklist	blacklist
2139322594	blacklist	blacklist
2142818599	blacklist	blacklist
2143234773	spam	L
2143582310	blacklist	blacklist
5000659596	salpak	.
5003867515	porn pict edit idol	UMI NICKI AND ARIANA
5005645509	rasis	Стана Бундесбанк
5006952311	blacklist	blacklist
5008138152	kebiasaan lu keep gajelas	Not raihans
5010555279	blacklist	blacklist
5016329924	blacklist	blacklist
5017323838	blacklist	blacklist
5017808015	blacklist	blacklist
5018386323	blacklist	blacklist
5021414042	porn	biell
5022822468	penipu dari fwb	naa
5024221501	mainan keeep	rbio) dd acaa || slctv chat
5029499696	blacklist	blacklist
5029685113	blacklist	blacklist
5030981227	porn	.
5034135959	doxxing ig anak mf	.
5034287708	spam	.
5041621853	blacklist	blacklist
5042166798	porn	kia's
5045159106	blacklist	blacklist
5047694458	faker , klon charlotte	🫡🫡
5050661838	spam	felix lee
5050897618	blacklist	blacklist
5055015545	blacklist	blacklist
5059660080	blacklist	blacklist
5060829147	spam	chaaCha
5063432124	blacklist	blacklist
5063546576	blacklist	blacklist
5066641576	blacklist	blacklist
5071804595	blacklist	blacklist
5073652748	blacklist	blacklist
5074256936	porn	pgn jadi bidadari
5079151405	blacklist	blacklist
5081735821	blacklist	blacklist
5083986455	blacklist	blacklist
5084018731	blacklist	blacklist
5089581191	another klon ke 3, jay faker	ray
5090448222	spam, ganggu	J
5090841551	blacklist	blacklist
5093034453	blacklist	blacklist
5095283173	autis	Nadiaa
5095983439	blacklist	blacklist
5097105186	blacklist	blacklist
5099304835	blacklist	blacklist
5100536182	blacklist	blacklist
5102557539	salpak	Awlsome
5103735886	blacklist	blacklist
5107255057	posting berbau sex di bulan suci	Bastian
5115755332	blacklist	blacklist
5119556450	blacklist	blacklist
5120165741	blacklist	blacklist
5120360430	klon faker liu	iloo
5122767643	send porn	pw
5128151089	blacklist	blacklist
5128387101	\N	\N
5129762331	spam	Caddie
5137285507	blacklist	blacklist
5142909884	blacklist	blacklist
5143668329	another klon jay , faker	fay
5143767935	faker pake video orang buat beli coin	Grazielo Loving Maki
5150752233	blacklist	blacklist
5153405178	faker clone charlotte	ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ
5153621540	salpak	c
5154549077	blacklist	blacklist
5154805366	pap memek	ngok
5157609345	blacklist	blacklist
5158149709	spam + salpak	𝐒𝐜ᶻ𖠧 • ᴄʟᴇɪʀᴀ
5158349648	doxing hmf	ilo
5159190394	salpak berkali2	Dad
5164343630	faker	𖥻 𓂅 𝗻𐐼𝗱𝕚ⴄᧉ 𝆺𝅥 ૮꒰ ᴗ.ᴗ ꒱აㅤ
5166662253	blacklist	blacklist
5168393530	nyampah	Grich close. Literasi!!!
5170011562	sinting	gea
5172517577	gjls nim mf lain	key
5176485364	spam	.
5177093613	faker	Liu ,
5178002745	blacklist	blacklist
5180301954	jualan	raaa
5180337033	blacklist	blacklist
5190264209	klon liu faker	kemple
5196320723	spam on purpose	Nathan
5203216829	spam	Jerich
5203891031	blacklist	blacklist
5206090035	blacklist	blacklist
5209659528	mainan keep	ron
5211064005	blacklist	blacklist
5216945869	doxing	kepo
5218400020	asal keep	a
5219828753	autis	Z
5223383456	blacklist	blacklist
5223698803	sapm	✩★ +62 𝓕resh
5227585882	blacklist	blacklist
5228887664	keep gje	r
5229559018	spam	(35) +62 JERICHO
5230807841	blacklist	blacklist
5236689933	salpak	Bagas
5237957147	blacklist	blacklist
5238152721	hmf	haha
5238191087	spam	Julian
5248825994	autis	Syd
5254763881	blacklist	blacklist
5256848322	doxing	memek
5257273244	hate pake klon	,
5258646681	doxing	ilo
5262837890	nyampah + spam	dixa, fsr dong.
5271744539	blacklist	blacklist
5272979615	blacklist	blacklist
5273970906	fitnah	adrian
5275306380	tll	Feli
5276944028	ngekeep ga jelas	Sharlina
5277357603	klon charlotte faker	aChar
5277408422	blacklist	blacklist
5277496557	spam	이차 – leya
5278978634	porn	Azka 🍷⛓️
5283538943	blacklist	blacklist
5287062594	send porn	.
5289698261	spam	marvel
5290778453	simting	,,,,,,,,
5291081624	blacklist	blacklist
5292061233	hate with klon	ngen
5306114654	nyampah + spam	Ay
5306338936	mainan keep	.
5310902694	porn	apa
5314902619	mainan keep	𝓕lora 𝓓elapaz 🧚🏻‍♀️
5338050333	spam	dni
5362043568	spam	lipa~!
5375695469	spam + salpak	Zio
660712245	nyampah	alen
965283688	blacklist	blacklist
5358960855	nyampah	ben
1855106904	salah lapak + nyebar id org	Keysilaa
5102638297	nyampah	ngab joice
5197475141	porn	ㅤ·‌ ₊ ᨦ 𔘓 ᨩ ₊ Merrybelle · 👼🏻💌
5331074111	mainan keep	z
1677791253	mainan keep	.
1753875769	salpak trus	dean #$atrnuz🇦🇱
5327231476	nyampah	dina
5060536954	salpak	anyaci *ੈ
5493536464	fitnah	Velocity
5370171830	salpak	⊹ ᨘ໑▸ 𖥻 𝓌𝒾𝓁𝓁𝓎 ˑ 𖦹
5065421278		Guts
1738806064	spam	rembulan
1554160592	spam	nana!?
1865656015	mainan keep	pecinta wendy rv bukan wendy cagur
5395451062	spam	skipper.
5025058180	salpak + sangean	hoks
1861122400	mainin keep	kvn
5327654134	mainan keep	kevin
5476929637	send porn	anas
1639738214	faker	DNI! Gabby.
1485195963	mainan keep	a
5306150934	mainan keep	nyenye
5393576654	mainan keep	venos
5423233788	spam	marvel
5371373697	mainan keep	.
5477656517	orang gila	Yin
5347478866	sangean + salpak terus	yor pusing
5359124329	suka keep ahay pale pale	.
5228519042	spam	cherlyy
5206863290	memek	a
5507323286	spam	stev
5150114852	saraa	cikka
1755348733	salpak + spam	noor.
5525392261	spam	Heol
1840466230	sangean	-
1753603213	nimbun mf lain	reog adalah maung
1834529737	spam	Nanda
5385641139	salpak + spam	Z
5150683983	telah mencapai batas surat peringatan	cantika
5146354880	spam + salpak	J0K| Tugas
5303003991	fake pm orang	.
1836270903	spam	Nonton
5353078972	spam	Hasan
5184357434	telah mencapai batas surat peringatan	Karan
5320270554		namika llyria⅌
2007706806	spam	qn
2049708433	spam ngl	rahasia
2073442752	salpak + spam	heysal
1889292146	spam	Karinaa
5238683920	telah mencapai batas surat peringatan	Virans
2075020907	spam	Kevin
5489010378	spam mulu	andri123
5546799995	spam	dimasanjaymabar
1838392950	nimbun mf lain	Kiaaa
1659738704	faker	Piccy.
5248058485	faker	Celline
5161699274	telah mencapai batas surat peringatan	Lowis
1961374205		AREL
5129608761	nimbun mf	bitabibi
1694342999	spam	lian
1923051779	telah mencapai batas surat peringatan	Leo kv
1614558862	nyebar id org + fake pm	ㅤㅤㅤㅤㅤㅤㅤ
5298059785	fitnah	Harvel.
5033785780	fitnah	mouna s/ia
5374034320	fitnah	Gerald
5098587033	fitnah	KaLann🅰️
5153423222	fitnah	Kaze
1886785036	fitnah	werf
2123972286	fitnah	Vai
1929693430	fitnah	Selena, kinda inactive.
5202110187	fitnah	Kazumi.
5033934480	klon broja, yng fitnah	en
5571867660	klon	Kaze
5300808003	klon	Xieci
2127496247	klon	Chunaa
1900414071	spam	S
5006671551	klon	aaron
5561417622	spam	.
5510999082	salah lapak	Ayang4You
5279993733	spam	Acc lpm
5187141819	spam	morisawa
1989735968	spam	Rèyy
953439718	spam	Raldy Louis
1667304187	pedofil	Homan
2093175602	t	tika
1873617710		Løren sdg glw.
1678154603	pengecut. chat dainty kalo mau unban	kntl
5000323516	fake pm	danielle’s 🌷
5574652168	spreading hate + porn	John
5470712737	t	Kaze
5308384744	faker	Mevyn
1430176213	spam	alvin
1800832134	spam	azril²²
5654525150	spam + salah lapak	ibam
1711915428	penipu	Mint
1608896945	spam	zzz
5643506207	fake pm	test
1875407557	nyampah + salah lapak	Raf
5033917212	send porn	keith salimaw¡kky
5454859952	pitnah	Miura.
5691552057	keep gpntg mlu	lupi isn't mood
5680650042	porn, sorry bru buka tele	ㅤㅤㅤㅤㅤㅤㅤㅤ
5313799923	brisik lo	Reza
991868918	spam	Glng
5482897441	keep gjls	˖ ࣪ za
5552720131	salah lapak + bukan tempat pm	hazz
5658741576	jualan	sc akun
5328009969	jualan	Pill
5506561298	jualan	:>
5583950585	jualan	Love
5597122651	promosi	hablq
5769050395	promosi	.
1155513628	jualan	bayuputraa
1089360667	langgar rules	ℝ𝕖𝕪𝕟𝕒𝕝𝕕𝕚
1428141043	keep gapenting + hate mf	nay
5078293951	hate mf	r
5534619349	hate mf	Dab
5060265295	clone	Yulianti
1693337460	meresahkan member	Ilyas Sadewi.
5632756043	nyampah	liyyo
5499342711	jualan	bayuu
1829838316	keep gapenting + salah lapak	sherinesya bisex
2035443846	spam + nimbun mf	nokos 2
1784120830	spam + nyampah	rest
1745699039	spam + nyampah	nokos 6
1755509530	spam + nyampah	nokos 3
2017489946	spam sm nympah	nokos 5
1795665853	nyampah + spam	nokos 1
1683116725	spam	sandra
5738973770	ganggu + hmf	tiara
5973378251	jualan	𝖎𝖙'𝖘 𝖒𝖊
5698070592	jualan	IrfannnX
5422058692	jualan	Trex
1907255676	jualan	ɪʏᴀɴ ᴀᴡ🇦🇷
5630481939	jualan	BluSky
5720884267	hmf	.
5721609591	send link gjls	cila
5382174545	salpak + spam	Ilham
1598888346	jualan	Gue Tau Cari Yang Setia Itu Susah
2018805447	nimbun mf	지수. 💟 🩹
2095046875	promosi jualan	cassieee open fsr
5786318218	salpak + promosi	90$
1706909438	salpak	Zam
5508003727	salpak	𓊖 ꝛᴇxx x ᴢʏᴄʜᴏ'ᴍɢᴍ
5975240459	meresahkan member + hmd	j
5919155474	keep gapenting	Haloo
5730084658	jualan	196 jack
1155613712	cabul	gar
5337394275	jualan	Meeca.
5869634798	jualan	ᴘʀɪɴᴄᴇ ɴᴀᴛʜ ʏᴏᴜʀe̷xᴛᴢ
1763553153	nyampah	s
5891230122	promosi + salah lapak	aysa
5382019939	spam	Lazif
5409389560	jualan	key
1818658463	jualan	matchaicy
1061041760	promosi + salpak	Bumi
5401976032	send pict porno	-
5528813386	keep g penting	ماريبل 𝗠𝗔𝗥𝗬𝗕𝗘𝗟
5500069747	jualan	Nafis
5639463209	hmf	no name
5242140336	promosi	meimei
1994085487	main keep	dni.
5856311637	jualan	Chaerubin! ♡
1830008062	nimbun mf	zzz
1988696967	nimbun mf	Asep
5710693608	jualan	es bunga
1932827971	t	?
1909127861	jualan	luiza
5651153295	jualan	aninditā
5486612727	main keep	.
5837716444	nyampah	Rennn
5137466256	jualan	exotice.
1707440938	prosmosi	enzie
5041176450	promosi	arga bth duit
5197037116	hmf	kay
5170252843	pm	zoe raya
5883263969	fitnah	Meyaa
1731048096	fitnah	SANOOO sayoursop
1904110405	fitnah	Steam
5583387181	hmf	abid
1027809695	keep gjls	K.
5932792900	promosi	Sam
1880644381	rasis	axl
5913299354	keep gpenting	.
5546161250	langgar rules	broo?
5036665844	salpak	yor still sma
5989323266	spam	ᴠɪʀx
1661392502	hmf	Adam Iskandar
5549686967	promosi	Mad
5219607445	send porn	.
5874148863	nuduh gjls	s
6007861545	\N	\N
5973284627	bullying, sorry tp banyak yg keganggu sm dia jd di ban aja ya drpd klian ga nyaman, jg kasian org yg kena bully 🫶	ysy
5019128481	mf lo mancing ribut	.
1619975502	salty mulu sm yg cakep	482. ecaa stp
5270282150	stop salty sm yg cakep	ki
6068467334	brisik n	kal
2051561982	fmf	keshi
5825911095	klon	\N
5804453744	jangan batu, jgn mainin mengkaget.	Alan
6037940151	batu, jgn mainin mgkaget	Hadi
6109143902	batu mainin mengkaget	Temen hadi
6127235827	ngundang ribut	vanka
1806727012	pelecehan idol, hmf, ngundang ribut.. klo ad masalah pribadi di chat aj gsh hmf	Dea ayu
1691558801	fitnah	ywdah
1325007415	bahas & kirim mf 18+	Portgas
2145011912	send porn	rheina
5001255561	salpak	Javier Maximillano
5630673877	keep g jls, cape gue warn ny	yasim ctdrg
5638009502	fitnah	jeord
6002448817	pitnah	g
6107569898	pekel	kanayy
6139903754	kemauan ndiri	.
5822191470	salpak, berkali’ di blgn masih badung	dafka
6197369121	salpak	Ay
5867780990	porn	abian
1214547905	telah mencapai batas surat peringatan	adi
6070714827		404
1450668079	mmk	Jevangga. R
1662407894	p	.
5648772224	salah lapak	yuppy
5891486302	caper, gasopan ngehina ibu	Prpw rael
5972077630	caper	Aming
5630648081	klonnya	fuckih
1522462888	open gtuan di fwb ja	FEBB
6046298261		azki
5056330788	salpak, gd bokep’	ay ayy kapten
5658414488	gd bokep’	pitik
6017004347	gue diemin bkn buat ngelunjak	flow
1840605716		girl
5856272833	astaghfirullah	agustina
6209345860	porn	kimaw mode normal
2005133413	tod	jasasuntiksosmed.id
5902776138		vie
1050376182	tkg hmf	e
6195999866	ft	d
5898770860	spam	spencer 2
5729866642	hmf	248. ailine
5875635289	hmf	.
5882558441		let me know if you need anything
2130382411	fitnah	kilalaa
5262514022	ftnah	.
1744356365	fitnah	holeshit
5741703714	no body shaming di blg	…
6081659161	fitnah	𝗻𝗼𝗸𝗼𝘀
5752442914	klon	R
2052260539	fitnah	Athena
6037172781	fitnah	youtha
5747233389	fitnah	asahi
1836681323	fitnah	๑ piyaaa
5315284152	prof	j
1472350353	t	anne
5719736769	nyebar muka orang tanpa izin	isakk
5826877942	hmf	jawir
813122746	sara	d
5845055207	t	bi
5733612547	mainin mengkaget + ngaku ngaku fafai	fafai kedua
5720002560	udah salpak sangean tolol lagi	achi
5680174023		syasya
5901433524	t	Rahmat
6261111827		memek
5862590024	orang gila sangean	cinta
1205282606	telah mencapai batas surat peringatan	G
2106901206	telah mencapai batas surat peringatan	ᴀʀᴛʜᴜʀ
1951788255	palpak	J
5521946682	porn	Rahmatt
6057785456	t	f
6264475746	t	vonso alnashrul
5870242244	t	desni
5075224564	t	xanzur
6026768213	\N	\N
5848113621	\N	\N
5537066596	t	syahrul
1666489265	t	nadd
2062331122	maling foto	arga
1974534964	p	off telegram
5934528148	\N	\N
5806404541	kurang waras	.
6119678076	\N	\N
5483209647		Antoine Griezmann
5935351236	\N	\N
5063626292	t	Gia’s feeling unmood
6213272086	t	jaka udin usep
5721150424	telah mencapai batas surat peringatan	Bapak
2111833460	telah mencapai batas surat peringatan	Garcia
5556594497	sedat sedot, ubun ubunmu ku sedot	Darel alvarez
1662747256	telah mencapai batas surat peringatan	by
1801663539	biar ga perlu repot liat ch alay yg bau m*ki	⸙ꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋsukijem
5423083144	telah mencapai batas surat peringatan	Masapapppp
6282737158	t	nunung
5810937545	rese	Renjuxn
5297802637	au	ur
6212943777	\N	\N
6177367019	\N	\N
6104019295	\N	\N
5718770957	telah mencapai batas surat peringatan	Morinn
5861416270	caper	Y
5951891266	telah mencapai batas surat peringatan	iqbals
5822899358	telah mencapai batas surat peringatan	Elvaro
6113263882	\N	\N
5788602624	telah mencapai batas surat peringatan	.
6069265459	gje	Sherazade
5794754744	hmf	ji
2129081719	ppk	Wint, sell @ banting harga
6072485877	dari tadi kayanya caper banget, ada masalah apasih dek?	c
5928134226	hmf	.
5921480192	bkp	miwa love dilfs
6261086075	miskin.	chelsea
5893781865	caper.	no name
5890887189	bkp	tracyy
6273362833	\N	\N
5608788364	salpak anjir stres	Luis
5457213858	sagapung.	Johan
5808761146		.
5255170591	ngok	Nadia
5999517394	pitnah	Noktel
6144212666		ㅤ`envy?
2037209770	pitnah	lauren
5919080352	orang goblok	lani
5953549967	hmf	lol
6187065288	\N	\N
6041865901	t	v
5977551939	t	zura
5891858470	t	anak hendra
5307550789	salpak ah, fwb aja	Azmi
2087443755	t	jess
6005740492	elu babi	robert
5859736627	telah mencapai batas surat peringatan	reja
5990695545	t	vivi
5891707326	telah mencapai batas surat peringatan	celo @celoceloan :3
1199366289	rese	Mega
1847769775	\N	\N
6109353026	salpak, aneh, ewwww	Fakturo
5236410951	porn	lau
5950951959	u pikir aja sendiri alasan i ban u.	renata
5758819635	keep promosi gapenting.	`el falera
5331735562	t	hunter slctv, dni
5732485124	faker	adisha
6218714320		Af
6046888140	p	fy
6167747749	ni aku ban	eleonora.
6085454791	caper	脸红.
5843241237	tolol	per
6046652256	fmf	male
6084319330	p	demie
5961296009	t	pierre
5290020425	pitnah	505
5594358026	p	flo
6070715403	telah mencapai batas surat peringatan	kevin
5671161484	sagapung.	tika
1777198721	p	a for anj
5808741108	hmf	nanang
6139124752	p	kenzo
6123177431		tr
5973572675	t	Ina
5859602188	porno	Hanafi
6178609370		.
5515346928	salpak abiezzzzz	blue lesbi
5211618850	telah mencapai batas surat peringatan	yoya 𖹭
1864850107	salpak	ｷﾌ' Limmp ‘funk
5466329235	salpak.	choco ft latos
6091131670	lonte.	Renita
6198777027	\N	\N
5775065465	salpak	Akbar
6220640947		Lala
6139986753	lonte.	jL
5142983574	salpak dek.	risbella
5879276366	salpak.	Nayla
6191529177	uda diban dari fwb malah kesini, salpak.	Yuna
5956367600	p	ah ah ah
6124219557	apasi stres	ᴄʟᴀʀᴀ
1291969802		.
5849859709	stress	harif
5929544869		jesb
6131813870	stres.	.
5918284561	salpak.	barack
1713252496	wkwk ku ban aja	Rey
6027776385	\N	\N
6275714098	\N	\N
6213400827	penipu	nda
1230902729		Hang
6251753578	salpak	el
6248260826	pitnah	Bulan
6058363920	\N	\N
1609918901	sagapung.	Arda
6137622816	orgil.	uwuw
5748568831	fack lah, uda basi bro gausa lo bahas terusss	.
6104383516	sipaling hating everyone 🤭🤭🤭	freyya
5813576920	semangat beli nokos yaa buat ngehate 🤭	ㅤ
6089162212	ajarin pansos juga 🥺🥺🥺	Lyhz
1469730120	orgil.	E&
5848150442	p	\N
6194262887	p	Rahmat
5878926952	p	.
5660955507	p	aikana
1720875578	p	nella fox
6095591396	p	prince
6251445518	p	rub
5972073862		kanku
6255156813		sheees
6299252332	porn.	أمير
6100517702	berisik udah berapa kali mf gajelas kek gini.	dimas
6093624852	udah di warn masih aja.	law.
5110738393	ketikannya jelek doain orang yang ga baik.	Erza
5395728419	porn	bro ron
6171321355	s.	drickk.bøcriz
6225863266	colmka colmek colmak colmek lu.	stev
1859207651	ini juga satu.	??
1971432994	salah kalo lu bikin mf disini.	?
6103139707	lu kontol.	Fuck Mooi
5852904317	bct.	Fuck Mooi
6259605198	video siapa lu ambil kontol.	dede
6011133335	sagapung.	Hanapiah Paturohman
6215883390	caper	Ok
5862657253	caper.	Fuck Mooi
6085756673	caper.	Fuck Mooi
5567757665	ribut.	kazira
6275691860	spam.	reiya
6140843571	soam.	Mppi Jeleg :p
1325919431	porn.	it's
1860003871	minta pap tt sama mak lu aja.	cibe srz
2064637508	salpak.	Shafir
6179624283	ga senonoh.	jeno's pretty kitten, karin #OPMEMVK
6147560198	hobi kok ngentot.	sedih
6157172629	muka lo kek kodok.	35.
6080143670	pernahnya colmek sambil makan nasi padang.	🦋
5268431109	t.	Raraw
1840314824	kalo masih smp tu belajar buat dapet sma impian, malah minta difantasiin hadeh.	Ra
6052762379	orgil.	j
5818470619	porn	pasyaa
5909514813	pn	.
6602035798		h
6554907176	telah mencapai batas surat peringatan	move acc
6099939363	“jangan join nanti sange” ga ada yang mau join juga ajg	naya
1625245378	fpm	yaaa
5834132169	apasih?	...
5974000728	porno	bila
6394010961	nyari ribut & hmf	Omen
5702538554	telah mencapai batas surat peringatan	Billy
5467286730	pelecehan & penistaan agama	mtfckrrrrr
6286421777	byebyec nyari ribut mulu	nbila
6040376702	telah mencapai batas surat peringatan	Ferri
6365766440	telah mencapai batas surat peringatan	miakha
5673632588	telah mencapai batas surat peringatan	Vina
5636202380	hmf	kiben ni mang sape
5936541712	telah mencapai batas surat peringatan	𝐿𝓎𝓃𝓍
1335777167	ngeri, serem	Lukas
1349087201	ngejokes tapi bawa bawa agama	nikzon
5174283548	ini juga bawa bawa agama	Chani
1653222509	ngejokes bawa bawa agama juga ini, lupa gua ban	ndaaa
1331129460	telah mencapai batas surat peringatan	Synchro
5968896527	jorok, salpak	linggoy
2005367107	pendukung porn revenge	cca
6204798256	hmf	momoi
6412314193	telah mencapai batas surat peringatan	azfa
5750447894	pn	cey
5820789849	porno	who i'm
6091582190	bct bgt asli ca	aca
6063776596		🚫
6344124487	berlebihan, mancing war	diioo
1774630900		Grace Cana
6538436296	salpak.	.
6574819814	kan baru gajian, pinjam dulu sratus bang	kino
5522226618		Rafa Silva
5599836557	telah mencapai batas surat peringatan	kapi
6574463895	caper	Sean
6430184032	pnp	cilaa
5823686475	salpak.	Hublottt
5844025483		pugh
1283424669		Fnny
5403945190	salpak.	Abrhm
1322710050	salpak.	adi
6037003659	salpak.	🦕
5717484444		kami
5556272286	salpak.	Kean
6148389867	salpak.	Kyky
6270681460	fake pm.	Ràymond داريلو, lustify
6279657675		Needassiss
6306080994	salpak.	leunorA
1182918684		Kiji
6940831663		joel.
5906661464		Prayyy
6964849317		heter Biya para
5802876075		ëran
5407349353		ur future daddy
5165577565	fpm.	.
2035085106		Kasep
6020287330		Xixixi
5582283223		Sjsjagwwjsj
6080828573		Javas
6257107880	salpak, miskin.	Kobo Kanaeru
6367149576		eaa
6463949027		omaga
5360022880		.
6828200852		BS
5934423824		Arvi
2126868124		res
5328865846		rinaaaww
1859217170		A
1963114454		aksa
6717598019		⊛ ᴏsᴄᴀʀ 1ꜱᴛ
6044113924		luna
6857868152		.
5768661825	fmf.	y
6446981227	salpak.	kepolo
6923024413		nicaa
6405105126	jgn dibuka nanti nyesell :))	Malesub
6786288624		pablo
818582478		oka
6761217365		Vin
1234492890		Miami heat
6044803487	salpak.	mystery
6493530365		Yuni
1314125887		Kanon
2147118384	your ddk 😭😭🤣	Kean¹²³
5835748224		S
6341153595		nev
1309521254		.Toniii
6298011101		jokep
6632400735		Dede wahyudin
6875034054		😍😍😍
6549391343	tolol	Clorim
6169794566		citra open vcs
1829075641		Lala
6226843471		.
6135055520		kylie ellish
6922721898		al
6309969240		Yunaa
6348723353		f, tasia.
6612421419		AxL
6430367633		NamiWP
6826254359		gemoy
5490485977		tyty
6779142748	salpak.	ᴄ ᴀ ᴄ ᴀ
6711900818		ceksjakaka
6700358616		⁪❁ཻུ۪۪ 𝓝adhira
5946303444	fmf.	Jiel
1117636337		y
6800103995	spam.	Cleo
6676947722	salpak.	ㅤz 🇵🇸
5554530878	PAKEIN TW KONTOL, KGET GUE BGST EE	d
6156455381	salpak.	Jean
6076865190	salpak.	.
2141679075	salpak.	lala
6027402639		narra
6529556467		Hajk
5697310299		Cowok Anime
1484646313		K
1832080814	salpak.	Gnial
6802143125		Jovic
6547252240		niaraa
5288438336		wendd
6587393096	hmf.	ew
6986775169		Leoooo
6706629514	salpak.	Deborah floptoqika
5122824911	p	ayos
6936489129	p	fy
6884991311		Hymn
6562050969		Anon
6814110354		.
6647245989		📎cya🦢🌷
5427621560		jexy
5074627528		cc
1257339080		vian
6195906519	penipu kon fayos	mary
6809440124		àzlyn R.
1855966790	salpak.	cowo
6964601986	pitnah	haje
6279622416	ptnh	manda🍉
6065189024	fayos penipu	kelly
5991381088	fitnah	Apip
6495409392	stop tolol :)	hy
6428036973		Nak
6820861992	fayos penipu	kontol lu
6920959024	pitnah mutar balik pakta	abip rarely active
6439432151	pitnah	eo
1790978944		TOKO PDI
6806875756	klon fayos pnp	41
6809014601		Pro Anies
6179734114	salpak.	Yohana
6617340484	salpak.	nanda
6656503131		Ella
6795941677		pq
6720257149		Wandaguritno
6338991205		Narcy.
6520879671		Din
6675820988		𝗝𝗲𝘆𝗮𝗮
1189907236		Skyzo
2061504936		Veee
6318589881		gie
6745006316	promosi.	Storrrre
6653892358		wans
6484624238		a
6943601768		Mina
6704615082		Caca Th
5429883505		Heiho
6598043308	salpak.	cia 1
6486095753		hazelnut
6544075282		pairi
6055982706		y
5424147363		arradeena itu kezia
5399456617		Laa
6400810862		a
6950966600		みdanu.
6886399483	salpak wibu.	Aku
6431919522		© Jordi Part 3
6538222577		mang boleh
2023850505		ceceww
6893564672		miya sinta
6795954884		Rai
6710193822		Xcat
6018514830		adit
5918564260	fmf.	🗿
6604414996	spam.	asist marvin
6103897017		Alaska
1104365971	salpak.	Megananda
6947666872	caper.	.
5222208138		rara neverlus"
5401076187		Rabu
6747760707	bacot bgt bgst, anis anis tai.	al
5350688529		Melisa
1342796412		ren
6303225678		Oke
7084189480		Gatau
5982835981		Tim SAR Barelang
6284771197		Diska vera angel valeria
6314503186		daniel
7085952036		Abid
6462334710	salpak	islllllll
7082949168		gita
6319344795	telah mencapai batas surat peringatan	adam
6998327084		org
6910341332		TESTI K1BO ban.
6427362654		lix
7007413990		eng
5123626661		Jenny
7155055858		biyee
5991490653		res
6988680655		una
7136001399		Hana
6935416956	:v	.
2119150025	telah mencapai batas surat peringatan	Ikoo
6146931894	m	za
\.


--
-- Data for Name: commentfess; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.commentfess (comment_id, sender, jumfess) FROM stdin;
3300236	7187850754	11
3300161	5015023402	8
3300165	5814984521	0
3300170	6326771700	9
3300164	1697550383	3
3300163	5900146741	3
3300214	1379981741	4
3300229	5184158238	0
3300162	6326771700	16
3300167	5015023402	1
3300186	2077475265	8
3300192	6927562933	9
3300168	5814984521	1
3300228	1541339875	14
3300193	6225714014	2
3300251	6990788996	3
3300169	1379981741	2
3300172	6329308807	0
3300166	7136396929	5
3300194	5559431948	2
3300171	2144516591	4
3300261	5429361550	7
3300203	6514163213	10
3300181	1229423790	7
3300222	6209270823	7
3300160	6979324573	17
3300175	6307030217	0
3300226	6979324573	12
3300174	5718222957	5
3300184	1825482156	2
3300173	1994165099	2
3300179	7015982512	4
3300182	6795639833	7
3300159	1697550383	23
3300183	6218814124	6
3300176	7015982512	5
3300177	1994165099	2
3300196	6884541431	3
3300178	6307030217	3
3300202	5559431948	9
3300191	1860834442	7
3300180	6218814124	5
3300205	1860834442	0
3300201	1379981741	4
3300200	5757651090	26
3300197	1821866724	7
3300185	1959707856	7
3300232	6979324573	0
3300187	6218814124	8
3300198	6514163213	2
3300256	5868424145	0
3300231	1229423790	2
3300190	1959707856	2
3300195	2077475265	7
3300189	1379981741	4
3300277	6413904608	2
3300252	1899315038	2
3300207	7015982512	3
3300219	2005500110	4
3300218	7187850754	10
3300188	5727456358	6
3300208	5757651090	1
3300221	5551694052	8
3300204	6882118243	9
3300223	5184158238	1
3300206	6607636523	5
3300224	5419478686	1
3300209	7067753637	12
3300199	7158485795	2
3300268	5868424145	12
3300263	5015023402	13
3300271	6979324573	4
3300253	1413148206	2
3300212	6905329130	3
3300213	6849238753	1
3300210	6905329130	3
3300211	6979324573	6
3300215	5429361550	0
3300255	6979324573	4
3300238	6133172854	9
3300245	6512121176	1
3300230	6405060045	11
3300257	6990788996	21
3300216	6905329130	6
3300233	6958721429	2
3300274	6979324573	0
3300225	5559431948	5
3300240	6514163213	12
3300234	5496536024	8
3300243	2077475265	9
3300217	5110207266	1
3300220	5294363026	4
3300267	6882118243	16
3300258	6830695558	12
3300248	6401345983	2
3300235	6836373564	8
3300239	6836373564	5
3300270	6837173693	8
3300254	6647493163	5
3300227	5429361550	13
3300250	6830695558	3
3300272	1393114901	15
3300303	5133291716	1
3300246	6133172854	1
3300278	5039448973	10
3300260	1413148206	5
3300276	1899315038	6
3300242	6264936436	14
3300241	6658805581	5
3300244	6401345983	11
3300262	1962785365	16
3300237	6405060045	13
3300249	6401345983	3
3300259	1899315038	3
3300264	6413701056	19
3300247	5868424145	9
3300281	6123470027	1
3300265	6979324573	3
3300269	2077475265	2
3300275	6413701056	2
3300266	1962785365	15
3300282	1899315038	1
3300280	1230036097	8
3300273	6307030217	7
3300279	6123470027	1
3300283	1899315038	8
3300287	6647493163	0
3300286	5419478686	3
3300285	1379981741	0
3300284	5974529023	3
3300289	2063567111	0
3300288	1230036097	1
3300292	6647493163	10
3300291	1541339875	2
3300290	7197779940	13
3300293	5060545800	2
3300294	2081115433	0
3300295	6812589503	0
3300296	6744464052	0
3300298	5276828440	0
3300299	5276828440	0
3300297	1962785365	2
3300300	6088154499	0
3300302	6891340291	4
3300301	6163880471	1
3300304	7154788561	8
3300305	1454976663	3
3300306	6364382298	2
3300332	6000284750	3
3300309	1216745642	3
3300312	6421293016	3
3300333	1842536812	2
3300402	1859355481	9
3300335	6856385038	0
3300529	6836802559	10
3300474	6527846273	2
3300519	1574728745	2
3300440	6048299347	4
3300401	1821159048	4
3300407	7023278879	4
3300442	6163252687	1
3300337	5277054597	8
3300338	1639703411	0
3300334	5523602507	4
3300340	2143593377	1
3300341	5972445915	0
3300443	5833813454	0
3300343	6383176685	2
3300345	6783584965	0
3300346	2007430061	0
3300350	6532138633	0
3300348	6790237095	4
3300351	6216804159	1
3300353	6475998429	0
3300354	1440200580	0
3300357	5850408081	0
3300445	6004368939	3
3300355	6990788996	2
3300361	1274521818	1
3300359	1783301265	1
3300365	6691452267	0
3300364	5004749393	1
3300369	1593813362	0
3300447	6326735208	0
3300373	5554354843	2
3300376	1871389993	2
3300380	5968917080	0
3300377	1848234232	2
3300405	5247394967	12
3300378	1710795460	2
3300408	6516319986	2
3300381	6770100211	2
3300383	5281830050	1
3300385	6828670670	1
3300389	5261709374	0
3300414	5835005695	0
3300390	6779433805	0
3300392	6865122773	0
3300388	1954666311	3
3300393	5835005695	0
3300395	6156787840	0
3300397	5777393063	1
3300448	2132392149	1
3300413	5799144442	2
3300415	1719272209	0
3300527	6776602873	3
3300418	6397932649	0
3300494	6235767893	1
3300422	6163880471	1
3300424	6163880471	2
3300425	7100212809	0
3300450	5936524505	1
3300524	2118728362	0
3300495	1714664561	0
3300454	1259833960	2
3300431	5460983436	9
3300428	5268911619	4
3300449	7061090276	4
3300541	6995799602	2
3300458	1905191549	0
3300497	6073895034	2
3300366	1603604334	1
3300457	5983756548	6
3300482	6200970216	0
3300499	1825402966	0
3300453	5739311643	4
3300417	1719272209	2
3300420	6877257508	2
3300460	5440123013	3
3300433	5849150092	10
3300434	5642402408	2
3300430	7036334865	4
3300461	1458914781	1
3300465	1285761179	0
3300456	1077516849	1
3300439	6522971663	4
3300498	5574857720	2
3300466	6071041299	3
3300544	6395349440	0
3300479	6435792806	2
3300476	6795639833	5
3300501	7061090276	1
3300504	1503572072	0
3300467	6520401993	8
3300477	1811478345	8
3300463	6461052340	2
3300483	6764503334	3
3300481	5893491762	8
3300468	5072403847	6
3300473	6476236332	0
3300470	6326735208	1
3300500	6073895034	3
3300487	5958348690	2
3300531	1441585887	4
3300505	7092719155	2
3300489	6473491893	4
3300490	5301695292	3
3300507	5516494289	1
3300550	7121759766	6
3300492	6086589687	11
3300526	6086589687	2
3300509	1898587495	2
3300511	6200970216	0
3300502	5366715578	2
3300517	7154422718	1
3300522	2005558201	6
3300557	6508240802	2
3300535	7154422718	2
3300546	6159343088	3
3300547	1809765081	1
3300537	1930961868	3
3300539	6332612061	1
3300552	5554354843	3
3300554	6660282397	0
3300553	6159343088	1
3300559	6073895034	3
3300561	7067609895	8
3300564	6795639833	0
3300336	6856385038	1
3300329	6475998429	5
3300308	7154788561	3
3300307	5218544262	3
3300339	1725750342	1
3300344	5263938539	1
3300342	6568584169	1
3300347	6822955743	0
3300349	7002898421	0
3300311	1919362935	4
3300530	6461150516	3
3300314	5712137598	0
3300313	6364382298	7
3300310	5319569203	3
3300435	5739311643	1
3300316	5712137598	4
3300315	6830695558	2
3300488	5222002367	3
3300317	6595140411	3
3300356	7130865620	0
3300441	7061090276	4
3300358	5835005695	2
3300318	1358567167	6
3300362	6795850851	0
3300360	5406797046	1
3300319	5277054597	4
3300367	1603604334	0
3300363	7113973933	1
3300368	5048954985	1
3300403	1821159048	5
3300322	6994245738	2
3300321	5277054597	1
3300409	1317277470	1
3300325	5419478686	0
3300320	6849238753	8
3300323	6329308807	1
3300370	2094083310	2
3300372	2013640332	1
3300371	6780258211	4
3300324	7197779940	3
3300374	1769994103	0
3300375	2016742471	1
3300410	1980144232	0
3300406	6156787840	4
3300382	5216792019	2
3300384	6326735208	2
3300379	1549476686	1
3300328	6397932649	3
3300326	7197779940	6
3300411	6992693116	0
3300387	1710922839	0
3300330	1787426076	0
3300404	1486953683	4
3300412	6849238753	1
3300327	6754281017	11
3300386	5962529220	4
3300331	1639703411	2
3300391	6779433805	0
3300485	1657732157	3
3300398	6992693116	1
3300444	6048299347	2
3300396	5999787938	4
3300491	1942126993	1
3300416	6806976992	5
3300419	1704915562	0
3300400	5261709374	1
3300394	6779433805	1
3300399	6303016060	5
3300446	6234546912	2
3300421	7184421688	2
3300427	6828670670	0
3300493	6397932649	0
3300451	1907724245	2
3300423	6702206460	4
3300452	6163252687	2
3300455	6853374490	1
3300432	2043118987	5
3300426	2027549261	1
3300459	5554354843	0
3300464	5983756548	0
3300429	6004368939	4
3300438	5394547413	2
3300352	6660282397	8
3300462	1574728745	1
3300469	6516319986	1
3300542	5640092722	4
3300496	6995496802	2
3300437	1657732157	8
3300503	5366715578	0
3300436	5962529220	2
3300508	7099222045	0
3300536	1898587495	1
3300471	5406797046	4
3300472	5001845155	5
3300518	6086589687	6
3300543	6427215173	7
3300506	6456894203	4
3300475	2030556964	8
3300478	1657732157	2
3300520	6540252521	4
3300512	5893491762	1
3300480	5451472438	5
3300545	5382836079	1
3300521	5893491762	2
3300484	7057020737	2
3300486	7184421688	1
3300540	5261709374	3
3300510	6968920427	9
3300513	6476236332	1
3300515	1905191549	1
3300563	1602037670	10
3300532	5873671622	7
3300516	5751881373	4
3300514	1455261679	6
3300525	7154422718	5
3300533	1980144232	4
3300528	6227775632	5
3300558	1825402966	2
3300555	5261709374	5
3300523	2056083366	3
3300534	6568584058	4
3300549	5849150092	9
3300551	6198829905	7
3300538	907041559	6
3300562	5516494289	3
3300548	6159343088	1
3300560	2143605037	2
3300556	5038901651	7
3300565	5407690322	7
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (user_id, pesan, name, status, menfess, peringatan, mediafess, coin, comment, kado, lock) FROM stdin;
5900146741	1	shierin	0	1	0	0	0	0	0	0
6849238753	3	jn	0	355	0	0	0	19	\N	0
6326033906	0	ab	0	5	0	0	0	2	\N	0
5799144442	1	𝙈𝙖𝙣𝙣 𝙒𝙞𝙣𝙩𝙚𝙧𝙨.	0	396	0	1	118.30000000000001	136	\N	0
1860834442	2	ㅤ꒰۪۪۫𑁬(ི𝗸ιƙᦅ̱۪)ྀ‌໒۪۪۫꒱ ‌	0	2	0	0	0	0	0	0
5551694052	1	quaso sayang tian	10	1614	0	0	9834.07999999999	3478	\N	0
1379981741	5	elio	2	6196	1	0	6.249999999999773	876	\N	0
6476236332	2	C	0	2	0	0	0	0	0	0
907041559	1	hkmprb	0	1	0	0	0	0	0	0
6332612061	1	.	0	228	0	0	0	37	\N	0
1033814434	0	py	0	110	0	0	2093.2	96	\N	0
5230350551	0	𝓐.	0	3	0	0	0	0	0	0
6335974985	0	sayanggku	0	192	0	0	1817	17	\N	0
5552666721	0	fan	0	128	0	0	285.22999999999996	99	\N	0
1899315038	5	f	11	1200	0	0	256.8499999999997	1269	\N	0
6647493163	3	floren #ratuiblis	0	9	0	0	0	42	\N	0
6364382298	2	S . travisha :: ōtsukitzu #OtsukiWithJendral	7	113	0	0	0	122	\N	0
2007430061	1	rara	0	19	0	0	0	4	\N	0
1769994103	1	je	10	3885	0	1	1039.3300000000013	7666	\N	1
5909755417	0	ebi furai	0	2	0	0	2184.05	128	\N	0
7160950649	0	safiii, openg	0	11	0	0	0	151	\N	0
2003485571	0	Takapung	0	172	0	0	6.450000000000003	122	\N	0
1549333279	0	ashark.	6	197	0	0	1702.44	1399	\N	0
6888042158	0	open isian but slr	0	49	0	0	0	5	\N	0
1640493333	0	mengg	0	179	0	0	1	120	\N	0
2012196004	0	Genas	0	632	0	0	515.535	33371	\N	0
2077475265	4	Ⓜ	5	929	0	0	6.670000000000499	5028	\N	0
1454976663	1	crow	0	1	0	0	0	0	0	0
5523602507	1	mvk. caamy =3	0	1	0	0	0	0	0	0
6954821620	0	Immanuel	0	1	0	0	0	0	\N	0
1954666311	1	𝔰𝔱𝔞𝔯 atennnn	0	1	0	0	0	3	0	0
6995799602	1	ayam	0	1	0	0	0	0	0	0
6976025753	0	la vie	0	18	0	0	277.81	67	\N	0
1909845002	0	mey	0	675	0	0	12	38	\N	0
6786637503	0	𝕟𝕒𝕟𝕒	0	72	0	0	1.0199999999999996	243	\N	0
5477260745	0	a	0	349	0	0	0	2689	\N	0
6501378285	0	Malio	0	9	0	0	0	0	\N	0
6546282455	0	A	0	51	0	0	0	4	\N	0
7015982512	3	nezha	0	8	0	0	1948	1	\N	0
5386110626	0	eline	0	475	0	0	23.040000000000475	868	\N	0
5980838008	0	.	0	11	0	0	0	21	\N	0
6301845632	0	girl	0	28	0	0	0	2	\N	0
2140903876	0	c	0	866	0	0	0	0	\N	0
1680899112	0	ray	0	1	0	0	0	169	\N	0
934380109	0	л	0	229	0	0	0	45	\N	0
5593410334	0	Armyyy	0	51	0	0	0	19	\N	0
6364654860	0	rasji 🇹🇰	0	7	0	0	0	0	\N	0
6536279694	0	.	0	43	0	0	0	12	\N	0
1628275074	0	roar	5	76	0	0	2150.62	84	\N	0
6782693086	0	Arsen	0	340	1	0	0	15	\N	0
6437915673	0	aeris 𐙚	0	2	0	0	0	0	\N	0
5230001535	0	a	0	74	0	0	0	0	\N	0
6114006720	0	𝗞enzi.	0	1	0	0	0	0	\N	0
1737222420	0	jean v2.	0	6	0	0	14.82	96	\N	0
6856651140	0	mika ratu iblis	0	458	0	0	6	76	\N	0
6764503334	1	xyxxn	0	2	0	0	0	0	0	0
6958158826	0	janeeta	0	21	0	0	926	21	\N	0
5250400779	0	giseila 4twenty	0	1	0	0	0	0	\N	0
6988139748	0	feila’ a. 🕷🏴	0	2	0	0	0	0	\N	0
5680364745	0	s/ia . faYy	0	99	0	0	1.3900000000000006	786	\N	0
6890778325	0	Britney	0	1	0	0	0	0	0	0
7100394088	0	ᴢᴀʀᴄ pacar zuraaa	0	4	0	0	0	19	\N	0
6796448429	0	M31♡	0	3	0	0	0	0	\N	0
6717150389	0	ojan	0	3	0	0	0	1	\N	0
5965279563	0	m	0	1	0	0	0	0	\N	0
5104529214	0	acaaa	0	29	0	0	0	0	\N	0
1728774408	0	⋆	0	157	0	0	226.81000000000006	1968	\N	0
6786042297	0	Sey	0	15	0	0	0	267	\N	0
5297762551	0	dni	0	23	0	0	13	14	\N	0
6852635971	0	a	0	42	0	0	0	168	\N	0
5281830050	1	miawni ʚɞ	0	643	0	0	6.610000000000014	672	\N	0
6520401993	1	rv	0	4	0	0	0	0	\N	0
5933239070	0	su zaizai >___= 🧘🏻‍♀🍰🪞🧤🌀	3	45	0	0	16971.809999999994	13359	\N	0
1241746162	0	aca moya	0	42	1	0	0	257	\N	0
6142489580	0	phu	0	38	0	0	412	2	\N	0
5980177564	0	Valerie Elvan Kanoa	0	6	0	0	0	5	\N	0
1546373813	0	Syana.	0	3	0	0	0	0	\N	0
6540766049	0	lzev	0	25	0	0	0	25	\N	0
6358487554	0	𝐣𝐣𝐯𝐨𝐧𝐤𝐚	0	4	0	0	0	9	\N	0
6702367237	0	arka	0	1	0	0	0	0	\N	0
6209515041	0	Joanna	0	66	0	0	0	104	\N	0
1818158893	0	dni	0	325	0	0	2195.25	264	\N	0
6856803483	0	ansa	0	1	0	0	0	0	\N	0
7051419209	0	Luezthaa	0	29	0	0	0	17	\N	0
7118439739	0	ak anak baiq	0	3	0	0	0	0	\N	0
6818171590	0	gab	0	54	0	0	0	1	\N	0
5436355206	0	ginaa `malfoys gf	12	147	0	0	914.3000000000001	786	\N	0
6461935436	0	Cassieee, hufttt	0	1	0	0	0	31	\N	0
6286801860	0	amaw	0	8	0	0	0	6	\N	0
7053556561	0	louv	0	1	0	0	0	0	\N	0
5006695943	0	jabay fesco	0	0	0	0	0	0	\N	0
7141383957	0	odesth	0	1	0	0	0	3	\N	0
2112369683	0	shasa	0	9	0	0	0	1	\N	0
5579579580	0	Satilla	0	440	0	0	376.109999999999	212	\N	0
6248409438	0	stfu.	0	210	0	0	6.190000000000055	196	\N	0
1801907718	0	n	0	2	0	0	0	6	\N	0
2043475832	0	mamas	0	30	0	0	0	10	\N	0
6808751017	0	Peter D. 4twenty	0	3	0	0	0	1	\N	0
1900152047	0	cewe kul	0	1	0	0	0	0	\N	0
6829464524	0	jaki	0	2	0	0	0	1	\N	0
6990890880	0	⁣⁫⁣⁫⁣⁫⁣⁫⁣⁫⁣⁫⁣⁫⁣⁫⁣⁫⁣⁫⁣⁫⁣⁫⁣⁫⁣⁫⁣⁫⁣⁫⁣⁫⁣⁣⁫⁣⁫ㅤ	0	15	0	0	0	473	\N	0
7158485795	1	L	0	8	0	0	0	1	\N	0
6691452267	1	Intan titatitu	0	34	0	0	0	24	\N	0
6080509807	0	nik	6	696	0	0	5612.03	1205	\N	0
6461052340	1	pidaa	0	23	0	0	41.879999999999995	134	\N	0
6427215173	1	Asam Karbonat	1	1385	0	1	1.089999999999577	13092	\N	0
6476545612	0	cici 🇵🇭	0	3	0	0	0	1	\N	0
1887678193	0	re	0	318	0	0	0	5	\N	0
5872387270	0	Cala	2	661	0	0	8773.74	2356	\N	0
2005152368	0	Naomi. @sMisora	14	248	0	0	277.3799999998964	16153	\N	1
1809765081	1	nouchaa 🍄	12	368	0	0	740.8799999999993	1921	\N	1
6998463390	0	𝖆𝖈𝖍𝖆🐇	0	1	0	0	0	0	\N	0
6648399510	0	yyy	0	3	0	0	0	165	\N	0
6321564629	0	.	0	2	0	0	0	0	\N	0
1943277262	0	Andrea Kevanoʷ⁶⁹	0	623	1	0	1051.51	549	\N	0
7112209300	0	N	0	27	0	0	0	50	\N	0
1557135637	0	reota	0	54	0	0	0	136	\N	0
7074790370	0	Annake.	0	1	0	0	0	0	\N	0
6867862296	0	pIYAa	0	1	0	0	0	1	\N	0
1716857453	0	Teresa.	0	1	0	0	0	0	\N	0
5185087419	0	︎︎	12	1117	0	0	845.7900000000003	3018	\N	0
5510901248	0	lenee.	10	676	0	0	3896.1599999999994	19100	\N	0
5664821727	0	shaqy ⋆⋆	0	61	0	0	0	822	\N	0
6934294919	0	Ra	0	1	0	0	0	37	\N	0
7068499580	0	Jose	0	3	0	0	0	33	\N	0
6306266079	0	fuck tami.	0	333	0	0	8967.47	466	\N	0
6422426294	0	.	0	2	0	0	0	11	\N	0
7180838513	0	C	0	1	0	0	0	0	\N	0
1683024445	0	gyena	0	1	0	0	0	2	\N	0
605166480	0	taelha	0	976	1	0	987441901	83	\N	1
6715388215	0	J, Aurora.	0	1	0	0	0	1	\N	0
1893970878	0	˖ 🎀 ᝬ icil GAK OPEN JJ ANJG! awr	0	525	0	0	10.259999999999991	489	\N	0
6804310603	0	Cassidy Hale	0	10	0	0	54.269999999999996	86	\N	0
5926079691	0	r	0	28	0	0	8.08	50	\N	0
1751295739	0	Chey	0	7	0	0	0	9	\N	0
6153095409	0	rowena	0	6	0	0	0	3	\N	0
6390993145	0	Juya	0	0	0	0	0	3	\N	0
6252306679	0	naren	0	3	0	0	0	0	\N	0
6303711776	0	seraa	0	2	0	0	0	1	\N	0
5435483601	0	🤏🏻	0	60	0	0	478	15	\N	0
5349055870	0	Bulan.	12	1194	0	0	1508.239999999984	6131	\N	1
1670072201	0	sin	0	1185	0	0	637.6299999999997	402	\N	0
6090205353	0	R	0	6	0	0	0	0	\N	0
5520566623	0	al	12	28	0	0	13143.419999999998	230	\N	1
1093975517	0	yh	0	17	0	0	0	12	\N	0
1784019170	0	mi	0	12	0	0	871.8499999999999	15	\N	0
6670057236	0	yoo	0	33	0	0	396.88	0	\N	0
1418326383	0	sz.	0	59	0	0	0	24	\N	0
6092222195	0	Zeal.	0	12	0	0	0	77	\N	0
6886829240	0	syaki	0	2	0	0	0	0	\N	0
2043306437	0	Prettiest dhea♡	0	3	0	0	0	10	\N	0
6192858581	0	Wonder Kezia.	0	14	0	0	3.13	142	\N	0
5194529439	0	Kazuki	0	27	0	0	0	11	\N	0
5911021707	0	raffy’ wikky salima	0	0	0	0	0	7	\N	0
5202842693	0	pikachu	0	1	0	0	0	0	\N	0
1710915127	0	manusia galau	0	0	0	0	0	0	\N	0
6251343335	0	Chira Michalle Octavia	0	20	0	0	0	1	\N	0
1806326506	0	wokwok	0	60	0	0	0	0	\N	0
1219509709	0	Sky nāvt²	0	1	0	0	0	3	\N	0
1128234653	0	kii	0	1	0	0	0	2	\N	0
6812130307	0	zell	0	1	0	0	0	0	\N	0
2085323091	0	nav	0	274	0	0	41.780000000000086	184	\N	0
6979479263	0	skksk	0	37	0	0	0	18	\N	0
6803555107	0	Esyaaaa	0	5	0	0	0	0	\N	0
1957614195	0	lizzie	0	196	0	0	30.5	227	\N	0
1387863825	0	raka	0	107	0	0	0	61	\N	0
7119403616	0	vvv	0	4	0	0	0	2	\N	0
6178130490	0	araa.	8	20	0	0	506.66999999999996	44	\N	0
6800954636	0	n.	0	1	0	0	0	1	\N	0
6219419352	0	adiphraya dipta.	0	1	0	0	0	0	\N	0
6417958898	0	heavenly	0	11	0	0	0	0	\N	0
6235189269	0	F’kanaira.	0	5	0	0	0	3	\N	0
2047032647	0	ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ	0	608	0	0	24.03	4255	\N	0
6201750756	0	hermione's bsf, rory	0	4	0	0	0	18	\N	0
1467041262	0	diq	0	277	0	0	438.72	11	\N	0
7071386833	0	elle	0	1	0	0	0	0	\N	0
6550688333	0	讷蜡.	0	6	0	0	0	71	\N	0
5549272082	0	stfu	0	2	0	0	0	0	\N	0
5935016122	0	Gama	0	1	0	0	0	3	\N	0
6192243567	0	kavi	0	7	0	0	0	11	\N	0
1723057294	0	Angel	0	2	0	0	0	4	\N	0
1105118372	0	lilan	0	1	0	0	0	8	\N	0
1440200580	1	cacaa	1	466	0	0	143.4999999999996	1628	\N	0
5110207266	1	lin	0	1153	0	0	10.2199999999997	598	\N	0
5063906707	0	pale	1	1357	0	0	651.5800000000017	5725	\N	0
5160380696	0	Dwyné.	0	73	0	0	0	46	\N	0
2090026553	0	miko	0	673	0	0	0.9099999999996271	920	\N	0
5415227276	0	.	0	19	0	0	0	3	\N	0
6765267564	0	n	0	8	0	0	83.97000000000061	0	\N	0
5542020354	0	ashe 🇵🇸	0	1	0	0	0	0	\N	0
1796518323	0	bubu	0	10	0	0	8	4	\N	0
5352340554	0	Evan	0	1	0	0	0	0	\N	0
1484607099	0	rain	0	1	0	0	0	0	\N	0
889031358	0	cece	0	1	0	0	0	5	\N	0
6012659693	0	Nami, slowrespon.	0	7	0	0	0	0	\N	0
5330806958	0	𝓜s. Div	0	91	0	0	36.32999999999956	155	\N	0
6872498855	0	ran	0	1	0	0	0	1	\N	0
5904380125	0	ɑccɑρellɑ (⁠＾⁠0⁠＾)	0	47	0	0	141.65	16	\N	0
1161558630	0	Gavi si “Janhae's Lovetaker” ^___^	0	139	0	0	0	157	\N	0
1135995845	0	di	0	1	0	0	0	0	\N	0
5530863009	0	Abyasa Dharma Jayachandra	3	509	0	0	262.670000000001	41	\N	0
6447302257	0	Ares Pratama	0	2	0	0	0	0	\N	0
5241738759	0	FE	0	5	0	0	0	1	\N	0
5118879179	0	rAin🧸💭	0	2	0	0	0	0	\N	0
1930756375	0	on resting	0	19	0	0	0	0	\N	0
1266453153	0	kobo	10	831	0	0	5069.3899999999985	9648	\N	1
6397932649	3	.	0	228	0	1	279.56999999999994	96	\N	0
6836007581	0	Alceena	0	15	0	0	9.689999999999856	1293	\N	0
1881916966	0	calv	0	29	0	0	908.09	1702	\N	0
2047168531	0	—	0	286	0	0	1551.51	12274	\N	0
6994121521	0	Sai Lizvenhert.	0	8	0	0	0	9	\N	0
1812793679	0	Kana	0	1	0	0	0	44	0	0
6865122773	1	kael	0	2	0	0	0	4	\N	0
5263876934	0	berenice, no rush!	0	48	0	0	69.69	280	\N	0
7050497687	0	...<hachi3!	0	2	0	0	0	30	\N	0
1780494298	0	Cátly.	0	1	0	0	0	8	\N	0
1872907271	0	Shabiel.	0	210	0	0	332.35	50	\N	0
6159194741	0	𝑸𝒖𝒆𝒆𝒏𝒏𝒂	0	150	0	0	2038.2700000000002	6589	\N	0
1621476276	0	chulo drpw	0	2	0	0	0	7	\N	0
7183079042	0	“.. Barbara Oniel	0	4	0	0	0	0	\N	0
6531137552	0	.	0	106	0	0	471.2600000000001	97	\N	0
5245007147	0	ara	0	2	0	0	0	0	\N	0
5328554788	0	szé.	6	655	0	0	432.7300000000006	4747	\N	0
1945607730	0	jenna	8	361	0	0	157.30999999999995	1	\N	0
6849946781	0	ale	0	2	0	0	0	1	\N	0
1153586702	0	Sada	14	41	0	0	1488.24	2302	\N	0
6193460185	0	Révia.	0	5	0	0	0	11	\N	0
6331417593	0	𐙚 Cä	0	9	0	0	0	85	\N	0
1664815293	0	Liddy grant	0	4	0	0	0	36	\N	0
5285859287	0	kaii miaaw	0	5	0	0	0	32	\N	0
1647848888	0	salvatore	0	516	0	0	0	18	\N	0
5160650134	0	𓆝 𓆟 𓆞	0	42	0	0	0	653	\N	0
5381166567	0	𓈒 anggieೀ 	0	33	0	0	0	466	\N	0
5315883064	0	bell || maba undip²⁴	0	11	0	0	0	66	\N	0
6180153139	0	aril	0	0	0	0	0	0	\N	0
6173075493	0	r	0	2	0	0	0	36	\N	0
6326417598	0	sheraa	0	24	0	0	0	22	\N	0
7128977705	0	ar	0	1	0	0	0	0	0	0
2001878807	0	૮₍˶• . • ⑅₎ა	0	1	0	0	0	0	0	0
6051004438	0	a	0	3	0	0	0	0	\N	0
7130845613	0	gab	0	3	0	0	0	12	0	0
6989761181	0	Julian	0	7	0	0	0	40	\N	0
6167855568	0	harley.awr	0	2	0	0	0	0	0	0
6670516013	0	feya d'amourth	0	3	0	0	0	3	\N	0
6573437894	0	₊ 𐙚 ׄ chilla	0	1	0	0	0	2	0	0
1069532274	0	yan	0	3	0	0	0	13	\N	0
6875463992	0	irr #love's gf ∞ᶦⁿᵗʸ	0	37	0	0	0	31	\N	0
5123305953	0	𝐀𝐦𝐚𝐚	0	34	0	0	46.82	15	\N	0
1710592982	0	atha	0	45	0	0	0	37	\N	0
1623129647	0	17. Gáriël Knight.	0	26	0	0	0	633	\N	0
5309690325	0	binda	0	139	0	0	0	55	\N	0
1319646510	0	kay ^__^	0	0	0	0	0	0	\N	0
1367959559	0	bryan	0	17	0	0	53.31999999999999	240	\N	0
6583556281	0	ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ	0	57	0	0	0	20	\N	0
6298429862	0	𝐁𝐊𝐂. 𝐂𝐙 🐈‍⬛️ léya 7102 🌀🦅⚡️𝐒𝐙𝟏 #ZLS #𝐂𝐃 𝐀𝐋𝐒𝐁	0	353	0	0	5.729999999999983	115	\N	0
5749034044	0	hooh	9	422	0	0	64.36999999999999	75	\N	0
5717109202	0	yaya	0	452	0	0	14.250000000000018	422	\N	0
5055559780	0	ashel	0	144	0	0	1296	265	\N	0
1821766397	0	issa.	0	185	0	0	0	27	\N	0
6715777651	0	6	0	27	0	0	0	310	\N	0
7195650124	0	ccc	0	1	0	0	0	0	\N	0
6115482611	0	sgr. Gadis tensāi	0	48	0	0	0	131	\N	0
7031258649	0	Louis	0	3	0	0	0	0	\N	0
6499885806	0	arunaaa	0	114	0	0	13.279999999999973	534	\N	0
2080406877	0	Rizky Goenardi	0	1	0	0	0	0	\N	0
1974615152	0	sabil	0	26	0	0	0	1	\N	0
7096429087	0	Rriioooww	0	1	0	0	0	0	\N	0
1253538508	0	mia	0	1	0	0	0	1	\N	0
1453593657	0	Why June?	8	290	0	0	463.38	3810	\N	0
6765465860	0	bllen	0	9	0	0	1011.03	252	\N	0
6524570310	0	ashyla	0	25	0	0	104.92999999999994	23	\N	0
5912255532	0	Ayna Yumna.	0	40	0	0	0	76	\N	0
1089963936	0	:)	0	76	0	0	0	4	\N	0
5685401886	0	falsya 🐬	0	35	0	0	0	166	\N	0
6101247126	0	frel	3	426	0	0	6900.299999999998	3242	\N	0
5814403750	0	Nae's Protector, Jethero 🦅	0	81	0	0	0	3	\N	0
1720137468	0	pam	0	8	0	0	0	0	\N	0
1605888331	0	lenn 👩🏻‍🔧	13	1904	0	0	566.4699999999968	4160	\N	1
1817788030	0	.	14	1027	0	0	1599.5150000000012	12139	\N	0
7126441203	0	myeci h.	0	1	0	0	0	0	0	0
1890699001	0	re	0	676	0	0	0	2	\N	0
6343901398	0	860 յׁׅɑׁׅ֮	0	12	0	0	0	0	\N	0
5559352118	0	Nebula M.	0	339	0	0	8.769999999999996	233	\N	0
6516319986	2	Shadira M. Ladmvk	4	211	0	0	0	767	\N	0
6316326167	0	zy	0	2	0	0	0	6	\N	0
5213009165	0	dαmenα sedih.	12	1370	0	0	2491.590000000001	12232	\N	1
6088154499	1	𐙚 ๋. Alula Chaliya	0	39	0	0	0	87	\N	0
7136396929	1	🌺💨🎀🫁🧜🏻‍♀️🌸🌺🌻🍄☃️❄️🩰🐰🐈🐕🐑🐿️🦫🌍💧🌹💃🏻ᴴᴸ	0	34	0	0	0	128	\N	0
2143593377	1	ayapie	12	760	0	0	468.3000000000002	1568	\N	1
6830695558	3	😶‍🌫	0	200	0	0	582	87	\N	0
1422447121	0	acaz	12	346	0	0	3826.7499999999995	5321	\N	0
5463863409	0	🦒	0	381	0	0	0	0	\N	0
1913194383	0	athalaaa a nya tiga lagi pusing 7 keliling info joki tugas	2	51	0	0	447.80000000000007	1052	\N	0
1617407239	0	Agatha Kinaya	0	259	0	0	3.2099999999999937	148	\N	0
5408494644	0	𐙚˙⋆ 𝗱𖦹︎𝗹𝗹𝗶𝗲𝘀 𝘃𝗶𝗲𝗻𝗻𝗲 📨 ·⊹⊱ᥫ᭡ ˖	0	133	0	0	157.9399999999999	2455	\N	0
1699394823	0	—irfan harrison	14	3391	0	0	1012.2974999999967	9950	\N	1
5477465282	0	222	0	26	0	0	0	3	\N	0
1837205884	0	♡	0	86	0	0	0	3	\N	0
6274301689	0	⊹ 🎀🍓‧ 𝐏𝗋‌𝗲‌ׄ𝘁‌𝘁‌ꭚ ˖ ᘝ ׄ nanauu ₊˚	0	15	0	0	0	36	\N	0
6739277733	0	Halfeyaa	0	31	0	0	0	1	\N	0
6146237322	0	#𝓝𝐜𝐧𝐢𝐭 🐈‍⬛️ 🌷 D for Dvn #𝐒𝐍𝐀 #𝐂𝐙 #ZLS 🔮 👩‍🚀	0	258	0	0	12	40	\N	0
1909076402	0	Libelle Yonara.	0	4	0	0	0	0	\N	0
6414195512	0	sera	0	235	0	0	150.07	517	\N	0
5244120499	0	Inka anak nakal	0	9	0	0	0	45	\N	0
5544578572	0	kajop	0	2	0	0	0	0	\N	0
5946949903	0	sa	0	1	0	0	0	0	\N	0
6768263280	0	ㅤel inMelbourne	0	1	0	0	0	1	\N	0
1042373265	0	D	0	155	0	0	100.2199999999999	21	\N	0
6215677617	0	si yunhi anak baik	1	275	0	0	1716.7000000000003	315	\N	0
7048625267	0	Sadewa	0	1	0	0	0	0	\N	0
7054438766	0	rere'ɢꜱ𖤓.	0	15	0	0	0	1	\N	0
6726194070	0	Arsha	0	2	0	0	0	0	\N	0
6235931489	0	Leo	0	1	0	0	0	0	\N	0
1836590610	0	pi	0	9	0	0	0	0	\N	0
6951701584	0	glishya. limit bentar	0	17	0	0	0	0	\N	0
1833700206	0	nin	0	56	0	0	0	0	\N	0
1657506790	0	𝐅 ction`	0	39	0	0	26.449999999999967	403	\N	0
1438829256	0	natt.	0	123	0	0	0	60	\N	0
5200728160	0	liam	13	145	0	0	3788.4100000000035	14116	\N	1
5727239112	0	.戦ᴍᴛᴢɪ.Marsha🩰𝗠𝗘𝗧𝗔𝗘𝗫𝗣𝗟𝗢𝗥𝗘𝗥	0	12	0	0	0	26	\N	0
6946210235	0	Ale	10	49	0	0	1237.3200000000002	1408	\N	0
6057607144	0	Suh's B.	0	1	0	0	0	9	\N	0
1982955527	0	ra	0	113	0	0	2.469999999999999	1731	\N	0
6118411280	0	zevra	0	951	0	0	9.66000000000011	610	\N	0
6466644592	0	w	0	15	0	0	0	9	\N	0
5884151216	0	sanny	5	230	0	0	2311.1300000000033	1705	\N	0
5584382820	0	ᴠᴏʀᴋᴀ ᴄᴀʀʟ	0	7	0	0	0	7	\N	0
7007910082	0	˖ ࣪𐙚 meyii ⋆ ࣪.	0	70	0	0	575	34	\N	0
5935673078	0	ckk.	0	3	0	0	0	2	\N	0
7069339257	0	shabriena	0	1	0	0	0	98	\N	0
6739242206	0	⛦	0	206	0	0	11.829999999999984	572	\N	0
6816457011	0	deww	0	105	0	0	0.6100000000000136	9	\N	0
6742612289	0	ϩ0५ 𝔩𝔦	0	7	0	0	0	0	\N	0
6968827741	0	Kanade	0	129	0	0	4.229999999999997	171	\N	0
5374666313	0	zz	0	7	0	0	41.64	294	\N	0
1987076153	0	mars	0	2	0	0	0	1	\N	0
5788482457	0	Lilangel	9	324	0	0	578.519999999998	20716	\N	1
7096397476	0	k	0	22	0	0	2000	103	\N	0
6648195023	0	Renn	0	2	0	0	0	58	\N	0
2085428128	0	kael	0	375	0	0	105.38999999999999	6	\N	0
7142251701	0	drere and VERNON coty!1!1!	0	1	0	0	0	0	0	0
6469137936	0	a	0	63	0	0	0	18	\N	0
1822189691	0	Ge	0	1	0	0	0	0	0	0
6179408534	0	𝐓𝐑≛𝐏𝐒 nara(k)vit	0	98	0	0	0	85	\N	0
7169805076	0	𝔢𝔵𝔞	0	1	0	0	0	1	0	0
5273434723	0	arine	0	246	0	0	0	151	\N	0
1623529441	0	nanta	2	568	0	0	2296.77	4029	\N	0
6397793909	0	jeehan 🇹🇭	3	112	0	0	17.109999999999907	383	\N	0
5290973502	0	Elle M. #Délρhinꫀ Harmꪮnyɞ	4	751	0	0	2144.139999999999	1285	\N	0
6023754950	0	veree	0	113	0	0	803.66	1918	\N	0
6156787840	2	reanaa🐠	2	721	0	0	28.270000000000152	381	\N	0
7130865620	1	v	0	5	0	0	0	34	\N	0
7187850754	2	Draco, M.	11	200	0	0	3663.1699999999996	5209	\N	0
5857455390	0	Vey. Jake's lover.	0	0	0	0	500	0	0	0
1657732157	3	nadhira	5	1450	0	2	7732.51	3567	\N	0
5234835595	0	Joel	9	957	0	0	3452.244999999997	9947	\N	0
1755332204	0	nara	0	7	0	0	1021.3399999999999	1799	\N	0
6709210857	0	星野ルビィ🦋❄️	0	5	0	0	0	168	\N	0
6095641952	0	Sowie's, Next alpha safaaa	14	547	0	0	19.959999999999752	174	\N	0
6966332534	0	misel	7	210	0	0	5942.509999999998	7765	\N	0
896042436	0	❦	12	175	0	0	104171.03	16252	\N	1
5136140562	0	vivian	8	83	0	0	1112.8200000000002	3284	\N	0
1744636822	0	Allysa	0	15	0	0	0	5	\N	0
1369741134	0	Lorèn	0	103	0	0	0	64	\N	0
6902617465	0	ancika	0	11	0	0	416.16999999999996	399	\N	0
6399090435	0	san edelweiss.	6	123	0	0	18.42999999999998	122	\N	0
6339839189	0	rena	0	89	0	0	0	4	\N	0
5924451345	0	K	0	11	0	0	35.98	42	\N	0
6416705997	0	Menyala	5	192	1	0	453.6500000000001	967	\N	0
6846940378	0	Jsmxy	0	85	0	0	0	0	\N	0
5482913472	0	Rosie	0	278	0	0	0	56	\N	0
6350637053	0	Tyra Theresia'	0	115	0	0	0	223	\N	0
1422979009	0	j	0	88	0	0	0	3	\N	0
1111615732	0	WhOs	0	1129	0	0	17.5	476	\N	0
6848842418	0	cesaa	0	2	0	0	0	2	0	0
5706073966	0	janee	6	152	0	0	1484.3000000000002	9880	\N	0
1626539111	0	C	0	2	0	0	0	6	\N	0
5320866823	0	Just	0	1	0	0	0	0	\N	0
6932514435	0	ೀ the prèttiest, celli	0	4	0	0	0	0	\N	0
6632356830	0	gabby	0	6	0	0	0	14	\N	0
7167860689	0	Jeha adiswara	0	32	0	0	0	20	\N	0
7087340545	0	Marlboro	0	18	0	0	0	310	\N	0
2068875547	0	Boby.	0	67	0	0	0	142	\N	0
5437218664	0	valeeeen	0	248	0	0	0	24	\N	0
6461398640	0	ody	0	1	0	0	0	0	\N	0
5196480131	0	🐈‍⬛	0	207	0	0	0	1	\N	0
6565306662	0	.	9	76	0	0	202.2	0	\N	0
5849090090	0	arielle🎀	0	1	0	0	0	0	0	0
5235126494	0	.	0	5	0	0	0	1	\N	0
1694157108	0	lalaa	0	12	0	0	0	247	\N	0
5086351163	0	sha	0	117	0	0	0	208	\N	0
7054036154	0	𐂂 milly miu	0	1	0	0	0	2	0	0
1096128109	0	Octaviana	0	26	0	0	0	229	\N	0
6919317266	0	Naomiaw	0	12	0	0	0	0	\N	0
1913272093	0	yefune	0	2	0	0	0	31	\N	0
5883194769	0	call me ra	0	1	0	0	0	1	\N	0
5432407539	0	dine	0	2	0	0	0	0	\N	0
5446928180	0	.	0	80	0	0	3.6999999999999886	216	\N	0
6807573217	0	🔒	0	1	0	0	0	0	\N	0
6411322901	0	Kailynx	0	26	0	0	44.06999999999999	94	\N	0
6516636944	0	angry	0	28	0	0	0	6	\N	0
5351234894	0	244. vel ōtsukiken,	0	12	0	0	0	22	\N	0
6271085934	0	Joy is pink!🎀	0	14	0	0	0	283	\N	0
6988615948	0	Marlong	0	1	0	0	0	0	\N	0
6577514354	0	aurel	0	35	0	0	0	398	\N	0
1996875827	0	a	0	19	0	0	0	12	\N	0
7162244606	0	Manager KingTaeMinKook	0	1	0	0	0	0	\N	0
6116099974	0	+🎀𓆪 ܷ dwoll:ie Namiella˔ཀ	0	4	0	0	0	2	\N	0
5747431248	0	ishvara	2	21	0	0	1064.7200000000003	1350	\N	0
2081115433	1	abeya	0	1038	0	0	4.5	109	\N	0
6933363434	0	frzchsy	0	14	0	0	0	2	\N	0
6262621188	0	pia ,	0	21	0	0	0	236	\N	0
5549311671	0	.	0	5	0	0	0	1	\N	0
5883188076	0	A	0	5	0	0	0	0	\N	0
6743809191	0	🦋	0	2	0	0	0	560	\N	0
6057430865	0	cocom(ayen)	0	1	0	0	0	35	\N	0
5773901289	0	769 lea	0	8	0	0	0	1	\N	0
1959400247	0	evan	0	58	0	0	278.01000000001113	28571	\N	0
6892423549	0	mayra	0	6	0	0	20.48	16	\N	0
1370446884	0	𝐤𝐚𝐯𝐢𝐧	0	1	0	0	0	0	\N	0
5044754777	0	sintia	0	2	0	0	0	4	\N	0
6712732123	0	lyaw	0	1	0	0	0	4	\N	0
1630058276	0	cc :]	0	6	0	0	478	130	\N	0
6547643634	0	Geamu	0	4	0	0	0	1	\N	0
7084603603	0	Mëchaya 🇵🇭	0	1	0	0	0	3	0	0
6828670670	2	thira	0	6	0	0	163	54	\N	0
1671882756	0	Elmyra	0	216	0	0	0	1	\N	0
6934925307	0	Raisya esyaa	0	4	0	0	0	0	\N	0
5237575825	0	Lyaaw 𐙚вαℓт⁶ᵀʳᵃⁱⁿᵉ	5	1597	0	0	172.33999999999946	727	\N	0
5902038759	0	mirell 🍦	0	20	0	0	0	61	\N	0
5366715578	2	restu	0	31	0	0	0	4	\N	0
5909609296	0	Goze. @trappres	0	6	0	0	0	53	\N	0
5133291716	1	jiuu🎀	8	475	0	0	289.53999999999996	1021	\N	0
5999787938	1	teh pucuk goreng	0	394	0	0	11	234	\N	0
2005558201	1	.	0	237	0	0	2	14	\N	0
6992693116	2	asha.	0	20	0	0	0	89	\N	0
1377830849	0	A	0	53	0	0	0	174	\N	0
6072484807	0	niml	0	3	0	0	0	6	\N	0
6843327204	0	A.	0	1	0	0	0	1	\N	0
2066493141	0	Kaesa.	0	85	0	0	1412.77	405	\N	0
5178437415	0	— 𝐖illi.	0	1	0	0	0	0	\N	0
1399404942	0	Ezkepall	0	249	0	0	85	126	\N	0
2117094208	0	gavin spiderman	5	322	0	0	10.109999999995466	365	\N	1
6280215425	0	trishA	0	1	0	0	0	0	\N	0
6131949215	0	.	0	2	0	0	0	0	\N	0
6385084327	0	jevana	0	256	0	0	161.8200000000001	259	\N	0
6846549952	0	ᅠᅠᅠᅠᅠzeva	0	2	0	0	0	1	\N	0
1724507382	0	eya	8	139	0	0	3285.050000000001	333	\N	0
6175705713	0	Mayyin	0	1	0	0	0	0	\N	0
1438668195	0	..fara	0	207	0	0	6.45999999999988	491	\N	0
5893068615	0	◼️Kevin	0	105	0	0	0	33	\N	0
7111841393	0	raa	0	1	0	0	0	0	\N	0
6581120299	0	ketua begal	0	0	0	0	0	0	\N	0
6269491167	0	ilαnn wαnt υggie :<	0	2	0	0	0	0	\N	0
6788194777	0	Jade	0	1	0	0	0	0	\N	0
1736812694	0	yordania	0	297	0	0	360.3700000000001	2831	\N	0
1927314057	0	a	0	10	0	0	0	21	\N	0
1709954034	0	Laurence Saotome.	0	1	0	0	0	0	\N	0
5307086283	0	urgirl	0	10	0	0	0	56	\N	0
1682300841	0	avierelle	0	302	0	0	0	213	\N	0
1861292183	0	é	0	79	0	0	0	32	\N	0
6425930750	0	zy	0	0	0	0	0	0	\N	0
5730803568	0	nanas	0	124	0	0	71.79	170	\N	0
6676920040	0	Athena	0	4	0	0	0	16	\N	0
1375376164	0	vanesya	0	36	0	0	12.950000000000003	131	\N	0
7157290685	0	.	0	2	0	0	0	1	\N	0
5238586428	0	Davilham	5	485	0	0	999.2900000000006	14797	\N	1
5397692107	0	rxbyjxnx	8	518	0	0	6256.740000000001	352	\N	0
1960043122	0	jeno	0	41	0	0	0	1	\N	0
1482650469	0	nagata	12	8	0	0	2049.970000000001	1404	\N	1
7135875750	0	winter	0	1	0	0	0	5	\N	0
5344027523	0	Alana	6	190	0	0	625.71	269	\N	0
1985824432	0	eve	0	6	0	0	0	0	\N	0
5399255442	0	Nutly corresā¹⁸.arkëus	0	12	0	0	32.33	40	\N	0
1354640946	0	moonella	0	1	0	0	0	0	\N	0
2116667092	0	unknown	0	1	0	0	281.34	32	\N	0
5291133015	0	꧁kalixtzy:v꧂	8	1593	0	0	12768.789999999997	4087	\N	1
6010772133	0	wiu mw jadi ninja	0	117	0	0	654.25	1757	\N	0
6809124479	0	Cessa	0	0	0	0	0	0	\N	0
6934319199	0	A	0	1	0	0	0	0	\N	0
7111704317	0	´ 𐙚 ..tweetiny	0	1	0	0	0	0	\N	0
5928728388	0	𝓐 lzaa	0	75	0	0	0	45	\N	0
2099983244	0	zeooooo	0	318	0	0	3750.5699999999997	248	\N	0
1977936500	0	joycea	0	5	0	0	568.39	277	\N	0
5419389457	0	nay	0	27	0	0	411	7	\N	0
1952690329	0	pipi ōtsukigou	9	818	0	0	4473.14	26578	\N	0
6947608217	0	k	0	78	0	0	232	121	\N	0
6868117268	0	tatatatatatata	0	124	0	0	0	23	\N	0
6211059006	0	⑅᜔ 🧂🎀 ׄʬ ݊ ݂majalèa, 작은! ₊˚.	0	1	0	0	0	0	\N	0
6348074638	0	raala	0	3	0	0	0	3	\N	0
6751762941	0	Queen	0	3	0	0	0	11	\N	0
6824192884	0	ꫝ	0	5	0	0	0	2	\N	0
7171524005	0	ikan 🐬	0	2	0	0	0	0	\N	0
6759120410	0	𝐞𝐥	0	4	0	0	0	6	\N	0
6962453096	0	Nisaka. 🍉	5	209	0	0	4.999999999999999	17	\N	0
5654629658	0	bibi	0	134	0	0	0	23	\N	0
6338872937	0	rusirfah	0	1	0	0	0	0	\N	0
1772745566	0	𔘓੭꯭ aisel !	0	96	0	0	0	131	\N	0
2044305829	0	öse dika	0	248	0	0	0	178	\N	0
1458914781	1	Weilian.	11	1542	0	1	240.8399999999997	1966	\N	0
1811478345	1	geeta	0	851	0	0	14.14	926	\N	0
7166312537	0	kay	0	3	0	0	0	30	\N	0
6776602873	1	.	6	85	0	0	136.03	311	\N	0
6159343088	3	Zee	0	134	1	0	0	28	\N	0
7067753637	1	.	0	2	0	0	0	0	\N	0
5909268480	0	egin	13	613	0	0	98.37999999999988	6349	\N	0
5216792019	1	ilona	6	488	0	0	1745.6399999999994	1924	\N	0
6856385038	2	nasa	0	124	0	0	0	201	\N	0
7100212809	1	𝐓𝐑≛𝐏𝐒 vijayy	0	40	0	0	0	69	\N	0
2043118987	1	J. Eastville	0	712	0	0	7.490000000000009	261	\N	0
6772194075	0	idk	0	86	0	0	825.2199999999998	162	\N	0
6805572665	0	raya. - 𝕲𝕵	0	2	0	0	0	38	\N	0
7039932732	0	dayy — OPEN FREELANCE	0	2	0	0	0	2	\N	0
7078622513	0	athala	0	29	0	0	0	6	\N	0
7134936657	0	.	0	28	0	0	0	107	\N	0
6304228213	0	.	0	2	0	0	0	0	\N	0
5047124479	0	B	0	3	0	0	0	0	\N	0
6710825891	0	Sa.	0	12	0	0	478.09000000000015	5	\N	0
1789667677	0	J	4	158	0	0	2169.6800000000003	170	\N	0
1398762809	0	mzzm	11	889	0	0	476.55000000000257	1293	\N	0
5564692776	0	cilaa.dys	0	87	0	0	0	1147	\N	0
6185495095	0	re²	0	79	0	0	0	133	\N	0
5662913525	0	Brou	0	25	0	0	0	10	\N	0
7164211152	0	Vander 4twenty	0	1	0	0	0	0	\N	0
6128627691	0	Jaden	0	2	0	0	0	0	\N	0
5867987170	0	ashaa 🏎️	0	2	0	0	0	0	\N	0
5290004101	0	M	0	312	0	0	0	5	\N	0
1769345451	0	ww	0	31	0	0	0	37	\N	0
5046730224	0	ika, jeno girl🐈‍⬛	0	20	0	0	0	1851	\N	0
6492187280	0	cessa	0	8	0	0	58	0	\N	0
5537413652	0	Alex	0	4	0	0	0	50	\N	0
7129073039	0	elene. 🖐🏻🧍🏻‍♀🩰♥️>3!	0	0	0	0	0	0	\N	0
5563835598	0	aurel ultramimi¹⁶⁴	0	443	0	0	297.6500000000001	895	\N	0
1757750050	0	L	0	88	0	0	4	17	\N	0
7007686442	0	dea	0	25	0	0	89	97	\N	0
5770220194	0	s	5	704	0	0	0.9599999999949205	1746	\N	0
1856002338	0	Casyy	0	192	0	0	0	35	\N	0
5418644803	0	Allya	0	20	0	0	567.79	4	\N	0
5194027105	0	Helen	0	55	0	0	1	0	\N	0
6703386607	0	cipa syg🇿🇦 🇧🇫	0	1	0	0	0	0	\N	0
7111471549	0	𝕽♧	0	74	0	0	2	101	\N	0
5961114933	0	Razélla	0	10	0	0	0	5	\N	0
5715687859	0	[Hiatus] 狼. xylza arthanaᵈ'ᵛⁿˢᶜᵒʳᵉ	0	59	0	0	16.54	5	\N	0
5559781721	0	Joece	0	2	0	0	0	1	\N	0
5755680274	0	lavvv odeng	0	2	0	0	0	2	\N	0
6763924673	0	Chishy	0	0	0	0	0	3	\N	0
5531261699	0	bie	0	3	0	0	0	5	\N	0
1730969497	0	gwyneth c	0	0	0	0	0	0	\N	0
5189608295	0	chris 1975. ōtsukigou #OtsukiWithJendral	0	98	0	0	0	1122	\N	0
5951971432	0	nakula anak bunda 🐈	0	4	0	0	0	3	\N	0
1440484799	0	RaAa.	0	50	0	0	1407.08	19	\N	0
6278214313	0	nel	0	39	0	0	0	20	\N	0
1651997886	0	El Nino	0	1	0	0	0	4	\N	0
1698509521	0	piyy	0	441	0	0	10.8	56	\N	0
5979955828	0	302. Andra	0	4	0	0	0	4	\N	0
5527045896	0	awa.	0	1	0	0	0	5	\N	0
6835628972	0	dafa	0	7	0	0	0	0	\N	0
6889056686	0	sa	0	1	0	0	0	0	\N	0
1399317648	0	vlone drips	0	1	0	0	0	1	\N	0
6052283042	0	125 Layla	0	36	0	0	17.950000000000102	77	\N	0
6061655977	0	chie	0	6	0	0	0	0	\N	0
6452313555	0	ami	6	189	0	0	1685.030000000001	1071	\N	0
6169783654	0	⍣	0	17	0	0	300	2	\N	0
6989432903	0	on ts. ⌗ ciyo cinta dohyun ‹𝟹 💌🧎‍♀️	0	2	0	0	0	0	\N	0
6630111061	0	Kenan 𝐉. 𝐋𝐎𝐔𝐈𝐒	0	7	0	0	0	15	\N	0
1797871775	0	Zava	0	1	0	0	0	0	\N	0
6193632597	0	shaa	0	138	0	0	12	24	\N	0
6173955514	0	kim jua	0	1	0	0	0	2	\N	0
2003755400	0	alililililifah	0	32	0	0	0	2	\N	0
2078422966	0	pirorr	0	21	0	0	0	32	\N	0
1954010343	0	cicii	0	182	0	0	0	61	\N	0
6702738521	0	kiii	0	2	0	0	0	0	\N	0
1920584799	0	命 Pouchie 244 tkh³ 325	3	553	0	0	13.020000000000323	229	\N	0
6724817737	0	kyle	0	3	0	0	0	7	\N	0
5848264497	0	aya	0	4	0	0	0	25	\N	0
6814610834	0	clar	0	4	0	0	0	0	\N	0
5433208072	0	ello	0	557	0	0	22.300000000000068	156	\N	0
5757651090	2	lalalalaaa	0	5	0	0	0	4	\N	0
1441585887	1	zzz	0	236	0	1	47.19	932	\N	0
7113973933	1	annelies	0	19	0	0	0	8	\N	0
6806976992	1	kay	0	12	0	0	9.95	6	\N	0
2132392149	1	naana	0	15	0	0	0	0	\N	0
1768835412	0	GLoriaaaa.	0	1	0	0	0	29	\N	0
6369500915	0	.	13	73	0	0	14.09000000000001	14	\N	0
5830030126	0	Ayyara J.	0	3	0	0	0	27	\N	0
6602164181	0	renee	0	10	0	0	0	18	\N	0
6095248399	0	aca | ada job? tag please.	0	2	0	0	0	49	\N	0
7176899662	0	chiarawrrr	0	1	0	0	0	0	\N	0
1245582741	0	pau	0	1	0	0	0	1	\N	0
7163590433	0	chaa	0	24	0	0	0	60	\N	0
5009319376	0	asyayaa	0	1	0	0	0	2	\N	0
7085854377	0	Kissa.	0	35	0	0	0	8	\N	0
1474688182	0	Zena	0	31	0	0	8.35	14	\N	0
5658416358	0	Jennica nada	0	23	0	0	21.370000000000132	34	\N	0
5751305326	0	nina	0	28	0	0	0	65	\N	0
6922336884	0	joler	0	1	0	0	0	0	\N	0
5916458894	0	.	7	388	0	0	2953.5100000000007	8212	\N	0
7100668702	0	jean	0	2	0	0	0	4	\N	0
6371218767	0	nananana	0	1	0	0	0	3	\N	0
1852451517	0	cemimiw	0	278	0	0	0.7000000000000455	681	\N	0
7133228967	0	naya	0	278	0	0	1.0099999999999625	1593	\N	0
6468896248	0	y	0	38	0	0	0	23	\N	0
1720660778	0	raley	4	339	0	0	3201.4899999999975	16821	\N	0
6815949696	0	rie୨୧	9	492	0	0	399.4200000000001	1291	\N	0
5483499595	0	maladev	1	466	0	0	1167.9099999999978	14204	\N	1
5025469756	0	𝟯𝟰𝟭. badut ciputat	13	288	0	0	2839.4600000000232	2766	\N	1
1191469861	0	s	0	417	0	0	12.5	557	\N	0
5901871312	0	Nicolette Withler.	13	1149	0	0	2199.91	9167	\N	0
7179920868	0	abeiya awr	0	31	0	0	0	144	\N	0
5027222948	0	Lucid	0	0	0	0	0	13	\N	0
5807464007	0	mizZzu 🍥	12	796	0	0	2447.12	2826	\N	0
6415106700	0	queen :>	0	45	0	0	95.3	378	\N	0
6852163389	0	ashery	0	28	0	0	0	2	\N	0
6231895249	0	ʟᴠ` caca • ɪ͢ɴꜱ͠ᴘʀᴅ	0	8	0	0	0	0	\N	0
6401098595	0	simsalabim keterima pilihan ke 1	0	3	0	0	0	3	\N	0
5155949547	0	rahyeo	0	11	0	0	16.869999999999997	62	\N	0
1817954515	0	lily, still little girl they said	0	9	0	0	0	566	\N	0
5895130067	0	jiwonie #WithCateuve	4	713	0	0	5	31	\N	0
6598666149	0	khai	0	64	0	0	0	145	\N	0
5436832068	0	inaaa	0	8	0	0	4.57	13	\N	0
5549182772	0	the naturhe's bianca	0	21	0	0	0	4	\N	0
5952988031	0	lele	0	800	0	0	2.6400000000001285	170	\N	0
6643522515	0	E	0	0	0	0	0	3	\N	0
5638410190	0	asshley awr	5	2399	0	0	2.6700000000000728	1697	\N	0
5572927816	0	Punjel	0	167	0	0	86.83	1034	\N	0
5329458388	0	sofia	6	60	0	0	19.37000000000012	44	\N	0
5954967507	0	🇬🇸 cei, awr r nya rawr	0	85	0	0	6.530000000000001	116	\N	0
7022110937	0	ar	0	1	0	0	0	1	\N	0
5987711735	0	punpun	0	103	0	0	13.27	183	\N	0
6110160327	0	ㅡ zell	0	7	0	0	0	0	\N	0
6070634123	0	ael	0	85	0	0	0	23	\N	0
5684703775	0	A. react = done	0	220	0	0	4.34	4	\N	0
5614994926	0	daddy's girl, andre with a 🎱	3	608	0	0	711.4599999999998	6321	\N	0
5120987268	0	G.	0	1	0	0	0	7	\N	0
1372517279	0	y	0	332	0	0	206.57999999999993	1289	\N	0
6735148456	0	˖ ݁𖥔 ݁˖ 𐙚 ˖ ݁𖥔 ݁˖	0	54	0	0	0	8	\N	0
1288276803	0	ㅤ—c	0	17	0	0	0	0	\N	0
6391698973	0	😇😇😇😇😇	0	1	0	0	0	0	\N	0
5324579195	0	k	0	8	0	0	0	140	\N	0
6751793764	0	zelvania	0	0	0	0	0	0	\N	0
6418143350	0	hasta	0	2	0	0	0	0	\N	0
1628721834	0	anin	0	392	0	0	2.330000000000041	30	\N	0
1971870339	0	nin	0	132	0	0	33.75	0	\N	0
1256545625	0	am	0	3	0	0	0	0	\N	0
5041977467	0	D	0	3	0	0	0	0	\N	0
5961893294	0	cakra	0	12	0	0	0	0	\N	0
6167135909	0	j5z cattie	0	118	0	0	9.379999999999999	110	\N	0
6814605617	0	chesa 🧙🏻‍♀️	0	6	0	0	0	6	\N	0
2056083366	1	ceira	0	855	0	0	981.23	1151	\N	0
6076708009	0	SaNAa	0	8	0	0	51.74	1725	\N	0
5460983436	1	asyael	0	244	0	0	0	486	\N	0
7154788561	2	jeje	0	7	0	0	0	9	\N	0
1854719517	0	bieff	9	144	0	0	477.59000000000003	15	\N	0
7014850561	0	239. eja warkop	0	17	0	0	0	5	\N	0
7166118621	0	`drox†.	0	0	0	0	0	0	\N	0
7012999713	0	luki.	0	40	0	0	1462.65	1317	\N	0
5613964760	0	リゼ	0	11	0	0	0	60	\N	0
6676177063	0	ㅤ	0	18	0	0	0	62	\N	0
5812115156	0	L for ?	12	177	0	0	685.23	1621	\N	0
2072859052	0	k	0	1	0	0	0	0	\N	0
6977742328	0	Aubree Bridgette. (rarely active)	0	53	0	0	0	43	\N	0
1105456822	0	💅✨	0	1	0	0	0	37	\N	0
5419432426	0	.	0	3	0	0	0	29	\N	0
1869440149	0	Zephyraa.	0	5	0	0	0	3	\N	0
1412903493	0	🦁	0	18	0	0	0	29	\N	0
5527602021	0	eylin || open BO/CCLC	0	0	0	0	0	0	\N	0
5683259467	0	RYAN.	0	0	0	0	0	1	\N	0
5720191232	0	𝖻𝗈𝖺 𝗁𝖺𝗇𝖼𝗈𝖼𝗄	11	653	0	0	1036.2999999999984	2986	\N	1
6726466692	0	.	0	7	0	0	0	2	\N	0
6942608832	0	Fer	0	3	0	0	0	0	\N	0
7093094060	0	ran	0	1	0	0	0	0	\N	0
5098254156	0	n	0	241	0	0	0	50	\N	0
5392941779	0	🌕	0	39	0	0	0	51	\N	0
6995234077	0	Cheer	0	1	0	0	0	0	\N	0
5601770552	0	ecaww	0	21	0	0	0	78	\N	0
6940593484	0	Cici	0	28	0	0	113	88	\N	0
7184540679	0	ibu peri 🤏🌷🦢🕊🌦	8	453	0	0	10.409999999999968	2076	\N	0
7019456301	0	azee	0	3	0	0	0	0	\N	0
5901741330	0	deb	4	195	1	0	1513.9	1645	\N	0
7067094613	0	giliaa	0	1	0	0	0	4	\N	0
6185723187	0	923 ghhblh	0	3	0	0	0	0	\N	0
6759268104	0	ray	0	20	0	0	0	0	\N	0
1976891282	0	leon	7	94	0	0	12.540000000000006	73	\N	0
1948648298	0	mai gallagher	14	1336	0	0	2112.1900000000014	3445	\N	0
6057325757	0	Mikhael N.	0	0	0	0	0	0	\N	0
6536337529	0	Jerichó M.	0	2	0	0	0	0	\N	0
5889555157	0	zeee, pers.	0	72	0	0	6.140000000000001	1883	\N	0
6926752143	0	Kenal	0	2	0	0	0	0	\N	0
7068674446	0	jé.	0	1	0	0	0	0	\N	0
5409236642	0	BieAbie	0	2	0	0	0	0	\N	0
7109761933	0	evemisth c.	0	2	0	0	0	0	\N	0
6748671946	0	lIlIlIlIlI	0	9	0	0	0	1	\N	0
5765623842	0	racala	2	605	0	0	10036.31	14347	\N	0
1677580016	0	capi	0	92	0	0	1	119	\N	0
915353674	0	ayam, kinda inactive	0	609	0	0	2032.7100000000005	8221	\N	0
1775816774	0	Gabriel Forbes.	0	1048	0	0	239.69500000000016	889	\N	0
6157320724	0	Sharky🦈	0	35	0	0	426	0	\N	0
6932521354	0	syaa	0	63	0	0	9	1	\N	0
5328718221	0	asa	14	571	0	0	2140.570000000512	5700	\N	1
2072364557	0	gentala	0	470	0	0	3660.7	6532	\N	0
5567724428	0	jeez	0	179	0	0	230.03999999999996	417	\N	0
1652684760	0	vira	0	39	0	0	0	16	\N	0
7187780125	0	alaaa	0	8	0	0	0	4	\N	0
6681847762	0	sey, missing @Mwiou.	0	72	0	0	0	22	\N	0
2110923814	0	canalaa	0	22	0	0	0	2	\N	0
6642979487	0	Maisylva.	0	56	0	0	0	64	\N	0
6651526119	0	olla	0	214	0	0	0	0	\N	0
6320091413	0	oline	0	6	0	0	0	4	\N	0
1967324741	0	౨ৎ shìee.. !¡	0	5	0	0	0	0	\N	0
1856384851	0	Isabella orynth.	0	165	0	0	0	92	\N	0
1887525972	0	Chelle	0	903	0	0	0	7	\N	0
6871109817	0	farzan	0	1	0	0	0	0	\N	0
2129669504	0	disa gengster	0	2	0	0	0	5	\N	0
6680193544	0	“ i love you, Fredrinn ” Viy says	0	0	0	0	0	0	\N	0
1441030641	0	ccaa	0	0	0	0	0	2	\N	0
2037727490	0	JJ🧍🏻‍♀️	0	3	0	0	0	0	\N	0
6703177080	0	— Ꭼxël . Slr	0	54	0	0	0	116	\N	0
5396998299	0	yeyes, kinda stress.	0	4	0	0	0	1	\N	0
6407951469	0	ᘏ ˚₊ 🎀 Cassidy! ⊹ ʚ ׁ	0	5	0	0	0	0	\N	0
6527573876	0	dde kay	0	33	0	0	0	2	\N	0
7154337175	0	.	0	0	0	0	0	0	\N	0
1643975977	0	Eden.	11	51	0	0	15253.790000000005	4337	\N	1
1733737639	0	K.	0	9	0	0	0	28	\N	0
6210372365	0	k	0	1	0	0	0	1	\N	0
6379738682	0	naèva	0	25	0	0	184.54	3	\N	0
5712137598	2	Miya	0	237	0	0	0	31	\N	0
6780258211	1	dwyne, close cv.	0	4	0	0	0	3	\N	0
5648152228	0	vns	14	158	0	0	2865.5899999999965	2512	\N	1
1178321215	0	yumé	13	950	0	0	185.25000000000017	8297	\N	0
1493773846	0	ziiiii	9	1	0	0	1949.47	160	\N	0
1538594687	0	Javenthino H.	0	34	0	0	441	3	\N	0
6772468115	0	⋆˚࿔ asheyra 𝜗𝜚˚⋆	0	2	0	0	0	0	\N	0
6309661817	0	sheiyin	0	1	0	0	0	2	\N	0
6813533836	0	ryt	0	97	0	0	5.309999999999999	92	\N	0
6998571798	0	E, Abednego.	0	1	0	0	0	0	\N	0
5407826966	0	cassie	0	2	0	0	0	0	\N	0
1878297874	0	Aqila.	0	5	0	0	0	15	\N	0
5817668598	0	kiw	0	34	0	0	0	2	\N	0
7073718113	0	Putri	0	17	0	0	0	0	\N	0
6490785251	0	abcdefg	5	185	0	0	829.0299999999999	916	\N	0
5685099569	0	$yaa.	0	354	0	0	0	98	\N	0
6357635673	0	𝐓𝐑≛𝐏𝐒 ` .𝐃Λ.ᴍᴍᴠ.엘르	0	6	0	0	0	2	\N	0
6951498393	0	caca	0	148	0	0	0	40	\N	0
6116107273	0	soso	0	2	0	0	0	3	\N	0
6101104247	0	ara	0	186	0	0	243.81	190	\N	0
5105075006	0	rest.	0	1	0	0	0	0	\N	0
6946211548	0	N	0	3	0	0	0	14	\N	0
6820199400	0	Michie	0	80	0	0	8.899999999999999	184	\N	0
6984907911	0	ぬ˖ 𝐂𝐥𝐚𝐫𝐢𝐬𝐡𝐭𝐚	0	3	0	0	0	2	\N	0
1829540850	0	α	0	163	0	0	1274	177	\N	0
6972705412	0	kinan mode cariin pacar buat temen	0	11	0	0	0	83	\N	0
5936596766	0	Roky	0	2	0	0	0	1	\N	0
1839631742	0	—	0	6	0	0	0	38	\N	0
5812894041	0	morethyia.	0	8	0	0	0	8	\N	0
7033850947	0	wyne4twenty	0	1	0	0	0	0	\N	0
1725138849	0	pio	0	732	0	0	32.68000000000024	642	\N	0
5066352327	0	៸៸ sasaa 。☁︎	0	122	0	0	17.79	2	\N	0
6025529211	0	Khai. 🍉🍉	1	765	0	0	189.93000000000006	12	\N	0
1881972665	0	the dela #MDNI	0	1188	0	0	9.260000000000218	320	\N	0
1319865498	0	nad	0	24	0	0	0	25	\N	0
6896662972	0	die	3	159	0	0	688.0600000000001	1493	\N	0
7083080831	0	bangsa't	12	303	0	0	5.949999999999385	607	\N	1
6595089964	0	lauu	10	377	0	0	3.399999999999892	1264	\N	0
1935455213	0	msthcryxie	0	3	0	0	0	20	\N	0
7096662334	0	rara awr	7	207	0	0	-9.569999999999965	19	\N	0
6272476945	0	eca	0	7	0	0	0	0	\N	0
1638445915	0	♥︎ ،، axsa ˃ ⤙ ˂ ◗	11	686	0	0	2714.1400000000012	591	\N	1
6442396185	0	c	0	50	0	0	6	1226	\N	0
5839771132	0	Maudy	2	216	0	0	79.36000000000027	170	\N	0
6175517048	0	Kaluna	4	606	0	0	8.560000000000173	2805	\N	0
1934194292	0	jarkasa, lui's boyfriend	0	46	0	0	0	51	\N	0
6472394762	0	ttaa	0	18	0	0	0	7	\N	0
1848204083	0	𝐑ava.	11	2990	0	0	21297.680000000004	3694	\N	0
1598782576	0	Elsa	0	39	0	0	0	306	\N	0
5459101816	0	⋆˚࿔ Crista B’Sea 𝜗𝜚˚⋆	0	23	0	0	0	7	\N	0
6579663787	0	Jogi	0	4	0	0	0	5	\N	0
6737170097	0	bastian	0	1	0	0	0	0	\N	0
5848646005	0	shaaa	0	0	0	0	0	0	\N	0
5849185058	0	ᴇ͢xᴇ . ❅⃟ᴅsɴ .` ᴵᴰ╭‌ ࣭⸰♡ °᪤🎀 @𝗞ANAYA . ʟᴀ	0	4	0	0	14.900000000000006	0	\N	0
6264886526	0	Rendezvous	0	948	0	0	3422.8099999999995	274	\N	0
6031208345	0	k	0	48	0	0	1978	1	\N	0
1945476707	0	k/ia, nairà a.	5	1224	0	0	26832.890000000014	16637	\N	1
6582108599	0	cwe	0	10	0	0	2782	1	\N	0
1474105516	0	឵	12	91	0	0	511.27	204	\N	0
6381705029	0	dni	0	2	0	0	0	0	\N	0
5585145081	0	ㅤ	0	15	0	0	0	4	\N	0
1650985767	0	𝒅`𝑨𝒓𝒄𝒉𝒐𝒏 Arthe	0	194	0	0	5.5	139	\N	0
5588776060	0	canéle	14	748	0	0	18.029999999999987	2087	\N	0
1379658457	0	ay	0	59	0	0	0	5	\N	0
1765174562	0	fy	0	163	0	0	8.900000000000006	281	\N	0
5393086228	0	yuna	0	255	0	0	468.74	31	\N	0
6005364356	0	lazuiss	0	108	1	0	120	89	\N	0
7086664664	0	ael melon	0	1	0	0	0	0	\N	0
6729916337	0	f	0	5	0	0	0	7	\N	0
6334677159	0	al	0	71	0	0	0	20	\N	0
1885442965	0	s	0	11	0	0	0	7	\N	0
5176777631	0	kavi	0	27	0	0	579.26	44	\N	0
6980087103	0	Just A Cat,	0	1	0	0	0	0	\N	0
1922724911	0	D	5	62	0	0	35.29999999999973	834	\N	0
6216804159	1	Indra M	0	22	0	0	0	62	\N	0
1545545766	0	Bobo	0	95	0	0	757.51	5472	\N	0
7061090276	3	my do ~	0	9	0	0	0	0	\N	0
7099222045	1	🐰🎧	0	3	0	0	0	1	\N	0
6909404130	0	Hartono 🇸🇪	0	0	0	0	0	14	\N	0
1898587495	2	.	2	622	0	0	237.5799999999997	34	\N	0
1478997683	0	zar	0	5	0	0	0	315	\N	0
6326771700	2	:c	5	45	0	0	0	91	\N	0
1994165099	2	keicha carlisle.	0	228	0	0	679.2500000000001	700	\N	0
6987586130	0	Miguel	0	1	0	0	0	4	\N	0
5619041151	0	yow	0	1	0	0	0	0	\N	0
6104606147	0	۫ 𓋜 𝐓⁴⁰⋆ ࣪ ciaaaw	0	1	0	0	0	0	\N	0
5112682456	0	Nadiné C.	0	41	0	0	0	169	\N	0
6304520001	0	z	0	1	0	0	0	0	\N	0
6531397877	0	- 𝐁	0	3	0	0	0	0	\N	0
6753533499	0	joeyna 🪼	0	0	0	0	0	0	\N	0
1829591354	0	Daphne Pearl	0	91	0	0	0	26	\N	0
6410525945	0	alya	0	1	0	0	0	0	\N	0
5971432010	0	jarbie	0	7	0	0	83.19	6	\N	0
5580609546	0	Enn	0	5	0	0	0	6	\N	0
6344727152	0	ֶָ֢𐙚 sellà	0	10	0	0	0	0	\N	0
5917073066	0	b	0	15	0	0	0	0	\N	0
2028435025	0	💌 9324abul شذوذ	0	38	0	0	0	64	\N	0
6745606596	0	skala	0	16	0	0	411	194	\N	0
909566586	0	d	0	2	0	0	0	0	\N	0
6907695583	0	glen	0	4	0	0	0	1	\N	0
6842387111	0	˚₊ ꕨ 🩰 ࣪ ׅ𝅄 winnie ⪩⪨ ｡	0	1	0	0	0	0	\N	0
2025060633	0	Shèa.	2	47	0	0	0	370	\N	0
1705756843	0	liniel	0	172	0	0	0	37	\N	0
6472624958	0	karel	0	3	0	0	4500	40	\N	0
6009433970	0	awan tensāi	2	61	0	0	0	59	\N	0
1047578734	0	Y	0	13	0	0	19.11	29	\N	0
6953757190	0	n	0	67	0	0	0	22	\N	0
6024813677	0	.	0	74	0	0	0	10	\N	0
7123925965	0	vandra.	0	3	0	0	0	5	\N	0
7106442286	0	Nami, rechat.	0	6	0	0	0	17	\N	0
2085537687	0	satir	0	2	0	0	7.97	62	\N	0
6987202981	0	ell	0	39	0	0	0	8	\N	0
1393612518	0	jaeVvVv	11	5	0	0	3256.7800000000007	2872	\N	1
5464705893	0	Chico.	0	2	0	0	0	0	\N	0
7075049034	0	aesoo sobat	0	5	0	0	274.72	420	\N	0
780963510	0	melin	0	55	0	0	0	14	\N	0
2133843126	0	Mae	0	2	0	0	0	1	\N	0
6092967944	0	T	0	1	0	0	0	0	\N	0
1916699296	0	félis	0	19	0	0	4.579999999999998	11	\N	0
1914218921	0	key	0	133	0	0	0	0	\N	0
1618139833	0	!	0	383	0	0	7	502	\N	0
5008946290	0	Jovie, always open, rechat ke bot.	0	4	0	0	4.1200000000000045	69	\N	0
6297500368	0	offtele	0	17	0	0	0	36	\N	0
7031030603	0	Joe. Amorā awr	0	5	0	0	0	1	\N	0
7025945493	0	Zefan'ia	0	7	0	0	0	77	\N	0
7171064817	0	putriii	0	6	0	0	0	1	\N	0
5630004344	0	mie ayam	0	9	0	0	0	1	\N	0
6788347916	0	x	0	33	0	0	0	0	\N	0
1706307406	0	raka	0	478	0	0	503.9399999999998	239	\N	0
1542438906	0	ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ	1	1444	0	0	32465.55000000004	3085	\N	0
6468428440	0	nikzon	0	35	0	0	1328.69	3370	\N	0
2054039420	0	azmi	4	394	0	0	1057.5300000000009	6729	\N	0
6678904246	0	cwe jax	0	107	0	0	0	859	\N	0
1326639563	0	a	0	1	0	0	0	0	\N	0
6859407149	0	kiki	0	8	0	0	0	1	\N	0
5363277593	0	nd	0	23	0	0	941	49	\N	0
6592532018	0	Aress	0	16	0	0	0	10	\N	0
6769878138	0	nishimura's	0	3	0	0	0	0	\N	0
1140184040	0	Al	2	1228	0	0	22.579999999998716	4114	\N	0
6646037626	0	ᥣׁׅ֪ꪱׁׅꪀׁׅ	0	0	0	0	0	0	\N	0
7178776209	0	🌷	0	1	0	0	0	0	\N	0
6857799407	0	Natalia.	0	3	0	0	0	14	\N	0
5689847498	0	ㅤchitōs ōtsukioni	0	1	0	0	0	0	\N	0
1901909855	0	Z	10	2	0	0	1113.63	332	\N	0
2072632559	0	a	0	1	0	0	0	0	\N	0
6723027825	0	Aruna.	0	7	0	0	0	5	\N	0
6063479114	0	sese	0	144	0	0	20.189999999999998	110	\N	0
1466543960	0	FLORYN	0	35	0	0	0	342	\N	0
1498680832	0	fox	8	639	0	0	1997.5400000000022	3112	\N	0
7150802515	0	𖢷 ˚ ₊ ୨ 🌷𝗌𝖺𝗌𝗒𝖺 !♡ ˚ ⊹	0	4	0	0	0	9	\N	0
5367449999	0	◡̫࣪࣪ ♡̶ jae wife's	0	0	0	0	0	0	\N	0
2054410782	0	shei	0	10	0	0	0	33	\N	0
5114130953	0	yolA	0	2	0	0	0	0	\N	0
5402132778	0	𝐓𝐑≛𝐏𝐒 Algy' 𝑺𝑵 𝑂𝐴	0	4	0	0	0	0	\N	0
5649296722	0	lunaAAa	0	1	0	0	0	13	\N	0
6512121176	1	Ela	0	10	0	0	0	2	\N	0
6269270998	0	samone	0	61	2	0	2500	14	\N	0
6624044222	0	adibbb	0	8	0	0	0	2	\N	0
5346130941	0	Arniya	0	16	0	0	0	31	\N	0
1920463840	0	Sophea	0	0	0	0	0	0	\N	0
1938678568	0	nina$pacarasahi	0	90	0	0	10.870000000000005	148	\N	0
5688913863	0	R, Kanna	2	161	0	0	873.05	1296	\N	0
1842917435	0	Kunci	0	128	0	0	0	18	\N	0
5350398012	0	selyyyyyy	0	9	0	0	0	1	\N	0
6906546229	0	Lapian A. ׂ ݂ ੭	0	48	0	0	0	16	\N	0
5992734357	0	𐙚 ˙⋆keyl🅰️a⋆˙🎀	0	7	0	0	0	1	\N	0
2089029559	0	auudrey	0	4	0	0	0	0	\N	0
6999913967	0	Dyanftia	0	1	0	0	0	0	\N	0
6597432079	0	Mavis, S.	0	0	0	0	0	3	\N	0
1226915982	0	karellé 𝜗𝜚	13	58	0	0	3714.81	7618	\N	0
5934553742	0	dzian	0	15	0	0	0	0	\N	0
5895410168	0	majew, papar zicar	0	159	0	0	1371	3	\N	0
830972134	0	rian	0	334	0	0	20.850000000000023	2744	\N	0
5374954783	0	akbar	0	874	0	0	788.6000000000001	2385	\N	0
5325374588	0	Neca.	0	9	0	0	0	171	\N	0
7184571557	0	Elbara	0	17	0	0	0	12	\N	0
1535522810	0	Mewsie 🐈 Haechan's Lovetaker.	0	22	0	0	0	102	\N	0
6062744985	0	bulan	11	315	0	0	1380.8899999999992	612	\N	0
1817281056	0	idk	0	7	0	0	0	1	\N	0
5240898830	0	𝐇àzel	0	12	0	0	0	18	\N	0
6295932834	0	van	0	12	0	0	0	16	\N	0
1336704506	0	jadet	0	4	0	0	0	2	\N	0
1613587292	0	hiraaaa	3	607	0	0	1193.0600000000002	5492	\N	0
6342944546	0	ruwi	0	7	0	0	0	7	\N	0
5944750885	0	𝘍𝘭𝘦𝘶𝘳𝘪𝘯𝘦 𝘔𝘪𝘳𝘦𝘪𝘭𝘭𝘦'sh	0	174	0	0	62.18000000000001	1953	\N	0
5343125149	0	iya ini jean	0	463	0	0	0	2	\N	0
5950890648	0	🪺	14	518	0	0	3573.8999999999987	3224	\N	0
2137119259	0	eja	0	53	0	0	0	0	\N	0
6461326974	0	qy	0	279	0	0	11.45000000000016	908	\N	0
6612029255	0	t𝖎an - 𝐨𝐩𝐞𝐧 𝐟𝐬𝐫	4	363	0	0	918.1800000000001	865	\N	0
6567507061	0	ca	0	20	0	0	0	6	\N	0
5615325736	0	shia 𝓵𝓪𝓷ꋬ𝚍𝚎𝚕𝙖	0	38	0	0	0	7	\N	0
7057438463	0	Larasss	0	2	0	0	0	0	\N	0
1833084894	0	veganta	0	418	0	0	3013.5	101	\N	0
1801051775	0	netnott	0	46	0	0	1279.2099999999998	25	\N	0
6790706740	0	theara	0	54	0	0	0	184	\N	0
7071896347	0	kalila, z.	0	2	0	0	68.10999999999996	416	\N	0
5878634523	0	Mahendra	0	0	0	0	0	4	\N	0
1421160038	0	klie abimasta	0	0	0	0	0	0	\N	0
5233539063	0	Arka	0	4	0	0	0	0	\N	0
1862325059	0	atika	0	741	0	0	106.96000000000001	647	\N	0
5991952421	0	hulk pink kokwet 🎀🎀	0	3	0	0	21.86	9	\N	0
1277106234	0	Nathalie	0	655	0	0	0	57	\N	0
1266838220	0	D	0	1	0	0	0	0	\N	0
6169408485	0	𐙚 angēl	0	1	0	0	0	0	\N	0
6512534635	0	jiell 🌷	0	2	0	0	0	1	\N	0
1950280420	0	Rinjani	0	1	0	0	0	0	\N	0
5815585664	0	Zan	0	1	0	0	0	0	\N	0
1660468123	0	moja	0	1	0	0	0	0	\N	0
6211650847	0	𝒃𝒊𝒍𝒂𝒂 fast resp , ig @bilaa.nae	0	2	0	0	0	5	\N	0
1919922658	0	ayaa awr •ᴗ•	0	8	0	0	0	1	\N	0
1771085382	0	zani depresi	0	396	0	0	1283.8600000000001	2769	\N	0
5591682623	0	lily	0	7	0	0	0	42	\N	0
1258837858	0	ar	0	253	0	0	398.11000000000007	36	\N	0
5430150372	0	faisss	0	1	0	0	0	2	\N	0
1907960214	0	va.	9	96	0	0	395.21000000000026	22	\N	0
1917153632	0	d	0	201	0	0	18.930000000000007	96	\N	0
6701436681	0	n	0	1	0	0	0	0	\N	0
6310143659	0	lila	0	17	0	0	0	13	\N	0
1435551507	0	kyyyy	0	9	0	0	0	0	\N	0
1953430053	0	.	0	130	0	0	210.93000000000004	12	\N	0
1900061568	0	joyyyyyyfull	0	135	0	0	0	123	\N	0
1610812103	0	PPP	0	31	0	0	0	239	\N	0
6378686702	0	Rex. R	0	2	0	0	0	0	\N	0
6445150161	0	sarah	0	29	0	0	9.89	12	\N	0
6376042028	0	acel	0	12	0	0	0	3	\N	0
6651705908	0	mellody. ౨ৎ	0	4	0	0	0	0	\N	0
5359873565	0	sha	12	178	0	0	196.2600000000001	302	\N	0
6595140411	1	qia	0	96	0	0	0	1	\N	0
6383176685	1	𝑺𝑵 senn¹⁶⁴ #𝐎𝐑𝐂𝐓𝐙	5	38	0	0	784.4700000000001	483	\N	0
7184421688	2	P	0	142	0	0	19	6	\N	0
2005500110	1	ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ	1	153	0	0	445.1999999999992	2735	\N	1
6048475543	0	Noel	0	38	0	0	0	140	\N	0
6933424115	0	shannine	0	4	0	0	15.56	23	\N	0
5743183599	0	jo	0	64	0	0	0	110	\N	0
5569840763	0	hipaa	0	29	0	0	0	11	\N	0
6424147907	0	Alya	0	4	0	0	0	5	\N	0
1697814165	0	K. Anjani	0	52	0	0	0	38	\N	0
6757949614	0	capricorn🦄	0	2	0	0	0	4	\N	0
5538598186	0	𝗘ᥙᥒᥕ᥆ᥒ	0	14	0	0	89.31	72	\N	0
6488752018	0	Kִׂαִׂ໋ׅׅ֗ȶׂׅs	0	3	0	0	478	11	\N	0
7194824506	0	𝖐𝖆𝖗𝖑	0	9	0	0	0	4	\N	0
1628514803	0	sasĸιd'	0	6	0	0	0	5	\N	0
6189939042	0	Cy!	0	2	1	0	0	1	\N	0
7102559256	0	cᧉꪱꪱy !	0	8	0	0	0	40	\N	0
1854866937	0	ㅤd̾v	9	3181	0	0	7.4200000000005275	7280	\N	0
6639101471	0	Michaell J.	0	57	0	0	0	120	\N	0
6553014951	0	cawaa sedih	0	60	0	0	8	261	\N	0
1272007593	0	cha	0	198	0	0	1265.1	126	\N	0
5184872528	0	ciwaa awr	0	10	0	0	0	0	\N	0
6425649550	0	lana	0	69	0	0	0	3	\N	0
7101280086	0	AAAAAAA	0	2	0	0	0	0	\N	0
5161116669	0	a.	0	3	0	0	0	0	\N	0
5638279833	0	alaa	0	18	0	0	2.950000000000003	98	\N	0
5990516449	0	Manusia itu tidak bodoh cuma malas aja	9	1979	0	0	2.100000000000364	1166	\N	0
1787256160	0	akira	0	2	0	0	0	17	\N	0
7159426488	0	Adnan Hussein.	0	1	0	0	0	0	\N	0
7188020024	0	Vellyn	0	1	0	0	0	0	\N	0
678265263	0	🧁	0	90	1	0	950	494	\N	0
5215607808	0	achellll	13	1112	0	0	185.43000000000006	938	\N	0
6928740116	0	Hanafi Ghifariel.	0	7	0	0	0	11	\N	0
1499873406	0	keire.	0	70	0	0	0	81	\N	0
5000720577	0	Re	0	5	0	0	28	19	\N	0
5250658826	0	🍉	0	1615	0	0	9.5	3096	\N	0
6511396800	0	karin	0	166	0	0	0	284	\N	0
6996925041	0	P	0	4	0	0	0	0	\N	0
6754958224	0	outta reach	0	24	0	0	0	2	\N	0
1743300786	0	-1	0	0	0	0	0	2	\N	0
1325076453	0	awa	0	1	0	0	0	0	\N	0
6953120772	0	strwb'ry toria	0	1	0	0	0	0	\N	0
1440436071	0	hira	5	222	0	0	1890.52	446	\N	0
6849868644	0	On duty —	0	92	0	0	2.960000000000008	1169	\N	0
1526773747	0	kyl	0	2	0	0	0	3	\N	0
6588054309	0	Jonāthan E.	0	0	0	0	0	0	\N	0
6384769984	0	cymbercy	0	2	0	0	0	0	\N	0
2037603117	0	rinn	0	49	0	0	1380	8	\N	0
5596416821	0	key.	0	2	0	0	0	4	\N	0
6875575274	0	Daayyy	0	6	0	0	0	8	\N	0
7136511954	0	.	0	70	0	0	0	3	\N	0
5409938983	0	calice	0	47	0	0	0	15	\N	0
5496080171	0	karin	0	13	0	0	0	0	\N	0
5381004699	0	J.	0	895	0	0	0	245	\N	0
1791090231	0	K	0	142	0	0	297.03	72	\N	0
1869070242	0	094 jasmine	0	65	0	0	0	186	\N	0
6909996203	0	nay	0	3	0	0	0	1	\N	0
5505489385	0	neo nie	13	279	0	0	1594.9799999999998	1775	\N	0
5835836224	0	YHM	0	6	0	0	0	4	\N	0
6141644511	0	nano	0	7	0	0	0	1	\N	0
2056273491	0	Brandon	0	20	0	0	0	0	\N	0
1658714265	0	j	0	292	0	0	0.21000000000000085	126	\N	0
2028461627	0	aileen's alter ego	0	59	0	0	484.9200000000001	173	\N	0
1378003685	0	L.	0	51	1	0	172.77	9	\N	0
5227269157	0	꧁ঔৣ ᵘᶻᵘᵐᵃᵏⁱ𖧹メɴᴀʀᴜᴛᴏ ঔৣ꧂	0	0	0	0	0	25	\N	0
5183250409	0	𖥦 𝐚𝐬𝐡𝐞. 🎡 ࣪ ᵎᵎ ˖ ་ㅤ	0	8	0	0	14.56	141	\N	0
6432857447	0	fany	0	1	0	0	0	0	\N	0
6208797633	0	𝐕aera	0	13	0	0	441	0	\N	0
6929591163	0	Rere	0	8	0	0	0	1	\N	0
6537577524	0	Spideeumine	0	1	0	0	0	0	\N	0
1326323762	0	Cianneth	0	23	0	0	0	828	\N	0
2100997364	0	Priel Majore.	13	69	0	0	150.45	153	\N	0
1890887968	0	A	0	51	0	0	0	146	\N	0
7026199951	0	Tiko 🃏	0	78	0	0	0	3	\N	0
1435861035	0	nda	3	581	0	0	1060.3899999999999	194	\N	0
6847212288	0	kala	0	25	0	0	0	6	\N	0
1724128860	0	alan leaving	0	5	0	0	0	0	\N	0
5627044213	0	ailsie.	0	1	0	0	0	31	\N	0
6970077692	0	-	0	5	0	0	0	0	\N	0
5864573613	0	iykyk	0	2	0	0	0	0	\N	0
5084728201	0	rwin	0	24	0	0	2291.41	1895	\N	0
6958721429	1	key	0	7	0	0	0	7	\N	0
6163880471	3	Vell	0	164	0	0	0	119	\N	0
1624813956	0	Eyyoo	0	1	0	0	0	1	\N	0
6374238292	0	Hau	0	8	0	0	0	4	\N	0
6221687477	0	belca	0	15	0	0	0	50	\N	0
6767857825	0	killa	0	2	0	0	0	0	\N	0
6767963495	0	Zayya	0	24	0	0	0	11	\N	0
1092946160	0	Abid, back to iel lovetaker's	0	1	0	0	0	2	\N	0
6165900671	0	Jeremy pacar giselle	0	2	0	0	0	45	\N	0
6385409603	0	cilung aslie	3	164	0	0	1016.8799999999949	1046	\N	0
2020986184	0	Sele	0	20	0	0	0	911	\N	0
1752764273	0	Lenka or Rey!	0	138	0	0	0.6499999999999986	140	\N	0
6472188672	0	d333ll🥶🥶	0	13	0	0	7.27	3	\N	0
7149642161	0	joe	0	4	0	0	0	0	\N	0
5205437280	0	c	0	1	0	0	0	0	\N	0
7090280999	0	Talitha	0	2	0	0	0	0	\N	0
5349568209	0	Bellyna🫧	0	2	0	0	206.82	227	\N	0
5336243383	0	athar	0	64	0	0	3.829999999999842	9	\N	0
6960318265	0	hen	0	9	0	0	0	0	\N	0
5535387628	0	j's	0	175	0	0	1198.4	9	\N	0
6819191128	0	kei	0	61	0	0	0	6	\N	0
6129898134	0	ᵂʰʸNOT🍬	0	0	0	0	0	2	\N	0
6971882416	0	Martin	0	27	0	0	0	11	\N	0
6569690748	0	Lonely cigarette	14	83	0	0	1185.87	372	\N	0
6148495624	0	sa	0	2	0	0	0	0	\N	0
6900481448	0	𝙲𝚑𝚘 𝚄𝚖𝚊𝚛𝚞, slr	0	88	0	0	1769	61	\N	0
6257184998	0	Karel.	0	5	0	0	292.19	379	\N	0
6424920687	0	os	0	266	0	0	0.7599999999999909	4	\N	0
7091707129	0	Mashella	0	7	0	0	0	0	\N	0
5567807415	0	Vexxa	11	1529	0	0	123.83000000000058	3417	\N	0
7164183344	0	vober	0	18	0	0	0	42	\N	0
1354286030	0	ai	13	742	0	0	746.0899999999989	1731	\N	1
6790774847	0	honeyy	0	1	0	0	0	6	\N	0
1547552871	0	930	11	134	0	0	3043.84	1396	\N	0
7146272914	0	🐱_______🐶_______🐰______🐼_______🐹___	0	8	0	0	55	1	\N	0
5759853212	0	Xxxxxxxx	0	132	1	0	44.06999999999999	87	\N	0
6991327636	0	백 kárin	0	2	0	0	0	1	\N	0
1988518916	0	安吉塔. ᴹᴵᴳ٭s	0	1	0	0	0	0	\N	0
1634690892	0	𐙚 ִֶָ ° 𝐂esya 𝐋ivie 𓍯 ִֶָ	0	6	0	0	0	1	\N	0
1860256432	0	el	0	90	0	0	0	7	\N	0
6622932613	0	who’s thatt?!! 👀	0	130	0	0	664	77	\N	0
6939415200	0	ashela	0	0	0	0	0	0	\N	0
6867986747	0	shi	0	1	0	0	0	1	\N	0
7107241350	0	vava	0	59	0	0	0	61	\N	0
2038382127	0	p	0	1	0	0	0	1	\N	0
5041239942	0	Nicho	0	150	0	0	723.3600000000004	555	\N	0
5046208874	0	AL	0	1	0	0	325.8	83	\N	0
6924296053	0	.	0	6	0	0	0	2	\N	0
5159358264	0	nebula oc	0	2	0	0	0	0	\N	0
1710434018	0	gioo 4twenty	1	161	0	0	1248.31	287	\N	0
5891286453	0	Ajessllyne	0	4	0	0	0	2	\N	0
6287322318	0	c	0	5	0	0	0	0	\N	0
6743890651	0	Brennä Elâlia.	0	1	0	0	0	0	\N	0
6270538916	0	tara	0	20	0	0	0	0	\N	0
6706441745	0	Me	0	140	0	0	0	0	\N	0
6653769579	0	Isyaqill, M	0	8	0	0	0	2	\N	0
1418181877	0	Diw	8	10	0	0	47.450000000000045	209	\N	0
5640020372	0	Jo	0	2	0	0	0	0	\N	0
6666159253	0	☠️☠️☠️	0	1	0	0	0	0	\N	0
7114371429	0	Abjisaka Gamaliel	0	4	0	0	0	0	\N	0
5997203694	0	cheriee	0	12	0	0	0	80	\N	0
1907484962	0	Asher.	3	40	0	0	0	90	\N	0
5019280350	0	nana	13	736	0	0	1012.8699999999999	2729	\N	0
1495126988	0	Soniya	10	107	0	0	597.4199999999993	1176	\N	0
6193220490	0	saa	0	5	0	0	0	0	\N	0
5804858677	0	sian	0	253	0	0	0	3	\N	0
6762165502	0	S	0	2	0	0	0	0	\N	0
5686640783	0	Y	0	3	0	0	0	2	\N	0
6154849143	0	Evelyn	0	452	0	0	0	1	\N	0
6613494098	0	star	0	8	0	0	0	0	\N	0
6888350376	0	Gibran	0	8	0	0	0	0	\N	0
5136877253	0	Pribumi	0	7	0	0	0	63	\N	0
5898531095	0	b	12	1541	0	0	2098.069999999998	2997	\N	0
1971295253	0	C	0	104	0	0	0	4	\N	0
6329308807	2	ais	0	240	0	0	13	9	\N	0
5554354843	3	Kinaa.	0	413	0	0	7.280000000000101	129	\N	0
5718222957	1	jeje	14	160	0	0	5446.41	2457	\N	0
5496536024	1	pororo	4	119	0	0	9228.130000000001	15347	\N	0
6773634293	0	ar	0	5	0	0	0	19	\N	0
6234546912	1	k	10	194	0	0	53.68000000000001	50	\N	0
2040346100	0	𖦹๋࣭ 𝗰 𝗳𑄝ׅ𝗿 𝗰ᥱ𝗰ᥱ 𓍢ִ໋ ˖ ⑅	0	65	0	0	0	0	\N	0
5358286927	0	bintang	0	53	0	0	0	339	\N	0
6224729177	0	.	7	40	0	0	2187.3900000000003	7074	\N	0
6713858642	0	Lawine ༚ ꒰͡ 𐙚 ͡꒱ ༚	0	57	0	0	0	461	\N	0
5627979219	0	mou	0	262	0	0	980.0799999999999	5804	\N	0
6204160212	0	Sukma — R'adena	0	7	0	0	0	0	\N	0
5247089223	0	denoos	0	9	0	0	3298.7599999999998	919	\N	1
1867472933	0	Adelee	0	130	0	0	2014.9999999999998	3852	\N	0
1598395270	0	Rizal	0	2	0	0	500	2	\N	0
1148098207	0	Ler	6	0	0	0	0	700	\N	0
1431395402	0	rvl². b8海	0	28	0	0	0	85	\N	0
1698247288	0	cia	0	31	0	0	0	20	\N	0
5215422068	0	🐭	0	971	1	0	14.75	5523	\N	0
5481654716	0	vallez	0	5	0	0	0	102	\N	0
7081114013	0	-	0	5	0	0	0	95	\N	0
1427978538	0	gng	0	99	0	0	0	4	\N	0
6039559108	0	alanaa	0	15	0	0	0	19	\N	0
5026472902	0	kira	13	601	0	0	1440.7600000000002	1802	\N	0
1993572924	0	Ken	0	100	0	0	0	11	\N	0
7163542072	0	Personal	0	5	0	0	0	6	\N	0
6229887450	0	Azka Azikra Putra	0	99	0	0	0	32	\N	0
6517350807	0	candu kluyut	0	36	0	0	0	85	\N	0
6822983926	0	Josh #SEACOUPLE	0	49	0	0	0	0	\N	0
6574689401	0	K	0	104	0	0	0	670	\N	0
6634645768	0	aurelie. @UMJlf	0	1	0	0	0	5	\N	0
7069962509	0	ronaaa	0	2	0	0	0	7	\N	0
5254552324	0	nara	0	369	0	0	5.43	49	\N	0
5866268080	0	.	0	184	0	0	-2	0	\N	0
5794541097	0	kaninaaw 🦋	0	97	0	0	2752	805	\N	0
6230167070	0	...	11	311	0	0	13097.770000000002	391	\N	0
7164111641	0	.	0	30	0	0	0	5	\N	0
6468681442	0	niaww🎐୨୧	0	136	0	0	29.329999999999927	95	\N	0
1721708695	0	Winata	0	33	0	0	100	50	\N	0
6400265620	0	erick • js²	0	143	0	0	0	133	\N	0
1998738795	0	slctv.Sagara	0	4	0	0	0	0	\N	0
6022170580	0	c	0	6	0	0	0	0	\N	0
6092235493	0	risaa	0	2	0	0	0	0	\N	0
2069499804	0	fir	0	4	0	0	0	0	\N	0
5439546512	0	sha	0	22	0	0	0	0	\N	0
6153060460	0	lyana	0	2	0	0	0	1	\N	0
5068739021	0	.	0	1	0	0	169.95999999999998	17	\N	0
1604944738	0	arbie	0	13	0	0	0	0	\N	0
5659273685	0	rhacel	0	1	0	0	0	0	\N	0
1784492971	0	d	0	11	0	0	45	0	\N	0
6476340897	0	Aldera	0	2	0	0	0	0	\N	0
6312925514	0	Sopiii	0	2	0	0	0	0	\N	0
1621617034	0	nemoo⚡🐰🪻𖤍	0	276	0	0	254.99000000000018	328	\N	0
7132200657	0	Sate ayam makmur	0	3	0	0	0	0	\N	0
5031299022	0	gak usah rep, langsung ke rc	0	11	0	0	0	1	\N	0
1660186727	0	Marvel	0	1	0	0	0	6	\N	0
6844843331	0	amandalina	0	1	0	0	15.86	4	\N	0
1345295261	0	laney b.	13	714	0	0	1956.76	7279	\N	0
1927338441	0	Arumi Halisa.	4	5	0	0	8217.430000000004	7671	\N	0
2013665057	0	444.kayes	0	16	0	0	200	26	\N	0
1971432994	0	?	0	4	1	0	0	2	\N	0
6931159423	0	jess	0	2	0	0	0	0	\N	0
6254088956	0	k	0	1	0	0	0	0	\N	0
5757841809	0	𝐒handara 𝐀	0	0	0	0	0	0	\N	0
5135836073	0	biru	0	68	0	0	0	65	\N	0
6989628985	0	Abizar	0	7	0	0	0	35	\N	0
6941693213	0	aninn	2	22	0	0	100	445	\N	0
5604191671	0	Rizec.	0	5	0	0	0	12	\N	0
5732552355	0	deborasya, not replying	0	6	0	0	0	3	\N	0
2024904207	0	NYANYA	0	40	0	0	0	229	\N	0
6372617157	0	Gabriel	0	4	0	0	0	2	\N	0
6209233346	0	dio	0	38	0	0	1019.8	522	\N	0
5942325454	0	Uhuy	0	67	0	0	0	32	\N	0
5731701435	0	c	0	52	0	0	0	6	\N	0
5329605649	0	Nadine	0	5	0	0	0	0	\N	0
5013112008	0	vello 𝑺𝑵	0	14	0	0	0	58	\N	0
5183334823	0	Lin	0	1	0	0	0	0	\N	0
1874896265	0	kavi	0	1030	0	0	11	862	\N	0
1777027097	0	Ulun	10	1319	0	0	30382.780000000002	28492	\N	1
5001845155	1	Kadiesaa	0	6	0	0	0	0	\N	0
1616151080	0	ㅤ	8	63	0	0	5529.120000000001	10	\N	0
5036468651	0	🧜🏻‍♀️	0	127	0	0	21.72999999999999	86	\N	0
1905970558	0	na	0	1	0	0	0	0	\N	0
6399030689	0	naraa 𝐬𝐭𝐳𝐠¹ #RPRL	0	3	0	0	0	0	\N	0
6500170428	0	???	0	14	0	0	0	27	\N	0
2051620526	0	💤	0	4	0	0	0	0	\N	0
7112395956	0	나 alèiia LAGI EPEP AN	0	20	0	0	316.31	28	\N	0
6252551803	0	Adraffan Phelion	14	276	1	0	59.21000000000035	55	\N	0
1379523695	0	Abc5dasar	3	881	0	0	1032.9200000000008	824	\N	0
5077763056	0	nya	0	49	0	0	0	175	\N	0
6400611354	0	188	0	1	0	0	0	1	\N	0
6734218820	0	Lily	0	1	0	0	0	0	\N	0
6142678053	0	K	0	117	0	0	0	50	\N	0
5954732827	0	-	0	14	0	0	0	1	\N	0
6547540224	0	meca	0	5	0	0	0	0	\N	0
1546769078	0	winery	0	36	0	0	46	0	\N	0
6943956766	0	Bibi	0	119	0	0	0	0	\N	0
1082549093	0	j	0	37	0	0	0	58	\N	0
1846641375	0	Hira . ୨୧	10	208	0	0	1855.42	1119	\N	0
5984050992	0	caa	0	30	0	0	0	42	\N	0
1899895417	0	hegar	0	11	0	0	0	14	\N	0
5865426098	0	bastian	0	5	0	0	0	1	\N	0
1037979847	0	ㅤㅤㅤㅤㅤㅤㅤ	0	24	0	0	0	0	\N	0
6039363559	0	[ 𝐒𝐡𝐢𝐨 ] 𝕭як¹	0	10	0	0	0	1	\N	0
6206794012	0	pudu :]	0	1	0	0	0	0	\N	0
5120749944	0	.	0	77	0	0	0	3	\N	0
7055794951	0	Renz 👽👑	0	4	0	0	0	1	\N	0
6559117020	0	𝐊aatiya	0	14	0	0	0	3	\N	0
5599621180	0	Dea Adiptara.	0	14	0	0	0	66	\N	0
1932974084	0	ann	13	1299	0	0	1679.4699999999993	10686	\N	0
5950728642	0	sielass	0	22	0	0	0	7	\N	0
1608420081	0	kaja	0	360	0	0	2206	338	\N	0
6464053846	0	kucing sleding	0	28	0	0	0	7	\N	0
5288883166	0	san’s serotonin boost, abe.	0	243	0	0	1948.8200000000004	544	\N	0
7045873141	0	Kalèa G.	0	13	0	0	0	0	\N	0
7011599636	0	ᅠ😂	0	19	0	0	0	133	\N	0
1360766517	0	Dinooo	0	15	0	0	0	10	\N	0
1915676428	0	ijey	0	29	0	0	0	64	\N	0
5841779461	0	a	0	9	0	0	0	0	\N	0
5022707770	0	diem lu	0	11	0	0	0	27	\N	0
5062277865	0	noah	0	92	0	0	0	42	\N	0
5845449650	0	Mirabelle Bukater	0	1	0	0	0	64	\N	0
2041159204	0	DeXi	0	1	0	0	0	1	\N	0
5909589622	0	𝙣𝙖𝙤	0	3	0	0	0	0	\N	0
1842956147	0	🎀 ׅ ۫ ⊹ ♡ Eireena Aichie!୧ ׅ ۫ ⑅𝔮𝅦🇬🇩	0	42	0	0	0	75	\N	0
1394559410	0	︎ ︎ ︎ ︎	0	130	0	0	0	1	\N	0
1010923870	0	ઽ⍺ઽ⍺–ᥴჩiყo :VvV	0	208	0	0	43.889999999999986	165	\N	0
6672450204	0	ra	0	9	0	0	0	1	\N	0
1430405502	0	ad¡raa	0	2	0	0	0	47	\N	0
5865686838	0	Randy	0	1	0	0	0	1	\N	0
6219805148	0	alya	0	2	0	0	0	0	\N	0
5863488167	0	sheyra	0	11	0	0	0	5	\N	0
2123954839	0	Gapin	0	2	0	0	0	0	\N	0
1759189466	0	Kiaaa	0	14	0	0	0	13	\N	0
5697310299	0	Cowok Anime	0	1	0	0	0	1	\N	0
5911276262	0	Kenneth Karta	0	33	0	0	0	16	\N	0
5993069330	0	bian 𝗗𝗬𝗪ʷᵃᵏᶦˡ	0	1	0	0	0	0	\N	0
5825808857	0	vic.	0	3	0	0	0	0	\N	0
6195066235	0	ra	11	340	0	0	682.79	1664	\N	0
5363667561	0	vi	0	7	0	0	0	4	\N	0
6776931699	0	DAZZ🐟	0	1	0	0	0	5	\N	0
5629652351	0	nix	0	27	0	0	0	25	\N	0
2048870891	0	Megan's	0	1	0	0	0	0	\N	0
1771863912	0	ㅤlio	0	181	0	0	2658.91	403	\N	0
6707630808	0	𝐘𝐧𝐳𝐞𝟑	0	1	0	0	0	0	\N	0
5935613246	0	Kalana Sofia 🌷🍣🎟🩰🎀🩷💅🏻💃🏻🍓🧁🎧🎠	11	322	0	0	218.03	205	\N	0
2072902226	0	annika tjoe a on øts	0	55	0	0	0	9	\N	0
1319406892	0	Aca	0	434	1	0	19.039999999999736	198	\N	0
1430034374	0	805.saa	0	18	0	0	0	0	\N	0
5549477033	0	awa	0	2	0	0	0	0	\N	0
6488706049	0	Nay	0	1	0	0	0	0	\N	0
5721031735	0	nazeera.	10	163	0	0	0	167	\N	0
1955314841	0	Naya	0	97	0	0	0	4	\N	0
1045999953	0	Serena Sacha.	0	680	0	0	210.3599999999995	1067	\N	0
6235767893	1	j	0	178	0	0	0	139	\N	0
6209054200	0	Sendy	0	7	0	0	0	242	\N	0
1630522391	0	nini	0	0	0	0	0	0	\N	0
5674831522	0	Zie	0	1	0	0	0	0	\N	0
1918803533	0	Sea.	0	18	0	0	0	149	\N	0
5074733604	0	Maximus	0	0	0	0	0	0	\N	0
1807827427	0	Z	0	0	0	0	0	0	\N	0
5560009670	0	Leo	0	32	0	0	0	89	\N	0
6671878947	0	Man	0	42	0	0	0	67	\N	0
6023115993	0	s	0	32	0	0	9.43	0	\N	0
6369912991	0	🧚🏻‍♀️ Camorra	0	5	0	0	0	13	\N	0
6564874025	0	Pelangi	0	65	0	0	782	722	\N	0
6274333696	0	Ai	0	8	0	0	0	115	\N	0
6719219624	0	lulu ✧˚ ·	0	1	0	0	0	0	\N	0
1748692097	0	vallin	0	25	0	0	0	92	\N	0
6077361982	0	jaja	0	4	0	0	0	0	\N	0
921175609	0	Ama	0	1	0	0	0	0	\N	0
7083990148	0	Ara pingin ngiseng	0	0	0	0	0	0	\N	0
5042885534	0	Meidiana F.	0	1	0	0	0	0	\N	0
6922170526	0	“h,niscala” .. 매우 작은	0	0	0	0	0	0	\N	0
1892434813	0	k	0	15	0	0	0	0	\N	0
1783800197	0	!	0	377	0	0	18	47	\N	0
1486169433	0	s	0	291	0	0	3652.4500000000003	1290	\N	0
6590816168	0	j	0	117	0	0	63.43000000000001	249	\N	0
5350688529	0	Melisa	0	18	0	0	212	0	\N	0
1815408921	0	.	0	1	0	0	0	0	\N	0
5888165492	0	Käva helokanjut	0	57	0	0	0	41	\N	0
1854188424	0	kavi	0	2	0	0	0	1	\N	0
1167479370	0	.	0	15	0	0	0	26	\N	0
1369710250	0	lizz	0	93	0	0	0	14	\N	0
1996198376	0	jake's gf.	8	83	0	0	563.1999999999999	2	\N	0
1855603244	0	raya 🇵🇸	0	540	0	0	42.790000000000106	7308	\N	0
6210744387	0	sean norris	0	9	0	0	0	0	\N	0
5308435677	0	Ganteng	2	348	0	0	4694.040000000002	6363	\N	0
5904875966	0	d	3	732	0	0	3.9900000000002365	2024	\N	0
1814785180	0	f	4	432	1	0	84.85999999999999	702	\N	0
1565392450	0	isa	11	178	0	0	5813.16	300	\N	0
2133000182	0	jarve	0	42	0	0	0	2	\N	0
2076939800	0	Eyaa	13	1305	0	0	327.4399999999996	3037	\N	0
5447910932	0	kacau balau	0	1	0	0	0	4	\N	0
5315866350	0	Aliyah?	0	9	0	0	500	4	\N	0
6649442512	0	.	0	7	0	0	0	2	\N	0
6970403018	0	adel	0	22	0	0	0	136	\N	0
1853419785	0	a	0	2	0	0	0	0	\N	0
1803485417	0	aninnn	0	1150	0	0	3213.5499999999993	10056	\N	0
6176879765	0	v	0	2	0	0	0	1	\N	0
2064269145	0	callea .1445	0	26	0	0	0	106	\N	0
6650684484	0	a	0	9	0	0	0	0	\N	0
1273157740	0	jae	0	7	0	0	0	0	\N	0
1305246665	0	😛	0	13	0	0	0	1	\N	0
6379219411	0	️️️️️️️️️️️️️J.	0	36	0	0	0	105	\N	0
6562517995	0	sall ˚｡ ୨୧⋆	0	9	0	0	0	0	\N	0
1893770439	0	UFS @ Wfnwoo	0	9	0	0	0	6	\N	0
2003472954	0	el	0	1	0	0	0	0	\N	0
1440554060	0	Meguira	0	14	0	0	0	0	\N	0
5428793543	0	miaw miaw miaw miaw 🐈🐈🐈🐈🐈🐈🐈	0	20	0	0	0	73	\N	0
1371757781	0	Cityyy	6	45	0	0	961.8299999999999	200	\N	0
1456750431	0	kinal 4est	0	2	0	0	0	0	\N	0
5569187432	0	rez	0	3	0	0	0	0	\N	0
5596894708	0	yyyannn	0	28	1	0	0	28	\N	0
6446539783	0	jemwaaa	0	1	0	0	0	0	\N	0
5879474830	0	🐻	0	36	0	0	1483.97	16	\N	0
6218734418	0	ara	0	22	0	0	0	2	\N	0
6393852084	0	thisstuck	0	10	0	0	0	9	\N	0
6245028780	0	deyvana	0	0	0	0	0	0	\N	0
5852951797	0	sy	0	4	0	0	0	9	\N	0
6429261178	0	umi alEni	0	5	0	0	0	5	\N	0
1291208515	0	Keiyzshayang	4	343	0	0	1663.6800000000005	787	\N	0
1778279821	0	Ayasa	0	35	0	0	0	0	\N	0
5901560755	0	𝐓𝐑≛𝐏𝐒 `A 𝑺𝑵	0	3	0	0	52.4	53	\N	0
6724329650	0	𝐇yujinn	0	3	0	0	0	11	\N	0
1394413859	0	🫧	0	648	0	0	45.38000000000001	1265	\N	0
5818236838	0	sya	0	2	0	0	0	0	\N	0
6875420969	0	yya	0	3	0	0	0	0	\N	0
7067737902	0	Ai	0	1	0	0	0	0	\N	0
6803159682	0	Nin	0	1	0	0	0	1	\N	0
6924970087	0	`𝐊𝐀𝐉𝐄𝐅	0	8	0	0	0	0	\N	0
5854235054	0	bakpia	0	4	0	0	0	2	\N	0
6584632716	0	Bangchan's little girl, Amore.	0	11	0	0	0	76	\N	0
5039448973	1	— nát ʚɞ	0	307	0	0	4.020000000000003	59	\N	0
6749992548	0	sasa	0	76	0	0	0	8	\N	0
6381808943	0	kAlilac💋	0	2	0	0	0	5	\N	0
922524382	0	~ _ 0	6	14	0	0	352.94999999999993	314	\N	0
6755186254	0	h3llena 💋 rlly g mood.	0	13	0	0	0	58	\N	0
6695064807	0	E. Adam	0	5	0	0	0	4	\N	0
1458295045	0	Gladys	0	444	0	0	0	6	\N	0
6245477017	0	sheila	7	75	0	0	605.8399999999999	590	\N	0
1418047763	0	224.megan	0	27	0	0	0	115	\N	0
6671361161	0	.	0	2	0	0	0	0	\N	0
6008733772	0	na	7	393	0	0	760.97	428	\N	0
5113821431	0	sharkie 🦈💭	0	16	0	0	0	0	\N	0
5815033694	0	｡· re	0	0	0	0	0	0	\N	0
7104895959	0	saya	0	1	0	0	0	0	\N	0
6633036500	0	mine	0	1	0	0	0	0	\N	0
6762985689	0	pajel 4twenty	0	11	0	0	262.98	391	\N	0
6145554489	0	戦ᴍᴛᴢɪ	10	305	0	0	1329.6699999999998	1181	\N	0
1486622590	0	lauraa	10	467	0	0	0.57000000000005	5969	\N	0
6274292468	0	adiss	0	33	0	0	433	81	\N	0
1987488628	0	Regan	0	54	0	0	0	5	\N	0
5334192022	0	A	0	118	0	0	14.190000000000055	1258	\N	0
6714196562	0	melle	0	4	0	0	1134	0	\N	0
6999771627	0	cin	0	0	0	0	0	0	\N	0
7157813329	0	Elleamore, Namira.	0	26	0	0	13	17	\N	0
1333107628	0	?	13	1382	0	0	2.850000000004833	520	\N	0
5791098713	0	aimira monarch	0	173	0	0	203.28999999999996	174	\N	0
6176786471	0	balsem	0	20	0	0	4.78	17	\N	0
7195157337	0	tracey ramah lingkungan	0	6	0	0	0	19	\N	0
6920599865	0	yossey	0	7	0	0	0	255	\N	0
1724539348	0	lin	0	59	0	0	0	34	\N	0
6993035610	0	Arièl Van G	0	61	0	0	0	7	\N	0
6828757669	0	caca	0	10	0	0	0	0	\N	0
1602841364	0	Zico	1	237	0	0	1055.3899999999999	1171	\N	0
6909207720	0	erina✿ S83	0	2	0	0	0	0	\N	0
6258914038	0	Ca	0	17	0	0	0	3	\N	0
1534414788	0	sasha	0	72	0	0	0	0	\N	0
5901687886	0	Empty	3	5	0	0	725.3100000000001	2	\N	0
7027894441	0	𝜗𝜚 .. oline	0	56	0	0	0	0	\N	0
1843648726	0	yessa	0	5	0	0	0	2	\N	0
520848262	0	Gol	0	14	0	0	0	60	\N	0
6399984666	0	Lannn	0	30	0	0	234	35	\N	0
6276554004	0	c🎀	14	149	0	0	0	16	\N	0
1608933174	0	Vaska	0	9	0	0	0	102	\N	0
1654732531	0	Rayla 4twenty	0	60	0	0	0	27	\N	0
5823945440	0	Mattheo Ajarifh	0	3	0	0	0	2	\N	0
1828738539	0	女孩 ─ Nēy-ria Càrtner :	0	1	0	0	0	0	\N	0
1819735161	0	𝐀𝐜𝐡𝐚	0	10	0	0	0	0	\N	0
5010706409	0	Acha	0	2	0	0	0	0	\N	0
1994190991	0	noyes	0	7	0	0	0	271	\N	0
7071907806	0	a 👾	0	3	0	0	0	12	\N	0
5820711436	0	Heru	0	61	0	0	1639.4099999999999	137	\N	0
5273048291	0	JØSE	0	55	0	0	0	0	\N	0
6534955534	0	༄●⃝Mr.Zera࿐	0	40	0	0	0	7	\N	0
1207024713	0	flop	0	14	0	0	0	1	\N	0
6735282133	0	kylie	0	17	0	0	0	0	\N	0
1681276989	0	୨୧	0	664	0	0	0	0	\N	0
6754730101	0	𝐍akula. ōtsukisan	0	67	0	0	0	1	\N	0
6363231468	0	K.	0	58	0	0	0	1	\N	0
5669065825	0	aries	0	464	0	0	157.3800000000001	1004	\N	0
6856439939	0	Ayça	0	35	0	0	0	241	\N	0
1605753114	0	kael.	0	105	0	0	0	4	\N	0
5972509325	0	Wajib	0	38	0	0	14.07	60	\N	0
6954158788	0	VG.	0	1	0	0	0	0	\N	0
6253676866	0	Y	0	1	0	0	0	13	\N	0
6092557005	0	wit	0	2	0	0	0	5	\N	0
5977552165	0	Bielka (view era)	0	1	0	0	100	6	\N	0
5172819377	0	mocimi	0	3	0	0	0	5	\N	0
5588972596	0	bung	0	193	0	0	0	117	\N	0
5561397674	0	𝓐 qis 𐙚	0	1	0	0	0	1	\N	0
6632511380	0	awa	0	2	0	0	0	2	\N	0
1673176957	0	kayana :p	0	9	0	0	0	508	\N	0
7132839748	0	c	0	1	0	0	0	0	\N	0
6305800498	0	Adamn	0	19	0	0	0	37	\N	0
5928144254	0	ccc.	0	62	0	0	202	15	\N	0
5200563977	0	A	0	0	0	0	0	0	\N	0
5418943339	0	ci🅰	0	27	0	0	26.13	45	\N	0
6444710622	0	𓇻֢ ׁ .... “ARCHiE!”	0	10	0	0	0	3	\N	0
5167458468	0	.	13	395	0	0	1170.68	154	\N	0
6511988162	0	vibell	0	38	0	0	10	26	\N	0
1331795473	0	mav	0	1519	1	0	223.63999999999987	254	\N	0
1997769984	0	.	0	0	0	0	0	0	\N	0
5283390671	0	galen [ wone's ] turu dek	0	252	0	0	215.38	203	\N	0
6617747344	0	𝐏𝐑𝐀𝐃𝐄𝐄𝐏𝐀	0	5	0	0	0	15	\N	0
5254193093	0	DANIEL X PASUKAN HOBAH	0	0	0	0	0	1	\N	0
5148419926	0	dess	0	71	0	0	0	2	\N	0
7196457971	0	j	0	1	0	0	0	0	\N	0
6105709526	0	choe	0	1	0	0	286.42	6	\N	0
2016587452	0	jēsselyn	0	15	0	0	0	54	\N	0
5054251363	0	Adham H.	5	918	0	0	3657.37	1623	\N	0
5051939739	0	~	0	1	0	0	0	0	\N	0
6907614999	0	sanabi	0	0	0	0	0	0	\N	0
1276017242	0	sera	0	42	0	0	0	4	\N	0
6655458289	0	𓍯kay	0	11	0	0	0	13	\N	0
5682991188	0	Kaieslaa	0	46	0	0	0	27	\N	0
6953390468	0	M.	0	90	0	0	2.8400000000000034	11	\N	0
1685949373	0	amii	0	182	0	0	0	16	\N	0
6611549458	0	c	0	9	0	0	0	71	\N	0
5026705124	0	The madame. Èithar 🫧	0	244	0	0	1813.02	68	\N	0
6341659914	0	spix	0	5	0	0	5000	17	\N	0
5740222006	0	La	0	1	0	0	0	0	\N	0
5246477880	0	eyla	0	1542	0	0	-5.830000000000069	704	\N	0
1715633477	0	arsen	12	706	0	0	2381.43	947	\N	0
6113073556	0	cici	0	51	0	0	389	205	\N	0
7038054542	0	ⓙ	0	84	0	0	214.33999999999997	147	\N	0
5248061851	0	raaa	0	15	0	0	0	2	\N	0
2071682935	0	elbiaa	0	5	0	0	0	21	\N	0
6167937797	0	gebii	0	7	0	0	0	3	\N	0
1703168267	0	kalea.ೃ࿐	0	53	0	0	0	7	\N	0
6384543424	0	kara	0	4	0	0	0	1	\N	0
6857746037	0	caca marica hey hey	0	5	0	0	0	3	\N	0
1532280083	0	Ren Sturniolo	0	91	0	0	485	92	\N	0
1640568608	0	sha	0	43	0	0	0	0	\N	0
7086533618	0	vi	0	1	0	0	0	2	\N	0
1568844367	0	r🅰️d	0	214	0	0	13	46	\N	0
6879615383	0	Ajeng Sartika	0	1	0	0	0	1	\N	0
5279645130	0	Idenn	0	2	0	0	13.09	11	\N	0
5352107980	0	seul	0	28	0	0	0	545	\N	0
1587246980	0	lang always lonely	0	2	1	0	0	0	\N	0
6916367575	0	wiloop	0	7	0	0	0	1	\N	0
1864207430	0	deca	0	12	0	0	0	15	\N	0
6311958931	0	....	0	1	0	0	0	0	\N	0
6440564081	0	p	0	4	0	0	0	2	\N	0
7098591571	0	kentot	0	3	0	0	0	4	\N	0
5914197577	0	ūna	0	1	0	0	0	0	\N	0
1353334421	0	Bieflyra.	0	1	0	0	0	0	\N	0
5428892670	0	.	0	3	0	0	0	4	\N	0
5194861713	0	.	0	2	0	0	0	8	\N	0
1995333943	0	BellaAaa	0	5	0	0	0	0	\N	0
5348974513	0	Alzaya Djeva	0	1	0	0	0	0	\N	0
1857973883	0	hazuki	0	1	0	0	0	0	\N	0
6134551748	0	k	0	18	0	0	0	0	\N	0
930701560	0	biya	5	439	0	0	898.1399999999999	1275	\N	0
1867720380	0	ijaa	0	22	0	0	0	51	\N	0
6142970378	0	sabreena	0	25	0	0	0	19	\N	0
7079519198	0	sasa	0	5	0	0	0	0	\N	0
6408176865	0	Luna	0	12	0	0	0	16	\N	0
5081770425	0	ollie motor	8	5349	1	0	6.735000000001037	37639	\N	0
1655188328	0	Mey the kid	0	1	0	0	0	574	\N	0
6419791888	0	𝐓𝐑≛𝐏𝐒 `shaa	0	30	0	0	104	4	\N	0
7094584707	0	𝐓ara	0	4	0	0	0	1	\N	0
7133193181	0	zura	0	8	0	0	0	0	\N	0
7170668001	0	ɳαყαα🧚‍♀️	0	4	0	0	0	0	\N	0
7079467100	0	N Roter! Open Kuota, Pulsa, CV	0	1	0	0	0	49	\N	0
6583769450	0	Nanap	0	85	0	0	0	0	\N	0
1804776231	0	c	7	167	0	0	7342.009999999999	1437	\N	0
5719706357	0	arthur	4	511	0	0	2.6499999999996255	69	\N	0
5846312215	0	.	0	0	0	0	0	0	\N	0
6429890046	0	sky	0	0	0	0	0	0	\N	0
6716941093	0	javarensaa	0	4	0	0	0	0	\N	0
5878739371	0	anee	0	3	0	0	0	0	\N	0
1675794539	0	Ay	10	218	0	0	1878.0099999999998	498	\N	0
5967812115	0	Lyanniee	0	2	0	0	0	1	\N	0
5815067112	0	ㅤ	0	84	0	0	62.579999999999984	36	\N	0
1793530595	0	Ayay	0	587	1	0	1426.8500000000004	924	\N	0
6342320297	0	Gama, ini seller pls udh pasti fsr	0	6	0	0	24.08	11	\N	0
1949786268	0	ran	0	6	0	0	0	135	\N	0
1617164015	0	ai ai	4	115	0	0	1371.65	202	\N	0
1090974855	0	A	0	1	0	0	0	2	\N	0
1794534394	0	kai	0	383	0	0	0	0	\N	0
6505405559	0	Tyexie H.	0	1	0	0	0	0	\N	0
5482483821	0	karin.	0	25	0	0	0	35	\N	0
1229235658	0	audy galau bet	0	6	0	0	50.42000000000171	1	\N	0
6206580187	0	Merleay	0	10	0	0	0	74	\N	0
2028170640	0	bilOoo	0	29	0	0	0	10	\N	0
7054485551	0	Nanta	0	1	0	0	0	0	\N	0
6696673954	0	karel	0	1	0	0	0	0	\N	0
5268496264	0	Aerassel Rachleirè, lsgk.	0	18	0	0	0	43	\N	0
836480436	0	Kiä	6	578	0	0	58.769999999999214	599	\N	0
1788200526	0	Brixyna	0	75	0	0	293.87	39	\N	0
5358791562	0	karel	0	285	0	0	458.78999999999996	646	\N	0
6079464919	0	mil’s	0	7	0	0	0	5	\N	0
6872920604	0	Arabella	0	7	0	0	0	8	\N	0
2057044436	0	tita sayang echanie	0	1	0	0	0	2	\N	0
5766750635	0	dni. noe	0	3	0	0	0	1	\N	0
1343430345	0	Elkairo A.	0	6	0	0	0	4	\N	0
5009293026	0	key 🚩	0	673	0	0	-13.620000000000012	201	\N	0
5041818205	0	K.	0	241	0	0	0	128	\N	0
6378795932	0	.	0	3	0	0	0	36	\N	0
5621633602	0	lanaa	0	191	0	0	4.25	83	\N	0
1826805586	0	Keane.	8	122	0	0	3875.109999999999	3274	\N	1
6934533672	0	lei	0	86	0	0	117.36000000000001	229	\N	0
1705258137	0	Nadeola.	0	118	0	0	13	801	\N	0
1497064114	0	zii	0	2	0	0	0	30	\N	0
2049797873	0	liam	0	296	1	0	1375.71	178	\N	0
6605350340	0	naka	0	10	0	0	0	1	\N	0
1336541990	0	dy	0	7	0	0	0	24	\N	0
5540424352	0	ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ	0	3	0	0	0	4	\N	0
6881940042	0	KaYRa T—T	0	85	0	0	220	262	\N	0
6019476819	0	p for peju bg	0	1	0	0	100	67	\N	0
6590852542	0	🚗__🚕__🚙__🚌__🚎__🏎__🚓__🚑__🚐__🚒__	0	31	0	0	0	12	\N	0
5040258245	0	Hara	0	8	0	0	0	64	\N	0
6457880283	0	s	0	12	0	0	0	0	\N	0
6335896936	0	mona	0	6	0	0	0	0	\N	0
5132900634	0	I'm yours	0	11	0	0	0	3	\N	0
5045111491	0	Bargaskara	0	3	0	0	0	8	\N	0
5900818731	0	r	0	70	0	0	5	11	\N	0
5277656797	0	Diana	11	43	0	0	11572.689999999982	12228	\N	1
1612625943	0	esgit	0	10	0	0	0	0	\N	0
5581210111	0	Al	0	2	0	0	0	0	\N	0
6764499872	0	athen	0	1	0	0	0	0	\N	0
6532798794	0	hrrxa	0	1	0	0	0	0	\N	0
6791769400	0	𝐓𝐑≛𝐏𝐒`grey	0	10	1	0	0	0	\N	0
5219607445	0	.	0	7	1	0	2460	16	\N	0
1771496157	0	return @Dukeh to Arlan	14	136	0	0	37	1296	\N	0
6986163748	0	qiyo	0	7	0	0	0	1	\N	0
1723848344	0	Ruelèy Maeve	0	14	0	0	0	71	\N	0
2099039334	0	sl.	0	1	0	0	0	2	\N	0
6172893928	0	𝗻︪︩ׄ𝝰᷁	6	131	0	0	12888.130000000001	242	\N	0
1907344107	0	Alva	0	23	0	0	492.69	143	\N	0
5666747333	0	Rynnê	0	4	0	0	0	0	\N	0
6907206737	0	S	0	28	0	0	0	18	\N	0
6539586744	0	asya	0	4	0	0	0	1	\N	0
1683810090	0	la luna	0	41	0	0	0	800	\N	0
5763020442	0	Yosha. D	0	5	0	0	0	1	\N	0
6884619285	0	C'Lozar kyla.	0	9	0	0	0	1	\N	0
5235983840	0	ceii	0	9	0	0	0	33	\N	0
5573405974	0	️️️	0	4	0	0	0	19	\N	0
1838745666	0	aya	0	3213	0	0	4825.62	19703	\N	0
5236951576	0	fl	14	46	0	0	312.8999999999997	140	\N	0
1283558765	0	gaaaa	0	11	0	0	0	282	\N	0
6708485377	0	mOoishella	0	5	0	0	0	0	\N	0
5400386257	0	j	0	35	0	0	0	65	\N	0
6142054519	0	ciua	0	6	0	0	0	4	\N	0
1696452055	0	A	0	88	0	0	859.4200000000003	39	\N	0
5577375271	0	Kyou.	0	3	0	0	0	0	\N	0
6574798530	0	@Ssanzu, Kal.	0	17	0	0	0	35	\N	0
6200915071	0	Thalassa Feyya	8	15	0	0	4863.510000000002	147	\N	0
1470111333	0	Hazard.	0	15	0	0	0	0	\N	0
5943068547	0	Okkotsu Hanel =D	0	3	0	0	0	9	\N	0
2138466010	0	khala	0	173	0	0	262.89	99	\N	0
5600787398	0	atama	0	0	0	0	0	0	\N	0
5997229326	0	Ur girl	5	352	0	0	43.229999999999905	598	\N	0
6097622574	0	Aylie.	0	3	0	0	0	15	\N	0
6760479762	0	Afana	0	0	0	0	0	0	\N	0
2135285396	0	ilooo	0	1	0	0	0	0	\N	0
1882450535	0	Nadipal	0	8	0	0	0	20	\N	0
5258670659	0	Kiira	0	61	0	0	978	2	\N	0
2125309163	0	ana.	0	39	0	0	0	85	\N	0
1984934895	0	giyo :<	8	87	0	0	1494.34	1560	\N	0
1861384659	0	hanum	0	19	0	0	0	0	\N	0
5047489885	0	Gondes.	0	1	0	0	0	0	\N	0
819540582	0	Kiki	0	7	0	0	0	7	\N	0
6244979237	0	ᴍᴠɴ. zakiel	0	4	0	0	0	3	\N	0
1321467163	0	Nasha R.	0	0	0	0	0	0	\N	0
5540531047	0	ara	0	2	0	0	0	0	\N	0
5467574173	0	Mikel	0	3	0	0	0	0	\N	0
6452280208	0	pipiii	2	40	0	0	219.51	25	\N	0
5498499351	0	Love	4	578	0	0	1178.9499999999998	61	\N	0
5012174829	0	leen	0	108	0	0	0	0	\N	0
5234332823	0	𓆏 funky	0	4	0	0	0	11	\N	0
1348020794	0	.	8	1	0	0	0	0	\N	0
6778660524	0	j	0	7	0	0	0	0	\N	0
6492334325	0	Mecca,	0	11	0	0	3220	42	\N	0
5527735357	0	ptr. bargo	0	9	0	0	0	0	\N	0
6159655929	0	ʀᴇʏ	0	75	0	0	0	115	\N	0
5443186414	0	Aubrya.	4	189	0	0	6.5499999999999545	91	\N	0
1701010513	0	lifaa	0	656	0	0	2	94	\N	0
7036375444	0	cecee	0	15	0	0	0	25	\N	0
7194411277	0	mwemew	0	77	0	0	0	0	\N	0
5212529719	0	Ezekiel's Princess, Abel ^~~^	0	90	0	0	1029.28	708	\N	0
1651415599	0	amettaₑₛᵩ	0	2	0	0	0	10	\N	0
6195906519	0	mary	0	3	0	0	0	0	\N	0
1780982949	0	s	0	1	0	0	0	0	\N	0
1582718222	0	Hasan	0	1	0	0	0	0	\N	0
5015131335	0	KIN	0	1	0	0	0	0	\N	0
5589274033	0	filia	0	17	0	0	18.66	128	\N	0
7057236403	0	sasa	0	1	0	0	0	0	\N	0
1455371916	0	za	0	158	0	0	8.469999999999999	36	\N	0
6826505378	0	Biubiu	0	2	0	0	478	2	\N	0
5666856218	0	🅃🄰🅂🅈🄰	0	29	0	0	0	6	\N	0
5406075848	0	-𝐋	0	5	0	0	69.09	18	\N	0
5808841523	0	Lulu ><	0	8	0	0	1178	0	\N	0
2065934921	0	$haacov •𝙺ˢᵍ	0	2	0	0	0	3	\N	0
1333131660	0	kireii calysia	14	498	0	0	1549.94	944	\N	0
1494418780	0	yvesss	0	19	0	0	0	21	\N	0
6453242942	0	Ouyinn	0	14	0	0	0	3	\N	0
6309476748	0	GR3333😜🫶🏼	0	28	0	0	0	9	\N	0
6719310577	0	j	0	15	0	0	0	4	\N	0
1938072749	0	k	0	311	0	0	1.5500000000000114	78	\N	0
6005113610	0	dito	0	17	0	0	0	135	\N	0
5827900052	0	Nar	0	1	0	0	0	0	\N	0
5950268566	0	belva.	0	4	0	0	0	5	\N	0
5597091508	0	nay	0	1	0	0	0	23	\N	0
1711805064	0	cimilikitiw	14	63	0	0	1162.3100000000002	4315	\N	0
5301598496	0	Kesya	0	5	0	0	0	0	\N	0
1974398673	0	Nando	0	1	0	0	0	0	\N	0
5728010467	0	Clover-lay	0	4	0	0	0	2	\N	0
5828459691	0	lxry. catrine	0	46	0	0	0	0	\N	0
1796925500	0	k	0	13	0	0	0	4	\N	0
6198001981	0	rayhan	0	156	0	0	9.280000000000655	782	\N	0
6765180082	0	ryan`	0	0	0	0	0	1	\N	0
6586850755	0	aurora	0	63	0	0	0	630	\N	0
6461426193	0	szha	0	27	0	0	50	43	\N	0
6451074157	0	Adara	0	10	0	0	0	0	\N	0
6545154990	0	Ka-zu カズ	0	13	0	0	0	0	\N	0
1924337744	0	clay's	0	0	0	0	0	0	\N	0
6863855974	0	pian. fake subs phobic	0	1	0	0	0	0	\N	0
5721865241	0	nata	0	2	0	0	0	1	\N	0
1773662281	0	pebrianaji	0	6	0	0	0	99	\N	0
6222522285	0	¿	0	1	0	0	0	0	\N	0
5844356555	0	pralam	0	1	0	0	0	0	\N	0
1789493682	0	TYAAAAAAA	0	125	0	0	0	15	\N	0
1755487998	0	Rigel	0	8	0	0	0	14	\N	0
1481948312	0	Neco Roozan	0	39	1	0	0	86	\N	0
6356035566	0	Boa	0	2	0	0	0	1	\N	0
6577167618	0	r e a h	0	1	0	0	0	0	\N	0
5484386594	0	khnia	0	1	0	0	0	0	\N	0
5321363129	0	karen	0	49	0	0	816.5	23	\N	0
1739585756	0	Acel	0	2	0	0	0	8	\N	0
2079347152	0	bewbew	0	23	0	0	0	3	\N	0
6912822010	0	Muffyn Kensington.	0	1	0	0	0	0	\N	0
1692193868	0	Plavrinë	0	2	0	0	0	0	\N	0
5965308829	0	ian	0	156	0	0	91.72000000000003	804	\N	0
1709462179	0	biyaf	0	4	0	0	0	9	\N	0
5849150092	2	hanindya	3	946	0	0	427.36000000000024	881	\N	0
2099267574	0	🪼	0	7	0	0	0	28	\N	0
7154422718	3	memekgram	0	78	0	0	0	141	\N	0
1199006343	0	ira vk.	0	68	0	0	0	121	\N	0
2042222149	0	H	0	325	0	0	0	46	\N	0
1663266871	0	cáy	0	9	0	0	63.97	0	\N	0
6234919533	0	Kaitharas Winata	0	5	0	0	21.12	3	\N	0
1843944579	0	예쁜.	1	781	0	0	2794.5800000000036	6439	\N	0
1825107695	0	felyn	0	2	0	0	0	0	\N	0
5811027216	0	𝘝𝘢𝘯𝘦𝘴𝘩𝘢 𝘊𝘢𝘴𝘴𝘢𝘯𝘰	0	64	0	0	0	2	\N	0
1881039832	0	yettaa	0	61	0	0	7.750000000000002	107	\N	0
5241041972	0	Wulan	0	24	0	0	0	41	\N	0
1234256264	0	licie	0	233	0	0	0	123	\N	0
1740667817	0	Jess	0	0	0	0	0	0	\N	0
1715030433	0	anyak	14	359	0	0	8603.58	1886	\N	0
6466897060	0	ash	0	3	0	0	0	0	\N	0
6136681048	0	Migel. 🍂	0	9	0	0	0	1	\N	0
5797156040	0	G-NoSide	0	53	0	0	0	672	\N	0
6618379048	0	🦖	4	34	0	0	54.889999999999745	21	\N	0
6336435192	0	lex	0	77	0	0	0	8	\N	0
6002099576	0	biya	0	19	0	0	975	26	\N	0
6071469689	0	archié bobo	0	6	0	0	41.68	368	\N	0
1577147344	0	k	0	321	0	0	0	298	\N	0
5865217167	0	949. cilá. Neow` #606	0	11	0	0	0	11	\N	0
6340069824	0	n.	0	78	0	0	10.980000000000018	116	\N	0
5436348480	0	hans	0	1	0	0	0	0	\N	0
6657249830	0	33	0	1	0	0	0	0	\N	0
6029535180	0	keiko libby	0	14	0	0	0	3	\N	0
5122824911	0	ayos	1	582	0	0	668.4399999999439	24406	\N	1
6111954177	0	eca	0	0	0	0	0	1	\N	0
1929436159	0	oya	0	19	0	0	0	32	\N	0
7060332843	0	Sereia D.Gellamy	0	1	0	0	0	0	\N	0
6138601483	0	Glen A.	0	1	0	0	0	0	\N	0
5507852455	0	anakmama	0	15	0	0	0	47	\N	0
5390364206	0	j	0	92	0	0	0	1	\N	0
1843766820	0	ia	0	547	0	0	3539.42	127	\N	0
5303232146	0	Rafael	0	2	0	0	0	0	\N	0
5273887428	0	.	7	228	0	0	6403.879999999999	280	\N	0
5479478608	0	LuciNotCare	0	3	1	0	9.78	50	\N	0
5223955531	0	Arzylla	0	19	0	0	0	13	\N	0
5481967951	0	annie	0	4	0	0	0	0	\N	0
5662672926	0	fezzy	0	23	0	0	0	0	\N	0
1588889741	0	d	0	2	0	0	0	0	\N	0
1998098511	0	귀여워 ✦ Hαilᥱy	0	0	0	0	0	3	\N	0
5965217722	0	Faye	0	3	0	0	0	0	\N	0
1653381016	0	.	0	23	0	0	0	0	\N	0
5102031877	0	Daisy ✿`	0	66	0	0	1560	81	\N	0
1981969313	0	Vi	0	1	0	0	0	0	\N	0
1909817196	0	dooo	0	0	0	0	0	0	\N	0
7112214229	0	greasily, e!	0	1	0	0	0	0	\N	0
1762413988	0	Edward	0	8	0	0	51.92	174	\N	0
6360206944	0	Ananta.	0	33	0	0	0	135	\N	0
6431038304	0	rere	0	0	0	0	0	0	\N	0
5657816686	0	koya	0	8	0	0	0	0	\N	0
5122886090	0	j	0	43	0	0	0	0	\N	0
6917719841	0	ubiiiyaaa`	0	2	0	0	0	3	\N	0
1583895610	0	Wawa pgn ke glory	0	4	0	0	0	4	\N	0
6271250680	0	Marg	0	14	0	0	35	23	\N	0
1466697245	0	ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ	0	7	0	0	0	2	\N	0
5626712492	0	nana	0	29	0	0	0	38	\N	0
2119552965	0	Dex	0	35	0	0	0	82	\N	0
6302767588	0	j	0	8	0	0	0	3	\N	0
6588588337	0	.	0	5	0	0	0	0	\N	0
6574651756	0	L	0	44	0	0	554	121	\N	0
5391716801	0	naw	0	1	0	0	0	0	\N	0
1984953341	0	Saylee	0	136	0	0	0	89	\N	0
1818943849	0	hᥲᥒเꫀ	0	33	0	0	0	39	\N	0
5301787090	0	altarel	0	5	0	0	0	1	\N	0
7133624766	0	Jennaraa	0	2	0	0	0	0	\N	0
5685427125	0	noya, Hadley.	0	3	0	0	0	2	\N	0
5906912088	0	irfan	0	9	0	0	99.61	1	\N	0
6913650259	0	Challto	0	10	0	0	0	0	\N	0
5692232326	0	catty ,	0	0	0	0	0	7	\N	0
1226496151	0	Nida’an, H	0	0	0	0	0	0	\N	0
1077615363	0	SN	0	2	0	0	0	3	\N	0
1318290967	0	Adeknya Winwin	0	0	0	0	0	9	\N	0
1218704772	0	Rey	0	1	0	0	0	5	\N	0
1227648176	0	...	0	1	0	0	0	0	\N	0
5299438431	0	Kylie	0	3	0	0	0	1	\N	0
5466982328	0	Lalaa	0	12	0	0	0	30	\N	0
6378050543	0	ju	0	16	0	0	0	120	\N	0
5258737803	0	jeki chan	0	13	0	0	0	26	\N	0
6374315859	0	kenny	0	1	0	0	0	0	\N	0
6208813381	0	melody	0	1	0	0	0	1	\N	0
2088386352	0	.	0	713	1	0	6.189999999999998	1401	\N	0
6294544480	0	keya	0	3	0	0	0	1	\N	0
1866511531	0	D/Don Legoᵈˢˣ	0	36	1	0	53.03000000000005	44	\N	0
6285780264	0	die	10	104	0	0	4	58	\N	0
5769947143	0	t	0	25	0	0	0	31	\N	0
5219038477	0	L	0	2	0	0	0	0	\N	0
1378195671	0	888	0	1	0	0	0	0	\N	0
6401719018	0	pipaw	0	5	0	0	0	2	\N	0
2133367298	0	w	0	28	0	0	0	19	\N	0
5070728523	0	A.	0	26	0	0	14.720000000000113	113	\N	0
5018295657	0	kaile	1	1067	0	0	1717.1100000000006	2796	\N	0
5862364620	0	me	0	2	0	0	0	8	\N	0
5907371853	0	Elise.	0	6	0	0	0	0	\N	0
5631577883	0	shelfaa	0	0	0	0	0	0	\N	0
5595070196	0	Anasera.s	0	2	0	0	0	4	\N	0
1860003871	0	cibe srz	0	56	0	0	1770.3600000000001	39	\N	0
6253901564	0	Damian	0	56	0	0	12	47	\N	0
5436902236	0	Adriana Agatha	0	0	0	0	0	0	\N	0
5613234571	0	💋	0	2	0	0	0	2	\N	0
656457288	0	Dennji	0	8	0	0	0	1	\N	0
5825694721	0	Desti	0	39	0	0	0	14	\N	0
6529051990	0	ai	0	5	0	0	0	0	\N	0
2056063686	0	matcha	0	5	0	0	0	0	\N	0
6403352521	0	𐙚 “ .. seanna “ 🪷	0	1	0	0	0	0	\N	0
5868138892	0	aisy	0	0	0	0	0	0	\N	0
6235020037	0	ce'ce	0	0	0	0	0	32	\N	0
1786229057	0	Paniii!	0	8	0	0	0	5	\N	0
5614023685	0	sheena mestara	0	21	0	0	0	76	\N	0
1840643900	0	belle	0	1	0	0	0	0	\N	0
5422648715	0	v	0	5	0	0	0	3	\N	0
803414076	0	Damn.	0	2	0	0	0	2	\N	0
6267737726	0	enay	0	1	0	0	0	1	\N	0
1514792585	0	idk	0	88	0	0	0	21	\N	0
1859595347	0	Jerov B.	0	40	0	0	96	14	\N	0
1388320905	0	F	0	51	0	0	0	16	\N	0
1992910862	0	Abizar.	0	13	0	0	0	44	\N	0
5575717382	0	Chyeffello.	0	19	0	0	62.47	0	\N	0
1433267674	0	Ron	0	4	0	0	0	8	\N	0
1930630701	0	✹⃟ᶜ̶ˢ̶̶̶̶͢͢͢ⁱ̶ shel 𝖝	0	38	0	0	26.689999999999998	92	\N	0
5159522309	0	L	0	61	0	0	0	1	\N	0
5397559416	0	ndaaaa	0	3	0	0	0	0	\N	0
6365096977	0	Maddie	0	6	0	0	0	1	\N	0
6358900697	0	69	0	5	0	0	0	0	\N	0
6050827503	0	Winca Acatya.	0	2	0	0	0	11	\N	0
1580498027	0	𝐊e͏y͏r͏αα,	0	4	0	0	500	791	\N	0
1744498810	0	.	0	24	0	0	0	0	\N	0
5362842051	0	244marko	0	35	0	0	0	0	\N	0
6765295160	0	wooft aj	0	12	0	0	0	3	\N	0
1684495575	0	oce, open jasa buat qris	0	2	0	0	0	42	\N	0
1721256415	0	joe	10	553	0	0	1029.19	627	\N	0
6584240570	0	aii	0	5	0	0	0	9	\N	0
1983467773	0	eka	0	0	0	0	0	38	\N	0
1756526756	0	Kennie	0	2	0	0	0	3	\N	0
1720679810	0	DNFI. adek bobo	0	5	0	0	0	16	\N	0
1687247175	0	505	0	27	0	0	133.24	2	\N	0
5692792062	0	Joshua, Supremacist	0	17	0	0	0	66	\N	0
2041188284	0	⚶	0	4	0	0	0	1	\N	0
6316873128	0	b	0	1	0	0	0	0	\N	0
5127926969	0	james Voltigure	0	0	0	0	30	5	\N	0
5268103425	0	k	0	3	0	0	0	0	\N	0
5272122299	0	000	0	21	0	0	0	31	\N	0
6702836634	0	userwrrrruww	0	28	0	0	0	0	\N	0
1129630961	0	gm	0	1	0	0	0	0	\N	0
5316984481	0	asa	0	157	0	0	627	25	\N	0
6914071105	0	ayaa	0	1	0	0	0	0	\N	0
2140100001	0	alvlen	0	0	0	0	0	0	\N	0
6572385642	0	Alfajor	0	49	0	0	107.61000000000001	726	\N	0
6026420388	0	aihara mei	0	7	0	0	0	2	\N	0
5802073783	0	nala	0	10	0	0	0	0	\N	0
5293170245	0	Kate	0	1	0	0	0	0	\N	0
6773751737	0	f	0	31	0	0	0	29	\N	0
2056100576	0	hwanchacoou	0	95	0	0	0	0	\N	0
2021558777	0	cleo	0	1	0	0	0	0	\N	0
2144516591	1	Nawa salima	0	8	0	0	0	60	\N	0
5885660320	0	peler	0	7	0	0	0	2	\N	0
5149596629	0	bibipay ᴴᴸ ʀʀᴡ	0	1	0	0	0	0	\N	0
6124155667	0	Denjaka. sabulan	0	6	0	0	0	3	\N	0
6287364274	0	isye	3	25	0	0	3563.3199999999997	2422	\N	0
7018934653	0	Reina. HARI INI AKU US 😔😔😔😔	0	13	0	0	0	7	\N	0
1331630152	0	dudun	0	1	0	0	0	0	\N	0
1723983200	0	eesh	0	1	0	0	0	0	\N	0
6014974772	0	al	0	13	0	0	0	0	\N	0
5114970997	0	apr	0	26	0	0	0	9	\N	0
2145839511	0	Yea	0	4	0	0	0	0	\N	0
1928122543	0	dira	0	3	0	0	0	18	\N	0
5229959092	0	𝐓𝐑≛𝐏𝐒 `yayöse	0	5	0	0	0	12	\N	0
1788187587	0	@Nayesaka	0	1	0	0	0	0	\N	0
6110056503	0	TEMP — Tyiössa.	0	1	0	0	0	0	\N	0
1803280555	0	k/ia. chitaa :3	0	8	0	0	0	7	\N	0
6985777650	0	hyunnjeee	0	203	0	0	104	390	\N	0
6654317625	0	ᅠ	0	39	0	0	0	1	\N	0
5781271066	0	Malf. hobi nya pending	0	0	0	0	0	0	\N	0
5670087343	0	mantu umi kmu	0	19	0	0	0	50	\N	0
1812876343	0	Haris	0	1	0	0	0	0	\N	0
5805786130	0	shᥱnᥲ	0	1	0	0	0	9	\N	0
5559175248	0	Samuel	0	1	0	0	0	7	\N	0
5644460410	0	shizu	0	1	0	0	0	0	\N	0
5574065271	0	Geisha	0	1	0	0	0	4	\N	0
1988579852	0	.	0	1	0	0	0	0	\N	0
5596499894	0	mili	0	4	0	0	0	12	\N	0
6109087723	0	Zee • Joki tugas | open	0	17	0	0	0	0	\N	0
6032491678	0	Misha	0	6	0	0	39.39	0	\N	0
6883271292	0	A	0	1	0	0	0	0	\N	0
5820536525	0	j	0	3	0	0	0	11	\N	0
5912677241	0	MJ NYAMNYAMBYAM.	0	11	0	0	0	0	\N	0
5085473015	0	kiaaa	0	6	0	0	0	18	\N	0
5621386550	0	ivy	0	2	0	0	0	0	\N	0
6203391610	0	ya	0	158	0	0	550.22	510	\N	0
5185345368	0	a	0	6	0	0	0	0	\N	0
6723012027	0	k	0	14	0	0	0	2	\N	0
6473342648	0	m #achacantikpacartsuki☝️😋	0	5	0	0	0	4	\N	0
5320628632	0	bukan popo	0	4	0	0	0	14	\N	0
750361118	0	d	0	2	0	0	0	0	\N	0
2058221203	0	Nevara.	0	6	0	0	0	24	\N	0
6114407642	0	Archen J	0	164	0	0	269.29999999999995	132	\N	0
5241843564	0	mavizar	0	51	0	0	0	138	\N	0
6573882740	0	Pusipaw	0	5	1	0	63	0	\N	0
2047057924	0	Rinn・♡🌷	0	2	0	0	0	2	\N	0
6923885903	0	k	0	4	0	0	0	1	\N	0
6040035777	0	aye	0	8	0	0	533.21	6	\N	0
1546128533	0	Ikyy	0	2	0	0	0	5	\N	0
1272549553	0	abian anjay mabar propesional	0	1	0	0	0	1	\N	0
6641396046	0	celine	0	7	0	0	0	1	\N	0
6073829207	0	raga.034	0	1	0	0	18.26	0	\N	0
5482467872	0	bakso tikus jumbo	7	994	0	0	1362.7400000000002	3514	\N	0
5073505393	0	kinanan	0	260	0	0	1195.9599999999994	970	\N	0
5918610365	0	Belva Janettra	0	1	0	0	0	2	\N	0
1852528390	0	Yiselva Blythe.	0	41	0	0	0	20	\N	0
1864803206	0	G	0	0	0	0	0	1	\N	0
6464782450	0	Aldi	0	1	0	0	0	0	\N	0
1987968160	0	nad'd // fastt	0	16	0	0	0	4	\N	0
6276011735	0	Nata	0	6	0	0	0	11	\N	0
6058048909	0	shicAa	0	2	0	0	0	3	\N	0
1847953386	0	Lucass	0	2	0	0	0	29	\N	0
1683920983	0	IjaT	0	146	0	0	236.76000000000002	141	\N	0
6045413265	0	jiwa raga	11	259	0	0	-2.8499999999999863	51	\N	0
792925283	0	Indra	0	1	0	0	0	0	\N	0
1915960330	0	Claire	0	52	0	0	0	231	\N	0
1454328337	0	kosong	0	0	0	0	0	0	\N	0
5497845411	0	khaila	0	1	1	0	0	0	\N	0
1727334348	0	kai	0	16	0	0	0	217	\N	0
5136203468	0	Alzenn🐣	0	104	0	0	242.77000000000004	63	\N	0
5846750956	0	gishaa	0	1	0	0	0	0	\N	0
6284828002	0	Ethaniel S.	0	2	0	0	0	0	\N	0
6435237256	0	alam	0	1	0	0	0	1	\N	0
2035301975	0	crista	0	3	0	0	0	3	\N	0
5582589931	0	air aqua	0	29	0	0	0	21	\N	0
5322843763	0	𖤝.. La'beaute 𝐀shellash˚₊	0	117	0	0	5.039999999999983	114	\N	0
6200444455	0	⋆ ᐢ..ᐢ ▾ zeyaa ࣪ ͎ ᵎ	0	394	0	0	0	0	\N	0
6816018179	0	How do you	0	6	0	0	0	0	\N	0
5847052629	0	Who?	12	74	0	0	43.63000000000011	417	\N	1
5387644158	0	Kika Cerqueira	0	105	0	0	0	644	\N	0
6826208280	0	Praga J	0	0	0	0	0	0	\N	0
6252836130	0	diyah	0	4	0	0	0	3	\N	0
7184888453	0	🕊️🫧	0	1	0	0	0	2	\N	0
1771788891	0	haikal 🦹🏻‍♂️	0	4	0	0	0	0	\N	0
1549877383	0	𖤓҈͜͡Nᴏɪ Zᴇʀᴏ 𖤍𝖌𝖉𝖈♛	0	10	0	0	0	56	\N	0
2023992291	0	𓂀.💎 (.◜◡◝) Eyi	0	1	0	0	0	0	\N	0
1992489594	0	Ger	0	6	0	0	0	1	\N	0
5932696069	0	p	0	60	0	0	66.2799999999999	1	\N	0
5095567579	0	Kimberly pacar jaehyuk	0	149	0	0	6.600000000000023	106	\N	0
5838270954	0	jibran kaeseng	0	4	0	0	0	0	\N	0
6852246065	0	doo0med	0	6	0	0	0	195	\N	0
6404943331	0	Logout	0	26	0	0	130	22	\N	0
5509895145	0	.	0	20	0	0	0	4	\N	0
6129907181	0	joie	4	44	0	0	382.09999999999997	364	\N	0
5893825757	0	⋆ ⃟⁞⃟𔗨ꪚ Rosa	0	139	0	0	220.91000000000008	865	\N	0
5691731985	0	kaies	0	6	0	0	0	0	\N	0
1530108174	0	c	0	1	0	0	0	0	\N	0
1326724238	0	..	0	24	0	0	74.72	68	\N	0
7196120899	0	lalaaAa	0	14	0	0	978	28	\N	0
1732323142	0	Anaya Poetry	12	84	0	0	1715.0900000000004	1591	\N	0
5824684018	0	Gestara Uciha🥷	0	1	0	0	0	2	\N	0
6628269782	0	.	0	2	0	0	0	0	\N	0
6521841680	0	clery zoe	0	11	0	0	0	71	\N	0
1830364123	0	yaa	0	59	0	0	4	5	\N	0
6889513626	0	ciaaa	0	24	0	0	0	30	\N	0
1041124787	0	wleo	0	2	0	0	0	8	\N	0
1824370024	0	jaseb updating..	0	1	0	0	0	1	\N	0
5606702699	0	alta	0	1	0	0	0	1	\N	0
1115637255	0	salima	0	3	0	0	0	0	\N	0
1794553098	0	Astein-ran Diego.	0	0	0	0	0	0	\N	0
6326909092	0	rez	0	1	0	0	0	1	\N	0
6047430435	0	a	3	29	0	0	374.5100000000002	1453	\N	0
1747639691	0	arēz. Busy	0	2	0	0	0	0	\N	0
5293642287	0	cici	0	60	0	0	0	30	\N	0
6001613732	0	Mai	0	15	0	0	0	1	\N	0
6310729001	0	Roter! Open Pulsa, Kuota, Topup	0	2	0	0	0	65	\N	0
6498487984	0	Geta	0	16	0	0	0	7	\N	0
1963066562	0	qeena	0	15	0	0	0	0	\N	0
6173551173	0	ze	0	0	0	0	0	0	\N	0
1582996937	0	𝐀𝐫𝐤𝐚𝐧	0	2	0	0	0	2	\N	0
1823218600	0	Maiden	0	6	0	0	22.19	207	\N	0
1701268966	0	Abigail	0	1	0	0	0	1	\N	0
413703920	0	rev	0	26	0	0	261.34000000000003	169	\N	0
6103038014	0	?	0	1	0	0	0	0	\N	0
6090775087	0	Mami Caine	0	2	0	0	0	1	\N	0
6345991311	0	Unknown	0	3	0	0	0	14	\N	0
1808739810	0	ĐieŁ	0	0	0	0	0	0	\N	0
1429068943	0	lenananana	0	1	0	0	0	0	\N	0
2065403489	0	ayy well	0	7	0	0	0	0	\N	0
6523110995	0	teh kotak	0	1	0	0	0	1	\N	0
1978857716	0	N.	0	83	0	0	0	2	\N	0
5780281696	0	Always nt !	0	35	0	0	0	11	\N	0
5022696711	0	rr	0	64	1	0	60.58000000000007	24	\N	0
1242414853	0	⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣ㅤ	0	44	0	0	0	52	\N	0
6313010719	0	Arbìe	0	3	0	0	0	2	\N	0
5825110727	0	fian	0	8	0	0	0	3	\N	0
1814519137	0	୭ৎ rhéa	0	47	0	0	100.28999999999999	106	\N	0
5583225305	0	move @	0	3	0	0	0	0	\N	0
1221269666	0	Putra	0	1	0	0	0	1	\N	0
6193597836	0	tabita.	0	79	0	0	1153.1200000000006	148	\N	0
6561716221	0	aldi	0	1	0	0	0	0	\N	0
1633728657	0	𝐑	0	1	0	0	0	4	\N	0
6268095528	0	leaa	0	9	0	0	0	92	\N	0
2113910229	0	Kai Chivalry.	0	2	0	0	0	0	\N	0
1285952570	0	gioo	0	0	0	0	0	0	\N	0
1873316168	0	ael ga diving dulu soalnya [] cuapek 💤	0	2	0	0	0	0	\N	0
5986986251	0	Adiwidya Jiyo	0	6	0	0	0	4	\N	0
6531557101	0	Ardianta	0	1	0	0	0	0	\N	0
1557588374	0	zanne	0	7	0	0	0	3	\N	0
2124687007	0	rest.	0	10	0	0	0	5	\N	0
1507488382	0	ley	0	7	0	0	49.38	550	\N	0
5109784312	0	Taavi.	0	3	0	0	0	0	\N	0
5154154285	0	Arīsha D.	0	53	0	0	0	110	\N	0
1752929023	0	Zhari.	0	312	0	0	366.7999999999994	1712	\N	0
6988544745	0	ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ	0	1	0	0	0	0	\N	0
5697436499	0	ayasss	0	0	0	0	0	0	\N	0
1854176777	0	k	0	63	0	0	0	29	\N	0
1481436784	0	aylie 🐿️	0	3	0	0	0	9	\N	0
6354532142	0	j	0	0	0	0	0	1	\N	0
5584749273	0	UrNightmare	0	2	0	0	0	5	\N	0
5845948269	0	bina.	0	4	0	0	0	1	\N	0
1362492084	0	Bbe:*	0	1	0	0	0	1	\N	0
6583138275	0	A	0	7	0	0	0	0	\N	0
5196791989	0	caca	0	3	0	0	0	0	\N	0
5181657967	0	kezia	0	7	0	0	0	1	\N	0
6154448180	0	f	0	1	0	0	0	1	\N	0
6129129792	0	aisyahhh	0	11	0	0	12	5	\N	0
1748938524	0	a	0	1	0	0	0	0	\N	0
5330868453	0	Krystier Jésayaa	0	10	0	0	20.64	9	\N	0
1870554340	0	Séanne	0	1	0	0	0	0	\N	0
1392607217	0	𝙰𝚕𝚎𝚝𝚝𝚊	0	1	0	0	0	0	\N	0
6117479274	0	𝐓𝐑≛𝐏𝐒 ` 𝖎𝖆𝖓 bruh	0	24	0	0	0	20	\N	0
1330277714	0	akun kedua ༊ᴢʏ	0	79	0	0	439.5100000000002	2	\N	0
2109326585	0	Lowkie ָ ♡	0	0	0	0	0	0	\N	0
5403032198	0	ariéllé	0	7	0	0	0	6	\N	0
6445657604	0	alin sedot wc	0	2	0	0	0	18	\N	0
5554633362	0	zyn.	0	2	0	0	0	0	\N	0
6001893709	0	nolwen	0	6	0	0	0	36	\N	0
5886481796	0	Lala	0	1	0	0	0	4	\N	0
1697865777	0	z	0	6	0	0	0	0	\N	0
5060721046	0	Dika	0	32	0	0	0	47	\N	0
6006694593	0	rs	0	1	0	0	0	0	\N	0
1900157499	0	aruna	0	22	0	0	2.34	19	\N	0
5532994461	0	zz	0	16	0	0	0	2	\N	0
5489479434	0	Danzel	0	1	0	0	0	0	\N	0
1891959353	0	meurea	0	0	0	0	0	0	\N	0
6334667980	0	yo.	0	5	0	0	0	1	\N	0
1763595504	0	Thalassa Miciela.	0	21	0	0	0	2	\N	0
5617158895	0	vergas	0	1	0	0	0	0	\N	0
6209261259	0	kaii	0	1	0	0	0	1	\N	0
6244932489	0	nay	0	2	0	0	0	0	\N	0
2134978025	0	talAa	0	55	0	0	0	208	\N	0
2045220925	0	Ocicicici	0	38	0	0	0	2	\N	0
1834072518	0	෴ 𝐇𝐚𝐞vyn彡	0	2	0	0	0	0	\N	0
1627086515	0	c	0	1	0	0	0	0	\N	0
6355500735	0	anitaa nars	0	10	0	0	4312	35	\N	0
1410921451	0	saa	0	2	0	0	0	36	\N	0
5663012814	0	Gilang brave man,	0	23	0	0	949.8200000000002	247	\N	0
1604380633	0	Ale.	0	15	0	0	0	0	\N	0
1331129460	0	Synchro	0	3	3	0	0	6	\N	0
1598811638	0	wa	0	1	0	0	0	0	\N	0
6128448323	0	open fast	0	1	0	0	0	0	\N	0
6118289651	0	Margareth	0	0	0	0	0	0	\N	0
5020819618	0	berapa aja	0	2	0	0	0	0	\N	0
1540947879	0	Jociyelyel (gemi’s)	0	5	0	0	0	133	\N	0
5647514914	0	ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ	0	90	0	0	154.56	55	\N	0
1684398522	0	Nadèleine ୨୧	0	54	0	0	451.8100000000002	108	\N	0
1973166264	0	rora:D	0	2	0	0	0	1	\N	0
5562124810	0	sfs	0	1	0	0	0	0	\N	0
6401778369	0	دمنت	0	2	0	0	0	3	\N	0
1994085487	0	dni.	0	187	0	0	302.5	21	\N	0
5942237928	0	rey	0	1	0	0	0	0	\N	0
6617340484	0	nanda	0	2	0	0	0	0	\N	0
1858474471	0	LiLi	0	4	0	0	0	3	\N	0
5225794965	0	Kwkw	0	23	0	0	0	645	\N	0
6916642854	0	el	0	2	0	0	1134.06	110	\N	0
2041291653	0	uvuweve	0	3	0	0	0	5	\N	0
1298756788	0	Rizkky	0	36	0	0	285	36	\N	0
1329569776	0	#𝐏𝐄𝐍𝐀❄️𓅫☊💎🦋͓ꦿ݉ 𝑲𝑹ˢᵉˣ₁₈₊ #𝐒b : hayden.	0	4	0	0	69.05	4	\N	0
1521810156	0	Sasha.	0	13	0	0	0	156	\N	0
1610840687	0	k	0	41	0	0	0	4	\N	0
6261570081	0	veyaa	11	38	0	0	30264.989999999994	2593	\N	1
6983367528	0	almira, a	0	2	0	0	0	0	\N	0
5383516298	0	Sansan	0	2	0	0	0	2	\N	0
1224831370	0	💎ndaa	0	1	0	0	0	1	\N	0
1774079624	0	h	0	64	0	0	46.650000000000006	67	\N	0
1550966476	0	🄿🄾🄸🅂🄾🄽🄴🄳 🅈🄾🅄🅃🄷	0	0	0	0	0	3	\N	0
5657008450	0	allen	0	1	0	0	0	0	\N	0
6288456368	0	fa	0	6	0	0	0	5	\N	0
5098587033	0	KaLann🅰️	0	20	0	0	0	18	\N	0
6044393994	0	ilovemaizeninsomuch	0	1	0	0	0	0	\N	0
1946814116	0	Maysa	0	9	0	0	0	20	\N	0
1523173359	0	jooyii	0	28	0	0	0	48	\N	0
6207210152	0	.	0	19	0	0	0	2	\N	0
7024382939	0	Gilbert Matthew Lawles	0	2	0	0	0	0	\N	0
6724129394	0	716 ivy	0	5	0	0	0	6	\N	0
6113070457	0	Jade	0	20	0	0	0	1	\N	0
5565657120	0	Janessa.	0	1	0	0	51.61	76	\N	0
5972914388	0	Moordki	0	4	0	0	0	1	\N	0
5416745342	0	On resting.	0	9	0	0	0	0	\N	0
6293228357	0	lynˢˡᵛ	0	0	0	0	0	0	\N	0
5342617916	0	niskala. Usn ku bisa nyicil semua	0	23	0	0	0	12	\N	0
5398369317	0	ayaa	0	4	0	0	0	2	\N	0
857607569	0	riz	0	1	0	0	0	1	\N	0
5973135474	0	K, alterego🪬	0	10	0	0	309.03	363	\N	0
6317495908	0	— เฮนลีย์.	0	64	0	0	11.03	26	\N	0
1998426102	0	shel	0	6	0	0	0	0	\N	0
5635305468	0	𝚈𝙾𝚄𝚃𝙷	0	6	0	0	0	2	\N	0
5866460191	0	Sir. Ganesha' الجزائر	0	6	0	0	0	48	\N	0
6239240137	0	Hijumee.	0	0	0	0	0	3	\N	0
5395287149	0	Kyᴴᴸ	0	2	0	0	0	35	\N	0
6581309429	0	Roderick	0	1	0	0	0	0	\N	0
1330805988	0	Ark	0	171	0	0	8	12380	\N	0
6280542529	0	cale mohaylokit 🇸🇿 #BOCILSENCAZ	0	5	0	0	0	2	\N	0
1812987548	0	Sheela	0	3	0	0	0	0	\N	0
1558803277	0	Kaluna.	0	2	0	0	0	0	\N	0
2032102739	0	𝑪𝐥𝐚𝐮𝐮 .	0	80	0	0	0	3	\N	0
1340603114	0	zakira	0	5	0	0	0	41	\N	0
5176643680	0	Januar dvs🇵🇲	0	1	0	0	0	0	\N	0
1838213810	0	Bailey Ash.	0	13	0	0	0	163	\N	0
5051289705	0	yeen / personal account	0	96	0	0	0	0	\N	0
1639631840	0	🥱🥱	6	2573	0	0	34.24500000000114	25	\N	0
1740165099	0	Alea	0	3	0	0	0	5	\N	0
5370121076	0	heleenna	0	2	0	0	0	0	\N	0
1734542830	0	ejejejejejejeji	0	1	0	0	0	0	\N	0
6606992238	0	❥⍣⃝claaisyʚɞ❦	0	1	0	0	0	2	\N	0
5668815276	0	jessica, open	0	6	0	0	0	1	\N	0
1670523611	0	Egina Lestari	0	8	0	0	0	9	\N	0
6514933394	0	Arvinza not arpinja	0	21	0	0	0	3	\N	0
1754487571	0	Sergio B.	0	8	0	0	0	10	\N	0
1744732444	0	marpe	0	0	0	0	14.480000000000018	1	\N	0
2025133764	0	Bilaa	0	2	0	0	0	2	\N	0
5726843157	0	Anon	0	82	0	0	978	0	\N	0
6725188202	0	xhin	0	0	0	0	0	5	\N	0
5423806893	0	shee	8	803	0	0	4344.97	819	\N	0
6213333056	0	Jeth	0	77	0	0	0	12	\N	0
1815885969	0	a	0	5	0	0	18.07	0	\N	0
5297426970	0	paysie	0	3	0	0	0	354	\N	0
5813303593	0	jeje	0	2	0	0	0	6	\N	0
5030901776	0	godmother	0	31	0	0	0	20	\N	0
1556721933	0	.l	0	4	0	0	0	0	\N	0
6926151412	0	さalicia your gf	0	6	0	0	0	0	\N	0
5186912105	0	opal	0	41	0	0	0	2	\N	0
1707972875	0	Radit A.	0	2	0	0	0	0	\N	0
5117108419	0	MARIN!	0	120	0	0	0	18	\N	0
1336220723	0	yaya	0	1	0	0	0	0	\N	0
1191159007	0	Abrielkras	0	44	0	0	12	19	\N	0
6704455367	0	r	0	1	0	0	0	3	\N	0
1711897654	0	leaving.	0	54	0	0	356.23	4	\N	0
1910160271	0	jaegar bukan starboy	0	39	0	0	200	250	\N	0
5120521109	0	157 melka wōlthsbalak 𖣂 🇰🇪🇹🇲	0	22	0	0	0	0	\N	0
6687170103	0	🕷	0	0	0	0	0	0	\N	0
1335365094	0	leroy	0	32	0	0	1605.2199999999998	225	\N	0
5109210321	0	panggil ae lau	0	1	0	0	0	0	\N	0
1447432414	0	rayven	0	0	0	0	0	0	\N	0
1631045819	0	A	0	32	0	0	137.3	19	\N	0
1142584189	0	ㅤalysa	1	23	0	0	1719.47	874	\N	0
1772626855	0	cecil	0	7	0	0	100	638	\N	0
5475026959	0	ayinnnn	0	22	0	0	0	0	\N	0
1459696591	0	Megencis Leresta	0	1	0	0	0	0	\N	0
6286818322	0	nurul	0	1	0	0	0	0	\N	0
6283150336	0	vinvin	0	9	0	0	0	5	\N	0
1685836741	0	Sinva	0	5	0	0	0	5	\N	0
1635565542	0	a	0	3	0	0	0	15	\N	0
1387116590	0	Almer R.	0	6	0	0	0	0	\N	0
5012423450	0	myrabell	0	3	0	0	0	0	\N	0
1853245210	0	takia z.	0	1	0	0	0	1	\N	0
6139986753	0	jL	0	21	0	0	0	5	\N	0
2054938087	0	ryuu	0	2	0	0	0	0	\N	0
1314910114	0	J	0	2	0	0	0	9	\N	0
5845486245	0	onell	0	3	0	0	0	8	\N	0
5383949209	0	Vaylline, r.	0	0	0	0	0	0	\N	0
5651225171	0	chuzien	0	1	0	0	0	0	\N	0
6663590526	0	Cyl	0	2	0	0	0	0	\N	0
2146245486	0	Eive:o.	0	1	0	0	0	0	\N	0
5331659135	0	arkala	0	1	0	0	0	0	\N	0
1077625224	0	Leighton Devonex	0	8	0	0	0	8	\N	0
5144227937	0	vannyy	0	21	0	0	0	18	\N	0
1982884188	0	jason	0	15	0	0	0	2	\N	0
1097691954	0	Micaaaa	0	1	0	0	0	0	\N	0
6207693444	0	Rfki	0	1	0	0	0	2	\N	0
5629704434	0	adam	0	1	0	0	0	0	\N	0
1628852994	0	c	0	8	0	0	-4.599999999999909	0	\N	0
5931947396	0	shakaa	0	409	0	0	78.53999999999985	2855	\N	0
6246155570	0	Leo spider	0	2	0	0	0	1	\N	0
1982579148	0	yura mau jadi kucing	0	4	0	0	0	0	\N	0
6034338247	0	Cathlyne.	0	7	0	0	0	0	\N	0
1601048512	0	̈̈̈̈̈Achel	0	2	0	0	0	5	\N	0
1909947862	0	Czea	0	19	0	0	0	1	\N	0
1799342465	0	ino	0	150	0	0	0	54	\N	0
5087568609	0	august.	0	7	0	0	0	6	\N	0
6933993462	0	jelita	0	3	0	0	0	0	\N	0
5307139925	0	yara	0	1	0	0	0	4	\N	0
2040960252	0	S	0	3	0	0	0	0	\N	0
6192966776	0	csamel	0	5	0	0	0	1	\N	0
2004034853	0	Sya	0	2	0	0	0	0	\N	0
1983318322	0	cleona	0	1	0	0	0	2	\N	0
1183393462	0	olie	0	22	0	0	2159	9	\N	0
5817857790	0	R	0	0	0	0	0	0	\N	0
6791704641	0	Controller	0	1	0	0	0	0	\N	0
5698138400	0	.	0	17	0	0	0	17	\N	0
1536690539	0	lecii	9	106	0	0	3320.17	461	\N	1
5941989496	0	sheii.	0	21	0	0	0	29	\N	0
6484320243	0	louraa	0	0	0	0	0	5	\N	0
5664901115	0	luca	0	17	0	0	0	0	\N	0
5985772716	0	shana	0	0	0	0	0	1	\N	0
6857868152	0	.	0	3	0	0	0	0	\N	0
6802264776	0	vann's	0	1	0	0	0	13	\N	0
5393683425	0	el	0	1	0	0	0	3	\N	0
1302117534	0	anabell	0	2	0	0	0	0	\N	0
5883725984	0	🤍	0	11	0	0	0	84	\N	0
1718029007	0	-	0	1	0	0	0	1	\N	0
6021113825	0	nola	2	3	0	0	1457.91	0	\N	0
5864977219	0	mecha	0	1	0	0	0	0	\N	0
2054672496	0	Kei	0	138	0	0	0	55	\N	0
6749752336	0	dlstar	0	0	0	0	0	0	\N	0
5371526383	0	⊹ ⋆ﾟ꒰ఎ ℘ꪱׁׅꭈׁׅ𝝏𝝏 ໒꒱ ⋆ﾟ⊹	0	1	0	0	0	0	\N	0
5990787781	0	26	0	21	0	0	0	0	\N	0
5122009869	0	Jeno	0	1	0	0	0	21	\N	0
6603772456	0	𝕽ʳ Piwoaw	0	1	0	0	0	0	\N	0
1486015372	0	arta	0	1	0	0	0	2	\N	0
1454014504	0	ziaa	0	143	0	0	10.879999999999981	116	\N	0
6804218298	0	192. kabi	0	1	0	0	0	1	\N	0
6631205956	0	Javi.	0	1	0	0	0	0	\N	0
6886399483	0	Aku	0	1	0	0	0	0	\N	0
5261570124	0	💤	0	17	0	0	0	112	\N	0
5330731117	0	Vin	0	0	0	0	0	0	\N	0
6154183318	0	willyyyy	0	11	0	0	0	16	\N	0
1818368224	0	iccooo 🎈	0	3	0	0	0	1	\N	0
6803196007	0	Jaze open sl	0	2	0	0	0	4	\N	0
6253963820	0	tata	13	464	0	0	859.6600000000007	1741	\N	0
6824242459	0	zoey	0	0	0	0	0	0	\N	0
6287154859	0	っ𖹭 xiaa 🪐ʿ ୭	0	1	0	0	0	0	\N	0
6791846467	0	paulina 💢	0	23	0	0	5	0	\N	0
5297259433	0	madelyne	0	13	0	0	43.68000000000001	11	\N	0
2100669426	0	fel	0	5	0	0	0	1	\N	0
5653655022	0	saint	1	4	0	0	17.510000000000133	26	\N	0
5305822480	0	viza ◡̈	0	2	0	0	200	275	\N	0
1480300440	0	G	0	114	0	0	0	516	\N	0
5467122718	0	ki	0	11	0	0	0	16	\N	0
1930048920	0	kayrinéa	0	5	0	0	0	2	\N	0
1345204732	0	ghea	0	250	0	0	925.64	298	\N	0
1466335440	0	ling	0	2	0	0	0	7	\N	0
1010654237	0	K—Karinaya.	0	43	0	0	2452	12	\N	0
1870500147	0	Shella 🐈‍⬛️	0	55	0	0	0.23000000000000043	128	\N	0
5795957892	0	Batara Maalik.	0	3	0	0	0	5	\N	0
1628281425	0	ej	0	1	0	0	0	0	\N	0
1673042284	0	602 zøi 々	0	5	0	0	0	18	\N	0
5092090023	0	ibvyy(without b)	0	2	0	0	0	7	\N	0
1834599007	0	drexa	0	143	0	0	23.290000000000248	765	\N	0
5039005370	0	.	0	3	0	0	0	0	\N	0
5346662874	0	ravinaa.	0	2	0	0	0	8	\N	0
1792995974	0	Adischa L.	0	62	0	0	50	0	\N	0
5368517688	0	anyae	0	3	0	0	0	40	\N	0
6072205088	0	Zaaxx	0	0	0	0	0	0	\N	0
1867568578	0	meow meow	0	31	0	0	978	0	\N	0
5209222327	0	Verdi	0	0	0	0	0	17	\N	0
1830383495	0	bear	0	1	0	0	0	0	\N	0
1304822014	0	Earth.	0	6	0	0	0	16	\N	0
1675804520	0	Ichan	0	5	1	0	0	3	\N	0
1722798114	0	Oshy	0	2	0	0	0	0	\N	0
1704772710	0	kahelio	0	22	0	0	0	11	\N	0
6147732969	0	awa	0	14	0	0	1259.8400000000001	30	\N	0
1120493132	0	take a guess	0	1	0	0	0	4	\N	0
5289416317	0	nara	0	0	0	0	0	4	\N	0
5470163672	0	Bayii	0	1	0	0	0	1	\N	0
1993382485	0	stevanya	0	47	0	0	0	132	\N	0
6914772443	0	ian	0	1	0	0	0	0	\N	0
7040445556	0	Anne 𝕏 「ᴀʟᴛᴇʀᴇɢᴏ」	0	1	0	0	0	0	\N	0
1932678526	0	Ariella ۫ 𐙚	0	62	0	0	34.379999999999995	50	\N	0
1831326565	0	Fariq	0	18	0	0	0	10	\N	0
6049345843	0	BA). eny	0	6	0	0	0	12	\N	0
1913057231	0	k	0	2	0	0	0	1	\N	0
5756848262	0	Haerell.	0	8	0	0	0	0	\N	0
6946208601	0	retta	0	2	0	0	0	1	\N	0
1660702262	0	cece	0	343	0	0	1.6000000000000227	40	\N	0
1342981280	0	velly	0	10	0	0	0	0	\N	0
6340142712	0	K1BO 1	0	0	0	0	0	0	\N	0
5107742998	0	kanggeswara anak gadis colay	0	0	0	0	0	0	\N	0
1940657479	0	casey vacnora.	0	2	0	0	0	0	\N	0
2052298632	0	abiyu ovk³	0	78	0	0	88	121	\N	0
6824465406	0	hazai	0	2	0	0	0	0	\N	0
5386299202	0	naxnasha	0	15	0	0	0	0	\N	0
5249726479	0	geya	0	10	0	0	0	9	\N	0
5676203418	0	Rory	0	17	0	0	0	2	\N	0
1880926984	0	z	0	5	0	0	0	0	\N	0
6982323200	0	kael	0	1	0	0	0	0	\N	0
5073604891	0	.	0	1	0	0	0	3	\N	0
1818011960	0	yyy	0	157	0	0	52.5	116	\N	0
1853557907	0	hannah	0	1	0	0	0	3	\N	0
1844055139	0	asa	0	13	0	0	0	9	\N	0
5671580224	0	fania	0	1	0	0	0	1	\N	0
1418195381	0	sky	0	1	0	0	0	4	\N	0
993207730	0	ololo	0	1	0	0	0	0	\N	0
1616083196	0	ALUN4	0	16	0	0	0	0	\N	0
5849396629	0	aji	0	4	0	0	0	1	\N	0
803762042	0	wendy	0	10	0	0	0	0	\N	0
1602906341	0	M¡MIii	0	1	0	0	0	0	\N	0
6460140775	0	queen	0	0	0	0	0	2	\N	0
5403220223	0	joleᴴᴸ	0	24	0	0	0	28	\N	0
6893985655	0	Aatrox	0	1	0	0	0	0	\N	0
6533564605	0	abeeyy gege	0	5	0	0	0	4	\N	0
5686294364	0	Hi	0	1	0	0	0	0	\N	0
6882962249	0	jay	0	26	0	0	89.48	41	\N	0
5653497377	0	grᥲᥴіᥲ	0	5	0	0	0	7	\N	0
2083137112	0	dhirr	0	10	0	0	0	2	\N	0
5818590032	0	cici	0	8	0	0	2.45	0	\N	0
5068878177	0	Bang galer	0	175	0	0	250	4130	\N	0
1775750075	0	Ajay	0	6	0	0	0	1	\N	0
5452881847	0	wildannn	0	0	0	0	0	0	\N	0
1744474417	0	helga	0	9	0	0	0	2	\N	0
2025503775	0	jiyel	0	28	0	0	0	36	\N	0
1634228562	0	eja	0	1	0	0	0	2	\N	0
5145601099	0	bjr . JENANDRA ` clz	0	2	0	0	0	0	\N	0
6432807336	0	6	0	3	0	0	0	12	\N	0
5670955942	0	𝐃𝐏𝐑—𝗔. sekon	0	0	0	0	0	0	\N	0
1704502342	0	argan	0	1	0	0	0	0	\N	0
6601188596	0	Azeera.	0	1	0	0	0	0	\N	0
2133131490	0	odii	0	3	0	0	0	86	\N	0
6103097411	0	brin	0	1	0	0	0	0	\N	0
5596173791	0	ef	0	1	0	0	0	29	\N	0
5236410951	0	lau	0	146	1	0	343.7199999999999	408	\N	0
5665332358	0	dikta s.	0	1	0	0	0	0	\N	0
1934332492	0	Abigail	0	7	0	0	0	0	\N	0
5893816681	0	Emily. Suka matcha	0	1	0	0	0	0	\N	0
5029630717	0	z	0	45	0	0	0	5	\N	0
5947894002	0	mystique, stressed	0	0	0	0	0	0	\N	0
5485312830	0	Helga.	0	1	0	0	0	2	\N	0
1979323679	0	io	0	63	0	0	69.47	198	\N	0
7148452591	0	Khainara.	0	4	0	0	0	17	\N	0
1752842704	0	jasmine	0	177	0	0	37.95	53	\N	0
5317633591	0	cilok	0	3	0	0	44.18	2	\N	0
5860685398	0	yakali	0	4	0	0	0	9	\N	0
1977360973	0	me	0	15	0	0	0	9	\N	0
5628117392	0	kanjeng ratu	0	10	0	0	0	1	\N	0
1267205424	0	salwa	0	2	0	0	0	0	\N	0
1490234063	0	pek	0	40	0	0	959.24	78	\N	0
5526625275	0	kaLeA	0	0	0	0	0	1	\N	0
1614943591	0	mate kiri.	0	365	0	0	529.5699999999996	673	\N	0
1227939104	0	Mars	0	1	0	0	0	1	\N	0
1963097639	0	Juju	0	1	0	0	0	0	\N	0
5537827373	0	Fadil	0	3	0	0	0	50	\N	0
1841072718	0	val.	0	5	0	0	275.32	6	\N	0
1886620565	0	SFS	0	5	0	0	0	1	\N	0
1485949701	0	α	3	100	0	0	85.16999999999804	38	\N	0
5003042736	0	rey @qekasih	0	6	0	0	0	91	\N	0
1787853366	0	Narendra B.	0	1	0	0	0	0	\N	0
6062695661	0	t	0	5	0	0	0	6	\N	0
6341135643	0	ezra	0	0	0	0	0	31	\N	0
6133113477	0	cashaa	0	10	0	0	0	21	\N	0
6953612152	0	Sakura 🌸💮	0	1	0	0	0	0	\N	0
6376020375	0	joy	0	3	0	0	0	4	\N	0
6116089365	0	.	0	1	0	0	0	0	\N	0
6328420414	0	senja	0	3	0	0	0	1	\N	0
6228919987	0	alexa	0	2	0	0	0	0	\N	0
6632843026	0	𝖈𝖎𝖊𝖑	0	3	0	0	0	13	\N	0
5370589001	0	Apaaajdehkpo	0	1	0	0	0	0	\N	0
2015698757	0	lia	0	9	0	0	0	0	\N	0
6266209537	0	soobin's sunshine, adrey 11111	0	1	0	0	0	7	\N	0
2111315696	0	Panji Siregar	0	110	0	0	2414.5599999999995	1210	\N	0
2068146478	0	caca	0	420	0	0	12.779999999999347	300	\N	0
6075962947	0	bela	0	3	0	0	0	1	\N	0
1726689534	0	$	0	49	0	0	1753.04	13	\N	0
5930272896	0	hado	0	1	0	0	0	0	\N	0
5035995340	0	𓇻 sweet—doll, jiiueeoo. 𐙚 @rsweeaty	0	0	0	0	0	5	\N	0
5871893181	0	ℭ	0	3	0	0	0	16	\N	0
5744942096	0	Abian.	0	2	0	0	0	0	\N	0
6478805458	0	kilaa	0	4	0	0	0	0	\N	0
1765866647	0	.	0	1	0	0	0	0	\N	0
6432023052	0	Alee	0	3	0	0	0	10	\N	0
6082608358	0	acrs	0	4	0	0	0	39	\N	0
6295908144	0	Leviethan.	0	1	0	0	0	0	\N	0
1567899559	0	dd	0	2	0	0	0	14	\N	0
5640871570	0	ʚïɞ zeoou ' s	0	3	0	0	0	9	\N	0
6623812560	0	eynaa	0	1	0	0	0	0	\N	0
6187502334	0	juan	0	6	0	0	0	0	\N	0
5345570254	0	Dikta	0	0	0	0	0	8	\N	0
6544901991	0	♋	0	9	0	0	0	0	\N	0
6984222808	0	m	0	1	0	0	0	11	\N	0
1698268276	0	Maxx	0	5	0	0	0	30	\N	0
686864470	0	ra.	0	112	0	0	6.260000000000082	462	\N	0
1392696211	0	albi . #esse 🇪🇬	0	2	0	0	0	2	\N	0
5458786643	0	kharash	0	35	0	0	0	0	\N	0
1724863786	0	𝐀	0	1	0	0	0	11	\N	0
6129190792	0	scx. jopekk	0	1	0	0	0	9	\N	0
6358447028	0	a~pril @beranngberang ᡣ𐭩	0	5	0	0	50	90	\N	0
1888846346	0	Ralivy.	0	1	0	0	0	1	\N	0
5653908652	0	knay	0	95	0	0	318.2199999999999	38	\N	0
6955796760	0	𝐓𝐑≛𝐏𝐒 `𝖣𝖾𝗇𝗍𝖺	0	7	0	0	0	68	\N	0
2147182958	0	ale	0	0	0	0	0	0	\N	0
5822690677	0	ecá	0	587	1	0	994.1699999999998	199	\N	0
6983649578	0	vasha	0	5	0	0	0	16	\N	0
5442646486	0	who?	0	86	0	0	0	42	\N	0
6867572896	0	ale	0	1	0	0	0	3	\N	0
6298632986	0	d	0	363	0	0	4.599999999999909	352	\N	0
5345902348	0	melzio	0	1	0	0	0	0	\N	0
5776699527	0	farhan	0	2	0	0	30.98	7	\N	0
5403148110	0	juji	0	105	0	0	0	448	\N	0
1494528916	0	r	0	1	0	0	0	0	\N	0
1701004216	0	Kanaya	0	2	0	0	0	2	\N	0
1788751947	0	yaya pgn mie ayam	0	1	0	0	0	0	\N	0
5657237349	0	galen	14	44	0	0	0	52	\N	0
6855619684	0	Moonciel	0	0	0	0	0	0	\N	0
5248678902	0	iyan udah broken banget	0	3	0	0	0	13	\N	0
5790615057	0	bulbull lustify	0	1	0	0	0	0	\N	0
6005499647	0	Sagita.	8	10	0	0	450.79	44	\N	0
5360965357	0	Tsyaulia	0	1	0	0	0	0	\N	0
6064836905	0	ell	0	1	0	0	0	0	\N	0
1757993303	0	Ragasha Vaanderanji	0	0	0	0	0	0	\N	0
2006104096	0	Lee	0	97	0	0	153.3300000000001	391	\N	0
5151114384	0	sorry	0	1	0	0	0	0	\N	0
5108782592	0	alvian 📴	0	8	0	0	0	2	\N	0
1926205866	0	ayaa	0	4	0	0	0	8	\N	0
5279890225	0	I'm	0	2	1	0	0	2	\N	0
5890235712	0	JOKI MURAH	0	9	0	0	0	6	\N	0
6973122675	0	Millen❣️	0	4	0	0	0	1	\N	0
5222268261	0	kanya	0	18	0	0	0	1	\N	0
6330445624	0	Danielle supremacy	0	3	0	0	0	0	\N	0
2004461416	0	a	0	5	0	0	0	5	\N	0
5399097911	0	sakse	0	11	0	0	0	0	\N	0
1675090156	0	꒰ ♡ 🧺 ˚ˎˊ˗ ୭ৎ 🎀 ૮ ˃‌ 𐃷 ˂‌ ྀིა	0	5	0	0	0	1	\N	0
1429145301	0	al	0	3	0	0	0	2	\N	0
1986061224	0	Ancika.	0	1	0	0	0	1	\N	0
5115627518	0	Naomi K.	0	35	0	0	3014.0699999999997	31	\N	0
1722897979	0	a	0	1	0	0	0	0	\N	0
1718435578	0	cha cha	0	1	0	0	0	22	\N	0
5888088169	0	Camny's Protect, bintang.	0	5	0	0	188.18	196	\N	0
1382285702	0	sa	0	45	0	0	0	565	\N	0
6296553700	0	v	0	10	0	0	0	1	\N	0
5851633702	0	⁣⁫⁣⁫⁣ ladesh	0	14	0	0	0	0	\N	0
1753998816	0	Bright	0	4	0	0	0	0	\N	0
6042558552	0	Morgan A.	0	6	0	0	0	14	\N	0
5364461908	0	zain	0	30	0	0	0	23	\N	0
2144561278	0	𝐕𝗮ren𝗓𝗈𝖾̀	14	128	0	0	576.4	568	\N	0
5145866059	0	Kiya	0	3	0	0	0	2	\N	0
5951721522	0	salwa 🕷	0	1	0	0	0	15	\N	0
5890903300	0	podhy.	3	30	0	0	13839.209999999994	3951	\N	0
5207463063	0	ㅤ	0	0	0	0	0	2	\N	0
1942526474	0	Ares	0	22	0	0	0	3	\N	0
1965202747	0	princess yubbie ōtsuki	0	1	0	0	0	0	\N	0
2002960595	0	Ed.🚩	0	83	0	0	139.58	728	\N	0
2023685807	0	Regav.	0	1	0	0	0	0	\N	0
5066426066	0	💎er	0	62	0	0	0	8	\N	0
1807906034	0	Diana	14	99	0	0	0	0	\N	0
6616591299	0	Sxok	0	7	0	0	0	24	\N	0
5892299402	0	metas	0	1	0	0	0	0	\N	0
6251394240	0	C	0	4	0	0	0	0	\N	0
6038467957	0	𝟑𝟗𝟕. 𝐀’ momy asya	0	5	0	0	0	6	\N	0
1642255989	0	12	0	2	0	0	0	0	\N	0
7052294590	0	finley	0	7	0	0	0	1	\N	0
6409458750	0	𝕰𝒕𝒉. 𝐘𝐮𝐮 -1 loper	0	2	0	0	0	0	\N	0
1850891501	0	Al	0	25	0	0	1419.39	116	\N	0
6454849804	0	caa	0	17	0	0	0	44	\N	0
5954196159	0	lia Vivin	0	1	0	0	0	0	\N	0
5097933074	0	enjel, sibuk sekolah.	0	30	0	0	1487.4199999999998	1333	\N	0
1358116643	0	.	0	41	0	0	0	1	\N	0
1304479938	0	Nico	0	1	0	0	0	0	\N	0
2026014926	0	L	0	1	0	0	0	0	\N	0
1931136400	0	ājeng, open apk prem	0	1	0	0	0	11	\N	0
1422097032	0	Rakha hengker mermet pro mafia	0	0	0	0	0	1	\N	0
1928031929	0	arshaka	0	11	0	0	934	0	\N	0
5303366417	0	ji	0	3	0	0	0	4	\N	0
5592673894	0	tari	0	32	0	0	0	233	\N	0
5902196347	0	kayy's !¡	0	2	0	0	0	3	\N	0
1789540457	0	Panglima R.	0	90	0	0	700.5	1703	\N	0
5124902120	0	Bàron, on resting	0	2	0	0	0	3	\N	0
1833517313	0	choco	0	26	0	0	0	10	\N	0
1361988104	0	.	0	16	0	0	0	0	\N	0
5414206448	0	.	0	3	0	0	0	6	\N	0
1882327783	0	abe	0	10	0	0	0	2	\N	0
1291884215	0	Hanzel Han	0	2	0	0	0	0	\N	0
5186883507	0	keisha	0	3	0	0	0	4	\N	0
1969320875	0	m	0	250	0	0	213.35000000000002	76	\N	0
1870222426	0	Jezelle Corlisha.	0	0	0	0	0	0	\N	0
1815840951	0	Naecy Moushie	0	1	0	0	0	0	\N	0
6472428321	0	Nadia	0	1	0	0	0	3	\N	0
7195573889	0	cheryl	0	4	0	0	0	0	\N	0
5249824522	0	Vincentius.	0	319	1	0	6.730000000000018	95	\N	0
5132105052	0	aiden	0	6	0	0	0	7	\N	0
5738927967	0	cessa	0	1	0	0	3166.8399999999997	27	\N	0
5005207302	0	naya💨	0	37	0	0	0	8	\N	0
5163293454	0	syaaa	0	38	0	0	5.6299999999999955	19	\N	0
6171248408	0	sworr	0	0	0	0	0	1	\N	0
6168964656	0	Kai	0	25	0	0	0	85	\N	0
7191079714	0	Sarah.	0	1	0	0	0	0	\N	0
1692728020	0	asaaa.	9	61	0	0	11.04	68	\N	0
6579859497	0	Keli	0	1	0	0	0	2	\N	0
2041726118	0	b	0	3	0	0	0	20	\N	0
1931932408	0	ㅤ	0	5	0	0	0	0	\N	0
5937270418	0	hi	0	14	0	0	633	2	\N	0
5328652089	0	.	0	5	1	0	0	0	\N	0
5972564372	0	bian lucu mode on	0	2	0	0	0	8	\N	0
5334196196	0	kaivan	0	63	0	0	0	6	\N	0
6380422073	0	sennya #CALMINJICHU	0	2	0	0	0	8	\N	0
5725581223	0	.	0	2	0	0	0	0	\N	0
2028645111	0	dandi	0	3	0	0	0	11	\N	0
2048670797	0	.	0	17	0	0	0	0	\N	0
5114573888	0	heather	0	286	0	0	0	53	\N	0
1793912888	0	Jo	3	19	0	0	564.2199999999999	103	\N	0
1884856702	0	putra @ptrjmn	0	1	0	0	0	0	\N	0
1658233689	0	dg. Apin	0	59	0	0	314.6100000000001	47	\N	0
6120567367	0	𝐔𝐫 𝐀𝐧𝐧𝐚	0	5	0	0	1000	51	\N	0
5744766668	0	Clya	0	93	0	0	90.29	17	\N	0
6713585714	0	Claryn.	0	0	0	0	0	26	\N	0
6135992096	0	gaprel.	0	3	0	0	0	5	\N	0
1898064017	0	ranindya S.	0	8	0	0	282.89	4	\N	0
2035399774	0	lunarie dearest.	0	18	0	0	956	47	\N	0
1955123204	0	Daebora.D	7	36	0	0	314.5899999999999	24	\N	0
6907511063	0	fib	0	10	0	0	0	139	\N	0
5429071625	0	✨	0	0	0	0	0	12	\N	0
5276096208	0	N	0	1	0	0	0	0	\N	0
1232576131	0	jagat lingga e	0	80	0	0	1020.6500000000001	20	\N	0
5222444330	0	Picaa💭	0	49	0	0	183.89	70	\N	0
6539453825	0	huhuhaha	0	33	0	0	13.030000000000001	146	\N	0
1150493650	0	Ur Crush?	0	1	0	0	0	5	\N	0
1815746536	0	𐙚 ⁺ ݂ acha' morutie ۫ ⊹	0	209	0	0	286.9200000000001	150	\N	0
6375352440	0	-	0	1	0	0	0	0	\N	0
6593743636	0	F.	0	3	0	0	0	0	\N	0
1772964717	0	ㅤ	0	13	0	0	87.5	0	\N	0
6117436263	0	If ?	0	4	0	0	0	5	\N	0
5182955434	0	j	0	2	0	0	0	1	\N	0
1919675034	0	Moramoon.	0	1	0	0	0	38	\N	0
1495076411	0	nadya🪸	0	68	0	0	0	218	\N	0
5992902362	0	Hohang	0	1	0	0	0	0	\N	0
1762791673	0	apipaaa	0	281	0	0	0	17	\N	0
1513379454	0	arrrd	0	10	0	0	0	4	\N	0
1956411833	0	medfhL	0	90	0	0	0	29	\N	0
1765472996	0	jea	0	4	0	0	0	32	\N	0
1913093886	0	kaonii @haestrnwj	2	253	0	0	854.7199999999999	292	\N	0
1531309870	0	ale yh	0	17	0	0	0	3	\N	0
5014976689	0	Rachelia	0	17	0	0	0	1	\N	0
1465448151	0	Miko	0	1	0	0	0	0	\N	0
5946114170	0	Sera	0	1	0	0	0	0	\N	0
5754247450	0	Oreo 🐈 !	0	2	0	0	794.2100000000003	249	\N	0
1565990272	0	⏤͟͟͞͞⃝⋆⃟𝐅ᵗᶜ•RipCuree	0	1	0	0	0	0	\N	0
5594193231	0	A.	0	2	0	0	0	0	\N	0
5499342711	0	bayuu	0	3	0	0	0	1	\N	0
6535671596	0	カラ	0	0	0	0	0	0	\N	0
1803451288	0	atala doang	0	15	0	0	0	223	\N	0
5903043997	0	ellaaaAa	0	10	0	0	0	168	\N	0
5675198767	0	ares	0	3	0	0	0	1	\N	0
5303519248	0	n's	0	9	0	0	0	3	\N	0
2040284980	0	eveee.	0	9	0	0	1001.86	162	\N	0
1287102276	0	A	0	24	0	0	0	56	\N	0
2004464211	0	sha	0	1	0	0	0	0	\N	0
1860071336	0	රඩㅤㅤㅤㅤㅤㅤㅤㅤㅤ rvg³Matwous	0	2	0	0	0	2	\N	0
1593711740	0	mary	0	4	0	0	0	0	\N	0
6529206351	0	vanchocolate	0	2	0	0	0	2	\N	0
1783392615	0	cata	0	1	0	0	0	0	\N	0
6874846446	0	lio, dni.	5	314	0	0	611.6099999999999	507	\N	0
5996038296	0	nelly	6	11	0	0	20.38	129	\N	0
5074405542	0	arshaka	0	1	0	0	0	0	\N	0
1249893172	0	👩🏻‍🎨	0	1	0	0	0	2	\N	0
5958575922	0	najel.	0	5	0	0	0	19	\N	0
2137520711	0	•𝘈-ᴀʀɢᴀ𝕲𝕶²-	0	3	0	0	0	10	\N	0
1633694207	0	bella	0	0	0	0	0	0	\N	0
5297937991	0	grace [rawrr]	0	0	0	0	0	0	\N	0
2071449560	0	ꦱ. Jayden ༆ öwlges³ இ ᴵᵛˢ ຊ₠¹ ᵇʰˢ	0	1	0	0	0	0	\N	0
5066931542	0	alesa	0	13	0	0	0	124	\N	0
1884205777	0	del	0	1	0	0	0	0	\N	0
1753171332	0	Pusing	0	4	0	0	0	0	\N	0
5793859573	0	J	0	3	0	0	0	11	\N	0
5056384332	0	ian jr	0	67	0	0	10.29	51	\N	0
6847314757	0	dracuhara 🧛🏻‍♀️	0	23	0	0	0	4	\N	0
6329292605	0	Ellaina, H.	0	3	0	0	0	0	\N	0
5330589805	0	tariii	0	4	0	0	0	1	\N	0
7062699063	0	papi alter	0	2	0	0	0	50	\N	0
6134006644	0	공주, Adriel!	0	8	0	0	0	0	\N	0
5305054937	0	jims	0	6	0	0	0	0	\N	0
1905528654	0	Gracia	0	66	0	0	0	0	\N	0
1682708967	0	flo's	0	1	0	0	0	1	\N	0
5017544381	0	j	7	86	0	0	374.05999999999904	126	\N	0
1744018386	0	zzz	0	0	0	0	63.530000000000044	0	\N	0
1930920708	0	Putra.	0	28	0	0	76.76	112	\N	0
1840605716	0	girl	0	6	0	0	0	0	\N	0
5833971429	0	Raja	0	2	0	0	0	0	\N	0
1980736396	0	mishël pending bngt pls	0	1	0	0	0	0	\N	0
6391923525	0	serena	0	5	0	0	0	0	\N	0
5654171681	0	Inactive	0	1	0	0	0	6	\N	0
1111009159	0	auristella	0	5	0	0	704.1700000000001	71	\N	0
1190402839	0	Cylnn	0	1	0	0	0	1	\N	0
1894037143	0	ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ	0	3	0	0	0	0	\N	0
1908923846	0	⚕︎ stumpy, kania	0	1	0	0	0	0	\N	0
1735630425	0	karina	0	13	0	0	186.99	150	\N	0
5815909718	0	ophelia,	0	2	0	0	0	4	\N	0
5252035522	0	angkasaaa	0	2	0	0	67.77	4	\N	0
5874104546	0	Kathya.	0	0	0	0	0	0	\N	0
1793214546	0	kay	10	105	0	0	1293.5700000000002	1158	\N	0
1753700987	0	l	0	125	0	0	66.93	47	\N	0
5919156315	0	noye	0	7	0	0	564.56	151	\N	0
6265518018	0	j	0	9	0	0	0	104	\N	0
6171530727	0	Ardi	0	0	0	0	0	0	\N	0
6971447700	0	meilyanth.	0	1	0	0	0	0	\N	0
1876507397	0	qylaa	0	1	0	0	0	0	\N	0
5244156547	0	ocha	0	13	0	0	0	143	\N	0
1779429168	0	Dd. Ucull Ufs @.najaeoin	0	3	0	0	572.94	50	\N	0
1921678623	0	ojap	4	22	1	0	1097.2899999999995	69	\N	0
6374385535	0	"~	0	0	0	0	0	2	\N	0
5220333626	0	tasya	0	1	0	0	0	3	\N	0
6000411805	0	rexali	0	6	0	0	0	3	\N	0
1844733475	0	jovan	0	1	0	0	0	2	\N	0
5807854769	0	geca pcr vrt	0	4	0	0	0	26	\N	0
6500509138	0	vanelope	0	2	0	0	0	1	\N	0
1472324594	0	ohmypan	0	9	0	0	0	14	\N	0
6164510261	0	melv.	0	1	0	0	0	0	\N	0
6553430610	0	mami casey	0	1	0	0	0	1	\N	0
5665734540	0	erna	0	52	0	0	-5.949999999999989	19	\N	0
1294478961	0	ashley aja	0	5	0	0	0	0	\N	0
6144986102	0	Bella	0	1	0	0	0	0	\N	0
5576478363	0	Axelo	0	1	0	0	87.52000000000001	76	\N	0
1334769444	0	marcell	0	5	0	0	0	22	\N	0
1638284388	0	m	0	1	0	0	0	0	\N	0
6868714950	0	fael	0	4	0	0	0	0	\N	0
932417661	0	mafuyu` [slr parah]	0	3	0	0	0	0	\N	0
5944157020	0	miyamiya	0	1	0	0	200	1	\N	0
1976102164	0	stacey	0	22	0	0	0	33	\N	0
6785849600	0	Faiz	0	24	0	0	0	32	\N	0
6259475976	0	N	0	1	0	0	15.37	27	\N	0
1308194145	0	rioo gntng	0	1	0	0	0	3	\N	0
6163268492	0	1	0	1	0	0	0	1	\N	0
2113153610	0	Mern	0	25	0	0	0	21	\N	0
1922971925	0	j	0	34	0	0	0	54	\N	0
1776114412	0	makey	0	289	0	0	1251	307	\N	0
5445133435	0	u mine	0	4	0	0	0	1	\N	0
5423127284	0	josh	0	0	0	0	0	0	\N	0
6145827672	0	nayca	0	0	0	0	0	0	\N	0
7016725085	0	𝐓𝐑≛𝐏𝐒 ` 𝘬𝘦𝘴𝘩𝘪 – ⁶⁶⁶	0	4	0	0	0	0	\N	0
5973547072	0	sherlyy	0	7	0	0	0	5	\N	0
5986478094	0	ciaaa	0	1	0	0	0	0	\N	0
1653951179	0	who?	0	179	0	0	0	418	\N	0
5090425427	0	lol	0	12	0	0	6.229999999999997	25	\N	0
5753357202	0	rangga's	0	49	0	0	0	293	\N	0
5512248943	0	Juan	0	42	0	0	35.44	44	\N	0
1368833678	0	Hilmy A.	0	1	0	0	0	0	\N	0
6191963383	0	Alena Laura	0	6	0	0	301.23	39	\N	0
6997640790	0	kzn	0	3	0	0	0	0	\N	0
1743379098	0	Archie, @Meeirabelle.	0	1	0	0	0	0	\N	0
6453301977	0	Cleta Xanthippe.	0	457	0	0	8.86999999999992	193	\N	0
1859842687	0	gaby 🇷🇴	6	269	0	0	1234.14	429	\N	0
6154430362	0	sh	0	3	0	0	0	0	\N	0
5343613579	0	ਏਓ yayaz	0	481	0	0	0.05999999999998096	9	\N	0
6219687228	0	💤	0	3	0	0	0	9	\N	0
1896895225	0	jica	0	1	0	0	0	8	\N	0
6361240934	0	ㅤㅤ₊ 𖤝 ˚ Sœcjddaël Cænniē	0	1	0	0	0	0	\N	0
5464802092	0	R•A•M•A	0	16	0	0	46.41999999999955	102	\N	0
1939510763	0	nes	3	109	0	0	1056.2900000000002	257	\N	0
1314257485	0	Pers, jac miller	0	3	0	0	0	1	\N	0
1338252173	0	mey	0	0	0	0	0	4	\N	0
1944244199	0	.	0	214	0	0	113.28	86	\N	0
6823508418	0	key	0	40	0	0	0	79	\N	0
1832516664	0	.	0	211	0	0	10.689999999999998	16	\N	0
5237460653	0	cici	0	1	0	0	0	3	\N	0
6829886238	0	erjee	0	1	0	0	0	3	\N	0
2145197677	0	Cathrine	0	12	0	0	0	23	\N	0
1909728442	0	salwa	0	186	0	0	1666.39	187	\N	0
6142112108	0	tama	0	1	0	0	250	0	\N	0
5379410238	0	Aá	0	1	0	0	0	9	\N	0
1788097350	0	pacar ben	0	3	0	0	0	3	\N	0
1814824831	0	Olaa🎧	0	3	0	0	0	9	\N	0
1888283943	0	Zārkashax Stephe.	0	0	0	0	0	14	\N	0
5007366838	0	Juan	1	148	0	0	344.06	314	\N	0
5130288445	0	recy	0	30	0	0	0	50	\N	0
5202984648	0	− Sab	0	15	0	0	0	10	\N	0
1420945330	0	V . Yola	0	22	0	0	0	10	\N	0
6179668278	0	ㅤaraa	5	26	0	0	7.8	64	\N	0
6272813131	0	cabaw	0	1	0	0	0	0	\N	0
1681273453	0	.	0	7	0	0	0	0	\N	0
5962046051	0	ra	0	3	0	0	0	0	\N	0
1510095962	0	zaa	0	10	0	0	0	0	\N	0
5322552471	0	Odette.	0	13	0	0	0	4	\N	0
6025381478	0	Karla	0	2	0	0	0	0	\N	0
5580540045	0	hema.	1	609	0	0	11.629999999999654	5036	\N	0
1424069536	0	yaya	0	26	0	0	426	208	\N	0
1736055713	0	J. Lana child	0	42	0	0	0	10	\N	0
5511623983	0	Sofia Amalia	0	17	0	0	0	3	\N	0
5194081367	0	Romeo	0	3	0	0	0	5	\N	0
6307027951	0	ar j.	0	56	0	0	0	5	\N	0
1818954837	0	??	0	1	0	0	0	0	\N	0
2058411896	0	M. Riley	0	53	0	0	159.48000000000002	213	\N	0
1491074855	0	K.	0	25	0	0	0	0	\N	0
2127981168	0	168 𝐃ominic.	0	46	0	0	712	53	\N	0
2047810662	0	Pelif Walthen	0	1	0	0	0	0	\N	0
5317334090	0	hanum	0	65	0	0	0	7	\N	0
5184655276	0	Jeizen's lovetaker, Ayuri.	0	40	0	0	0	67	\N	0
1702093960	0	rarely actve	0	2	0	0	0	1	\N	0
1298197092	0	🐬 ⊹ nji pcr kak dingin !	0	5	0	0	0	14	\N	0
2083575063	0	freey	0	56	0	0	0	17	\N	0
5767136922	0	c	0	4	0	0	0	0	\N	0
1497709133	0	ocell🧚‍♀	0	559	0	0	126.23499999999996	3837	\N	0
5872881081	0	akleema	0	3	0	0	0	24	\N	0
5363943508	0	ranhaaa	0	5	0	0	0	3	\N	0
1989340078	0	𝕬𝖗𝖟𝖆𝖟 𝔢𝔩𝔳𝔢𝔯𝔫	0	0	0	0	0	0	\N	0
5364650332	0	celloo	0	10	0	0	0	3	\N	0
6076046465	0	biru	0	2	0	0	0	1	\N	0
6093663883	0	Eusta-cé	0	1	0	0	0	0	\N	0
6358927873	0	ᴄᴀᴄᴀ	0	0	0	0	0	7	\N	0
7004367251	0	zeOraa🌷	0	4	0	0	78	0	\N	0
1830166896	0	winnie galau	0	1	0	0	0	0	\N	0
2115204920	0	Sabie	0	83	0	0	441.0899999999985	522	\N	0
1892396972	0	rere	0	47	1	0	0	95	\N	0
5817352839	0	ree	0	2	0	0	5036.85	1	\N	0
6056385475	0	nad	0	21	0	0	35.55	18	\N	0
5282037076	0	Jeff tamvan	0	1	0	0	0	0	\N	0
1714260805	0	gf jehyun	0	70	0	0	0	118	\N	0
1632276027	0	a	0	33	0	0	0	102	\N	0
1475930108	0	ailyn	0	21	0	0	70.71000000000001	148	\N	0
6097112580	0	lance cosplay Ultraman	0	1	0	0	21.19	26	\N	0
1876026513	0	Seréina.	0	16	0	0	0	72	\N	0
6335993588	0	L	0	3	0	0	0	1	\N	0
1342331062	0	Pablo	0	7	0	0	0	5	\N	0
1723785672	0	Ca	0	1	0	0	0	0	\N	0
5376031957	0	🐡	0	3	0	0	0	111	\N	0
2059660889	0	ㅤㅤㅤ	0	46	0	0	0	50	\N	0
1748558697	0	c	0	37	0	0	0	13	\N	0
6274307119	0	.	0	1	0	0	0	0	\N	0
5791839003	0	jeff	0	0	0	0	0	0	\N	0
5260806949	0	ze	0	1	0	0	0	0	\N	0
1565688955	0	␥ vög. valisha	0	1	0	0	0	0	\N	0
5182448806	0	JIYEL	0	210	0	0	306.65000000000003	19	\N	0
1944946819	0	sandra	0	62	0	0	0	98	\N	0
1810581919	0	ahahahay	0	24	0	0	0	8	\N	0
1604097625	0	sad	0	63	0	0	0	7	\N	0
2059695967	0	Helen	8	63	1	0	2454.2	248	\N	1
6085572772	0	L	0	5	0	0	0	0	\N	0
2061826561	0	R	0	0	0	0	0	1	\N	0
6826347900	0	zar	0	5	0	0	0	0	\N	0
5529848277	0	Syazrianaa	0	70	0	0	0	57	\N	0
2108228286	0	jeha	0	5	0	0	0	1	\N	0
1464829771	0	macey	0	9	0	0	0	5	\N	0
5229562355	0	Angela	0	1	0	0	0	0	\N	0
6612707071	0	biaaan	12	56	0	0	2091.75	245	\N	0
1886644732	0	hauraa	2	142	0	0	3952.4800000000005	1019	\N	0
7092799266	0	ֹ ᮫ ⑅ ֹ 𝐚𝐢𝐦𝐢𝐢 ۪ ֹ𓂃݊ ׅ˖♡	0	1	0	0	0	0	\N	0
6284369203	0	SIANG	0	1	0	0	0	1	\N	0
6942390034	0	pramiswari	0	1	0	0	205.26	35	\N	0
6507474298	0	♡	0	7	0	0	0	1	\N	0
1929663223	0	sab!l wikky	7	217	0	0	1514.8900000000003	362	\N	0
6276319161	0	Ta	0	20	0	0	-10.57	6	\N	0
6624172940	0	nata	0	11	0	0	0	1	\N	0
1772683272	0	iel🌱🤺	0	5	0	0	0	4	\N	0
6770846561	0	Ocen :>	0	3	0	0	0	0	\N	0
1795678205	0	vgx al Victoryking	9	74	0	0	551.4	20	\N	0
6221338317	0	easya	0	14	0	0	0	0	\N	0
6761491131	0	Steve.	0	2	0	0	0	2	\N	0
1701215590	0	A	0	82	0	0	219.99	6	\N	0
1645415116	0	logout	0	27	0	0	260.47	966	\N	0
6571817925	0	Jeje	0	1	0	0	0	0	\N	0
5761880715	0	ᴀʟ 💤	0	1	0	0	0	4	\N	0
1848030035	0	aliya	0	1	0	0	0	0	\N	0
1175905395	0	ʚɞ all	0	9	0	0	0	4	\N	0
1689285717	0	Sœrge C.Dimitriscu	0	1	0	0	980	48	\N	0
6196138134	0	Aleen.	0	5	0	0	0	5	\N	0
5981474861	0	Kalina	0	9	0	0	0	1	\N	0
6953321204	0	avil⁴, Jjess	0	1	0	0	0	1	\N	0
1908695920	0	kala	0	369	0	0	0	7	\N	0
5214596482	0	freya anak baikk. 💐💐	0	4	0	0	0	1	\N	0
5126357830	0	prut	0	1	0	0	0	0	\N	0
6851112697	0	--	0	0	0	0	0	0	\N	0
5441573833	0	kaira	0	18	0	0	0	8	\N	0
2020718913	0	ra	6	31	0	0	0	2	\N	0
1977829206	0	này	0	1	0	0	0	0	\N	0
1754427232	0	Riss	0	927	0	0	5.569999999999936	161	\N	0
2022231373	0	Aiss.	0	0	0	0	0	0	\N	0
1842222916	0	J	0	65	0	0	0	6	\N	0
1903638555	0	pizza	0	3	0	0	200.07	8	\N	0
6327874630	0	June┊ ೃ⁀➷	0	2	0	0	0	0	\N	0
2127557331	0	Iroo.	4	192	0	0	452.92999999999995	1690	\N	0
5932675655	0	.	0	1	0	0	0	0	\N	0
1688802157	0	molly	0	1	0	0	0	0	\N	0
5592792762	0	.	0	1	0	0	0	2	\N	0
5038570701	0	et	0	2	0	0	0	0	\N	0
5074699644	0	tiny-baby, liviaa.	0	971	0	0	0.44999999999998863	25068	\N	0
5774684310	0	Kylé	0	4	0	0	0	1	\N	0
5315372499	0	logout	0	1	0	0	0	0	\N	0
1448533547	0	lucienne	0	57	0	0	0	97	\N	0
1800191373	0	DAGG€R THEK!NG 🏴‍☠	0	1	0	0	0	1	\N	0
6366854786	0	𐙚 ࣪säsaa méow 🐈	0	6	0	0	0	14	\N	0
5060000801	0	Cassiopeia Salazar.	0	1	0	0	0	2	\N	0
5477396156	0	dama4	0	0	0	0	0	0	\N	0
5550646517	0	repa cwkmu🌀🌀	0	2	0	0	0	6	\N	0
6131865265	0	pinaa	10	1	0	0	142.53000000000003	2	\N	0
1808933941	0	faa	0	1	0	0	0	0	\N	0
6217982330	0	Vin	0	1	0	0	0	0	\N	0
5906307988	0	kim.	0	3	0	0	0	3	\N	0
1617900268	0	bastian SIBUK PROKERAN	6	652	0	0	2341.74	1467	\N	0
1687411729	0	becca	0	8	0	0	0	39	\N	0
6845530020	0	ka	0	8	0	0	0	15	\N	0
6974933059	0	ocean🌊..	0	53	0	0	2434	32	\N	0
1966141183	0	cilyzeila	0	8	0	0	0	32	\N	0
7019216584	0	MORVIENNA	0	1	0	0	0	0	\N	0
1790302600	0	Raraa.	0	22	0	0	0	0	\N	0
5439858357	0	Maraka.	0	4	0	0	0	18	\N	0
1706464159	0	Choco	0	1	0	0	0	0	\N	0
1720781230	0	K	0	4	0	0	0	0	\N	0
1932026746	0	Pangeran	0	9	0	0	0	0	\N	0
1774825048	0	Minji.	0	72	0	0	140.32	20	\N	0
1229547112	0	widyaaa	0	7	0	0	0	3	\N	0
5352618405	0	Luna	6	17	0	0	171.10000000000002	93	\N	0
1244630754	0	mia scallouvey.	0	2	0	0	0	0	\N	0
1287191180	0	X-H 20 Nayla Kanahaya	0	0	0	0	0	0	\N	0
6074770832	0	unknowns	0	26	0	0	0	3	\N	0
6279622416	0	manda🍉	9	12	0	0	2121.76	4434	\N	0
5936617306	0	cloo🐺🦋	0	5	0	0	0	0	\N	0
5229921391	0	erissa	0	4	0	0	0	5	\N	0
1746462052	0	jwan	0	1	0	0	0	0	\N	0
6947883621	0	rA	0	0	0	0	0	0	\N	0
5461047118	0	Muhamad	0	75	0	0	124.84	30	\N	0
5892016184	0	Jenri Cholas	0	2	0	0	0	0	\N	0
1842866258	0	kayie	0	43	0	0	0	8	\N	0
1164642486	0	biii	0	2	0	0	0	2	\N	0
6101266690	0	Kazoo	2	141	0	0	417.3599999999999	418	\N	0
1626314658	0	rn	0	1	0	0	50	0	\N	0
1968320831	0	aca	0	0	0	0	0	0	\N	0
2021344940	0	.	3	534	1	0	13.859999999999673	318	\N	0
1436611619	0	ajora cebeww	0	698	1	0	986.7099999999916	2808	\N	0
6826051052	0	Dopica P.	0	8	0	0	0	7	\N	0
6144346843	0	aurell	0	3	0	0	0	0	\N	0
5969364764	0	Faayth	0	16	0	0	0	179	\N	0
1438373195	0	reinjun	0	8	0	0	0	0	\N	0
6482788319	0	Ge	0	1	0	0	0	9	\N	0
2033729359	0	Amiw.	0	4	0	0	0	0	\N	0
5737763130	0	la	0	1	0	0	0	0	\N	0
6117035345	0	L. weasley	0	11	0	0	0	22	\N	0
6850533641	0	thal	0	2	0	0	0	1	\N	0
249322575	0	Kyyy	0	9	0	0	4.27	163	\N	0
5657014363	0	allysa	0	2	0	0	0	0	\N	0
6696775812	0	bibiel	0	0	0	0	0	0	\N	0
5212601840	0	Meiji.	0	1	0	0	0	0	\N	0
5287526502	0	eja	0	0	0	0	0	11	\N	0
1782000363	0	Keithara	0	6	0	0	0	37	\N	0
6837920189	0	Yirena ainsley.	0	8	0	0	0	8	\N	0
1492014194	0	raka	0	4	0	0	0	7	\N	0
5254951524	0	bibey	0	2	0	0	0	0	\N	0
1910668075	0	Oye	0	1	0	0	0	0	\N	0
5284430088	0	Reana Adwell Dixon	0	19	0	0	0	4	\N	0
1296393056	0	Adikta. SLCTV	0	21	0	0	0	64	\N	0
2063600249	0	𝐔𝐜𝐚𝐥𝐥𝐦𝐞𝐤𝐚𝐧𝐣𝐞𝐧𝐠	0	14	0	0	0	25	\N	0
1889149537	0	?	0	244	0	0	283.65	60	\N	0
5546161250	0	broo?	0	1	0	0	0	0	\N	0
5396491707	0	Jaegar's serotonin, Alby	0	0	0	0	0	17	\N	0
5498510677	0	chase. park jisung love taker	3	4	0	0	0	47	\N	0
5891067396	0	ga	0	8	0	0	0	20	\N	0
1968096468	0	Tiara	0	1	0	0	0	0	\N	0
5487993891	0	zee	2	56	0	0	1458.3	45	\N	0
1927988297	0	cell lagi ngambek	10	74	0	0	14.049999999944703	3729	\N	1
6377673460	0	F	0	1	0	0	0	0	\N	0
5114285094	0	bim	0	34	0	0	20.019999999999982	89	\N	0
5032926498	0	awān	0	27	0	0	0	1	\N	0
1887552292	0	alana	0	50	0	0	0	131	\N	0
1813418353	0	Klee supremacy	0	104	0	0	13	1463	\N	0
5185810216	0	@jovalynstore	0	2	0	0	0	0	\N	0
5310419402	0	rest. olive	0	39	0	0	374	8	\N	0
1838261254	0	mel	0	4	0	0	0	1	\N	0
6111972643	0	arshafaaᴴᴸ	0	3	0	0	0	0	\N	0
5004230270	0	Vievie	14	289	0	0	136.39999999999998	318	\N	0
1237130916	0	grv. ethanasía el leoudíes	0	3	0	0	13.05	29	\N	0
6857465271	0	vaness (Ariana's grande gf)	0	4	0	0	0	2	\N	0
6220073288	0	qara	0	84	0	0	3152.4900000000002	60	\N	0
1719639656	0	Gwennie	0	1	0	0	0	0	\N	0
806415638	0	Tam	0	3	0	0	0	9	\N	0
5009115412	0	ashleyyyyy	0	3	0	0	0	4	\N	0
6317125628	0	𝐉𝐞𝐚𝐧𝐚𝐚.	0	1	0	0	0	1	\N	0
5431774414	0	r	0	134	0	0	0	9	\N	0
7066901617	0	nOthInG	0	8	0	0	0	0	\N	0
1672836828	0	cici	0	1	0	0	0	0	\N	0
2078979433	0	?	0	104	0	0	0	2	\N	0
5359624640	0	alif	0	1	0	0	0	2	\N	0
5153706440	0	jhovanca	0	30	0	0	0	36	\N	0
1769726763	0	ㅤㅤㅤ	0	5	0	0	0	1	\N	0
1232185698	0	Aillie	0	5	0	0	0	20	\N	0
5518659667	0	Raveska Vonderich.	0	2	0	0	0	7	\N	0
5500609995	0	Zeandra	0	3	0	0	0	1	\N	0
1560641655	0	~	0	10	0	0	0	4	\N	0
5246841806	0	Joexya	0	8	0	0	0	17	\N	0
5890427737	0	jj	14	3	0	0	778.66	85	\N	0
5382019939	0	Lazif	0	135	0	0	1133.5	804	\N	0
5844565385	0	sasa	0	8	0	0	491.45	1	\N	0
1681679204	0	Zara	0	6	0	0	0	65	\N	0
5928536658	0	alyz	0	2	1	0	0	2	\N	0
5926984692	0	A.	0	5	0	0	0	1	\N	0
1768792151	0	serra	0	111	0	0	0	21	\N	0
1638913508	0	Reno	0	7	0	0	0	0	\N	0
1793024126	0	jav	0	1	0	0	0	2	\N	0
1850536666	0	Taeyong	0	6	0	0	0	0	\N	0
7053911879	0	C M T	0	0	0	0	0	0	\N	0
1790270739	0	Zevanya C.	0	13	0	0	0	7	\N	0
6097200851	0	A	0	53	0	0	0	3	\N	0
5053781010	0	kayy	0	127	0	0	153.87	486	\N	0
1419140021	0	Chillael •	0	2	0	0	0	21	\N	0
5225975249	0	amarine.	0	2	0	0	0	5	\N	0
5185194396	0	Milea.	0	29	0	0	0	256	\N	0
5023575549	0	gaviDel	0	1	0	0	0	0	\N	0
1711838490	0	derson	0	16	0	0	4.289999999999999	1	\N	0
5870368769	0	Jeager	0	2	0	0	0	0	\N	0
6616733845	0	C	0	4	0	0	0	0	\N	0
993346773	0	kucil.rdt	0	0	0	0	0	0	\N	0
1856164482	0	zasha pcr winwin	0	13	0	0	0	59	\N	0
1904300062	0	Angel	0	4	0	0	0	0	\N	0
1513112478	0	𝒂𝒓𝒂𝒏𝒄𝒆 𝇋♡︎𝇌	12	144	0	0	3203.7200000000003	7885	\N	0
6616809989	0	z	0	4	0	0	0	8	\N	0
5007945256	0	sya	0	2	0	0	0	1	\N	0
5168586823	0	Vienca.	0	29	0	0	5.93	19	\N	0
5078829877	0	nadyà	0	15	0	0	0	13	\N	0
5897889624	0	Gor	0	4	0	0	0	0	\N	0
5368828247	0	sera	0	40	0	0	316.6	2	\N	0
1447013287	0	S	0	1	0	0	0	0	\N	0
6670738833	0	Galaxy Andromeda	0	1	0	0	0	1	\N	0
5854550056	0	Harris, ctron	0	1	0	0	0	0	\N	0
643260374	0	faghyu	0	3	0	0	0	0	\N	0
6000944464	0	Sajiw	0	8	0	0	0	3	\N	0
1418094351	0	nina	0	1	0	0	0	0	\N	0
5129811320	0	윤찬영 xena	0	6	0	0	0	28	\N	0
5241204679	0	lont. karissa 🇬🇲	0	2	0	0	0	5	\N	0
7018551046	0	Ca	0	29	0	0	0	95	\N	0
1268857773	0	ic	0	8	0	0	0	13	\N	0
5971058433	0	a.	0	59	0	0	378.44000000000005	53	\N	0
1955915637	0	Watafak botaq	0	30	0	0	0	19	\N	0
5198051626	0	Camorra.	0	1	0	0	0	21	\N	0
1625285147	0	<3	11	393	0	0	104.72250000000008	54	\N	0
5182032893	0	shella	0	3	0	0	0	0	\N	0
5259217673	0	putra scorf	0	2	0	0	0	2	\N	0
5374122823	0	human made	0	1	0	0	0	0	\N	0
1232879286	0	xx_æ	0	42	0	0	0	49	\N	0
5250599839	0	Karin L. –chat ulg	0	392	0	0	2008.785	1394	\N	0
5503710131	0	bojone harry potter	0	269	0	0	0	115	\N	0
5216880100	0	denaa	0	1	0	0	0	0	\N	0
1962391416	0	yinyinayin	0	7	0	0	0	0	\N	0
5725655462	0	saskyyx	0	2	0	0	0	14	\N	0
5227386277	0	Lionkei	0	2	0	0	0	1	\N	0
2061507237	0	kvn	0	1	0	0	0	5	\N	0
2129827687	0	little fairy, ayyaaa 🧚🏻	0	22	0	0	0	14	\N	0
1786384562	0	A	0	89	0	0	0	39	\N	0
5900715375	0	ce.	0	3	0	0	0	21	\N	0
6338731020	0	Sharinna	0	1	0	0	0	0	\N	0
2028699757	0	aldi	0	12	0	0	0	3	\N	0
5697749758	0	Kajesha.	0	5	0	0	0	7	\N	0
1717898882	0	cana	0	1	0	0	0	1	\N	0
6033032805	0	wishnu.	0	3	0	0	0	2	\N	0
1629442945	0	𝜗𝜚 .. offpc. Holder Anett	0	120	0	0	0	17	\N	0
5976006660	0	Sukarti	0	1	0	0	0	0	\N	0
1830039034	0	Gab	0	30	3	0	0	11	\N	0
1818904479	0	Jasper. Co	0	49	0	0	0	1	\N	0
6304103161	0	alinn	0	0	0	0	0	0	\N	0
2103174361	0	hai, Riss?	0	2	0	0	478	17	\N	0
6238968199	0	asya	0	1	0	0	178.55	70	\N	0
6229396653	0	.	0	10	0	0	0	0	\N	0
2024613911	0	almouuu	0	6	0	0	793.3399999999999	52	\N	0
1661467147	0	B O B Y •	0	21	0	0	0	327	\N	0
5044348224	0	jiya	0	3	0	0	0	0	\N	0
1850551140	0	M	0	109	0	0	185.76999999999998	23	\N	0
6987241200	0	loren	0	1	0	0	0	0	\N	0
1804498326	0	☀️𖤣 matahari	0	0	0	0	0	0	\N	0
1628980615	0	.	0	175	0	0	0	0	\N	0
5328201036	0	vièl	0	4	0	0	0	5	\N	0
5101498753	0	julieth,	0	6	0	0	0	14	\N	0
1913039822	0	cemin	4	58	0	0	2015.56	411	\N	0
6970127853	0	Mahin	0	1	0	0	0	1	\N	0
5925238438	0	rayyen	0	122	0	0	0.36999999999999744	67	\N	0
1939237849	0	Ara	0	0	0	0	0	0	\N	0
6187691144	0	salika	0	1	0	0	28	0	\N	0
1612189768	0	Al	0	88	0	0	1473.875	658	\N	0
5924953157	0	louie	14	10	0	0	229.55999999999992	181	\N	0
6176735251	0	Senjo	13	4	0	0	1635.28	33	\N	0
5049590185	0	arlan	0	28	0	0	0	8	\N	0
1320399587	0	just me	0	3	0	0	0	0	\N	0
5087721717	0	A. on duty!	0	1	0	0	0	0	\N	0
5366409250	0	r	0	819	0	0	9.86	7	\N	0
5597304977	0	Micaelys	0	39	0	0	0	34	\N	0
5024482559	0	💎'kyle૮ ˙Ⱉ˙ ა	0	2	0	0	0	0	\N	0
1693628877	0	Mrs. Tara	0	1	0	0	0	0	\N	0
1875841619	0	ㅤ	1	48	0	0	57.88	4	\N	0
5036565625	0	ㅤㅤ	0	1	0	0	0	0	\N	0
6849148357	0	ᴊᴇɴᴅʀᴀʟ. jovi ōtsuki	0	3	0	0	0	7	\N	0
6680875430	0	Benedict Lërgdoum. #MONSTERJMHS⁴	0	2	0	0	0	15	\N	0
5801653511	0	oca	0	1	0	0	0	0	\N	0
5355792546	0	Mi	0	4	0	0	0	8	\N	0
6368598497	0	张柏芝	0	5	0	0	0	0	\N	0
1832799795	0	bela nih kids ☝🏻😝	0	1	0	0	0	0	\N	0
6654495063	0	yerra	0	1	0	0	0	0	\N	0
5109532755	0	gue dpr	0	336	0	0	4.759999999999536	1511	\N	0
5375737863	0	all	0	6	1	0	0	0	\N	0
6279368137	0	nara	0	3	0	0	0	3	\N	0
1388693282	0	kiL🅰️	0	16	0	0	0	0	\N	0
1770968215	0	gege	0	1	0	0	0	4	\N	0
2004263376	0	𝙉𝙀𝙀𝙇	0	4	0	0	0	5	\N	0
1770930901	0	zeo	0	1	0	0	0	0	\N	0
1182918684	0	Kiji	0	9	0	0	50	4	\N	0
1797628949	0	.	0	9	0	0	0	0	\N	0
1723766786	0	ersey cukaa alpacaa	0	0	0	0	0	62	\N	0
5134006652	0	pie mabok WINTEEEERR	0	1	0	0	0	1	\N	0
5600825893	0	Rafli	0	88	0	0	0	11	\N	0
6259337664	0	atlaana	0	3	0	0	0	6	\N	0
1149405735	0	k	0	68	0	0	0	15	\N	0
1379040098	0	hanna	0	1	0	0	0	0	\N	0
5722683070	0	𝐂ae	0	1	0	0	0	0	\N	0
5692227446	0	rago	0	6	0	0	0	0	\N	0
1777251273	0	jegas	0	24	0	0	0	0	\N	0
2137224056	0	pi	0	23	0	0	0	94	\N	0
990030236	0	dni	0	47	0	0	0	0	\N	0
1795478122	0	reizi	0	1	0	0	0	0	\N	0
1884877849	0	damelia	0	2	0	0	0	0	\N	0
5312457637	0	re	0	4	0	0	0	0	\N	0
5927747013	0	St. Lust	0	1	0	0	0	0	\N	0
6803462515	0	Daisy	0	1	0	0	0	0	\N	0
1400868127	0	Ꞌ𝘢𝘺𝘢	0	8	0	0	0	15	\N	0
1173535027	0	ʙᴡōʟғ. 𝚁𝚒𝚌𝚔𝚢 𝚍𝚅𝚊𝚗𝚘 ōtsuki ⚝	0	17	0	0	273.41999999999996	56	\N	0
1801854152	0	Jeevan	0	77	0	0	4	117	\N	0
5868651138	0	jehya evesther	0	14	0	0	0	4	\N	0
6177828183	0	naren	0	5	0	0	0	1	\N	0
5816255294	0	Eknath J.	0	0	0	0	0	0	\N	0
1907089756	0	Narellise J'vaerlsuoth.	0	4	0	0	0	0	\N	0
6456111288	0	dan naga	0	3	0	0	0	0	\N	0
5014424547	0	:o	1	12	0	0	0	47	\N	0
1913305884	0	esa	0	4	0	0	0	6	\N	0
6913480008	0	— Novaa	0	1	0	0	0	0	\N	0
1452090240	0	Mid	0	1	0	0	0	0	\N	0
6481674789	0	Amichellé	0	0	0	0	0	0	\N	0
1893133935	0	b	0	10	0	0	0	11	\N	0
6048085587	0	abel	0	11	0	0	166.49	46	\N	0
1432489555	0	D	0	1	0	0	0	0	\N	0
5200883306	0	Ehan	0	5	0	0	0	1	\N	0
1784418192	0	.	0	15	0	0	4.460000000000036	0	\N	0
5475445428	0	Wayann	0	3	0	0	0	0	\N	0
1798726374	0	safhira	0	2	0	0	0	0	\N	0
1312133708	0	al	0	25	0	0	0	30	\N	0
6282089841	0	jane, lg sedih	3	325	0	0	413.0900000000015	608	\N	0
5577287251	0	Maego	0	19	0	0	1305.63	29	\N	0
1728113695	0	nks nta 4	0	1	0	0	0	0	\N	0
1887479175	0	Jay Wiguna	0	0	0	0	0	5	\N	0
5974395262	0	leysh	0	4	0	0	0	2	\N	0
905030800	0	Yaya	0	1	0	0	0	0	\N	0
1598888346	0	Gue Tau Cari Yang Setia Itu Susah	0	18	0	0	40	200	\N	0
1930949096	0	+ Javicha — 🎀🧺 ៸៸ ‌۰ .	0	8	0	0	0	85	\N	0
5797953784	0	Lauise.	0	28	0	0	950.1899999999996	20	\N	0
5330719337	0	amourena	0	1	0	0	0	0	\N	0
1369497934	0	mr	0	3	0	0	0	24	\N	0
6332204493	0	Andra.	0	3	0	0	0	5	\N	0
5521237783	0	pret	0	7	0	0	0	0	\N	0
6010898395	0	R	0	17	0	0	48.06	14	\N	0
6503666400	0	˹ ꜱ ᴇ ʟ ᴧ ˼‎ ˢˢˣ² 𑲭𑲭𑲭𑲭𑲭	0	1	0	0	0	2	\N	0
6922265639	0	el	0	1	0	0	0	0	\N	0
1473094647	0	ayden victoryking	0	88	0	0	0	4	\N	0
5974844648	0	ra	0	1	0	0	0	0	\N	0
1868571481	0	il tuo amante	0	2	0	0	0	0	\N	0
6937685108	0	N	0	24	0	0	0	13	\N	0
1657520144	0	🐈	0	2	0	0	0	1	\N	0
5966548273	0	Damian Achryson.	0	1	0	0	0	0	\N	0
5813659570	0	🫂	0	15	0	0	1412	10	\N	0
6430344353	0	かおり #mulchar	0	1	0	0	0	25	\N	0
1239559483	0	.	0	3	0	0	0	0	\N	0
828421148	0	Zenata	0	4	0	0	0	0	\N	0
5841990571	0	Raya Gavintara	0	2	0	0	0	5	\N	0
1660373403	0	cleo	0	16	0	0	0	0	\N	0
6028141006	0	Makio	0	15	0	0	0	12	\N	0
1614480253	0	FiksZ	0	35	0	0	1160.640000000014	454	\N	0
6871105760	0	🧁𓂋 ׁ されたと 𖣁 ֪ 】𓈒 gsh ngatur kontol	0	57	1	0	50	20	\N	0
5489031043	0	.	0	3	0	0	0	0	\N	0
5748547025	0	mei	0	157	0	0	0	16	\N	0
5195257925	0	ci ' w¡kky.	0	3	0	0	0	1	\N	0
6014656241	0	Nada	0	12	0	0	0	37	\N	0
6923849888	0	ca	0	0	0	0	0	2	\N	0
5859231309	0	˚ ༘ 𝗰𝗵𝗮𝗲𝗿𝗮𝗮 ⋆｡ asc¹³ vcr¹	0	5	0	0	0	0	\N	0
6859168798	0	tay's	0	0	0	0	0	0	\N	0
5600113480	0	.noir	0	2	0	0	0	4	\N	0
1303194301	0	flakeygrl	0	1	0	0	0	27	\N	0
5302336798	0	arsell issaedith.	0	0	0	0	0	1	\N	0
2093136927	0	aleexei telkomsel 𝒩ℋsᴄʜᴏᴏʟᵒˢⁱˢ	0	3	0	0	0	0	\N	0
5105599046	0	ar	0	135	0	0	6.029999999999973	0	\N	0
1977827800	0	SaintLaurent	0	18	0	0	400	34	\N	0
6060858828	0	Manusia	0	7	0	0	0	1	\N	0
1961228035	0	.	0	0	0	0	0	0	\N	0
6285822848	0	ayam	0	11	0	0	0	1	\N	0
5149638811	0	fey	0	145	0	0	913	432	\N	0
5595544979	0	shaour	0	22	0	0	941.07	0	\N	0
6414532238	0	Yaska Khiar	0	3	0	0	0	0	\N	0
1837491012	0	dion ckp	0	1	0	0	0	0	\N	0
5536893312	0	aileen	0	0	0	0	0	0	\N	0
6388448374	0	Oyen	0	8	0	0	0	2	\N	0
5327982616	0	Adam	0	3	0	0	0	2	\N	0
5933344778	0	xiu	0	3	0	0	0	3	\N	0
6437232401	0	Angelica	0	5	0	0	0	0	\N	0
1854342163	0	𝐀zza	0	2	0	0	0	0	\N	0
1154314229	0	Jerapahcongek	0	26	0	0	0	46	\N	0
1392491828	0	ai perli	0	1	0	0	0	0	\N	0
1948464774	0	Dont	0	1	0	0	0	0	\N	0
5599362726	0	hi	0	33	0	0	0	10	\N	0
1842975725	0	r	0	46	0	0	0	94	\N	0
5473482097	0	esa @saguvsa	0	2	0	0	0	0	\N	0
6554907176	0	move acc	0	4	3	0	0	0	\N	0
5564120018	0	damian	0	7	0	0	0	1	\N	0
6524053470	0	ayin	0	344	0	0	91	7	\N	0
1764134943	0	pael	0	1	0	0	0	0	\N	0
6491030149	0	iCEN . #antipenipu	0	1	0	0	0	0	\N	0
2067288846	0	rak	0	79	0	0	276	24	\N	0
1334859365	0	BOYS DONT CRY	0	8	1	0	0	10	\N	0
1386217268	0	Dre	0	30	0	0	0	170	\N	0
1773342440	0	a	0	149	0	0	0	23	\N	0
5606626060	0	ustad co	0	7	0	0	0	0	\N	0
6082428624	0	Lyn	0	7	0	0	0	5	\N	0
1870036892	0	nazeeRA	0	48	0	0	0	8	\N	0
6505053482	0	ㅤㅤㅤㅤㅤㅤㅤ	0	19	0	0	0	36	\N	0
1889820799	0	Keyrin'	0	20	0	0	92.34	0	\N	0
6598516524	0	sZee, open vcs	0	1	0	0	0	0	\N	0
1243330935	0	Your bae	0	0	0	0	0	3	\N	0
1729611375	0	razevha, m.	0	8	0	0	0	6	\N	0
1318888457	0	Asheya T.	0	2	0	0	0	0	\N	0
6101488940	0	HAZEL.	0	1	0	0	0	2	\N	0
1966317727	0	Louis	0	0	0	0	0	0	\N	0
6076137757	0	👺	3	209	0	0	94.80000000000001	155	\N	0
6168425035	0	k	0	7	0	0	868	5	\N	0
1295323506	0	aski	0	3	0	0	0	0	\N	0
1971768547	0	dina	0	4	0	0	0	1	\N	0
5931795644	0	Bakenloon💎	0	0	0	0	0	0	\N	0
1305314769	0	Mirza	0	2	0	0	0	1	\N	0
5058977494	0	M. Anastacia	13	36	0	0	1437.1099999999997	73	\N	0
912881186	0	gin	10	56	0	0	14.43	108	\N	0
5091170418	0	j	0	0	0	0	0	1	\N	0
5526185819	0	jack	0	12	0	0	0	2	\N	0
6690761030	0	Hasya.	0	9	0	0	0	22	\N	0
6444071919	0	𝐓𝐑≛𝐏𝐒 ` exsa	0	3	0	0	0	1	\N	0
1616202287	0	𝐑angga ror dinosaurrrr	0	10	0	0	0	1	\N	0
5554530878	0	d	0	137	1	0	576.0699999999999	24	\N	0
1063595460	0	Han	0	12	0	0	0	23	\N	0
5402036972	0	edise	0	1	0	0	0	17	\N	0
6072082974	0	Ucup	0	33	0	0	0	17	\N	0
5453569075	0	Yoshi	0	188	0	0	65.5599999999996	12	\N	0
6002330419	0	⊱ ֺ ۪ ayes	0	1	0	0	0	0	\N	0
1183809121	0	Jouzoo	0	14	0	0	0	6	\N	0
1710585015	0	rmd². Kayna A	0	15	0	0	0	0	\N	0
1854526448	0	diva	0	13	0	0	0	12	\N	0
5412852643	0	Tebak nama	0	29	0	0	0	54	\N	0
1863356759	0	idk	0	20	0	0	0	0	\N	0
2136726367	0	reysia 🌷	0	95	0	0	46.28	359	\N	0
5356469697	0	Memey sama lauren itu sama	11	149	0	0	427.2999999999996	1444	\N	0
6198527283	0	Noze	0	3	0	0	0	10	\N	0
1683554085	0	bajan	0	4	0	0	0	4	\N	0
5060143770	0	noturboy	0	1	0	0	0	0	\N	0
5163479624	0	drexa	0	16	0	0	0	7	\N	0
5053253425	0	miy	0	12	0	0	10.15	23	\N	0
6720865921	0	lukarakabs	0	6	0	0	0	3	\N	0
1987977461	0	Erlangga @stfvckk	0	8	0	0	0	40	\N	0
1694342999	0	lian	0	389	0	0	-2.5	2278	\N	0
5380644432	0	Drake,	0	1	0	0	0	0	\N	0
5764405928	0	Rei	0	1	0	0	0	3	\N	0
6962794853	0	Jean	0	1	0	0	0	6	\N	0
5698329257	0	jasper	0	2	0	0	0	10	\N	0
1776190621	0	daging	1	2	0	0	432.9599999999999	486	\N	0
5536493737	0	𝐀úl . tlong fsr yh	0	5	0	0	0	0	\N	0
1273887207	0	sa	0	132	0	0	283.76	2	\N	0
5413787714	0	Ika's here	0	4	0	0	0	2	\N	0
5466662319	0	kittyy	0	1	0	0	0	0	\N	0
5535274648	0	just lelé.	0	22	0	0	100	165	\N	0
1856216374	0	yemima	0	1	0	0	0	0	\N	0
1809828295	0	darren pradipta	0	3	0	0	0	1	\N	0
1471257413	0	jie satu dua tidak apa apah	0	1	0	0	0	3	\N	0
1781605784	0	Deora	0	6	0	0	0	0	\N	0
2055842570	0	< 📄🎀 > Kaluna Eustaria : ₊ ˚ ♡ :3	0	23	0	0	0	3	\N	0
6477034709	0	karisa	0	20	0	0	103.97999999999982	89	\N	0
5165950600	0	Jaki.	0	2	0	0	0	0	\N	0
1664962759	0	Irzha & Chiyo	0	90	0	0	0	20	\N	0
6628989450	0	rest.	0	22	0	0	0	168	\N	0
6796232554	0	rarely actv.	0	19	0	0	2235	24	\N	0
5424794242	0	Jello MonsTerra.	0	1	0	0	0	16	\N	0
1959735297	0	N	0	0	0	0	0	0	\N	0
5547018407	0	lalaa	0	4	0	0	0	2	\N	0
5395014074	0	b	0	12	0	0	0	0	\N	0
1819865605	0	naa	0	239	0	0	98.0499999999999	108	\N	0
1712529038	0	miela	0	6	0	0	0	0	\N	0
1766871918	0	lintàng. Rest	0	51	0	0	105.5	21	\N	0
1901912299	0	ruffy	0	105	0	0	0	59	\N	0
1505232691	0	𝐓y rest	0	1	0	0	0	0	\N	0
1266370286	0	a	0	4	1	0	0	0	\N	0
6226562112	0	misfit	0	1	0	0	0	7	\N	0
7104514699	0	ㅤ ㅤ ㅤ	0	3	0	0	0	3	\N	0
1800285988	0	Kayess.	0	1	0	0	0	3	\N	0
1314908576	0	unay	0	1	0	0	0	0	\N	0
1458002725	0	wlvs.nyr¹.cece zicar²	0	5	0	0	0	12	\N	0
1722381003	0	javas	0	1	0	0	0	0	\N	0
5156795401	0	Zu	0	6	0	0	28.86	4	\N	0
1082599785	0	Navie @ilovebigbooubs ₘₑᵣCᵤᵣY	0	16	0	0	0	13	\N	0
5031192798	0	Madame. Rou.	0	2	0	0	0	0	\N	0
5130848673	0	.	0	1	0	0	0	0	\N	0
5863705414	0	hazel suka heesung	0	9	0	0	0	0	\N	0
5379448380	0	bula	0	40	0	0	1308.6299999999999	1223	\N	0
5823550783	0	hihang hoheng	0	33	0	0	531.61	2	\N	0
5872764400	0	Shifa	0	1	0	0	0	9	\N	0
6077315202	0	shasha	0	4	0	0	0	33	\N	0
6493813828	0	⸙ꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋńalaa | berkabar lebseleb🐳	0	0	0	0	0	4	\N	0
6826061549	0	D.	0	4	0	0	0	0	\N	0
5097857044	0	ꪗoᥴเเ ૮ ๑ˊᯅˋ๑ აִ	0	103	0	0	0	26	\N	0
1008051743	0	i	0	0	0	0	0	0	\N	0
1717317389	0	A	0	1	0	0	0	124	\N	0
1879161003	0	lun	0	2	0	0	0	0	\N	0
1809908882	0	okaa	0	9	0	0	0	1	\N	0
5243264706	0	piaaa	0	876	0	0	6.5	13979	\N	0
1785315001	0	💤	0	13	0	0	0	11	\N	0
1245447380	0	Winniella A`Meilleure	0	1	0	0	0	15	\N	0
6594944751	0	𐀼’ •• 検索, VOUSSIERA	0	7	0	0	0	0	\N	0
5196891432	0	lix	0	3	0	0	0	10	\N	0
1187278818	0	lunar (taylor's version)	0	62	0	0	469.5	1586	\N	0
6269226816	0	Ryusei. lagi stress	0	0	0	0	0	0	\N	0
5805003932	0	Shaquilla	0	2	0	0	0	0	\N	0
2067760623	0	jaki	0	13	0	0	1212.56	359	\N	0
5035528521	0	kz	0	7	0	0	0	4	\N	0
2147160764	0	kesha	0	12	0	0	0	0	\N	0
5515346928	0	blue lesbi	0	3	0	0	0	31	\N	0
1742847400	0	miss someone.	0	2	0	0	0	4	\N	0
5618581235	0	Gys	0	17	0	0	0	18	\N	0
5107114176	0	hammm #anti4t	0	467	0	0	44.989999999999995	651	\N	0
6717863927	0	𝖕𝖜𝖊𝖙𝖙𝖆	0	6	0	0	0	29	\N	0
1891580773	0	a	0	6	0	0	0	281	\N	0
5954430924	0	👾	0	41	0	0	0	18	\N	0
5784340607	0	morgan	0	20	0	0	0	9	\N	0
6836101132	0	rest	0	54	0	0	0	13	\N	0
1795436133	0	kaiya mekdi	0	3	0	0	0	14	\N	0
2102617395	0	marmer	0	10	0	0	0	17	\N	0
5382262337	0	Benjamin	0	0	0	0	0	0	\N	0
6632000681	0	araya	0	1	0	0	0	0	\N	0
6474096734	0	Gtw	0	1	0	0	0	1	\N	0
5253755484	0	n	0	1	0	0	0	0	\N	0
5970295604	0	𝐚𝐜𝐚𝐚	0	3	0	0	0	1	\N	0
5259704122	0	ba	0	50	0	0	0	3	\N	0
6060922845	0	avors 912	0	2	0	0	0	0	\N	0
6165994726	0	ancà	0	46	0	0	38.4	5	\N	0
7131375898	0	tiya	0	0	0	0	0	0	\N	0
6139996383	0	Sophia	0	5	0	0	0	9	\N	0
6033192767	0	Fajri	0	0	0	0	0	0	\N	0
5215987338	0	sya.	0	27	0	0	0	7	\N	0
1764663603	0	gojo	0	1	0	0	0	8	\N	0
6786639512	0	penyu	0	1	0	0	0	6	\N	0
5598396726	0	dino rawr	0	77	0	0	88.14	99	\N	0
1648653751	0	Yuvika	0	1	0	0	0	0	\N	0
2024030789	0	ᗰIKᕼᗩᗴᒪ •	0	6	0	0	0	0	\N	0
1527144354	0	yenss	0	54	0	0	13.18	103	\N	0
5872708275	0	harl	0	16	0	0	0	7	\N	0
1820141841	0	nanat	0	1	0	0	0	0	\N	0
5053507431	0	arumi heirth	0	50	0	0	380	17	\N	0
6085756673	0	Fuck Mooi	0	30	0	0	0	0	\N	0
5396925623	0	ciaoo	0	2	0	0	0	0	\N	0
1588681730	0	p	0	36	0	0	511.67999999999995	439	\N	0
6667280926	0	amei	0	1	0	0	0	6	\N	0
1612178517	0	Acelll	0	48	0	0	0	40	\N	0
1650865026	0	jepaa dine	0	1	0	0	0	0	\N	0
7136982793	0	⚘... -	0	1	0	0	0	0	\N	0
5609285896	0	ɴ͢͢͢ᴇ̷ɪᴅ¹⁸⁺ Acha	0	1	0	0	0	0	\N	0
1707146398	0	eyenaa 🔍⍤⃝🔎	13	46	1	0	3935.280000000001	1912	\N	0
6285356781	0	ཏ✶ཏ jopayy nayya dan kia.	0	4	0	0	0	1	\N	0
1883735992	0	chikaaaa	0	5	0	0	0	1	\N	0
6236148189	0	bian	0	1	0	0	3.99	1	\N	0
1441144686	0	fuck	2	139	0	0	956.97	1452	\N	0
6098949806	0	KALO GA BALES LAGI TIDUR	0	5	0	0	0	2	\N	0
6231832899	0	ösenil	0	16	0	0	0	3	\N	0
6674874128	0	Tamara	0	0	0	0	0	13	\N	0
1977647360	0	Shopa feeling confused	0	24	0	0	12.76	445	\N	0
1308197233	0	Miko	0	36	0	0	171.17	68	\N	0
6409461114	0	Prof. Aviel	0	18	0	0	0	277	\N	0
1642978893	0	251. Wildan werdas 211	0	18	0	0	0	13	\N	0
5513567075	0	Mishell A.	0	10	0	0	0	16	\N	0
6227095198	0	%࣪🎀 wica..໒꒱ ⊹	0	0	0	0	0	0	\N	0
6513504178	0	jea 🪷	0	14	0	0	9.990000000000002	184	\N	0
1281113779	0	LOG OUT.	0	6	0	0	0	5	\N	0
5043049209	0	⊹ kinda inactive, mitha abelia.	0	5	0	0	0	36	\N	0
5745944490	0	Miraaa suka dino	0	625	0	0	47.68000000000393	3106	\N	0
5813830812	0	Mathild.	0	2	0	0	24.189999999999998	24	\N	0
1839627587	0	gastaa aktif klau ad yg chat aj	0	40	0	0	38.61	0	\N	0
1407785251	0	057 . zerasha	0	2	0	0	420.71	14	\N	0
6052808386	0	shoe ga vcs	0	1	0	0	0	0	\N	0
6026710705	0	kaley	0	5	0	0	0	10	\N	0
5674985724	0	jjoraya	0	4	0	0	0	0	\N	0
6544512482	0	vrr	0	11	0	0	5	0	\N	0
6310139653	0	bibo	0	1	0	0	0	0	\N	0
5727232538	0	raashy'J	0	3	0	0	0	4	\N	0
6857977569	0	drw. rel ʟȼᴛꜱ	0	9	0	0	0	0	\N	0
2017052640	0	asha	0	34	0	0	0	3	\N	0
5154356724	0	sa	0	8	0	0	0	122	\N	0
1928104571	0	jeje :p	0	47	0	0	0	22	\N	0
2072131209	0	allie	0	294	0	0	3761.3100000000004	5629	\N	0
1580849978	0	.	0	84	0	0	1918.62	1860	\N	0
5795730183	0	rara	0	1	0	0	0	0	\N	0
5972437855	0	Arrrrrrrrrrrrrrrrrrrrrrrrrr	0	7	0	0	6.85	38	\N	0
6507715714	0	Reana	0	53	0	0	11.780000000000001	276	\N	0
1876265115	0	Radepa 𝐖.	0	78	0	0	0	0	\N	0
2004816762	0	ss	0	49	0	0	7.389999999999986	13	\N	0
6853836291	0	౨ৎ. 𝐊alilaa cebong	0	27	0	0	0	123	\N	0
6434226655	0	shin's	0	3	0	0	0	0	\N	0
6781113445	0	frznn	0	4	0	0	0	0	\N	0
5943276647	0	Lily...... :3	0	3	0	0	0	20	\N	0
5019557705	0	MINJI DRIVES ME INSANE.	0	1	0	0	0	1	\N	0
6316853363	0	il	0	2	0	0	0	1	\N	0
2078169191	0	Meyolaa Reinhart.	0	15	0	0	748.6299999999998	1550	\N	0
1428733225	0	🧚‍♀	0	9	0	0	0	20	\N	0
1278691505	0	𐙚chiikoo ໒꒰ྀི´ ˘ ` ꒱ྀིა	0	18	0	0	3.14	11	\N	0
1935572987	0	Kireiza Mrscoutille R.	0	2	0	0	0	1	\N	0
1897006872	0	nia	0	31	0	0	0	42	\N	0
6015707333	0	Dipsy	0	8	0	0	78	1	\N	0
5555852759	0	Senja	0	2	1	0	0	0	\N	0
5692132644	0	odite	0	12	0	0	2.75	345	\N	0
5549007084	0	fafa	0	16	0	0	0	2	\N	0
5498727318	0	Jema	0	7	0	0	0	0	\N	0
1327158891	0	vier	0	2	0	0	0	0	\N	0
7062709195	0	hujaaa	0	5	0	0	0	1	\N	0
1847588188	0	d²⁶	0	6	0	0	0	0	\N	0
6119045157	0	icak,	4	152	0	0	4314.179999999999	1714	\N	0
5005839154	0	ASYAAAAA	0	20	0	0	0	1	\N	0
5544126448	0	vakum.	0	5	0	0	178	11	\N	0
5390629869	0	wite	0	1	0	0	0	0	\N	0
1773865561	0	rindy	0	30	0	0	1018.9700000000003	145	\N	0
5359878780	0	Alleta kenzura	0	21	0	0	0	4	\N	0
6398668885	0	abiy'e	0	11	0	0	0	5	\N	0
5487399674	0	mora	0	19	0	0	110.86	7	\N	0
6177754919	0	abcdeL_	0	0	0	0	0	0	\N	0
1908530829	0	áurel	0	26	0	0	0	2	\N	0
5263813424	0	kesyel	0	11	0	0	0	3	\N	0
1429353879	0	v	0	30	0	0	0	15	\N	0
1889411711	0	dni pick gua ga debut	0	41	0	0	0	137	\N	0
1794559235	0	Athaca S.	0	12	1	0	0	0	\N	0
6956248691	0	⁫⁣⁫⁣⁫⁣⁫⁣⁫⁣⁫⁣⁫⁣⁫⁫⁣⁫⁣⁫⁣⁫⁫⁣⁫⁣⁫⁣⁫⁣⁫⁣⁫⁣Neal #CALMEMBSALIMA	0	83	0	0	734.73	1020	\N	0
5172530295	0	cloudyane	0	1	0	0	0	3	\N	0
6270681460	0	Ràymond داريلو, lustify	0	29	0	0	0	37	\N	0
2098569446	0	Arvel, go to @Steinchy (rest)	0	1	0	0	0	0	\N	0
1775803447	0	.	0	2	0	0	0	0	\N	0
1768611845	0	kenan	0	0	0	0	0	1	\N	0
1819811392	0	nolan	0	1	0	0	0	30	\N	0
1562916383	0	K	0	1	0	0	0	0	\N	0
1934293819	0	nanananannaaa	0	16	0	0	0	0	\N	0
6778037281	0	Kevin	0	3	0	0	0	0	\N	0
1959381787	0	claryn.	0	31	0	0	0	47	\N	0
5905822689	0	mm	11	970	0	0	78.68999999999869	1840	\N	1
1589385498	0	f	0	87	0	0	6.625	205	\N	0
7058480170	0	fem! "..callist a." ♥️	0	8	0	0	0	3	\N	0
5500928304	0	Rsyaa	0	9	0	0	0	8	\N	0
1951470107	0	Yoga	7	1	0	0	593.13	80	\N	0
6913900524	0	Desmond Serphent.	0	1	0	0	0	0	\N	0
6226455683	0	Istri lo yg cantik i'douglas	0	2	0	0	0	14	\N	0
1826954064	0	ttnnnn	0	0	0	0	0	0	\N	0
5454525463	0	rei	0	328	0	0	0.2699999999999818	297	\N	0
5371095152	0	Eros	14	318	0	0	7824.0000000000055	16250	\N	1
1424827079	0	b	0	21	0	0	0	1	\N	0
5660578390	0	aerie	0	60	0	0	14.34	15	\N	0
6561504272	0	a	0	2	0	0	0	0	\N	0
2042171838	0	rakha	0	12	0	0	0	0	\N	0
5906739876	0	abella <3.	0	0	0	0	0	0	\N	0
6676704365	0	n	0	15	0	0	0	2	\N	0
5751361007	0	zio	0	4	0	0	0	0	\N	0
6359844146	0	f	0	1	0	0	0	0	\N	0
6308079396	0	grizielle.	0	3	0	0	0	0	\N	0
1299541680	0	Ilhamzzz	0	2	0	0	0	5	\N	0
1834043465	0	M.	0	1	0	0	0	0	\N	0
1714158281	0	Haidar	0	15	0	0	6	3	\N	0
6475574497	0	Gracie Barra	0	4	0	0	0	0	\N	0
1966054954	0	aylen	0	2	0	0	0	85	\N	0
1926348031	0	zevaa	0	2	0	0	0	0	\N	0
1213737320	0	brea calon maba ui	0	21	0	0	10020.499999999998	137	\N	0
5360674848	0	Fahar	0	12	0	0	0	0	\N	0
6300542335	0	Ren.	0	31	0	0	162.7	167	\N	0
1752766350	0	،،‌ 🦁 ⋆ 𝗻𝗮ׂ𝗻𝗮ׂ𝘀 ࣪ ִֶָ ᕱ ⑅ ᕱ	0	7	0	0	7.79	49	\N	0
6684296138	0	dipa	0	3	0	0	0	6	\N	0
1566785938	0	Rayhan Major ֆ	0	0	0	0	0	5	\N	0
5067977563	0	Attharazka	0	4	0	0	0	0	\N	0
1609923817	0	abibibi	3	719	0	0	7982.559999999998	957	\N	0
1934998150	0	pusing cik!	0	2	0	0	0	0	\N	0
1956472393	0	kipsi	0	24	0	0	0	479	\N	0
6891661344	0	kenner red plag	0	3	0	0	0	0	\N	0
2098272691	0	aaa	0	8	0	0	0	0	\N	0
5785167912	0	CeSaaa	0	6	0	0	0	17	\N	0
6328357703	0	˚˖𓍢ִ໋🌷Λ𝗞𝗗 Vᴇ⁷ ndoro ipi.	0	8	0	0	135.95	63	\N	0
5052368817	0	melaaa	4	440	0	0	1427.6399999999999	263	\N	0
6361032648	0	lovi	0	1	0	0	0	0	\N	0
5005938974	0	juanᴱˣᵛᵒ²	0	5	0	0	0	0	\N	0
5754723950	0	ayumi	0	3	0	0	0	0	\N	0
7143337425	0	rayaa	0	4	0	0	0	0	\N	0
5695356610	0	Sahara Jane-Delacour. ୨♡⁠୧	0	2	0	0	0	0	\N	0
5474827268	0	raraa	0	1	0	0	0	7	\N	0
1690737396	0	dya	0	246	0	0	0	2	\N	0
2088031952	0	amora	0	6	0	0	0	6	\N	0
968026950	0	gopatpi	0	1	0	0	0	4	\N	0
982649220	0	meshiuma	0	205	0	0	5335.099999999999	1040	\N	0
6209196106	0	jelia	0	7	0	0	0	2	\N	0
1312482596	0	sp	0	10	0	0	0	1	\N	0
1799852043	0	.	0	2	1	0	0	0	\N	0
1697638370	0	Laluna Luireth.	0	2	0	0	0	27	\N	0
6256267482	0	nola	0	10	0	0	0	1	\N	0
6092135565	0	ana	0	2	0	0	0	0	\N	0
2059792730	0	Rayel	0	3	0	0	0	0	\N	0
6894050040	0	octo	0	14	0	0	10.59	1	\N	0
1745304813	0	zee	0	1	0	0	0	0	\N	0
5837929288	0	cel	0	24	0	0	714	8	\N	0
1909719891	0	N	0	71	2	0	21	0	\N	0
2015376439	0	ashee	0	11	0	0	0	16	\N	0
1349281164	0	. Utonmna	0	15	0	0	0	23	\N	0
5073789750	0	alicia, openfast!	0	1	0	0	0	4	\N	0
1571326752	0	Pradipta	0	14	0	0	0	1	\N	0
5965911329	0	alee.	0	13	0	0	0	7	\N	0
6390269304	0	galang	3	128	0	0	0	45	\N	0
1503042731	0	pâyshie amoura	0	18	0	0	0	24	\N	0
5975104347	0	:3	0	100	0	0	2.8400000000000034	391	\N	0
5502074317	0	maxxiné─⋆౨ৎ˚⟡˖ ࣪	0	1	0	0	0	0	\N	0
5231768464	0	mama hillaryy	0	58	0	0	751.5699999999999	660	\N	0
6183996532	0	23	0	6	0	0	0	0	\N	0
6831431785	0	Willy	0	5	0	0	0	0	\N	0
5388307917	0	Ophelia	0	1	0	0	0	0	\N	0
1500991402	0	Diorlyn	0	128	0	0	1083.3200000000002	94	\N	0
5415998340	0	keelan	0	47	0	0	0	0	\N	0
6145531535	0	J. Glenn	0	1	0	0	0	0	\N	0
1375975191	0	kazhu	0	8	0	0	0	4	\N	0
5335148781	0	dev	0	0	0	0	0	19	\N	0
6280036185	0	??	0	38	0	0	0	7	\N	0
5431333438	0	Hanesa	0	7	0	0	0	3	\N	0
1605859113	0	caadew	0	4	0	0	0	0	\N	0
6678680763	0	cipa	0	5	0	0	0	9	\N	0
5354920826	0	anya	2	34	0	0	17.24	70	\N	0
1337687178	0	🌱𓂀👑🤺𖠌🦁.᭧ 卐𝜋ɱ𝗰៵᭡ִֹ°ʚĭɞ ᭄🍒🧛🏻⊱🍓𝔉𝔠𝔩𝔲𝔟🍓⊰	0	100	0	0	0	3	\N	0
5341597437	0	🧚🏻‍♀️	0	5	0	0	0	0	\N	0
5241691523	0	yass	0	0	0	0	0	6	\N	0
5814164653	0	Marelyn	0	63	0	0	2710.52	71	\N	0
5230312912	0	✠⃝𝐏𝐁𝐒⍣ ꈜ⃝⃗͜d 𝗕𝗔𝗡𝗚𝗢𝗥​	0	1	0	0	0	0	\N	0
1331648600	0	Geovani	0	4	0	0	0	0	\N	0
6289973450	0	Lucy	0	3	1	0	0	0	\N	0
5463586936	0	scaramouche	0	122	0	0	715.22	1973	\N	0
2110496176	0	.	0	42	0	0	0	85	\N	0
6111359888	0	cicell	0	47	0	0	2561.6200000000003	189	\N	0
5842638143	0	miiici	0	1	0	0	0	0	\N	0
5186198732	0	arpinja	0	87	0	0	0	0	\N	0
5446278939	0	Alice	0	39	0	0	0	58	\N	0
1542077389	0	Inactive.	14	60	0	0	2736.33	55	\N	0
5533877552	0	lili	0	0	0	0	0	0	\N	0
5318406385	0	al	0	2	0	0	0	3	\N	0
6235874990	0	meng	0	5	0	0	0	0	\N	0
2056346187	0	Ciiii🤍	0	1	0	0	0	5	\N	0
5431257580	0	~hantu	0	4	0	0	0	10	\N	0
1819120464	0	Ayak	0	53	0	0	0	0	\N	0
6539026987	0	Akmal	0	1	0	0	0	0	\N	0
6413640560	0	1101. bel	0	25	0	0	5.849999999999994	8	\N	0
5242464842	0	𝕽ʳ r lustify	0	0	0	0	0	0	\N	0
1267062989	0	FANS SANNY ONLY LOVE MWAH BABY	0	1	0	0	0	6	\N	0
6200659716	0	a	12	5	0	0	0	0	\N	0
6628688744	0	sze !¡	0	4	0	0	0	0	\N	0
6347388195	0	odeiiii	1	65	0	0	1523.7199999999996	1076	\N	0
1912763775	0	Fleisha, B	0	1	0	0	0	0	\N	0
6865082290	0	nlpij	0	18	0	0	0	8	\N	0
1755035297	0	piyo	0	39	0	0	1533.9899999999998	3888	\N	0
6505331204	0	Nameless.	0	4	0	0	0	0	\N	0
1969550902	0	fannyy. 🧉	0	184	0	0	0	306	\N	0
6046097725	0	ᝯׁhׁׅꪱׁׅꭈׁׅɑׁׅ	0	6	0	0	0	2	\N	0
1807524671	0	naka	0	9	0	0	0	0	\N	0
6006498226	0	Indraa	0	4	0	0	0	3	\N	0
6013261375	0	syee	0	1	0	0	0	1	\N	0
1049836013	0	liliv	0	57	0	0	0	20	\N	0
5541499692	0	kazumi	0	3	0	0	0	0	\N	0
6608093839	0	.	0	3	0	0	0	1	\N	0
6348799525	0	agam salimawikky	5	18	0	0	813.73	7	\N	0
1932402615	0	cel	0	3	0	0	0	28	\N	0
5047461763	0	wal.	0	6	0	0	64.36	4	\N	0
5297509008	0	Gibran	0	147	0	0	3428.41	2729	\N	1
5137177710	0	A	0	14	0	0	0	11	\N	0
5532476689	0	kajor.	0	5	0	0	0	320	\N	0
1751046868	0	pinong 3	0	228	0	0	0	2	\N	0
5491744784	0	sakila betmut	0	3	0	0	0	135	\N	0
1554897284	0	vienna	0	35	0	0	500	22	\N	0
5802653237	0	yuzin	0	52	0	0	26.86	45	\N	0
6334078328	0	shásya	0	17	0	0	0	156	\N	0
6245477577	0	ezar	0	1	0	0	0	0	\N	0
1866313829	0	Sachie :]	0	2	0	0	0	5	\N	0
6252418556	0	Kalea	0	5	0	0	0	1	\N	0
1624881745	0	jizo	0	7	0	0	0	1	\N	0
1628944301	0	kiara.	0	61	0	0	4.280000000000001	143	\N	0
1830935365	0	biw	0	1	0	0	0	21	\N	0
5160371253	0	Calla	0	0	0	0	500	1	\N	0
1228914315	0	rar	0	442	0	0	0	252	\N	0
1824984078	0	skyla	0	253	0	0	0	243	\N	0
6257542614	0	Amerta	0	2	0	0	0	8	\N	0
1604117857	0	Alister.	0	5	0	0	3463.08	890	\N	0
6115707801	0	mip	0	1	0	0	0	0	\N	0
1693606927	0	ᮙᮤᮊᮈᮜ᮪, el	0	13	0	0	0	111	\N	0
1955494062	0	asher	0	2	0	0	45	18	\N	0
6365532802	0	asila	0	0	0	0	0	463	\N	0
1493763349	0	el	0	1	0	0	0	23	\N	0
6484498837	0	lalaa	0	7	0	0	0	0	\N	0
5434017086	0	C	0	3	0	0	0	0	\N	0
1688641781	0	phiaa	0	4	0	0	0	1	\N	0
5161428968	0	shaquille	0	11	0	0	0	1	\N	0
6513579803	0	shaa	0	7	0	0	0	1	\N	0
6828200852	0	BS	0	1	0	0	0	0	\N	0
6117428377	0	a	0	1	0	0	0	0	\N	0
1623943285	0	.	0	11	0	0	0	33	\N	0
6989849554	0	Jocelyn.	0	3	0	0	0	0	\N	0
6812644968	0	Jong	0	3	0	0	0	1	\N	0
6103761073	0	pjl	0	5	0	0	0	63	\N	0
6166511282	0	juwaa	0	3	0	0	0	77	\N	0
6573314455	0	#$%©¥π€:)/&&	0	1	0	0	0	13	\N	0
1716253396	0	viro's personal cuddle monster, Rama.	0	40	0	0	0	102	\N	0
6219972676	0	lie	0	1	0	0	0	9	\N	0
5852786655	0	Bipap	0	174	2	0	0	22	\N	0
7002808833	0	ˡⁱᵗᵗˡᵉ ʸᵒʸᵃ	0	1	0	0	105.33	66	\N	0
5080652476	0	dapa	0	14	0	0	0	2	\N	0
6666056352	0	.	0	0	0	0	0	0	\N	0
5889133329	0	na	0	11	0	0	0	13	\N	0
6860984168	0	pány.	0	8	0	0	0	5	\N	0
5546510558	0	🌷	0	42	0	0	17.179999999999993	101	\N	0
1810678822	0	Firlyn	0	63	0	0	435.64	183	\N	0
6189447644	0	el	0	31	1	0	0	50	\N	0
6114086691	0	ciy's	3	35	0	0	22.479999999999997	172	\N	0
6671276581	0	Kall.	0	218	0	0	458.1899999999998	1026	\N	0
6294082218	0	Lou	0	154	0	0	0	5	\N	0
1919202053	0	ira	0	0	0	0	0	0	\N	0
5051308457	0	theresia.	0	480	0	0	1584.78	621	\N	0
6378494452	0	ruel	0	3	0	0	0	4	\N	0
1303311375	0	Noir	0	0	0	0	0	0	\N	0
5967945367	0	Abidzar	0	31	0	0	63.14	195	\N	0
6585061345	0	abell anak baikk	0	8	0	0	0	6	\N	0
1791732800	0	kurtnoune	0	0	0	0	0	0	\N	0
6864838432	0	Bibel	0	20	0	0	0	29	\N	0
6797091668	0	.	0	2	0	0	0	4	\N	0
7032716506	0	N M C	0	30	0	0	0	1	\N	0
1185567051	0	ℒulu	0	108	0	0	4307.749999999999	54	\N	0
1892365333	0	zeeker 袋	14	68	0	0	2499.46	12385	\N	0
6790100697	0	Baby	0	72	0	0	13	99	\N	0
1427648043	0	𝔞𝔯𝔢𝔰𝔨𝔞 𝔪𝔞𝔥𝔢𝔫𝔡𝔯𝔞	0	201	0	0	8.469999999999999	59	\N	0
6244319833	0	cimma基 苏	0	1	0	0	0	0	\N	0
5139184320	0	Fʀᴇʏ	0	0	0	0	0	1	\N	0
5541072502	0	fivearchie	4	101	0	0	1820.93	563	\N	0
6932505311	0	K	0	7	0	0	0	2	\N	0
1878577663	0	nittt	0	1	0	0	0	0	\N	0
6500974236	0	Drew	0	4	0	0	0	11	\N	0
5906666606	0	cinta umar banget	0	38	0	0	77.37	37	\N	0
5669505225	0	Louisa	0	0	0	0	0	0	\N	0
6578789668	0	nei	0	42	0	0	17.280000000000143	95	\N	0
5595267192	0	ajaaw	0	313	0	0	96.68000000000006	484	\N	0
6389334946	0	nebula	0	2	0	0	0	0	\N	0
5863821439	0	puspaa, sabar yh ay	0	1	0	0	0	5	\N	0
7065139748	0	pranona need a kiss.	0	3	0	0	0	3	\N	0
6179297897	0	ova slr	0	1	0	0	0	0	\N	0
1632140575	0	hara	0	2	0	0	0	2	\N	0
1890156468	0	𝓝ataa	0	1	0	0	0	4	\N	0
1301114410	0	karina	0	4	0	0	0	10	\N	0
5091488252	0	ayya gapake ng	0	625	0	0	525	1101	\N	0
1828787316	0	archie	0	11	0	0	0	9	\N	0
6699852340	0	kaiLa	0	0	0	0	0	4	\N	0
5790345058	0	.	0	7	0	0	0	0	\N	0
6233344841	0	cai	0	1	0	0	0	1	\N	0
6312171970	0	g	0	10	0	0	0	1	\N	0
1943681441	0	vigo	0	1	0	0	0	47	\N	0
6298591081	0	chér4n reckléss.	0	9	0	0	0	4	\N	0
1824483288	0	javas. dco	0	6	0	0	0	0	\N	0
5467799264	0	kalea 831 #zeelovers #𝐓ia𝐓eam #liyaalovers #Xylaa	0	1	0	0	0	0	\N	0
2040908591	0	dudududu	0	16	0	0	0	5	\N	0
6799494691	0	nesha 🩰	0	4	0	0	0	12	\N	0
1837869988	0	ᅠ	14	1	0	0	215.34000000000003	1	\N	1
6740636190	0	a	0	5	0	0	0	0	\N	0
6481659377	0	caera	0	1	0	0	0	26	\N	0
6181198204	0	kaa	0	5	0	0	0	0	\N	0
6507916624	0	zuu 1	0	5	0	0	0	0	\N	0
7153403379	0	Reygan	0	3	0	0	0	0	\N	0
1833739190	0	alea, on rest	0	0	0	0	0	0	\N	0
5532196164	0	zzcvv	0	0	0	0	0	8	\N	0
1726894763	0	ㅤ	0	13	0	0	0	38	\N	0
5125318213	0	Garth Mavis R.	0	5	0	0	0	5	\N	0
1264859516	0	Luna	0	1	0	0	0	0	\N	0
1869304993	0	Ardhito	0	2	0	0	0	0	\N	0
5515418285	0	Jia	0	27	0	0	0	65	\N	0
5383032910	0	miguel ipa 2	0	200	0	0	14.529999999999996	198	\N	0
6570065171	0	Ayde	0	4	0	0	0	0	\N	0
6873897350	0	luna	0	1	0	0	0	0	\N	0
1827141449	0	al	0	0	0	0	0	0	\N	0
6446780285	0	fgc	0	17	0	0	0	8	\N	0
5227422338	0	calsa	0	63	0	0	0	0	\N	0
1738053699	0	MeishaaAAaAaa	0	18	0	0	0	0	\N	0
5011486909	0	Aiden @iswaggyboy	0	2	0	0	0	0	\N	0
6270416665	0	beau diamant; jenay	0	3	0	0	0	10	\N	0
1911114580	0	y4	0	59	0	0	0	32	\N	0
1127054394	0	nu	0	6	0	0	0	26	\N	0
6850515273	0	aleccy	0	6	0	0	0	2	\N	0
6600806061	0	mici puyeng	0	4	0	0	0	3	\N	0
5643658488	0	Sandra	0	5	0	0	0	0	\N	0
5057718680	0	Josh Hutcher.	0	75	0	0	0	0	\N	0
5240449475	0	sheilaa	0	1	0	0	0	1	\N	0
1672380811	0	sturn	0	1181	0	0	31.87000000000262	2385	\N	0
6493192992	0	–	0	7	0	0	58.980000000000004	14	\N	0
1848133546	0	.	0	3	0	0	0	0	\N	0
5559261260	0	.	0	14	0	0	0	0	\N	0
5369096168	0	mayy	0	19	0	0	0	41	\N	0
5967402138	0	“{암캐} ִֶָ Amàxyllis`𐙚	0	20	0	0	0	2	\N	0
1794340774	0	Renji A.	0	9	0	0	506	460	\N	0
6237979758	0	Edwinna Mickael	0	2	0	0	0	4	\N	0
5857586009	0	kosong	0	2	0	0	0	0	\N	0
1937952460	0	je	0	2	0	0	0	5	\N	0
5070247306	0	Rev	0	1	0	0	0	1	\N	0
5425481261	0	J	0	2	0	0	0	0	\N	0
5002156971	0	Morgan	0	1	0	0	0	0	\N	0
5845272997	0	hui	0	90	0	0	12.160000000000053	31	\N	0
2129496935	0	ray	0	15	0	0	0	9	\N	0
1924869891	0	l	0	3	0	0	0	1	\N	0
6737286757	0	naa	0	3	0	0	0	0	\N	0
7085313846	0	Shanon	0	3	0	0	0	1	\N	0
1331074920	0	MURID INTROVERT	0	1	0	0	0	0	\N	0
1415075636	0	a	0	78	0	0	0	32	\N	0
1702003402	0	dyn	0	2	0	0	0	0	\N	0
2011298704	0	Al Jaegar	0	1	0	0	0	0	\N	0
6274053353	0	Its farelio, not el.	0	1	0	0	0	34	\N	0
6591408879	0	(return @ to stewert) mesca.rcr 6	0	50	0	0	66.74999999999994	2	\N	0
1066511952	0	Taka	0	6	0	0	0	1	\N	0
6429491685	0	a	0	1	0	0	0	0	\N	0
1979350910	0	Agil	0	8	0	0	0	7	\N	0
2067833154	0	nay	0	31	0	0	0	26	\N	0
1356699524	0	gd	0	6	0	0	0	8	\N	0
1740162408	0	ju	0	9	0	0	0	22	\N	0
6237307892	0	Grace Hopper	0	12	0	0	0	4	\N	0
5081100346	0	Jares	0	23	0	0	0	1	\N	0
5126971726	0	el	0	4	0	0	0	0	\N	0
6518820120	0	c	0	92	0	0	28.04000000000002	38	\N	0
1592966986	0	awdy	0	93	0	0	46.03	2	\N	0
1962137722	0	?	0	88	0	0	0	52	\N	0
1856591553	0	shabiel ⍣	5	10	0	0	133.96	207	\N	0
1782332070	0	Zella S	0	229	0	0	0	56	\N	0
6236063182	0	k	0	1	0	0	0	0	\N	0
1150347525	0	abie	0	8	0	0	0	31	\N	0
1380906576	0	𝐍𝐚𝐠𝐞𝐧𝐝𝐫𝐚 𝐀𝐜𝐡𝐢𝐥𝐥𝐞𝐨	0	6	0	0	0	8	\N	0
1853505098	0	cedric	0	33	0	0	0	0	\N	0
5089726856	0	nat	0	212	0	0	156.08	8	\N	0
1932086110	0	awokawokaokawok	0	7	0	0	0	0	\N	0
1973697967	0	al	0	123	0	0	78	46	\N	0
2107264462	0	Nasel.	0	4	0	0	0	0	\N	0
5730971929	0	ale	0	0	0	0	0	1	\N	0
5458037760	0	Chariné O'brien's	0	3	0	0	0	0	\N	0
1868718147	0	ji	0	29	0	0	0	94	\N	0
5939654968	0	`𝐻𝒢𝒾𝓇𝓁	0	1	0	0	0	0	\N	0
1965296582	0	Abil	0	1	0	0	0	0	\N	0
5860850795	0	rakna	8	143	0	0	296.01	97	\N	0
6831266190	0	kaylaaa.	0	1	0	0	0	0	\N	0
1589855543	0	sera	0	11	0	0	0	2	\N	0
5971167961	0	Yise.	0	0	0	0	17.79	16	\N	0
5708285395	0	ann	12	248	0	0	972.2299999999998	152	\N	1
5958826141	0	Biru	11	232	0	0	1086.39	118	\N	0
1540603886	0	jee	0	40	0	0	0	1	\N	0
6345675091	0	Keii	0	3	0	0	0	1	\N	0
6101525292	0	Kesha FSR	0	3	0	0	0	0	\N	0
5692565428	0	juu openn	0	6	0	0	0	0	\N	0
5106457726	0	'Nath'	0	3	0	0	0	0	\N	0
6577435958	0	Loreth.	0	0	0	0	0	0	\N	0
1795808568	0	n	0	149	0	0	0	3	\N	0
6331131489	0	asha	0	1	0	0	0	0	\N	0
5549215270	0	yolaa	0	11	0	0	1310.0600000000002	45	\N	0
6100436088	0	zae	0	1	0	0	0	2	\N	0
6910741222	0	sabe arvz	0	2	0	0	0	0	\N	0
962519810	0	ㅤ	0	1	1	0	0	0	\N	0
5469332846	0	hanabe,	0	6	0	0	0	5	\N	0
2071720792	0	AN.	0	26	0	0	0	83	\N	0
6963672104	0	bil•ʳʳʷ	0	4	0	0	0	0	\N	0
1335465072	0	|`Ĵɛиσℓαттɛ•	0	4	0	0	0	38	\N	0
6365506418	0	jaheerman	0	2	0	0	0	0	\N	0
2104969690	0	5889 . aliprada	0	0	0	0	0	0	\N	0
5948126823	0	cogan	0	10	0	0	393.16	5	\N	0
5970157942	0	Regas	0	118	0	0	99.34000000000003	182	\N	0
6231692654	0	kael	0	1	0	0	0	4	\N	0
5544909854	0	marfleric	0	1	0	0	1200	0	\N	0
6850766134	0	natha, slctv	0	21	0	0	0	16	\N	0
5890978382	0	Keavenly 🎭	0	5	0	0	0	0	\N	0
1794289752	0	who is there	0	197	0	0	3.4399999999999995	12	\N	0
1909513451	0	n	0	68	0	0	0	1	\N	0
6055561970	0	aii	0	2	0	0	0	1	\N	0
5414910073	0	Neine?? -	0	1	0	0	0	47	\N	0
1734928108	0	Degas	0	30	0	0	1186.4699999999987	2930	\N	0
7143200433	0	.	0	1	0	0	0	0	\N	0
5441954771	0	`princesse	0	27	0	0	0	90	\N	0
6753031692	0	hesaa	0	0	0	0	0	0	\N	0
6208963911	0	Akvya Daviana	0	9	0	0	0	4	\N	0
5931472752	0	lala	0	0	0	0	0	0	\N	0
1987937061	0	deleze	0	158	0	0	7.079999999999856	939	\N	0
5700209495	0	gina	0	1	0	0	0	0	\N	0
1574052409	0	bian	5	442	0	0	15.430000000000064	157	\N	0
5223987312	0	catherine	0	6	0	0	0	2	\N	0
6169257140	0	jeandra	0	2	2	0	0	1	\N	0
5131894744	0	Trafalgar D. Ian	0	25	0	0	20.989999999999995	19	\N	0
5579619468	0	hiro	0	1	0	0	0	1	\N	0
6799947412	0	shin	0	6	0	0	0	191	\N	0
6141455407	0	jyotika	10	4	0	0	4038.99	1082	\N	0
1779528700	0	dave	0	2	0	0	0	1	\N	0
6415163250	0	꒰ᐢ. Khayey ₊˚⊹ ౨ৎ	0	20	0	0	0	0	\N	0
5025738603	0	nanaa	0	1	0	0	0	5	\N	0
6084336792	0	﹫ayraa.	0	1	0	0	0	0	\N	0
6157619704	0	bella	0	38	0	0	0	1	\N	0
1414172121	0	se 🤏🏻🤏🏻	0	2	0	0	0	0	\N	0
5866224846	0	bebiww	0	22	0	0	367	39	\N	0
6043908563	0	ayy.	0	1	0	0	0	1	\N	0
1850864724	0	Ameera	0	1	0	0	0	2	\N	0
5490307568	0	Atlas.	0	2	0	0	0	0	\N	0
1859897203	0	l	0	6	0	0	0	8	\N	0
5000230105	0	lynnn	0	17	0	0	3.719999999999999	3	\N	0
837375760	0	mey	0	0	0	0	0	0	\N	0
7057827965	0	akimmm	0	0	0	0	0	1	\N	0
6897441339	0	Syaa?	0	2	0	0	0	6	\N	0
5508772993	0	ikooo	0	5	0	0	0	10	\N	0
5237135862	0	doja	0	1	0	0	0	0	\N	0
1969623252	0	Nera	0	46	0	0	387.91	2	\N	0
1390146464	0	𝐙𝐞𝐨𝐫𝐫𝐚 𝐚𝐭𝐚𝐫𝐚𝐱𝐢𝐞.	0	6	0	0	464.42	9	\N	0
2056360561	0	101team. rejaska @iTioyong	0	3	0	0	0	0	\N	0
5261728229	0	Zahra	0	8	0	0	0	1	\N	0
5706500332	0	serana	0	1	0	0	0	0	\N	0
5824427665	0	Ryota	0	1	0	0	0	0	\N	0
5661802654	0	Humairaa.	0	32	0	0	50	506	\N	0
1729125525	0	Navie	0	408	0	0	607.765	257	\N	0
2001317335	0	h'	0	1	0	0	0	0	\N	0
5400515532	0	lucii	3	585	0	0	1996.9300000000003	2573	\N	0
5141224450	0	Bella	0	1	0	0	0	16	\N	0
5319325569	0	Shakiero.	0	0	0	0	0	1	\N	0
5271787496	0	" ādelyn ^___^ ... "	0	3	0	0	42.18	25	\N	0
1177520530	0	Leia	0	42	0	0	189	281	\N	0
1848533411	0	yey dpet fox	13	173	0	0	2675.9500000000007	720	\N	1
2069892313	0	VL.	0	22	0	0	0	2	\N	0
1483243225	0	Lily Sinatra.	0	0	0	0	0	0	\N	0
1816571749	0	🍒☊🦋🌱🌾⚝💎Reyvan.˚ˑ༄ؘ◡̈🍑🤡💎🌻🍩🍄🍌🪐🍄 🐮🏩🦑🤺⦮ ⦯🦦ɱ𝗰៵᭡ִֹ✥ ⊱🫐🍒⊰🍰᭧🌈	0	732	0	0	1.6299999999999955	216	\N	0
1970697332	0	Lesavown Ravienos	0	44	0	0	17.269999999999996	30	\N	0
5327307911	0	rest. abi salimawikky	7	59	0	0	3364.96	139	\N	0
1353773530	0	14	0	10	0	0	0	2	\N	0
6572086409	0	Jey ⛧	0	1	0	0	0	1	\N	0
7080976595	0	Belac`	0	1	0	0	0	0	\N	0
1836306249	0	𝓢sean.	0	10	0	0	500	0	\N	0
5929996144	0	Loúvetta	0	26	0	0	18.56	11	\N	0
1777169362	0	tomyhas	0	1	0	0	0	0	\N	0
6776244430	0	𞋎𝑢𝑒𝑢𝑟, eleona 🩰꯭🪞 ࣪˳ ⊹	0	1	0	0	0	2	\N	0
1910821760	0	sAlena gomez	0	1	0	0	0	4	\N	0
5657350459	0	𝐂𝐑𝐕𝐙²`` Grey 🐳 on t—swap	0	11	0	0	199.66000000000017	7	\N	0
1867824524	0	vve	0	28	0	0	2153	3	\N	0
1745126324	0	arga	0	7	0	0	0	0	\N	0
7014842829	0	faiz	0	1	0	0	0	3	\N	0
6748336708	0	cila	0	1	0	0	0	0	\N	0
5892364928	0	Millie	0	1	0	0	0	0	\N	0
5634597889	0	biaa ²¹⁶	0	3	0	0	287.46	11	\N	0
2056674177	0	Jipéya d'masivve t__t ktvjksgtn¹	0	1	0	0	0	0	\N	0
5553678565	0	ty	0	18	0	0	0	118	\N	0
6280692733	0	zar	0	0	0	0	0	0	\N	0
6087900941	0	Audrey.	0	2	0	0	0	2	\N	0
1874064698	0	marchie	0	1	0	0	0	2	\N	0
6526002107	0	KAYRA NOT OBL	0	0	0	0	0	0	\N	0
6185925265	0	Ardzz	0	3	0	0	0	0	\N	0
6837997941	0	acell	0	1	0	0	0	0	\N	0
1429567173	0	El	0	9	0	0	0	0	\N	0
1105668409	0	Awawa.	12	19	0	0	2451.7900000000004	1356	\N	0
6720787546	0	Viiii	0	1	0	0	0	0	\N	0
1835850839	0	evelaa	0	105	0	0	55	50	\N	0
1860302407	0	n	0	6	0	0	0	2	\N	0
5436004224	0	karxiina	0	1	0	0	0	0	\N	0
6176150306	0	iqiss	0	2	0	0	0	1	\N	0
1671473648	0	haekal.	0	4	0	0	0	0	\N	0
6145286078	0	livie	0	0	0	0	0	1	\N	0
1776368160	0	badmood era. 24⁷ rpsg 〄⁹⁷² #BUJANGBTR	0	7	0	0	41	0	\N	0
5409755922	0	sayonara	0	45	0	0	0	948	\N	0
5850558664	0	Sowie's protector, nakesha	0	9	0	0	0	26	\N	0
1372590880	0	ce	0	36	0	0	480	4	\N	0
6739375245	0	jord	0	8	0	0	0	435	\N	0
6215980193	0	C	0	1	0	0	0	0	\N	0
5842371443	0	hyera	0	2	0	0	0	2	\N	0
5431874591	0	Myth.	0	4	0	0	0	11	\N	0
5687065607	0	Alif	0	0	0	0	0	0	\N	0
1699901837	0	Nazalea.	0	1	0	0	0	0	\N	0
5940684608	0	tiOo	0	115	0	0	12.330000000000082	26	\N	0
1974719959	0	Dysné support #1	0	100	0	0	0	0	\N	0
1759044218	0	rajéna	0	1	0	0	0	3	\N	0
1450327228	0	moccaaw	0	1	0	0	0	0	\N	0
6458852881	0	Ji	0	3	0	0	0	17	\N	0
5416605257	0	demjci	0	10	0	0	0	6	\N	0
5489037028	0	ᴋɪʙᴏ	0	0	0	0	0	0	\N	0
1824759675	0	clarzzzz	0	21	0	0	510.5200000000002	304	\N	0
5779309141	0	𝒛𝒅𝒏	0	1	0	0	0	2	\N	0
6468741162	0	syesha	0	2	0	0	0	0	\N	0
1765824522	0	mkay	0	16	0	0	0	8	\N	0
1895955711	0	𝐁𝐫𝐲	0	6	0	0	0	1	\N	0
5123145403	0	Davin	0	412	0	0	0	32	\N	0
5462605846	0	m.	0	2	0	0	0	0	\N	0
2070757674	0	blairé	0	3	0	0	0	0	\N	0
1106290227	0	..	0	3	0	0	0	7	\N	0
6087772736	0	shie rbio!	0	0	0	0	0	0	\N	0
1998183291	0	Fubuki	0	12	0	0	0	92	\N	0
1956361490	0	kijaA's caretaker, ARVAAA.	0	4	0	0	0	14	\N	0
5107288881	0	jaegar.	0	364	0	0	-2.5	193	\N	0
5286076478	0	Chelsea @hitorigot0h	0	1	0	0	68.33000000000025	20	\N	0
5344340173	0	Galaksi Orion.	0	65	0	0	623.6000000000001	204	\N	0
5234269490	0	karinee	0	17	0	0	0	1	\N	0
1022790079	0	kee	0	13	0	0	0	3	\N	0
6033206810	0	𝐤𝐞𝐢	0	4	0	0	0	13	\N	0
5572111262	0	dy	0	8	0	0	0	29	\N	0
5596562531	0	la	0	0	0	0	0	0	\N	0
2127754008	0	sweets, Sabin. ✿ close	0	7	0	0	0	1	\N	0
5345532689	0	a	13	1822	0	0	3722.920000000011	14034	\N	1
1834631649	0	za	0	6	0	0	0	21	\N	0
6048537374	0	jendra	0	12	0	0	0	3	\N	0
1383646267	0	O	0	5	0	0	0	5	\N	0
5281218790	0	mora nunggu	0	5	0	0	0	16	\N	0
5000335347	0	al	0	10	0	0	0	0	\N	0
5748568831	0	.	0	52	3	0	4198	0	\N	0
1413791567	0	élle kinda ia	0	8	0	0	0	16	\N	0
6019002096	0	ciyara	1	35	0	0	1260.6899999999998	164	\N	0
6216241386	0	Cee ! ₊ ׁ ১ 🍉	0	4	0	0	0	10	\N	0
5888436108	0	regas	0	4	0	0	0	1	\N	0
1937618433	0	･⃝𝙃𝙧𝙎𝙭 chelsea lagi turu	0	2	0	0	0	1	\N	0
5307394499	0	naza	0	0	0	0	0	0	\N	0
1367083358	0	kyakyakyaa	0	15	0	0	0	0	\N	0
5898687084	0	serotonin	0	26	0	0	0	52	\N	0
5614669626	0	Kvei	0	7	0	0	0	0	\N	0
1913478457	0	disaaa	0	106	0	0	0	2	\N	0
2090885174	0	Odette.	0	4	0	0	0	28	\N	0
6468320034	0	pp	0	1	0	0	0	0	\N	0
1782108095	0	Jaemin's lil kitten, Rean	0	20	0	0	0	0	\N	0
6062807625	0	Starla Kabarin ya, tolong.	0	1	0	0	0	1	\N	0
6958228403	0	69	0	0	0	0	0	0	\N	0
5778280206	0	ndahh	0	0	0	0	0	0	\N	0
6017794314	0	Marka.	0	2	0	0	0	0	\N	0
5974462183	0	Amora Brianna	0	75	0	0	8	123	\N	0
1845269266	0	p	0	1	0	0	0	4	\N	0
5261129816	0	Kanaya	0	13	0	0	0	29	\N	0
1849447091	0	Vala C	0	7	0	0	0	40	\N	0
1801458137	0	mencret basah	0	16	0	0	0	87	\N	0
1705027787	0	your girl	0	3	0	0	0	0	\N	0
5642823902	0	𝟐𝟓𝟎𝟕. Ќeenan	0	1	0	0	0	0	\N	0
2005488617	0	zaks	0	0	0	0	0	0	\N	0
5706199608	0	arab	0	1	0	0	0	3	\N	0
5630142026	0	Damian.	0	1	0	0	0	7	\N	0
7141757119	0	Rayez	0	0	0	0	0	0	\N	0
6530099780	0	kyraa, lustify	0	1	0	0	0	0	\N	0
5198011125	0	cmiww	0	74	1	0	0	37	\N	0
1812083111	0	Hades.	8	71	0	0	19.339999999996962	686	\N	1
5413731082	0	jean	0	2	0	0	0	2	\N	0
1425494750	0	Ley.	0	6	0	0	0	2	\N	0
6358572941	0	dd mala🗯	0	3	0	0	0	0	\N	0
6894547621	0	caa	0	1	0	0	0	0	\N	0
5719157408	0	augy 🤞🏻	0	1	0	0	0	0	\N	0
6711633315	0	a	0	7	0	0	0	0	\N	0
5045633681	0	akaa	0	29	0	0	0	22	\N	0
6981209975	0	qill	0	4	0	0	0	6	\N	0
5904371587	0	Nico.	0	1	0	0	0	0	\N	0
5279405202	0	Skayaa	0	0	0	0	0	0	\N	0
5290487629	0	june 🦥	0	4	0	0	0	416	\N	0
2132058501	0	s	0	4	0	0	0	3	\N	0
5128918456	0	.	0	2	0	0	0	772	\N	0
5871350373	0	Lydia	0	5	0	0	0	6	\N	0
5385426210	0	k/ia, capaayy	0	20	0	0	0	90	\N	0
1614138343	0	XXII, VII	0	1	0	0	0	0	\N	0
5122581875	0	kie	0	17	0	0	0	0	\N	0
1341326422	0	Kajuley	0	406	0	0	65	3454	\N	0
5392974974	0	Hellyeah	0	4	0	0	0	7	\N	0
5539778236	0	.	0	22	0	0	0	11	\N	0
1475884252	0	.clepaaa	0	0	0	0	0	0	\N	0
5902444657	0	K	0	24	0	0	0	30	\N	0
860516243	0	Kanala	0	6	0	0	0	5	\N	0
1945911985	0	Cellica Xvyera Queen	0	1	0	0	0	0	\N	0
1926878170	0	farhan	0	6	0	0	0	12	\N	0
6914157591	0	asyaa’slctv	0	18	0	0	0	24	\N	0
1539370660	0	.	0	16	1	0	0	3	\N	0
1635564083	0	kal	0	61	0	0	0	11	\N	0
6279684488	0	z	0	372	0	0	0	175	\N	0
1584684691	0	sleepy nara . R48hr	0	4	0	0	0	67	\N	0
1928765062	0	𝐣𝐞𝐧	0	9	0	0	0	7	\N	0
6273306733	0	GuzTod	0	6	0	0	0	10	\N	0
1657662222	0	bas	0	1	0	0	0	1	\N	0
5442720321	0	🪞🫧	0	20	0	0	0	0	\N	0
5032723417	0	james'd wekker. 🇨🇰	0	71	0	0	182	44	\N	0
6224750414	0	firzaaa	0	8	0	0	0	54	\N	0
6218391827	0	Eastlyn A.	0	3	0	0	0	3	\N	0
5675563796	0	aya	0	1	0	0	0	12	\N	0
5691343606	0	dhaiyu, lith.	0	3	0	0	23.22	14	\N	0
6630818201	0	kkyyyuuuuuuu	0	1	0	0	0	0	\N	0
5297651682	0	Jiryu69	0	2	0	0	0	6	\N	0
5814405472	0	Fgb	0	36	0	0	0	10	\N	0
1779873508	0	Aya, *bingung*	0	33	0	0	8410	267	\N	0
2074899903	0	ㅤㅤㅤㅤㅤㅤㅤㅤ	0	2	0	0	0	0	\N	0
6863241956	0	ㅤㅤㅤ❕	0	5	0	0	0	0	\N	0
6566829491	0	.	0	0	0	0	0	1	\N	0
5847156770	0	isa	0	5	0	0	0	3	\N	0
5347263340	0	𝐄line #CALMINTCS	0	8	0	0	0	33	\N	0
5747534557	0	Leona	0	20	0	0	0	0	\N	0
1665015460	0	Mark	0	1	0	0	0	3	\N	0
1470237058	0	mourrél	0	2	0	0	0	3	\N	0
5556468043	0	Unknown	0	4	0	0	0	10	\N	0
6692523462	0	All!!	0	1	0	0	0	8	\N	0
1967226342	0	reyy	0	5	0	0	0	2	\N	0
1398459852	0	lexa.	0	207	0	0	412.45000000000005	730	\N	0
1896607996	0	ra	0	13	0	0	0	7	\N	0
6212564557	0	jeyy	0	21	0	0	125.13999999999999	7	\N	0
5575938733	0	Aurel	0	0	0	0	0	0	\N	0
6208339697	0	decie	0	104	0	0	733.8899999999999	1606	\N	0
1140208947	0	.	0	16	0	0	0	0	\N	0
1992072052	0	.	0	44	0	0	0	0	\N	0
1473721406	0	lanka tidur	0	3	0	0	12.15	59	\N	0
1719758892	0	nor.	0	11	0	0	0	13	\N	0
5576287192	0	Zia	0	4	0	0	0	3	\N	0
6880996379	0	r	0	14	0	0	0	0	\N	0
5013925345	0	ian	0	27	0	0	0	0	\N	0
5970310788	0	dnda	0	2	0	0	0	0	\N	0
5396779553	0	liaa	0	2	0	0	0	0	\N	0
6835825207	0	ga bisa berkabar,timer aku ga jalanCatania. work #calmin𝐑𝐅 Sowie	0	2	0	0	0	2	\N	0
1549272469	0	wonnie	0	5	0	0	0	0	\N	0
1170021056	0	asha	0	65	0	0	85.54	68	\N	0
5755996898	0	Kennie. ribet skip	0	5	0	0	0	2	\N	0
1499999610	0	biyA	0	14	0	0	0	200	\N	0
1737937692	0	J	0	1	0	0	0	0	\N	0
5075453354	0	a	0	2	0	0	0	1	\N	0
2021954126	0	J for Jessie @YuBaromx	0	12	0	0	0	33	\N	0
6229804495	0	Mutia	0	0	0	0	0	1	\N	0
1500446429	0	beylee, c	0	9	0	0	0	8	\N	0
1728262178	0	ael	0	1	0	0	0	0	\N	0
5321656246	0	Eriq resting.	0	1	0	0	0	0	\N	0
5626631117	0	kay	0	2	0	0	0	1	\N	0
6547224500	0	kalula	0	1	0	0	0	3	\N	0
6265339259	0	chase atlantic	0	3	0	0	0	0	\N	0
6149069524	0	r	0	52	0	0	0	1	\N	0
6547300257	0	𝘰𝘭𝘪𝘷𝘦𝘳 🇵🇸	11	38	0	0	2946.9199999999996	479	\N	0
5955053166	0	Alexandra. REST	0	3	0	0	173.68	29	\N	0
5454337786	0	kayla ni dek	0	22	0	0	0	18	\N	0
6349080879	0	Seann	0	60	0	0	0	8	\N	0
5315377418	0	bonnn	0	1	0	0	107.89000000000004	134	\N	0
1197345531	0	itin	0	3	0	0	2000	0	\N	0
6286618572	0	hanny.	0	1	0	0	0	0	\N	0
1738969168	0	biya⋆	0	32	0	0	0	121	\N	0
1933815937	0	shanon🍜	0	7	0	0	0	8	\N	0
5813910862	0	lio	4	1	0	0	1886.94	7	\N	0
1801998853	0	abby	0	4	0	0	0	6	\N	0
5457213858	0	Johan	0	3	1	0	0	0	\N	0
1572494030	0	Cher	0	16	0	0	0	22	\N	0
1874873856	0	执	0	1	0	0	0	2	\N	0
5071568076	0	erina zeelda	0	80	0	0	560.27	108	\N	0
1889021376	0	Carl.	0	62	0	0	1.4699999999999882	6	\N	0
5275600460	0	aira slr? Turu bos	0	105	0	0	352.875	14	\N	0
5985488666	0	a	0	0	0	0	0	0	\N	0
1660632449	0	nas	0	4	0	0	0	0	\N	0
6137115326	0	k	0	16	0	0	0	4	\N	0
1475157449	0	alinn	0	14	0	0	824	3	\N	0
5138479822	0	Jeanne C.	6	118	0	0	1297.9799999999996	2601	\N	0
6033710380	0	j	0	31	0	0	11.82	6	\N	0
6372739178	0	kamala	0	0	0	0	0	0	\N	0
5630056433	0	Kucing	0	1	0	0	0	0	\N	0
5078904766	0	winter	0	18	0	0	0	15	\N	0
5225556210	0	KitinK	0	12	0	0	0	7	\N	0
5388070653	0	odi	11	282	0	0	1200.390000000002	1272	\N	0
5896272447	0	Revan	0	8	0	0	0	7	\N	0
2005876378	0	Mājē	0	37	0	0	0	23	\N	0
1106823918	0	Aldousy	0	3	0	0	0	5	\N	0
2123050697	0	𝒞herry 🧚🏻‍♀️	0	26	0	0	0	0	\N	0
5269797510	0	.	0	44	0	0	195	169	\N	0
5014496339	0	Geo.	0	10	0	0	0	61	\N	0
5479489992	0	dyn	0	1	0	0	0	0	\N	0
6979659428	0	예쁜, Heavèna N	0	19	0	0	0	4	\N	0
1488085054	0	.	0	71	0	0	5.5	98	\N	0
1879716337	0	RUUuUUNnNN 🏃🏻‍♀💨	0	10	0	0	0	3	\N	0
6287092579	0	gloriáSss	0	23	0	0	170.5300000000002	38	\N	0
5685841572	0	ren	0	74	0	0	0	3	\N	0
6724407982	0	Jia	0	1	0	0	0	0	\N	0
1685405685	0	ja	0	71	0	0	0	2	\N	0
6792943136	0	ᴀᴡᴀ ʜᴇʜᴇʜᴇʜᴇ	0	26	0	0	1.98	11	\N	0
5557295877	0	neroo	0	57	0	0	7.560000000000095	59	\N	0
6612152066	0	– Brigitte	0	18	0	0	0	10	\N	0
5971277742	0	yesaya	0	2	0	0	0	0	\N	0
6194180330	0	take a rest.	0	1	0	0	0	0	\N	0
5700978069	0	yaa	14	197	0	0	998.4399999999999	165	\N	0
1586627352	0	Jemima.	0	2	0	0	0	27	\N	0
1249422158	0	Noel👒	0	17	0	0	0	23	\N	0
5028896595	0	Gierlln	0	1	0	0	0	0	\N	0
1987245881	0	Marvel’s heart keeper, Razen.	0	14	0	0	13.25	508	\N	0
5253402730	0	Asa.	0	52	0	0	0	0	\N	0
1741000396	0	zuan	0	22	0	0	419	11	\N	0
5651807997	0	rora 'ᵍʳᶻ🇵🇬	0	5	0	0	0	9	\N	0
1216639663	0	veilia	0	46	0	0	0	63	\N	0
6289366223	0	:	0	9	0	0	1456	3	\N	0
5143276240	0	kaudrie	0	3	0	0	181.5	0	\N	0
1826793900	0	unactive.	0	157	0	0	0	24	\N	0
1809186606	0	lays	0	2	0	0	0	10	\N	0
6718727666	0	Dian #𝗣𝗟𝗡𝗡𝗘𝗪𝗚𝗘𝗡𝟭	0	93	0	0	1366	18	\N	0
2005499121	0	jeff	0	1	0	0	0	0	\N	0
5784214372	0	Bep	0	19	0	0	0.6499999999999986	69	\N	0
6213335764	0	Dipo 441	0	13	0	0	0	7	\N	0
1130201310	0	Faroo.	0	3	0	0	0	0	\N	0
621582214	0	ansel	0	3	0	0	0	2	\N	0
6045272163	0	Kaifeya	0	1	0	0	0	0	\N	0
5163450313	0	D	2	56	0	0	8.870000000000005	176	\N	0
6114565091	0	Mewwyel	0	3	0	0	0	59	\N	0
6422640634	0	joki.dlu	0	1	0	0	0	0	\N	0
6325912967	0	arayy	0	52	0	0	0	4	\N	0
1176641772	0	s	0	3	0	0	0	1	\N	0
1779805733	0	ᴠɪᴅᴀʀ ᴛ.ᴅ [ prpw. $⅞ fHᵈᵒᶜᵗᵒʳ ]	0	2	0	0	0	8	\N	0
6117728196	0	‌‌‌‌‌‌‎ ‌u	0	7	0	0	456	24	\N	0
1927934782	0	Sabiru N.	0	1	0	0	0	0	\N	0
1716786967	0	a	5	760	0	0	2736.75	179	\N	0
1807329075	0	a	0	14	0	0	0	146	\N	0
1232829686	0	febe opn joktug bing	0	4	0	0	0	87	\N	0
5971159196	0	keeho	0	3	0	0	0	0	\N	0
5967269042	0	Gienara	0	29	0	0	145.48	345	\N	0
6632857932	0	Naveen, Shani gf	0	15	0	0	0	153	\N	0
5097804985	0	?	10	169	0	0	10057.989999999994	4838	\N	1
5903188958	0	asep saepulloh	0	33	0	0	325.43000000000006	322	\N	0
6586659197	0	yas	0	7	0	0	0	11	\N	0
5065510824	0	Z	0	5	0	0	0	17	\N	0
5905567153	0	dicky	0	1	0	0	0	16	\N	0
5504278804	0	dai	0	11	0	0	389	13	\N	0
1870953493	0	:D	0	1	0	0	0	0	\N	0
1667252786	0	Bala	0	15	0	0	0	411	\N	0
6287225697	0	jojoy	0	1	0	0	0	13	\N	0
5925263304	0	in	0	95	0	0	0	5	\N	0
1602182543	0	Tama	0	26	0	0	110	131	\N	0
6257577463	0	ᨦ ֢ 𝆬 kiby 🎀 ꒷ ᰍ	0	5	0	0	0	1	\N	0
1981113402	0	dunfer	0	5	0	0	500	0	\N	0
1944218556	0	J.	0	22	0	0	0	2	\N	0
5260047391	0	ɪ ɴᴇᴡʙɪᴇ	0	3	1	0	0	0	\N	0
1722937065	0	Alicia A. vcr	0	29	0	0	561.12	204	\N	0
2023753453	0	zazay	0	9	0	0	0	48	\N	0
6186925568	0	償𝐃𝐢𝐜𝐤𝐲'°× diky	0	16	0	0	0	10	\N	0
823691980	0	Fuegoleon	0	6	0	0	0	18	\N	0
6123348331	0	teo	0	1	0	0	43.85	137	\N	0
6289211350	0	@lJeerk	0	11	0	0	50.840000000000074	11	\N	0
1000241065	0	Y	0	3	0	0	0	10	\N	0
6122666016	0	aii	0	3	0	0	0	0	\N	0
6349283876	0	c	0	1	0	0	0	1	\N	0
5067914917	0	ִ ˖ʾ	0	18	0	0	0	0	\N	0
5350581832	0	Acilatte	0	8	1	0	55.140000000000015	117	\N	0
5956172203	0	hionaaa	0	147	0	0	1657.9599999999998	11	\N	0
6526260247	0	scx. kirasha	0	1	0	0	0	0	\N	0
1509474626	0	Jae	0	9	0	0	0	3	\N	0
6088736020	0	Satir ya	0	3	0	0	0	3	\N	0
1849595746	0	Aji	0	1	0	0	0	0	\N	0
5876534394	0	︎︎ ︎︎ ︎︎ ︎︎ ︎︎ ︎︎︎ ︎︎ ︎︎ ︎︎ ︎︎ ︎︎ ︎︎ ︎︎ ︎︎ ︎︎ ︎︎Ra	4	208	0	0	3537.8499999999995	1807	\N	0
1848559967	0	niesna	0	7	0	0	0	0	\N	0
1132966729	0	Sinatria	0	3	0	0	0	0	\N	0
6318614996	0	devka	0	10	0	0	0	39	\N	0
5080377556	0	Agam	0	7	0	0	0	0	\N	0
5938223829	0	inasss	0	4	0	0	0	23	\N	0
5304186054	0	🐝	0	303	0	0	58	11	\N	0
1935488283	0	ody	0	97	0	0	0	5	\N	0
1334730892	0	.	0	2	0	0	0	0	\N	0
1831563618	0	Bi	0	52	0	0	473.18	124	\N	0
1616487521	0	yugo	0	0	0	0	0	2	\N	0
1959456347	0	djexvā	0	27	0	0	0	4	\N	0
5565618142	0	bibell	0	4	0	0	0	0	\N	0
1824891785	0	cikii	0	1	0	0	0	0	\N	0
6915525014	0	# 𝐅𝐚𝐧𝐢𝐢𝐢	0	0	0	0	0	0	\N	0
1270042042	0	joel	0	235	0	0	0	0	\N	0
6293176759	0	⊹ ࣪ ꒰🎀💭꒱ 𝗰ֹ𝕦‌𝗽꯭𝕚𝕕 ᗴ𝓵𝓵𝕚𝐚ɴ𝐚 ⋆𝖏𝖙𝖗 ♡︬ 𝅄 · 𓈒 ˚	0	0	0	0	25.99	3	\N	0
6808905873	0	୨ . ๑ 🎀🍓 Willona : ୧	0	5	0	0	0	15	\N	0
1447729079	0	syarla	8	893	0	0	12422.419999999996	665	\N	0
2019809020	0	𖤝°D. Cassa-lie. #calminjober's	0	7	0	0	0	2	\N	0
1431191041	0	dipo, return @	0	269	0	0	157	26678	\N	0
1671855510	0	nεγγαα🦋	0	1	0	0	0	0	\N	0
1484909521	0	Adara.	0	25	0	0	0	7	\N	0
2025760057	0	janaa	0	2	0	0	0	0	\N	0
1213286108	0	belvy	0	3	0	0	0	58	\N	0
5684611777	0	iqraar	0	51	0	0	0	176	\N	0
5603986362	0	wo	0	1	0	0	0	25	\N	0
1315637463	0	A.M	0	12	0	0	0	26	\N	0
5253775925	0	temp, Ume Trieésthy. 🇲🇶	0	2	0	0	0	8	\N	0
5145943954	0	Ashley.	0	0	0	0	0	1	\N	0
1639428081	0	arandu	0	2	0	0	0	0	\N	0
5517932088	0	pin	0	1	0	0	0	0	\N	0
1392747869	0	niko lagi nyari responden	0	2	0	0	0	0	\N	0
854291802	0	Ezzie	0	0	0	0	0	0	\N	0
5544825260	0	ε Riella @ksmsaeron	0	0	0	0	0	2	\N	0
5209025345	0	chae cintah dohyun	0	15	0	0	0	17	\N	0
5359254724	0	Shave 4twenty	0	3	0	0	0	0	\N	0
6080734878	0	versaché.	0	0	0	0	0	0	\N	0
5066084085	0	Evaa	0	1	0	0	0	0	\N	0
1640520981	0	kay	0	1	0	0	0	0	\N	0
6054386228	0	samudra	0	71	0	0	0	9	\N	0
6120692162	0	monyet	0	20	0	0	0	7	\N	0
2133513364	0	loh	0	0	0	0	0	1	\N	0
5258713802	0	rxy	0	92	0	0	11.32	82	\N	0
5440212097	0	vann	0	24	0	0	0	4	\N	0
5567883836	0	kafyan	4	15	0	0	2646.4000000000005	37	\N	0
5092048122	0	just lily	0	37	0	0	1180.53	187	\N	0
1764730915	0	Velaa.	0	1	0	0	0	23	\N	0
5666478639	0	steyy smõwkies.	0	34	0	0	4.74	21	\N	0
1766915503	0	h. rakarsa	0	26	1	0	0	25	\N	0
1350504150	0	ririnajiwa	0	1	0	0	0	0	\N	0
5579956094	0	neo pecinta meme	0	8	0	0	0	0	\N	0
5931724031	0	sss	0	151	0	0	48.65999999999838	337	\N	1
1227800478	0	A	0	3	0	0	0	13	\N	0
1629174001	0	Cessa	0	1	0	0	0	3	\N	0
6659584962	0	oca	0	0	0	0	300	203	\N	0
5975179154	0	jowa	0	19	0	0	0	30	\N	0
5035013117	0	ell	0	8	0	0	0	42	\N	0
5350365342	0	🐈	0	16	0	0	0	26	\N	0
5787157257	0	ovel	0	1	0	0	0	0	\N	0
5987410707	0	lac	0	14	0	0	0	2	\N	0
1958679729	0	Sauivel	0	3	0	0	0	2	\N	0
1989906826	0	𔘓	0	28	0	0	0	17	\N	0
1203881451	0	?	0	72	0	0	379.03999999999996	32	\N	0
6140130821	0	oo	0	5	0	0	1129.57	103	\N	0
5165276114	0	ur bf	0	2	0	0	0	2	\N	0
5929725518	0	Abi	0	1	0	0	0	0	\N	0
5725381307	0	kailash	0	1	0	0	0	1	\N	0
6634007212	0	off	0	2	0	0	0	1	\N	0
6087486158	0	Paw $ar	0	1	0	0	0	5	\N	0
5672428575	0	cia, rest.	0	17	0	0	0	107	\N	0
5522654273	0	Miwa	0	57	0	0	526	116	\N	0
5568871230	0	Jozu	0	2	0	0	0	4	\N	0
1306895719	0	keyla	0	35	0	0	0	95	\N	0
1885187551	0	humey	2	434	0	0	31787.770000000026	749	\N	0
1877053204	0	pukis	0	57	0	0	0	12	\N	0
1839575644	0	Aa.	0	175	0	0	177.1600000000002	1	\N	0
5973271547	0	jeli	0	1	0	0	0	181	\N	0
1415373653	0	mas F	0	1	0	0	0	0	\N	0
5526254284	0	Algy	0	2	0	0	0	1	\N	0
1797144246	0	Kaloova	0	31	0	0	31.129999999999995	106	\N	0
1314291241	0	jovan putra bangsawan	0	2	0	0	0	7	\N	0
1716561417	0	R	0	1	0	0	0	22	\N	0
5106815561	0	asik	0	319	0	0	9.300000000000011	664	\N	0
1894503617	0	lala	0	1	0	0	0	0	\N	0
5558308959	0	pinca	0	165	0	0	1.89	458	\N	0
5736946617	0	Katherine	0	0	0	0	0	0	\N	0
1785058788	0	arbie	0	1	0	0	0	0	\N	0
6638648999	0	Ace.	0	0	0	0	0	1	\N	0
6542308211	0	kezyy.	0	1	0	0	0	0	\N	0
5916078599	0	Han	0	3	0	0	0	4	\N	0
6170127111	0	helga	0	1	0	0	0	1	\N	0
7195101292	0	bian	0	1	0	0	0	0	\N	0
1340620485	0	zela	0	8	0	0	0	48	\N	0
5002368646	0	Prettiest Girl : Abellya.V	0	2	0	0	0	0	\N	0
6215694685	0	d	0	3	0	0	23.66	7	\N	0
1921516354	0	bsb.Drajor	0	13	0	0	0	60	\N	0
1724350114	0	Ra	0	158	0	0	105.70999999999913	624	\N	0
5695959833	0	kentang rebus	0	7	0	0	0	3	\N	0
2084248423	0	Max	0	5	0	0	0	0	\N	0
5272085292	0	pouu	0	9	0	0	0	0	\N	0
5670545417	0	rafa sedih	0	10	0	0	0	70	\N	0
6151320651	0	aly	12	221	0	0	2666.05	490	\N	0
5026915790	0	anann	0	5	0	0	0	74	\N	0
1989437913	0	Fernanda	0	3	0	0	0	0	\N	0
6792088145	0	yaya	0	0	0	0	0	13	\N	0
6335905733	0	Lilly	0	2	0	0	0	0	\N	0
1651805994	0	ㅤD:ㅤ	0	15	0	0	0	0	\N	0
6833701706	0	auraaa	0	7	0	0	0	0	\N	0
1389991454	0	Seanné Brie.	0	1	0	0	0	1	\N	0
1941095697	0	a	0	16	0	0	0	72	\N	0
1307331283	0	Radelaäaâa, promo dm🤩	0	9	0	0	11416.129999999996	23	\N	1
1081310356	0	zikrii	2	465	0	0	4861.5599999999995	327	\N	0
5699834232	0	affärel. ayara bf	0	7	0	0	0	26	\N	0
6665450065	0	marie, slow !	0	13	0	0	0	3	\N	0
5482908080	0	Nqn	0	16	0	0	0	15	\N	0
1790978944	0	TOKO PDI	0	5	1	0	0	71	\N	0
1215545972	0	MicroTrans	0	1	0	0	0	1	\N	0
6299743367	0	𝒛𝒆𝒍𝒊𝒏𝒆'𝒔	0	1	0	0	0	0	\N	0
6071340221	0	tjut m	0	1	0	0	0	0	\N	0
1274086792	0	Ayi, dni.	0	2	0	0	0	0	\N	0
6885856751	0	Veina K.	0	2	0	0	0	8	\N	0
5460878095	0	zidane	0	9	0	0	0	7	\N	0
1985904581	0	ophe!ossjak	0	1	0	0	0	2	\N	0
6985881304	0	44	0	1	0	0	0	2	\N	0
2001569514	0	Fay	0	2	0	0	0	8	\N	0
5742372623	0	Nola	3	359	0	0	5.800000000000068	396	\N	0
1834459325	0	ㅤㅤㅤㅤㅤㅤhbd cila!🎂	0	24	0	0	0	25	\N	0
1149178531	0	heroine	0	10	0	0	0	4	\N	0
7184831684	0	jnnfr?	0	6	0	0	0	22	\N	0
5390707970	0	raa	0	1	0	0	0	1	\N	0
5216847982	0	L	0	54	0	0	500	66	\N	0
1085743776	0	reefa	0	18	0	0	0	2	\N	0
6636735546	0	dv	0	2	0	0	0	1	\N	0
6278351905	0	rae galau njir	12	251	0	0	0.6800000000000406	2334	\N	1
1838301957	0	Winter.	0	39	0	0	0	15	\N	0
5620727224	0	yaa	0	29	0	0	0	1	\N	0
6164913824	0	Zens	0	6	0	0	0	7	\N	0
1614193919	0	Niel	0	6	0	0	0	23	\N	0
5130932015	0	Faya	0	7	0	0	0	95	\N	0
6074571752	0	Rezandra.	0	2	0	0	0	0	\N	0
6571308098	0	kaira	0	1	0	0	0	0	\N	0
6253528714	0	nab	14	154	0	0	2068.31	912	\N	0
5859595279	0	Arsenio V.	0	1	0	0	0	0	\N	0
942597600	0	…	0	3	0	0	0	5	\N	0
1708492911	0	.	0	1	0	0	0	1	\N	0
5202232951	0	yuno your clown [𝐒𝐕𝐇𝟑𝟏]ᴰ²	0	1	0	0	0	3	\N	0
1802941371	0	𝐀𝐋	0	236	0	0	4	2164	\N	0
5213530216	0	aresh	0	28	0	0	0	9	\N	0
2073088118	0	𓄼𝆬 𝐒imon	0	0	0	0	0	1	\N	0
5680172965	0	hanna	0	28	0	0	4.400000000000176	32	\N	0
2146911767	0	.	0	169	0	0	18	57	\N	0
5891230122	0	aysa	0	2	0	0	0	0	\N	0
6175714922	0	Usa	0	29	0	0	0	67	\N	0
6734071539	0	yya	0	10	0	0	0	0	\N	0
5052740677	0	Zzz	0	7	0	0	0	18	\N	0
1677398076	0	miss u	0	1	0	0	0	0	\N	0
1979810049	0	L	0	20	0	0	0	0	\N	0
5559766647	0	xen.	0	1	0	0	0	0	\N	0
5341143110	0	maydina net not.	12	141	0	0	5489.260000000003	7238	\N	1
5708895232	0	THALIA💐💐💐	0	4	0	0	0	8	\N	0
5697632318	0	-𝐅𝐢𝐧𝐬𝐞𝐧	5	237	0	0	100.9799999999999	352	\N	0
1784111402	0	𝓩ayn V.	0	1	0	0	0	0	\N	0
2073244397	0	ay	0	279	0	0	117.83999999999997	4	\N	0
6213225134	0	a user in love with dikaa, Shaa!	0	73	0	0	-10.049999999999955	23	\N	0
5412154729	0	ts	0	118	0	0	0	69	\N	0
1422958132	0	faay	0	23	0	0	46.33	8	\N	0
1768890448	0	r	0	1	0	0	0	0	\N	0
5195453649	0	a	0	23	0	0	0	27	\N	0
1278659370	0	Wismaya P. C.	0	1	0	0	0	3	\N	0
5359394323	0	Zayn Màlik insecure 4twenty	0	1	0	0	0	1	\N	0
1929056610	0	Catharina M.	0	7	0	0	0	0	\N	0
5851500990	0	eckrim	6	94	0	0	493.1299999999995	884	\N	0
1633326095	0	Kavier 🐈💭	0	129	0	0	545.46	109	\N	0
1898119671	0	.	0	7	0	0	0	19	\N	0
1879190658	0	mvl. elliss lagi cinta banget sama muichiro bau telonn😍😍💓💓	0	220	0	0	149.38	471	\N	0
5191487480	0	han	0	3	0	0	0	0	\N	0
5696640235	0	karel	0	4	0	0	0	4	\N	0
6296435981	0	Hitam	0	32	0	0	0	112	\N	0
6072318554	0	airshã	0	0	0	0	0	0	\N	0
6717598019	0	⊛ ᴏsᴄᴀʀ 1ꜱᴛ	0	2	0	0	0	0	\N	0
5389123099	0	kimi hime	0	31	0	0	0	8	\N	0
5045234290	0	mode galau	0	14	0	0	2.3299999999999983	22	\N	0
5924825519	0	𝓕elicia 𝓐ngelline	0	9	0	0	0	22	\N	0
1507577220	0	Cococras27	0	1	0	0	0	5	\N	0
7030902780	0	Dill	0	17	0	0	17.71	63	\N	0
1441560820	0	Jasmine	0	6	0	0	12.34	0	\N	0
6621179840	0	odi	0	20	0	0	0	34	\N	0
1987787627	0	Bby	0	2	0	0	0	0	\N	0
5152958461	0	Faine.	0	29	0	0	1140.74	20	\N	0
6598568742	0	esa	0	1	0	0	0	0	\N	0
6282819978	0	ayaa	0	1	0	0	0	0	\N	0
1832693696	0	saa	0	1	0	0	0	0	\N	0
1810977825	0	grace	0	0	0	0	0	0	\N	0
6602590803	0	jejenya abaayayay	7	22	0	0	484.41	232	\N	0
6977437359	0	Pia	0	6	0	0	0	171	\N	0
5052026412	0	Vicente	0	22	0	0	0	12	\N	0
1682554875	0	vall	0	5	0	0	0	2	\N	0
1867596142	0	🎀🩰🫧	0	2	0	0	0	0	\N	0
1983228290	0	jelly	0	7	0	0	0	7	\N	0
7000215609	0	.	0	6	0	0	0	6	\N	0
7026359676	0	Cahyeon	0	2	0	0	0	1	\N	0
1892356602	0	.	0	0	0	0	0	0	\N	0
5853873905	0	zen	0	2	0	0	0	0	\N	0
1757820365	0	HARRAA	0	24	0	0	0	6	\N	0
2106108840	0	luna ᵃᶠᵃᶻ	0	3	0	0	0	2	\N	0
1249194238	0	lexie.	0	8	0	0	0	0	\N	0
6398253082	0	mendusa	0	397	0	0	68.75	61	\N	0
6723915532	0	k	0	149	0	0	841.3900000000001	730	\N	0
5866855852	0	aaaaaa	0	1	0	0	0	1	\N	0
6615710967	0	lovē	0	1	0	0	0	0	\N	0
7163760023	0	caramell gy kesall	0	4	0	0	0	0	\N	0
2094443479	0	Malam	0	6	0	0	0	167	\N	0
1738796593	0	Do not fucking interact, bodoh.	0	2	0	0	0	108	\N	0
6594685740	0	Violetta	0	0	0	0	0	1	\N	0
6011078844	0	kys	0	0	0	0	0	9	\N	0
5172401774	0	egan	0	4	0	0	0	14	\N	0
6198639705	0	icel	0	12	0	0	1413.92	5	\N	0
1550661151	0	Keinna 🐚🐚	5	34	0	0	1485.3200000000004	296	\N	0
1753729743	0	shakiku	0	9	0	0	0	0	\N	0
6077799588	0	Kayyes	0	47	0	0	0	192	\N	0
1207000580	0	awaa	0	7	1	0	0	7	\N	0
6290486772	0	sha . kabarin pls	0	3	0	0	0	2	\N	0
5953256135	0	Jody	0	2	0	0	0	1	\N	0
5821132191	0	dap	0	1	0	0	0	0	\N	0
6269491725	0	a	0	1	0	0	0	0	\N	0
6588990021	0	𝖇𝐞𝐥	0	9	0	0	0	3	\N	0
6255010331	0	na.	0	16	0	0	0	5	\N	0
6306547199	0	galaksi 𝒮𝒽𝒶 ᴴᴸ	0	7	0	0	0	0	\N	0
6051449466	0	alan	0	2	0	0	0	0	\N	0
7143636202	0	Abay	0	1	0	0	0	0	\N	0
5852800296	0	fdo	0	34	0	0	0	6	\N	0
5401564128	0	isk	0	8	0	0	0	1	\N	0
6088173115	0	🐈	0	9	0	0	193.01	3	\N	0
6836982232	0	keith.	0	62	0	0	0	28	\N	0
5873933985	0	Rangga	0	2	0	0	0	5	\N	0
5050058705	0	bian close.	0	0	0	0	0	0	\N	0
1559883735	0	Kayana	0	8	0	0	0	0	\N	0
5219022934	0	awl	12	4	0	0	926.4899999999999	880	\N	0
1022964351	0	✨	0	53	0	0	0	360	\N	0
6978623429	0	Jijell	0	2	0	0	0	3	\N	0
5805285364	0	y-tic|𝙏𝙍𝘼𝙄𝙉𝙀𝙀𓂃᭙ⅈ*᥊ⅈꫀꫀ|	0	12	0	0	35	67	\N	0
6184533622	0	ecaaaa sdg tida mut ‼️	0	2	0	0	0	0	\N	0
1410888693	0	196 alan kopar	0	1	0	0	150	0	\N	0
1413852139	0	Bryan.	0	19	0	0	0	0	\N	0
5979741803	0	c	0	1	0	0	0	2	\N	0
1941797423	0	ruby	0	1	0	0	0	203	\N	0
6181245623	0	Syg elin	0	1	0	0	0	5	\N	0
1943701807	0	𝑨drienne i𝑺abelle	0	1	0	0	0	3	\N	0
6413560132	0	pariss	0	0	0	0	0	0	\N	0
6807010178	0	𝐊yle. kásseki	0	4	0	0	0	1	\N	0
1904675374	0	Yuhuuu dimancurin	0	0	0	0	0	0	\N	0
1953920623	0	kimeshiki	0	2	0	0	0	4	\N	0
1940191938	0	viona	0	1	0	0	0	1	\N	0
6605262538	0	kinan	0	1	0	0	0	0	\N	0
1592436084	0	VO1||jgn cht akun, tenggelam.ke bot sj	0	1	0	0	0	0	\N	0
5363540334	0	lalalalalalala	0	69	0	0	0	884	\N	0
2093431957	0	Samuel.	0	3	0	0	0	0	\N	0
5242194366	0	B!tch?	0	136	0	0	12	234	\N	0
1735148470	0	rararara	14	11	0	0	595.6999999999999	40	\N	0
5935910015	0	sab	0	1	0	0	0	0	\N	0
5192121797	0	depoyy	0	3	0	0	0	10	\N	0
5698562556	0	Rannn ft @BLADEEF	0	4	0	0	0	0	\N	0
6363889321	0	Zzz!	0	5	0	0	0	2	\N	0
5004600134	0	🚩Aksaᵖᵃˢᵍᵃᵇᵃᵗ ᵛⁱˢ	0	138	0	0	0	10	\N	0
1300163642	0	AR.	0	11	0	0	0	0	\N	0
5747396875	0	♡.. Da-vin'a	0	4	0	0	0	1	\N	0
2093531939	0	Igar, b!gásmkth	0	86	0	0	1723.7600000000007	127	\N	0
1856356482	0	Pinca. #HBDJENAN MWAH	0	4	0	0	0	35	\N	0
1684767841	0	adrie je	0	11	0	0	0	30	\N	0
5664690344	0	cikidall	0	81	0	0	15.529999999999916	4529	\N	0
2043795492	0	Rezky logout	0	43	0	0	0	90	\N	0
1904652952	0	18 cm.	0	73	0	0	8.16	14	\N	0
926899135	0	zy	0	92	0	0	0	0	\N	0
5401598553	0	aaaaasaa	0	1	0	0	0	3	\N	0
6943834342	0	GYssele	0	3	0	0	0	0	\N	0
5038201208	0	created by god for one and only one	0	2	0	0	0	0	\N	0
5618932250	0	navya	0	37	0	0	0	5	\N	0
5990104750	0	rbd.manuel	0	1	0	0	0	0	\N	0
5580322015	0	Lowliel	0	7	0	0	0	2	\N	0
6020746148	0	..	0	23	0	0	0	45	\N	0
6443747667	0	chocolate	0	2	0	0	0	4	\N	0
6060109562	0	Aster Viestern.	0	60	0	0	0	12	\N	0
5202662126	0	ceisya	0	9	0	0	0	0	\N	0
5468489876	0	₊˚꒰ఎ 작은 : kith.nana%.໒꒱˚₊	0	0	0	0	72	19	\N	0
5688268539	0	Li xixu || 李旭旭	9	37	0	0	2725.5499999999997	249	\N	0
6131780576	0	𝐎 · 𝐕𝐀 -Haruki	0	4	0	0	0	0	\N	0
1369358170	0	meta	0	5	0	0	0	5	\N	0
5220131354	0	zasya	0	68	0	0	0	53	\N	0
5271751037	0	Lyana	0	2	0	0	0	3	\N	0
2094341627	0	Gimyung	0	12	0	0	0	3	\N	0
2002797628	0	dindaa trii 𓆉	0	11	0	0	0	64	\N	0
5156397004	0	tuing	0	83	1	0	0	179	\N	0
1645147576	0	YENISA WAHYU KURNIA ASIH_AKL	0	0	0	0	0	0	\N	0
5570196290	0	Jo	0	3	0	0	0	1	\N	0
5529228360	0	reval	0	11	0	0	0	92	\N	0
5878690323	0	ㅤh	0	21	0	0	17.79000000000019	12	\N	0
1959833888	0	Beeeeeeverly	0	89	0	0	0	72	\N	0
6035774802	0	n	0	5	0	0	0	51	\N	0
1408590964	0	kae	0	4	0	0	0	82	\N	0
1980341858	0	nadine	0	35	0	0	0	0	\N	0
5698863230	0	Hanz	0	1	0	0	0	1	\N	0
606443325	0	Aby	0	2	0	0	0	3	\N	0
1443546573	0	na	0	5	0	0	0	1	\N	0
6395163389	0	el	0	4	0	0	0	0	\N	0
7086731004	0	Dom	0	0	0	0	0	0	\N	0
1845224086	0	alice	0	33	0	0	22.82	136	\N	0
2023687820	0	.	2	39	0	0	525.36	17	\N	0
6229722425	0	adis	0	3	0	0	0	81	\N	0
2114379304	0	nadine	0	2	0	0	0	5	\N	0
5329355269	0	Mozes	0	17	0	0	0	1284	\N	0
1764969932	0	najeee	0	3	0	0	0	14	\N	0
1772358028	0	Renja	0	6	0	0	0	7	\N	0
1330120318	0	ai	0	85	0	0	4.730000000000004	7	\N	0
5148241028	0	M	0	3	0	0	0	0	\N	0
1465925974	0	kEvin. ‘𝒮𝒽𝒶	0	14	0	0	24	1	\N	0
5107769327	0	໒ ˒ el ?! ៸៸	0	1	0	0	0	0	\N	0
6708572445	0	dhemiddes	0	2	0	0	0	0	\N	0
1773488207	0	ainsley.	0	101	0	0	2216.8299999999995	1889	\N	0
5152812536	0	v	0	3	0	0	0	1	\N	0
1030118628	0	-	0	1	0	0	0	0	\N	0
5434607434	0	viviiiiiii	0	2	0	0	0	0	\N	0
2131747805	0	ay	10	19	0	0	999.0200000000002	232	\N	1
6525680541	0	troia cuppi 🇫🇯	0	1	0	0	0	0	\N	0
5367387701	0	R	0	18	0	0	1606.6000000000006	169	\N	0
5910494624	0	Ayaa	0	244	0	0	18.920000000000186	49	\N	0
6201549270	0	zifa	0	17	0	0	0	6	\N	0
1964250656	0	ella	0	2	0	0	0	0	\N	0
5250950942	0	Who am i?	0	9	1	0	0	0	\N	0
2140217867	0	⋆⃟𝐍𝐂 Emily ꜱᴇxᴘ༃	0	0	0	0	0	10	\N	0
5033419762	0	rest, nour	0	19	0	0	0	5	\N	0
5444855258	0	Rea Park°	0	3	0	0	0	0	\N	0
5154573139	0	key-cha SELLER OFF DULU	0	1	0	0	0	0	\N	0
6861291349	0	bi'el rrw	0	3	0	0	0	40	\N	0
1606423399	0	' L!v	0	16	0	0	0	4	\N	0
5859436464	0	246.	0	0	0	0	0	5	\N	0
1328131445	0	c	0	1	0	0	0	0	\N	0
5072018522	0	Sigma	0	107	0	0	0	0	\N	0
6104383516	0	freyya	0	44	0	0	689	8	\N	0
1780232170	0	🦭	0	3	0	0	0	2	\N	0
5361877970	0	A	0	16	0	0	0	0	\N	0
1628933276	0	andin	0	61	0	0	1370.16	37	\N	0
1818907469	0	kamila	0	1	0	0	0	23	\N	0
5707972753	0	mimo ᴅᴛʀ²⁴	0	7	0	0	0	0	\N	0
7114145394	0	nad	0	1	0	0	0	0	\N	0
6396761774	0	Darow Open CV to all	0	7	0	0	0	0	\N	0
1009417479	0	a	0	1	0	0	0	2	\N	0
5123512752	0	Ditt	0	2	0	0	0	1	\N	0
5224322618	0	.	0	6	0	0	0	0	\N	0
5822219129	0	$hava	0	3	0	0	0	21	\N	0
1933471593	0	Faezar Hakim	0	1	0	0	0	0	\N	0
1624042310	0	team	0	4	0	0	0	0	\N	0
1836632819	0	arshaka	0	1	0	0	0	0	\N	0
2057737050	0	‎ ‎ arr.	0	59	0	0	125	118	\N	0
5338545833	0	ai kinda slowresp	0	2	0	0	0	0	\N	0
6106673904	0	Deril Verdiego	0	6	0	0	146	5	\N	0
5900001124	0	Jack's 【﻿ＨＬ】	0	39	0	0	0	6	\N	0
5355705540	0	rere	0	39	0	0	4.54	75	\N	0
6343208615	0	fayy	0	39	0	0	0	3	\N	0
7116719013	0	yuna	0	15	0	0	0	0	\N	0
5166379070	0	Kharles	0	10	0	0	0	54	\N	0
1539225215	0	Tiwi⁶	0	122	0	0	77.64999999999999	309	\N	0
6832123714	0	angel	0	43	0	0	0	14	\N	0
6417076695	0	ashley	0	26	0	0	95.25	49	\N	0
1072085346	0	♡ aeuncha. ( ga punya clone )	0	0	0	0	0	0	\N	0
6049109972	0	cel	0	10	0	0	0	9	\N	0
6520879671	0	Din	0	2	0	0	0	1	\N	0
5952250602	0	𝗻︪︩ׄ𝝰᷁ isi rnk	11	46	0	0	589.16	78	\N	0
5187020065	0	Hiroᴴᵒʳⁿʸ	0	570	0	0	24.01000000000004	89	\N	0
5975779806	0	Jophiel	0	2	0	0	0	0	\N	0
2030450888	0	jo	0	2	0	0	0	0	\N	0
5811247738	0	sa	0	6	0	0	0	8	\N	0
5122953498	0	Vina	0	7	0	0	0	0	\N	0
1463030753	0	cvs⁴. yurika	0	8	0	0	0	2	\N	0
5056237804	0	.	0	26	0	0	0	0	\N	0
5562683462	0	Lekim.	0	0	0	0	25.06	43	\N	0
6011440284	0	Bulan	0	7	0	0	0	5	\N	0
5599773186	0	Sagara A.	0	2	0	0	0	0	\N	0
5567138367	0	pending, ais	0	7	0	0	0	1	\N	0
5186791991	0	Theona, slowresp	0	1	0	0	0	0	\N	0
6812210514	0	Lix	0	2	0	0	0	0	\N	0
5649416773	0	Jane Austen.	0	479	0	0	1291.1000000000001	1083	\N	0
6768912745	0	ilyrewwlaaa🚩	0	1	0	0	0	0	\N	0
2015261563	0	tere ִֶָ	0	1	0	0	0	0	\N	0
5897951248	0	ibeyyy	0	4	0	0	0	37	\N	0
1963775262	0	katana	0	66	0	0	4.239999999999998	48	\N	0
1879344226	0	rrrrrrrrrrrrrrrrrrrr	0	312	0	0	4	84	\N	0
6394633477	0	𐙚 ׅ ⁺ — mayori ♟️	0	6	0	0	0	0	\N	0
1850536463	0	Jaki	0	1	0	0	0	8	\N	0
6125829096	0	Arsena	0	2	0	0	0	22	\N	0
954582339	0	a	0	2	0	0	0	0	\N	0
1763958933	0	Bear	0	19	0	0	0	19	\N	0
5680690542	0	Allisya C.	0	5	0	0	0	0	\N	0
1505971084	0	Finn #prayforjegar	0	1	0	0	0	17	\N	0
6428244667	0	naa	0	6	0	0	0	3	\N	0
5981787844	0	H	0	254	0	0	0	3	\N	0
6793670775	0	saga	0	2	0	0	0	4	\N	0
6628984889	0	Kal!	0	0	0	0	0	0	\N	0
1915133422	0	Langit geovandra davarenzo	0	1	0	0	0	0	\N	0
6101598251	0	Yikaaa	0	9	0	0	0	13	\N	0
1814864962	0	jaka widodo	12	12	0	0	86.5	167	\N	0
6094570264	0	reeetha	0	3	0	0	0	2	\N	0
5407107586	0	jean	0	46	0	0	0	111	\N	0
6533957281	0	kj	0	2	0	0	0	13	\N	0
5661120910	0	r	0	8	0	0	0	0	\N	0
5984527617	0	yuna ᯓ ᡣ𐭩	0	12	0	0	0	1	\N	0
1660412761	0	Ollie's lovetaker 155	0	32	0	0	6.780000000000001	220	\N	0
6359361059	0	aya	0	1	0	0	0	0	\N	0
1628062868	0	Jonathan	0	3	0	0	0	0	\N	0
1949193462	0	Baby Dolphin🐬	0	1	0	0	0	4	\N	0
6077481042	0	Alexei Feodorovnich.	0	14	0	0	0	7	\N	0
5280455435	0	nanas	0	27	0	0	4.659999999999997	0	\N	0
2073605610	0	sasmitha 481	0	187	0	0	17.340000000000032	336	\N	0
5656945756	0	ezra	0	7	0	0	0	0	\N	0
7001955655	0	зизе 🇷🇺	0	9	0	0	0	130	\N	0
6860267600	0	gita	0	0	0	0	0	0	\N	0
1789836365	0	ikan, ikan apa	0	125	0	0	12931.520000000006	1216	\N	1
6849822855	0	shà	0	131	0	0	34.84000000000003	43	\N	0
5186038899	0	detective. yilenaninu	0	367	0	0	330.29	576	\N	0
5380451005	0	zdnn	0	1	0	0	0	1	\N	0
5881114010	0	An	0	0	0	0	0	1	\N	0
6410696603	0	love	0	22	0	0	329	469	\N	0
6214864182	0	kilea on your left	0	118	0	0	626.3700000000001	55	\N	0
6304791442	0	Ecaaa sk lolipop	0	1	0	0	0	0	\N	0
6241073708	0	atharel	0	225	0	0	27.689999999999984	832	\N	0
1850321022	0	ACC PROMOTE, ASK CP/BOT.	0	7	0	0	0	0	\N	0
1554885552	0	caa isn't muddd	0	11	0	0	0	13	\N	0
5562557309	0	💐	0	0	0	0	0	0	\N	0
1903667535	0	.	0	0	0	0	0	0	\N	0
680240109	0	Dd	0	4	0	0	0	2	\N	0
1431853705	0	Dollyeve Miyéya 🪽	0	3	0	0	0	17	\N	0
5251833620	0	lik	0	6	0	0	0	7	\N	0
6038057669	0	eilin.	0	10	0	0	1458.56	161	\N	0
6255518785	0	naya	0	3	0	0	0	0	\N	0
2095674053	0	Kàtherine	0	117	0	0	-6	636	\N	0
1935034277	0	caca	0	13	0	0	0	2	\N	0
1642682164	0	Reano	0	1	0	0	0	1	\N	0
5068505932	0	B. Murray	2	111	0	0	1051.5399999999997	368	\N	0
5642238471	0	chezey	0	2	0	0	0	4	\N	0
2089072046	0	𓏲 ˖. ♡‌ 𝖱𝖺𝖾𝖿𝖺𝖺𝗅 " 𓂃 !	0	5	0	0	0	4	\N	0
6451905535	0	666	0	0	0	0	0	40	\N	0
2133831594	0	M	0	1	0	0	0	0	\N	0
1347432054	0	Kameira	0	96	0	0	829.0600000000004	1305	\N	0
1011763024	0	brussell	0	1	0	0	0	0	\N	0
5771134156	0	Alex	0	9	0	0	0	4	\N	0
5306286991	0	san	0	1	0	0	0	0	\N	0
1958995469	0	natha 🧏🏻‍♀️	0	0	0	0	0	0	\N	0
5149199073	0	Nirmala	0	9	0	0	0	5	\N	0
1505218032	0	lopiepop	0	3	0	0	0	0	\N	0
6035539427	0	Gardapatih	0	4	1	0	0	12	\N	0
1918063295	0	ola	0	9	0	0	0	0	\N	0
5898770860	0	spencer 2	0	8	3	0	0	0	\N	0
1904706087	0	h	0	117	0	0	326.25	268	\N	0
1633265206	0	Reiama, ☻	0	2	0	0	0	0	\N	0
1254035433	0	Nasywa ₍^.ˬ.^₎⟆	0	27	0	0	380	5750	\N	0
6623724269	0	oIverus	0	2	0	0	0	10	\N	0
5655700410	0	a	0	1	0	0	0	0	\N	0
2047952869	0	11. Kava.	0	21	0	0	0	6	\N	0
6167050355	0	biii	0	103	0	0	1178.69	233	\N	0
6887613006	0	Doms	0	0	0	0	0	0	\N	0
1902235223	0	riaa☁	0	0	0	0	0	0	\N	0
6746636677	0	adel	0	6	0	0	0	3	\N	0
6096630697	0	naje	0	1	0	0	0	1	\N	0
6702945124	0	greesel gf	0	2	0	0	0	0	\N	0
6647347174	0	lin🫀	0	0	0	0	0	2	\N	0
1874132017	0	bey	0	30	0	0	0	3	\N	0
1988285407	0	Nays	0	2	0	0	0	0	\N	0
1583473909	0	Akaa.	0	32	0	0	7.910000000000004	0	\N	0
815168753	0	Dev	0	2	0	0	0	0	\N	0
6381388461	0	nana	0	4	0	0	0	0	\N	0
6583887501	0	🍯	0	2	0	0	0	0	\N	0
5923105101	0	Wawa.	0	5	0	0	92.4	16	\N	0
5311212659	0	𝟗𝟔. 𝐁𝐞𝐲 SLR	0	7	0	0	0	0	\N	0
1141135676	0	𒆜rapa	0	30	0	0	0	3	\N	0
1707471714	0	ois	0	131	0	0	38.62	36	\N	0
1788987853	0	kalila nangis pcrnya cantik bgt	0	6	0	0	0	49	\N	0
1735441783	0	ᥙᥒᥲᥲ	0	8	0	0	0	0	\N	0
5520877555	0	aaa	0	44	0	0	0	0	\N	0
6521567631	0	ciaraa	0	2	0	0	0	1	\N	0
6912791204	0	bryann	0	2	0	0	0	0	\N	0
1685847356	0	jezz	0	22	0	0	0	7	\N	0
5640579781	0	kurt	0	1	0	0	0	1	\N	0
7007818541	0	gebi	0	3	0	0	0	1	\N	0
1416226684	0	Shalmeera A.🪞	0	4	0	0	0	12	\N	0
1535607217	0	keijaa	0	10	0	0	0	1	\N	0
6339732823	0	M!	0	5	0	0	0	1	\N	0
5705878783	0	Joden.	0	1	0	0	0	0	\N	0
6510954791	0	Star	0	1	0	0	0	1	\N	0
1403427954	0	zo	0	2	0	0	0	5	\N	0
1830008062	0	zzz	0	26	0	0	0	32	\N	0
6196024626	0	fayeee:3	0	1	0	0	0	0	\N	0
5130245830	0	kaye	0	40	0	0	1152.87	0	\N	0
1437030258	0	F	0	2	0	0	0	0	\N	0
5595773771	0	Cassandrakle.	0	14	0	0	0	21	\N	0
1974886686	0	Laura	0	108	0	0	0	0	\N	0
6637557258	0	allarick	0	3	0	0	0	17	\N	0
1615756075	0	mei	0	24	0	0	0	16	\N	0
5905378693	0	Marrow	0	6	0	0	0	2	\N	0
1576847400	0	kalula	0	35	0	0	0	11	\N	0
5308252671	0	jane, a.	0	49	0	0	0	26	\N	0
958931601	0	Jerry T.M	0	3	0	0	0	1	\N	0
7193050815	0	asa	0	3	0	0	0	1	\N	0
1968123301	0	sabil	0	275	0	0	14.71	20	\N	0
1900625360	0	Serin	0	2	0	0	0	1	\N	0
5122002800	0	Caramellia.	0	15	0	0	11.21	233	\N	0
5455719579	0	cannaby	0	2	0	0	0	3	\N	0
6713143106	0	esc. lady 𝖏𝖈𝖘¹ bjn³	0	4	0	0	0	4	\N	0
6022448497	0	Harune.	0	6	0	0	0	0	\N	0
6130300009	0	Deka 14°C	0	1	0	0	0	0	\N	0
5261144930	0	〣 𝙂𝘢ziiye𝘓 ㄠ f𝘙istᧉza ⟡‌ ָ֢ ׁ🐩	0	2	0	0	0	0	\N	0
5296168091	0	c	0	1	0	0	0	0	\N	0
5952206134	0	Mirawr 🎀	0	1	0	0	0	0	\N	0
2079735772	0	🤷🏻‍♀️🤷🏻‍♀️	0	1	0	0	0	0	\N	0
1625829706	0	IG @moy._amoy	0	0	0	0	0	6	\N	0
6073549788	0	.ennië #너 같이	0	1	0	0	0	1	\N	0
5569828938	0	Melodie	0	1	0	0	0	12	\N	0
5994531626	0	man.	0	72	0	0	85.38999999999999	34	\N	0
6076093481	0	cesa	0	4	1	0	0	0	\N	0
1421786218	0	Jeorge Bazerathan.	0	2	0	0	0	0	\N	0
1710952227	0	𝐂𝐀𝐋𝐌𝐈𝐍⋆𝐌𝐑𝐕 Ken mrv²'sadulan'zicar	0	23	0	0	0	101	\N	0
6325455897	0	aveyy:(	0	10	0	0	0	2	\N	0
6812216004	0	Ranggaa	0	4	0	0	0	0	\N	0
7103385114	0	miguel	0	3	0	0	0	1	\N	0
5983049955	0	sesya	0	90	0	0	0.9699999999999989	153	\N	0
5062438555	0	Chen	0	3	0	0	0	1	\N	0
6407284552	0	Shenina Gwen E. ꜱᴇɢᴀꜰ #CALMINWDS	0	82	0	0	472	317	\N	0
5862320178	0	bi	0	102	0	0	190	0	\N	0
6410108091	0	off. bimuw אָ	0	1	0	0	0	2	\N	0
6303151872	0	d	0	1	0	0	0	0	\N	0
6258685413	0	t	0	18	0	0	13.18	149	\N	0
6171984382	0	nay	0	136	1	0	990.6300000000001	244	\N	1
6139247180	0	eby	0	3	0	0	0	0	\N	0
5622292314	0	I LOVE YOU MORE MORE MORE MADA	0	3	0	0	1611.8500000000001	30	\N	0
6221501666	0	albert	0	1	0	0	0	0	\N	0
6409797606	0	⤫ Cherylie Jeannette	0	2	0	0	0	0	\N	0
1953198938	0	JADE.	0	263	0	0	3224.8800000000006	2762	\N	0
5330176501	0	Suci Dwi	0	42	0	0	0	0	\N	0
1831139901	0	v	0	1	0	0	0	0	\N	0
6188380887	0	akurasi peka 0%	0	1	0	0	0	2	\N	0
1808752592	0	Kasyi	0	2	0	0	0	0	\N	0
6516002227	0	this	0	10	0	0	3.91	19	\N	0
1355097115	0	Vinny.	0	8	0	0	4.82	11	\N	0
5955075405	0	dapsssssss	0	71	0	0	0	30	\N	0
5764504065	0	Desni	0	2	0	0	0	17	\N	0
6011660414	0	k	0	10	0	0	0	2	\N	0
5997373163	0	tir	0	2	0	0	0	2	\N	0
6243800681	0	theresa ' aogry	0	50	0	0	0	16	\N	0
6005358528	0	Meiiii	0	4	0	0	0	9	\N	0
1195951147	0	ola katanya	0	2	0	0	0	0	\N	0
1768074989	0	😷😷	0	2	0	0	0	0	\N	0
5841760775	0	quill	0	4	0	0	0	1	\N	0
6071024552	0	k.	0	1	0	0	0	0	\N	0
5360051447	0	ta	8	589	0	0	999.8999999999608	4141	\N	1
1722609564	0	XsecretX	0	4	0	0	0	16	\N	0
6874525087	0	upi bakwan	0	14	0	0	0	5	\N	0
5154146514	0	binta	0	1	0	0	0	11	\N	0
1904301452	0	Leu.	0	53	0	0	4.219999999999999	110	\N	0
5168391737	0	Sháyla ovk	0	53	0	0	0	34	\N	0
5885795072	0	bagas	0	2	0	0	0	0	\N	0
5108324209	0	Aruuul	0	23	0	0	0	25	\N	0
2015648353	0	ceii	0	768	0	0	447.625	1085	\N	0
6835000041	0	her	0	8	0	0	0	0	\N	0
2049938689	0	Rowen.	0	1	0	0	0	0	\N	0
1787795402	0	aqil	0	0	0	0	0	0	\N	0
1765763016	0	Aèris L.	0	0	0	0	0	0	\N	0
1855207890	0	j	0	1	0	0	0	0	\N	0
837878927	0	Lukman	0	3	0	0	0	0	\N	0
1537155636	0	Anselma	0	61	0	0	0	23	\N	0
1284875033	0	reree🧿	0	5	0	0	0	8	\N	0
6096044126	0	K	0	1	0	0	0	0	\N	0
5687262512	0	p	0	9	0	0	20.119999999999997	107	\N	0
6113598992	0	Anuuuu	0	4	1	0	0	4	\N	0
1333588147	0	Ji1	0	1	0	0	0	4	\N	0
6280391008	0	clone odenn	0	13	0	0	0	9	\N	0
2124752763	0	Nozelie.	0	1	0	0	14.56	1	\N	0
5154699333	0	coz	0	188	2	0	1.5	211	\N	0
2040611388	0	zoe	0	2	0	0	0	1	\N	0
2098495031	0	teresa	0	22	0	0	0	298	\N	0
1423962210	0	Nakhara.	0	3	0	0	0	0	\N	0
1602176693	0	kabin	0	21	0	0	0	0	\N	0
1710595838	0	bryan watanabe	0	3	1	0	0	10	\N	0
1551194557	0	.	0	4	0	0	0	0	\N	0
1633078881	0	cira	0	165	0	0	2.3	36	\N	0
6902866312	0	Ian hopes to die	0	0	0	0	0	0	\N	0
5587127479	0	not found	0	6	0	0	0	1	\N	0
2002596434	0	biwa	0	7	0	0	0	21	\N	0
5449744705	0	zaa	0	18	0	0	0	132	\N	0
5839348855	0	Annétte	0	5	0	0	0	3	\N	0
5827145681	0	Astrid Rhiannon.	14	3	0	0	26.06	56	\N	0
1963330096	0	adyaksa	0	1	0	0	0	0	\N	0
6187452099	0	jenni	0	2	0	0	0	0	\N	0
6177393071	0	childe	0	3	0	0	0	0	\N	0
1827030129	0	saa	0	8	0	0	0	3	\N	0
6202339027	0	Kilaaa	1	71	1	0	51.08999999999979	15	\N	0
5445510267	0	akuuu sasaa	0	0	0	0	500	1	\N	0
5249341327	0	vioo	0	15	0	0	0	10	\N	0
5354734810	0	Naldy.	9	50	0	0	13.640000000000418	322	\N	0
1863861466	0	184 Bria Uchiha	0	88	0	0	44	535	\N	0
1433863506	0	Jo	0	39	0	0	401.9599999999996	90	\N	0
5940441465	0	lol	0	8	0	0	0	17	\N	0
1745355042	0	nazwa r	0	114	0	0	0	0	\N	0
6238678517	0	Beby	0	11	0	0	41	25	\N	0
6218160127	0	isha	0	2	0	0	0	3	\N	0
1656319938	0	aleA., lea nya udah aku usir	0	1	0	0	0	0	\N	0
6260902994	0	Isabelle	0	6	0	0	0	0	\N	0
5688204826	0	O1	0	1	0	0	0	0	\N	0
1828937071	0	biyell.	0	2	0	0	0	29	\N	0
5185236576	0	shaabiinn	0	1	0	0	0	0	\N	0
1623570956	0	aarav.	0	121	0	0	0	117	\N	0
6746870182	0	— bybel	0	5	0	0	0	3	\N	0
1639788036	0	adisyaaa	0	1	0	0	0	0	\N	0
5163739261	0	Empty Name	0	1	0	0	0	1	\N	0
5464806480	0	Rhey Alvred	0	4	0	0	0	11	\N	0
1909728008	0	krisan	0	168	0	0	4.300000000000011	1407	\N	0
5252247102	0	bibielump!	0	11	0	0	0	0	\N	0
5054291810	0	b	0	11	0	0	0	1	\N	0
6006427454	0	sigit sfs	0	2	0	0	8.48	0	\N	0
1850270751	0	Maryjane	0	5	0	0	0	13	\N	0
5064777076	0	cview, gRrR	0	43	0	0	689.66	96	\N	0
6276080410	0	rinchan ✨	0	15	0	0	0	5	\N	0
7031534879	0	arl	0	5	0	0	0	16	\N	0
6309767651	0	szen	0	4	0	0	0	1	\N	0
1886218816	0	Zainrald	0	2	0	0	0	2	\N	0
6889926478	0	c 🌊	0	2	0	0	729.51	9	\N	0
6491077941	0	who?	0	5	0	0	500	4	\N	0
6627692120	0	ㅤㅤㅤ 🝳. 𝐆estara, rbio.	0	4	0	0	0	0	\N	0
1728486598	0	pp	0	3	0	0	0	0	\N	0
5019510523	0	gheaa	0	11	0	0	0	0	\N	0
6164798901	0	el	0	2	0	0	0	2	\N	0
5755391356	0	Jena	0	1	0	0	0	0	\N	0
6398990584	0	Savanna	7	100	0	0	2916.120000000001	2811	\N	0
1285294248	0	⚡	0	0	0	0	0	0	\N	0
5936727003	0	hanaaa🌊	0	3	0	0	0	1	\N	0
6283095302	0	Gahar	0	4	0	0	0	79	\N	0
2002405038	0	debii	0	68	0	0	0	6	\N	0
5870244977	0	bunny	0	5	0	0	0	9	\N	0
2077896101	0	sya	0	8	0	0	0	1	\N	0
6247313025	0	agtha	0	7	0	0	0	13	\N	0
7163729710	0	Joki	0	1	0	0	0	0	\N	0
6911994550	0	Gurl	0	1	0	0	0	0	\N	0
1788534217	0	enzey	0	159	0	0	728.32	91	\N	0
1622983544	0	Shaeryn Hiraeth.	0	88	0	0	4	52	\N	0
6333318151	0	ㅤㅤㅤ ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ ㅤㅤㅤㅤ	0	11	0	0	68	0	\N	0
6368213208	0	mihya	0	0	0	0	0	0	\N	0
1341386534	0	.	0	27	0	0	0	19	\N	0
6892701392	0	joel has dedee	0	14	0	0	0	0	\N	0
1452302633	0	k	0	3	0	0	0	0	\N	0
2084194833	0	Marcella ꒰⁠⑅⁠ᵕ⁠༚⁠ᵕ⁠꒱⁠˖⁠♡ @iFlutershy	0	19	0	0	1480	0	\N	0
6418817642	0	lele darat	0	82	0	0	42.84	353	\N	0
5075038518	0	.	0	49	0	0	0	0	\N	0
6386665216	0	Ne	0	3	0	0	4956	0	\N	0
5351593384	0	Davina	0	39	0	0	0	34	\N	0
6070385481	0	eze	0	2	0	0	65.03999999998209	45	\N	0
5462254563	0	jef	0	48	0	0	0	24	\N	0
5346934706	0	Difranca ōtsuki	12	2379	0	0	4057.9900000000007	1143	\N	0
1258485681	0	kasa	10	94	1	0	2364.37	933	\N	0
1879503429	0	bryna.	0	22	0	0	0	10	\N	0
5644612229	0	𝙉𝙄𝘾𝙊 𝘼𝙍𝙎𝙀𝙉𝙄𝙊	0	1	0	0	0	0	\N	0
5991381088	0	Apip	0	48	0	0	669.54	3161	\N	0
1648357553	0	l𝗎𝗇𝖺𝗋 . s/ia	0	1	0	0	0	0	\N	0
6581738594	0	revasha, s.	0	3	0	0	0	0	\N	0
1606232981	0	Another side	0	14	0	0	0	3	\N	0
6268314493	0	laras	12	3	0	0	3129.5699999999997	8	\N	1
1772581209	0	ꕀ ꕀ 𖠳 ᐝ	0	36	0	0	0	7	\N	0
5813949113	0	naneun	0	10	0	0	0	1	\N	0
6955568813	0	sa	0	1	0	0	0	0	\N	0
5204691474	0	Sen	0	2	0	0	0	1	\N	0
5251300276	0	Rakatama	0	1	0	0	0	10	\N	0
5099248078	0	pacar quanxi ril	0	1	0	0	0	2	\N	0
5409055919	0	💙💙💙	0	1	0	0	0	0	\N	0
1844539273	0	C.	0	1	0	0	0	0	\N	0
1682303018	0	Claudya	0	39	0	0	5.870000000000001	0	\N	0
6334242912	0	.	0	22	0	0	16.97	612	\N	0
1711456024	0	rael oma omaga	0	30	0	0	1745	66	\N	0
6665652686	0	دانيال 🇱🇨 pahay	0	7	0	0	0	0	\N	0
5465450670	0	D	0	20	0	0	0	6	\N	0
5462381900	0	𝐒amudra انسان	0	2	0	0	0	1	\N	0
6024330946	0	Janiwa	0	4	0	0	0	6	\N	0
5137245436	0	a	0	3	0	0	0	0	\N	0
1438309439	0	pinong	0	892	0	0	0	1	\N	0
5862450547	0	jvke	0	7	0	0	548.8199999999999	12	\N	0
5091647426	0	adam	0	13	0	0	0	8	\N	0
6420170255	0	⁺˳ . kinaLa ! 🎀๑	0	1	0	0	0	1	\N	0
5982694532	0	hika	0	1	0	0	0	0	\N	0
6884874461	0	victor	0	3	0	0	0	3	\N	0
6333400844	0	rachel	0	4	0	0	0	0	\N	0
5336519189	0	n	0	24	0	0	0	11	\N	0
1655972606	0	Ꞌꞌ ✧̸ 𓂃 ℬ𝐞𝐚𝐮𝐭𝐲 𓍼 𝐸𝑛𝑜𝑙𝑎 ⊹ ꒰ఎ ♡ ໒꒱ ⊹	0	35	0	0	0	576	\N	0
1778860231	0	𝟖𝟐. Ichié Masamune Ꮺ	0	1	0	0	0	0	\N	0
5757051750	0	americano lovers	0	20	0	0	0	31	\N	0
1399913361	0	𝙱𝚒𝚋𝚋𝚕𝚎	0	12	0	0	0	34	\N	0
5900864023	0	ABETH.	0	30	1	0	0	16	\N	0
5545290646	0	Khai G.	0	3	0	0	0	3	\N	0
5659381598	0	lunnna	0	2	0	0	0	1	\N	0
6089686355	0	Miyo taher	0	4	0	0	0	35	\N	0
6129561870	0	peyoo secc	0	1	0	0	0	0	\N	0
1333778470	0	jii🐄	0	1	0	0	0	0	\N	0
6964627322	0	ruka.	0	3	0	0	0	6	\N	0
1192933352	0	vian	0	24	0	0	0	64	\N	0
5492755530	0	K	0	9	0	0	0	2	\N	0
6005319830	0	maudi	0	5	1	0	0	5	\N	0
1231717712	0	Nao	0	2	0	0	0	23	\N	0
1994668737	0	bara	0	76	0	0	0	0	\N	0
7136159941	0	i.	14	80	0	0	3.1299999999999955	297	\N	0
1359772508	0	pipi	0	28	0	0	0	4	\N	0
5436222834	0	jesha	0	0	0	0	0	0	\N	0
1256093823	0	kenzo	0	4	0	0	0	0	\N	0
1961036056	0	Grazella	0	1	0	0	0	5	\N	0
1881010669	0	Michael Owwy.	0	14	0	0	875.9100000000001	33	\N	0
5308115894	0	Dexterian	0	1	0	0	18.7	4	\N	0
6962261693	0	l4aala	0	1	0	0	0	0	\N	0
5285937344	0	inibiyel	0	7	0	0	0	0	\N	0
2138542516	0	Ar	0	2	0	0	0	1	\N	0
1765600213	0	titid	12	64	1	0	256.1399999999999	11	\N	0
1730908506	0	yunav	5	325	1	0	3013.0200000000004	429	\N	0
1325993561	0	Chika.	0	1	0	0	0	1	\N	0
5468352241	0	𝒕𝒂𝒓𝒊𝒊	0	9	0	0	0	178	\N	0
5489347884	0	skyloo	0	8	0	0	0	2	\N	0
5090160624	0	raaAa	0	25	0	0	0	7	\N	0
1331718854	0	saa.	0	1	0	0	0	11	\N	0
6707146431	0	aleyya	0	4	0	0	0	0	\N	0
5874330214	0	Caramel.	0	9	0	0	0	18	\N	0
5455175090	0	Rakesh	0	0	0	0	0	0	\N	0
1896596138	0	Milly	0	1	0	0	0	1	\N	0
5350689687	0	lili	0	7	0	0	0	19	\N	0
1157199697	0	F3	0	8	0	0	0	16	\N	0
5964862437	0	teenyyy ♡	0	1	0	0	0	0	\N	0
1824042849	0	k/ia aily ovk	0	45	0	0	278.51000000000005	356	\N	0
5266830357	0	.	0	0	0	0	0	2	\N	0
5301158924	0	sofia	0	26	0	0	0	3	\N	0
5253229714	0	yyy	0	2	0	0	0	0	\N	0
6752470655	0	sss	0	9	0	0	0	9	\N	0
6079315958	0	ken	0	4	0	0	0	4	\N	0
1302925489	0	ㅤㅤ	0	0	0	0	0	0	\N	0
5187095718	0	rbio papar	0	655	1	0	5.699999999999818	75	\N	0
7194729906	0	𝐬𝐦𝐚𝐭𝐡𝐚 `	0	3	0	0	0	4	\N	0
5725146126	0	Emily	0	1	0	0	0	0	\N	0
6523651724	0	araya	0	5	0	0	53	26	\N	0
6483847262	0	mayi	0	30	0	0	0	11	\N	0
1721561030	0	Van	0	77	0	0	8.910000000000082	213	\N	0
1843991165	0	Becca	0	3	0	0	0	0	\N	0
6309266178	0	janice	0	1	0	0	0	1	\N	0
5448421780	0	mursid	0	68	0	0	834	108	\N	0
6641883965	0	.	0	10	0	0	0	0	\N	0
6173812814	0	rest.son	0	1	0	0	0	0	\N	0
1876994871	0	Bingung niknem	0	2	0	0	0	1	\N	0
5450429370	0	Duta	0	224	1	0	490.38	795	\N	0
6565658370	0	tepiw	0	7	0	0	0	0	\N	0
818458796	0	al	0	3	0	0	0	0	\N	0
5149015977	0	Dave	0	10	0	0	0	32	\N	0
1448843428	0	Ya	0	1	0	0	0	0	\N	0
6111348049	0	𐙚 Lou—Chie <3	0	134	0	0	3.5600000000000023	626	\N	0
1918672645	0	zi. ghostel¹	0	0	0	0	0	0	\N	0
1193842803	0	paansi	0	50	0	0	245	4	\N	0
5414320670	0	Riris closed, penipu dni	0	2	0	0	0	3	\N	0
6281336606	0	🐈‍⬛. ぬ˖ ࣪🦁 Rosyheart‘𝒮𝒽𝒶	0	7	0	0	0	0	\N	0
6559416770	0	Clemira cizarine	0	3	0	0	378	0	\N	0
6916139662	0	naur	8	16	0	0	1339.91	1545	\N	0
1875199095	0	Vi	6	131	0	0	1506.5300000000002	1833	\N	0
1827828346	0	Ishaa. cape begete.	0	81	0	0	4.12	30	\N	0
5780903763	0	d	0	16	0	0	0	25	\N	0
5137856625	0	gaby 4twenty	0	28	0	0	16.790000000000006	12	\N	0
1877148787	0	amara	0	1	0	0	0	1	\N	0
1800894419	0	zedax	0	23	0	0	0	440	\N	0
1930329823	0	lg cosplay anime	0	6	0	0	0	0	\N	0
1747034975	0	Vella capek jadi rumah singgah	0	1	0	0	0	0	\N	0
6012096332	0	Cassper. @CAPIITOL’s	0	8	0	0	0	2	\N	0
2113726989	0	Joel	0	1	0	0	0	5	\N	0
6497525436	0	xav kanashī	0	0	0	0	0	1	\N	0
5650817319	0	𝐍allen.	0	35	0	0	0	98	\N	0
6970301266	0	rest	0	2	0	0	0	0	\N	0
1849325537	0	Milleserna	0	14	0	0	5.09	43	\N	0
5154463954	0	cylo	0	2	0	0	0	0	\N	0
1987989730	0	ra	0	1	0	0	0	0	\N	0
5450462166	0	Nes	0	7	0	0	0	1	\N	0
1423350333	0	Die	4	358	0	0	5135.389999999999	124	\N	0
6153882653	0	räeysil, a.	8	25	0	0	6660.35	196	\N	0
6840832022	0	.	0	15	0	0	0	75	\N	0
1821612462	0	cabiL 🕸	0	22	0	0	0	1	\N	0
1946668122	0	seesile	0	3	0	0	0	6	\N	0
1472576176	0	Abayy	0	3	0	0	0	1	\N	0
1744394190	0	𝒂𝒍𝒖𝒏𝒂	0	8	0	0	0	18	\N	0
6505482662	0	reyra	0	1	0	0	0	0	\N	0
1436427082	0	Wira	0	22	0	0	0	9	\N	0
5230918144	0	d	0	571	0	0	1.8150000000001	706	\N	0
7089816273	0	abas	0	3	0	0	0	4	\N	0
6738888391	0	bigel	0	0	0	0	0	0	\N	0
6320108242	0	zergaz	0	2	0	0	0	0	\N	0
1357766646	0	alex	0	1	0	0	0	0	\N	0
1601028030	0	Marivi	0	2	0	0	0	6	\N	0
5289971653	0	scx.ガ	0	151	0	0	0	128	\N	0
5097402577	0	Awan	0	104	0	0	0	679	\N	0
5336714220	0	lic	0	10	0	0	128	4	\N	0
2045152515	0	𖤝. Belova. Ali caretaker’s ♡	0	1	0	0	0	2	\N	0
6394489909	0	Kai	0	2	0	0	0	10	\N	0
5301304348	0	vivindadaaa >__<	0	5	0	0	0	14	\N	0
6636950146	0	࿋⃟ᴘ͜͡ᴍ ˹ᴍɪᴀᴀ🍒 ᴴᴸ	0	0	0	0	0	0	\N	0
1792821443	0	SAKAMOTO	0	22	1	0	4706	7	\N	0
5299503656	0	irvyne.	0	2	0	0	0	7	\N	0
5181154757	0	niel	0	15	0	0	0	0	\N	0
5118029186	0	༺Ƭßα༻𝞋 -𝐀​	0	3	0	0	0	5	\N	0
2136631947	0	gv	0	1	0	0	0	0	\N	0
1789155866	0	darwin	0	1	0	0	0	3	\N	0
6770379589	0	ca	0	6	0	0	12.99	44	\N	0
1789610509	0	ustad sadam	0	8	0	0	0	26	\N	0
1719420518	0	🕸️	0	20	0	0	0	4	\N	0
1683136334	0	may	0	4	0	0	0	17	\N	0
5181773264	0	<3	0	7	0	0	0	10	\N	0
1892603936	0	c l a	0	244	0	0	0	540	\N	0
5321248305	0	adys	0	43	0	0	265.91	798	\N	0
5782356201	0	beyza	0	1	0	0	0	3	\N	0
1855777556	0	Rumm rummm dikala	0	5	0	0	0	17	\N	0
928701612	0	Indra	0	5	0	0	0	2	\N	0
5918500865	0	aile	0	6	0	0	0	3	\N	0
7187028648	0	nzo	0	5	0	0	0	1	\N	0
1945337088	0	Ojann	0	153	2	0	252.8800000000001	201	\N	0
5204652392	0	pretty bear, yolecaa!	0	1	0	0	0	1	\N	0
5854120034	0	Roland🕷	0	120	0	0	110	8	\N	0
1230274323	0	lamaokuning	0	71	0	0	0	0	\N	0
1739321834	0	justin	0	2	0	0	0	1	\N	0
6954088652	0	ic	0	2	0	0	0	26	\N	0
1099013212	0	A	0	42	0	0	0	113	\N	0
1786296438	0	ㅤㅤㅤ	0	88	0	0	1633.67	29	\N	0
5549075949	0	sherénn.	0	16	0	0	0	0	\N	0
5694400760	0	cc	0	0	0	0	0	1	\N	0
6884130058	0	ini YORA	0	50	0	0	17.33000000000004	176	\N	0
5074541851	0	Nessa,	0	11	0	0	0	43	\N	0
5301695292	1	FAST, Low	0	10	0	1	11.299999999999997	4	\N	0
2118918911	0	💟	0	623	0	0	3123.2	2546	\N	0
1700756091	0	Alren	0	1	0	0	0	0	\N	0
1319036235	0	san	0	22	0	0	0	31	\N	0
5569425162	0	ncaa.	0	1	0	0	0	0	\N	0
1712269203	0	Hyuka.	0	81	0	0	0.38999999999987267	2079	\N	0
5000588052	0	Melanie.	0	0	0	0	0	1	\N	0
6124011221	0	zoraa suka mengaji	0	39	0	0	73.1400000000001	166	\N	0
5287925613	0	al. berth	0	1	0	0	0	1	\N	0
6497107238	0	nana	0	0	0	0	0	2	\N	0
7052346787	0	évelly	0	1	0	0	0	0	\N	0
1676718645	0	harumi	0	26	0	0	30	18	\N	0
1867023319	0	Cibi 🐇 *off lg galau	0	7	0	0	0	2	\N	0
1691989522	0	⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣Tommy	0	0	0	0	0	0	\N	0
5758577859	0	Nyuak	0	1	0	0	3.25	54	\N	0
1853788279	0	lana	0	1	0	0	0	83	\N	0
2026875761	0	Theory.	0	158	0	0	0	112	\N	0
5996621485	0	Naya	0	1	0	0	0	0	\N	0
5285056861	0	໑ /ᐠ - ˕ -マ	0	8	0	0	0	0	\N	0
6142998917	0	442. A—yara	0	1	0	0	0	1	\N	0
6499020138	0	affey	0	8	0	0	0	85	\N	0
6218200120	0	bile.	0	2	0	0	0	0	\N	0
5593329732	0	yae	0	6	0	0	0	3	\N	0
5660955507	0	aikana	0	29	0	0	1461.97	104	\N	0
5838766109	0	pia🅰️	0	1	0	0	0	0	\N	0
6956455798	0	HAFIZ	0	0	0	0	0	0	\N	0
1713517428	0	ayya	0	2	0	0	0	1	\N	0
6076499695	0	.	0	1	0	0	0	0	\N	0
1994668957	0	jeje	0	1	0	0	0	0	\N	0
5757232410	0	giva	0	161	1	0	1563.35	139	\N	0
5481971079	0	zuzuumor	0	1	0	0	0	0	\N	0
6956871264	0	r	0	41	0	0	86.9	70	\N	0
1038732292	0	Pan	0	2	0	0	0	1	\N	0
5221325429	0	Sica #sica.	0	4	0	0	0	0	\N	0
6274299438	0	Shoko	0	4	0	0	0	1	\N	0
1908217576	0	Matley.	0	3	0	0	0	115	\N	0
6229629270	0	isabel	0	3	0	0	0	4	\N	0
6001451467	0	caleesy 🇨🇼	0	12	0	0	103.47	59	\N	0
1186223782	0	R	0	21	0	0	36.38	0	\N	0
1523958590	0	Jolicya - rest	0	69	0	0	50.08	20	\N	0
1758691546	0	Marvellio.	0	2	0	0	0	68	\N	0
6075859186	0	buyy-bbw	0	6	0	0	0	5	\N	0
5440501226	0	Crong	0	126	0	0	1046.6	1023	\N	0
5419086087	0	pn syndromè?	0	9	0	0	0	51	\N	0
5754924511	0	Fikri love 🇵🇸,	0	93	0	0	16.959999999999894	1770	\N	0
6247919181	0	j azurà ٭	0	26	0	0	0	18	\N	0
5258683635	0	amek cuwak #DRPWOPLINK	0	5	0	0	0	0	\N	0
5183502104	0	Ian	0	169	0	0	0	702	\N	0
1317426383	0	𝕚.𝕧	0	1	0	0	0	1	\N	0
6031265877	0	Mdni, Gracia.	0	7	0	0	111.31	32	\N	0
1929276848	0	Juan.	0	302	0	0	0	0	\N	0
6128440211	0	liam pacar muel	0	2	0	0	0	0	\N	0
6776907899	0	ㅤㅤㅤㅤ	0	8	0	0	0	1	\N	0
1263946051	0	meeko	0	2	0	0	0	0	\N	0
5104837751	0	ᴇᴢʀᴀ	0	149	0	0	171.24	68	\N	0
5391109776	0	Jeffry no spam	0	1	0	0	0	8	\N	0
1788384587	0	345.flo	13	206	0	0	764.9300000000001	207	\N	0
5403875825	0	𝐄i.	0	218	0	0	665.1899999999999	1266	\N	0
6115196736	0	mahesa	0	4	0	0	0	0	\N	0
2104590661	0	giss	0	22	0	0	0	183	\N	0
5238672242	0	jovi	0	1	0	0	0	0	\N	0
5653236982	0	ank baik	0	4	0	0	0	0	\N	0
6522524744	0	Kyntara	0	6	0	0	0	7	\N	0
1950642481	0	Fei alz	0	6	0	0	12.629999999999995	4	\N	0
1903191245	0	n	0	9	0	0	0	7	\N	0
1807655351	0	r	0	66	0	0	972.74	264	\N	0
1884819349	0	Lanchiaow	0	0	0	0	0	2	\N	0
1841632504	0	Chuuya	0	3	0	0	0	2	\N	0
6160827403	0	Vlet	0	3	0	0	0	3	\N	0
6452501322	0	ashey	0	45	0	0	1612.12	158	\N	0
1659470483	0	jopapapa	10	34	0	0	2726.9700000000003	199	\N	0
5677927024	0	Elsa miaw	0	3	0	0	0	4	\N	0
6366688738	0	eyca	0	2	0	0	0	51	\N	0
5202249646	0	Jovan	0	12	0	0	0	2	\N	0
5407279934	0	p	0	9	0	0	0	3	\N	0
1822800919	0	asa	0	565	0	0	214.5	1	\N	0
6262879591	0	jane ୫²	0	73	0	0	276.69000000000005	767	\N	0
5039456600	0	odēn	0	0	0	0	0	51	\N	0
5107500413	0	°24	0	24	0	0	0	25	\N	0
2043629339	0	Dita	0	1	0	0	0	5	\N	0
5360326130	0	Allanz	0	32	0	0	0	306	\N	0
5507363326	0	Ashliey	0	17	0	0	0	16	\N	0
1708558516	0	himaa	0	7	0	0	0	26	\N	0
1201072479	0	nabill	0	1	0	0	0	1	\N	0
1363664639	0	Ayya.	0	0	0	0	0	0	\N	0
6204444966	0	mir	0	24	0	0	0	66	\N	0
1895560005	0	sh	0	163	0	0	625	6	\N	0
1970724367	0	.	0	1	0	0	0	1	\N	0
1302505671	0	Nabel	0	18	0	0	0	21	\N	0
5132288028	0	Hanung.	0	1	0	0	0	0	\N	0
5285397238	0	𖢖 awa	0	26	0	0	12	31	\N	0
1135699558	0	boyyy	0	1	0	0	0	0	\N	0
1884690631	0	Clèment	0	11	0	0	0	34	\N	0
6732831125	0	shy³¹⁰	0	60	0	0	13.109999999999559	333	\N	0
1588894360	0	azka	0	13	0	0	0	29	\N	0
1325715126	0	Ashley emerson.	0	18	0	0	100	72	\N	0
5364350359	0	Aleid	0	19	0	0	0	39	\N	0
6411288666	0	Bianca	0	4	0	0	445.81	0	\N	0
5370406642	0	aecha	11	134	1	0	1012.2599999999986	1224	\N	0
1927400967	0	gaska	0	24	0	0	5280.400000000001	567	\N	0
1544253020	0	shey	0	344	0	0	2.009999999999991	1132	\N	0
1218169236	0	ji	0	1	0	0	0	0	\N	0
5699978455	0	shuyyaa	0	61	0	0	12.62	27	\N	0
1440726392	0	y	0	12	0	0	0	1	\N	0
1986569341	0	Caramel F.	0	0	0	0	0	0	\N	0
6208751758	0	ezapejux	2	385	0	0	9.109999999999786	776	\N	0
6093406708	0	Nazuraaa.	0	3	0	0	0	1	\N	0
6002578450	0	Vi	0	2	0	0	0	0	\N	0
1949068574	0	jeanne	0	7	0	0	0	144	\N	0
6349898128	0	blue	0	8	0	0	0	0	\N	0
6165037198	0	.	0	110	0	0	14.79	0	\N	0
5258584340	0	ayina	0	4	0	0	0	0	\N	0
1057007475	0	Jépp	0	40	0	0	2.3000000000000007	348	\N	0
5137310424	0	Rigel	0	26	0	0	0	5	\N	0
5741331878	0	ar loving ryujin	0	10	0	0	0	4	\N	0
5490572966	0	nayashaaaa :]	0	2	0	0	563.36	355	\N	0
1996442052	0	.ajenn	0	1	0	0	0	0	\N	0
6409510625	0	kay	0	40	0	0	0	15	\N	0
1865192824	0	nara	0	464	0	0	0	236	\N	0
2109242232	0	Faleysha C.	0	3	0	0	0	0	\N	0
1894490651	0	reiCi	0	158	0	0	42.525	21	\N	0
5404304659	0	ばス曖ᵣₑₙ	0	4	0	0	0	4	\N	0
1713765483	0	.	0	20	0	0	0	19	\N	0
5137391543	0	Zynlyn 𖢷 ۫ 𓈒	0	1	0	0	0	1	\N	0
1437682075	0	ㅤㅤㅤㅤㅤㅤㅤ	1	496	0	0	14.54	490	\N	0
1523850798	0	ar	0	3	0	0	0	2	\N	0
6234617931	0	caca	0	12	0	0	0	26	\N	0
1304105634	0	syaa	0	2	0	0	0	0	\N	0
6259183152	0	when ia	0	6	0	0	0	33	\N	0
1920210761	0	hana	0	20	0	0	0	1	\N	0
6136651968	0	zafi’s gf <3.	0	3	0	0	21.08	13	\N	0
1950206097	0	aleya	0	1	0	0	0	0	\N	0
5155761769	0	gekk	0	1	0	0	0	0	\N	0
2146081956	0	rengga	0	11	0	0	0	0	\N	0
5860317092	0	Chika	0	5	0	0	0	0	\N	0
6946134718	0	BOY	0	2	0	0	0	115	\N	0
5629486187	0	reyaa	0	43	0	0	0	0	\N	0
5648112113	0	syahiraa	6	632	0	0	16.7199999999998	693	\N	1
5294606287	0	?	0	106	0	0	11.19	3	\N	0
1806150997	0	who	12	151	0	0	694.29	149	\N	0
6371709207	0	icutt	0	57	0	0	0	25	\N	0
1713252496	0	Rey	0	4	1	0	39.75	2	\N	0
5175073346	0	ABE	0	1	0	0	0	1	\N	0
5069570756	0	Cweivsdollyn.	0	0	0	0	0	7	\N	0
5258149723	0	bar	0	2	0	0	0	0	\N	0
5829727925	0	Ghesya	0	2	0	0	0	0	\N	0
5660797643	0	dean	0	24	0	0	807.2800000000002	51	\N	0
1726488105	0	oci, 👻ing DNI.	0	5	0	0	0	20	\N	0
7004826651	0	ayaaa	0	15	0	0	0	4	\N	0
5630222909	0	rayna blm di bck? tlg rechat lagi	0	4	0	0	0	0	\N	0
703023500	0	NgakaK	0	1	0	0	0	0	\N	0
5987414675	0	🦋🦋🦋	0	8	0	0	0	0	\N	0
6040667711	0	eira ange	1	14	0	0	0	8	\N	0
6641412050	0	cca	0	0	0	0	0	36	\N	0
5902776138	0	vie	0	3	0	0	0	0	\N	0
6042656266	0	Kajesha	0	2	0	0	0	2	\N	0
5440950936	0	Xyzn "Calon ustadz"	0	22	0	0	0	340	\N	0
5189560935	0	akaa's.	0	2	0	0	0	0	\N	0
5539363075	0	Kamelia	0	341	0	0	135.9499999999996	59	\N	0
5718292368	0	sea	0	2	0	0	278	5	\N	0
1996413050	0	Nakata	5	208	0	0	216.3200000000003	0	\N	0
2012665252	0	le	0	0	0	0	0	4	\N	0
6950966600	0	みdanu.	0	7	1	0	85	15	\N	0
6254904958	0	Runabul.	0	1	0	0	0	5	\N	0
1042969563	0	Jeje	0	8	0	0	0	5	\N	0
1693719066	0	ailsie	0	266	0	0	1337.6100000000004	331	\N	0
5073352378	0	syila	0	3	0	0	0	20	\N	0
5696313625	0	,	0	94	0	0	95.5	86	\N	0
6598481569	0	Katharina	0	1	0	0	0	0	\N	0
5095170489	0	a	0	1	0	0	0	0	\N	0
5037125367	0	abc	0	1	0	0	0	0	\N	0
5694863202	0	ari	0	1	0	0	0	0	\N	0
5255170591	0	Nadia	0	33	1	0	2823.83	27	\N	0
6471888664	0	💀	0	1	0	0	0	0	\N	0
5484127116	0	sasa the kid	0	1	0	0	202.67999999999975	113	\N	0
5897646987	0	Cella	0	2	0	0	0	0	\N	0
6648028283	0	.	0	1	0	0	0	0	\N	0
6242841053	0	jay	0	1	0	0	0	1	\N	0
1186414215	0	reiv	0	1	0	0	0	1	\N	0
6904769434	0	ley	0	4	0	0	0	3	\N	0
7140277412	0	? she’s piká..	0	13	0	0	0	7	\N	0
5926413107	0	ibam	0	2	0	0	0	0	\N	0
1818658463	0	matchaicy	0	70	0	0	0	39	\N	0
2097961984	0	Bennet Hudson.	0	19	0	0	0	0	\N	0
2094015900	0	nadhira	0	7	0	0	0	3	\N	0
1791625357	0	riwww	0	2	0	0	0	0	\N	0
1274856266	0	belvina	0	41	1	0	363.82	1262	\N	0
1737012462	0	Nisaa	0	19	0	0	0	2	\N	0
6059628615	0	Muhammad	0	2	0	0	0	2	\N	0
5259879515	0	Nico Elynn.	0	183	0	0	0	57	\N	0
5194342603	0	kafka	0	14	0	0	0	13	\N	0
6343745317	0	nf ᴴᴸ	0	9	0	0	0	11	\N	0
6752869258	0	Faa.	0	1	0	0	0	0	\N	0
5430791252	0	A	0	17	0	0	1023.38	29	\N	0
5819338932	0	Esther	0	37	0	0	11.23	74	\N	0
1318424544	0	ayya	0	0	0	0	0	1	\N	0
1031367885	0	tamaaaaaaaa	0	4	0	0	0	4	\N	0
5878221510	0	Big Nice D	0	2	0	0	0	0	\N	0
1872342127	0	rbio. isa	14	196	0	0	1332.5600000000004	531	\N	0
6720722232	0	Ichigo M.	0	7	0	0	0	226	\N	0
5728882797	0	Th’Astronout, Livy	0	1	0	0	0	0	\N	0
1825745567	0	a	0	16	0	0	0	0	\N	0
5012280708	0	name. DNI	0	143	0	0	0	13	\N	0
6234355147	0	Luna	0	26	0	0	0	72	\N	0
2114215993	0	yaya 🎧	0	75	0	0	0	108	\N	0
2049661727	0	wendy	0	0	0	0	0	0	\N	0
5765073258	0	binnie	0	7	0	0	0	341	\N	0
5497023976	0	keyren gi betmut	0	1	0	0	0	0	\N	0
1429580188	0	𝐑ere.	0	22	0	0	0	36	\N	0
6112094177	0	Dekaa	0	2	0	0	0	0	\N	0
2070613722	0	moruu ?!	0	178	0	0	39.4099999999998	35	\N	0
6330920699	0	[🌊]	0	142	0	0	5721	177	\N	0
5669037884	0	Mine.ᴅᴄ²⁷²	0	72	0	0	0	7	\N	0
5800546212	0	katherine	0	2	0	0	0	0	\N	0
1719214913	0	Carraty	0	5	0	0	113.55	1	\N	0
5936856421	0	je	0	1	0	0	0	1	\N	0
5129137871	0	Abigail	0	6	0	0	0	1	\N	0
6271683459	0	kireii🪅	0	4	0	0	0	0	\N	0
5507803125	0	a	0	0	0	0	0	0	\N	0
7062509798	0	Forlantio	0	0	0	0	0	0	\N	0
1322710050	0	adi	0	23	2	0	0	2	\N	0
6468207127	0	caa	0	0	0	0	0	0	\N	0
6082085958	0	ell	0	2	0	0	0	53	\N	0
5879622191	0	Jerden	0	2	0	0	0	5	\N	0
5039434794	0	Yiruka, C. Lumey	0	12	0	0	0	7	\N	0
6138293734	0	n~ata	0	2	0	0	0	2	\N	0
5065540491	0	langit	0	0	0	0	0	3308	\N	0
1840527383	0	Jarrel Carter	0	99	0	0	23	55	\N	0
6265983725	0	bb ౨ৎ	0	3	0	0	0	1	\N	0
2037256795	0	Ryan.	0	1	0	0	0	0	\N	0
5442575116	0	Elayne	0	1	0	0	0	1	\N	0
1797691833	0	linlin	0	4	0	0	0	7	\N	0
1892390631	0	bukan riki	0	0	0	0	0	0	\N	0
5792332247	0	nitaaaa	0	68	0	0	0	21	\N	0
6782768900	0	Marlo.	0	0	0	0	0	11	\N	0
1228906183	0	Moon	0	1	0	0	11.65	4	\N	0
2117309018	0	ara	0	1399	0	0	2.4499999999989086	3937	\N	0
6970186141	0	Hugo D'rune	0	6	0	0	0	0	\N	0
2126850076	0	Van Ragas G.	0	12	0	0	0	148	\N	0
5464701085	0	kayis	0	9	0	0	0	0	\N	0
1692160052	0	.	0	1	0	0	0	0	\N	0
6940361401	0	aysel	0	2	0	0	100	0	\N	0
5464745274	0	echαα. drg¹	0	12	0	0	0	1	\N	0
6428571671	0	Chris	0	3	0	0	0	0	\N	0
2127994207	0	tereskhova	0	93	0	0	0	17	\N	0
1851032988	0	dijual	0	6	0	0	0	1	\N	0
1241499795	0	Nas.	0	17	0	0	0	12	\N	0
5058669089	0	aleale	0	80	0	0	1.7199999999999989	3	\N	0
5206567901	0	aldira	0	1	0	0	0	0	\N	0
5158764556	0	A	0	15	0	0	500	6	\N	0
5282715055	0	sienna . @ePetty	0	6	0	0	0	5	\N	0
5296601901	0	`abas d ҡɪɴꜰᴏʟᴋ	0	1	0	0	12.66	5	\N	0
5541238945	0	moyii	0	11	0	0	0	0	\N	0
1411562321	0	Asep	0	0	0	0	0	0	\N	0
6122491864	0	sta	0	3	0	0	0	12	\N	0
6808063401	0	kamas(kania gemas)	0	4	0	0	0	0	\N	0
5935479227	0	intan	0	9	0	0	0	34	\N	0
1655032027	0	Jeha	0	2	0	0	0	12	\N	0
1804450484	0	Jasmine the kid >__<	0	28	0	0	0	165	\N	0
5996603591	0	..	6	54	0	0	48.91	47	\N	0
1309388028	0	cals	0	1	0	0	0	0	\N	0
5364370929	0	Kembang	0	97	0	0	15	58	\N	0
6666695415	0	c'lil	0	1	0	0	0	0	\N	0
6904915083	0	aya	0	4	0	0	0	6	\N	0
1936122541	0	Radellana.	0	1	0	0	0	0	\N	0
1457960478	0	୨୧	0	33	0	0	0	19	\N	0
1621276642	0	zizze	0	6	0	0	0	0	\N	0
6432850247	0	ʬʬ. cy	0	1	0	0	0	0	\N	0
1219900040	0	b	0	0	0	0	0	1	\N	0
1015725281	0	ayaya	0	0	0	0	0	0	\N	0
6409875554	0	ya	0	3	0	0	0	11	\N	0
5813273971	0	yosh	2	57	0	0	740.7800000000005	1380	\N	0
5440143701	0	audrey.	0	1	0	0	0	0	\N	0
6430367633	0	NamiWP	0	2	1	0	0	0	\N	0
5820960716	0	ay	0	2	0	0	0	0	\N	0
5854298122	0	user	0	16	0	0	1164	3	\N	0
6707120415	0	puyo wikky	0	0	0	0	0	14	\N	0
5684130163	0	レイン	12	57	1	0	730.3799999999993	12041	\N	1
1401893888	0	Saga Boernan.	0	52	0	0	92.34	944	\N	0
6683693708	0	Dara	0	2	0	0	0	2	\N	0
6263627403	0	-	0	141	0	0	50.6400000000001	10	\N	0
1942817321	0	neil.	0	1	0	0	0	82	\N	0
5618054425	0	roel val.	0	1	0	0	0	0	\N	0
2029975726	0	idk	0	42	0	0	313.93	7	\N	0
1825886047	0	evelyn	0	49	0	0	14	10	\N	0
6205279630	0	lieaa	0	31	0	0	899.4	418	\N	0
5394540953	0	Shaka	0	3	0	0	0	3	\N	0
1931833670	0	Jose	0	14	0	0	0	6	\N	0
6265984985	0	rojee on duty!	0	5	0	0	0	0	\N	0
5674813323	0	K.	0	5	0	0	0	55	\N	0
5891632256	0	kanai	0	7	0	0	0	1	\N	0
5203857526	0	haelyn	0	0	0	0	0	0	\N	0
6057338708	0	kajedday yunasa m.	0	21	0	0	0	1	\N	0
1423847225	0	atiya	0	5	0	0	75.92	34	\N	0
1366235677	0	Nana nangisin kairi	0	32	0	0	625	19	\N	0
6612724769	0	z	0	2	0	0	0	0	\N	0
6394918110	0	Labeilla.	0	1	0	0	0	0	\N	0
5578774285	0	asa﹒⪩⪨﹒	0	28	0	0	456	1	\N	0
5190228994	0	Jendra	0	1	0	0	0	0	\N	0
1316776836	0	Magira	0	5	0	0	0	0	\N	0
5949463822	0	meccà	0	7	0	0	0	0	\N	0
6629272289	0	Josya	0	1	0	0	0	0	\N	0
1932668998	0	sabe	0	17	0	0	0	28	\N	0
6098091601	0	vio bukan viu	0	24	0	0	0	4	\N	0
1262808046	0	-	0	3	0	0	0	0	\N	0
6453320604	0	Jaegar	0	1	0	0	0	0	\N	0
5909854316	0	Qyizara Estrella A.	0	57	0	0	8.029999999999973	403	\N	0
5966957482	0	):)	0	1	0	0	0	0	\N	0
5220196601	0	beruk	0	16	0	0	30	43	\N	0
6653110266	0	lauyie.	0	6	0	0	0	0	\N	0
7106607865	0	puyo	0	1	0	0	0	0	\N	0
5296743113	0	yazua#fansprancis	0	7	0	0	0	0	\N	0
1928090789	0	arz.arasya	0	17	0	0	0	53	\N	0
1804371736	0	syashaa	0	7	0	0	0	13	\N	0
5319646368	0	princess	0	1	0	0	0	57	\N	0
1700327726	0	ray	0	3	0	0	0	5	\N	0
5770983895	0	129. nébulaa	0	14	0	0	0	8	\N	0
5267670397	0	BW | INNER+	0	11	1	0	0	25	\N	0
1548548520	0	rest) reyhan	0	2	0	0	0	0	\N	0
5676298565	0	avalyn lgi cape	0	3	0	0	83.01	39	\N	0
2013770647	0	Akmal	0	38	0	0	561.72	189	\N	0
6794674558	0	ni	0	2	0	0	0	4	\N	0
1902113685	0	Dean	0	10	0	0	3478	44	\N	0
2025621851	0	≛⃝𝕜𝕙⁶⁹Smuk Oʀʀᴇᴛᴏ	0	4	0	0	0	4	\N	0
5130354959	0	Rizky	0	2	0	0	0	3	\N	0
1739347807	0	J. Traiserd	0	3	0	0	2000	3	\N	0
1387741821	0	hi	0	0	0	0	0	0	\N	0
1659775697	0	Alseno.	0	188	0	0	2018.8000000000004	723	\N	0
5948883829	0	🥷	14	82	0	0	8.020000000000003	201	\N	0
1819247802	0	.	0	28	0	0	0	0	\N	0
6249124470	0	Kala, " Estoy ocupado amándote "	0	3	0	0	0	0	\N	0
5521946682	0	Rahmatt	0	159	1	0	51.110000000000014	60	\N	0
1937388285	0	rakasta, DNI.	0	34	0	0	0	1	\N	0
5322803499	0	🎀	0	8	0	0	0	0	\N	0
6236198179	0	andra	0	0	0	0	0	0	\N	0
5851229422	0	dini	0	16	0	0	0	1	\N	0
1821395557	0	arya not found	0	11	0	0	0	278	\N	0
1655679211	0	rayyaa	0	33	0	0	0	0	\N	0
6435126691	0	Medicca	0	4	0	0	0	3	\N	0
6259480868	0	𖧷🤍..> ℒa beauté kirana ◌ ִ ׄ ദ	0	11	0	0	0	4	\N	0
1076685923	0	Sabila.	0	1	0	0	0	0	\N	0
5161616539	0	ayin	0	3	0	0	0	5	\N	0
6059598265	0	piel	0	1	0	0	0	4	\N	0
5815399209	0	Hayes bgz¹ 3	0	3	0	0	0	18	\N	0
1739931978	0	biuw	0	466	0	0	116.03999999999999	1499	\N	0
5408567086	0	binaa	0	2	0	0	0	0	\N	0
1154977246	0	g	0	55	0	0	7.5	99	\N	0
6106569350	0	M	0	7	0	0	0	0	\N	0
6802491977	0	low	0	3	0	0	0	0	\N	0
6001963053	0	🦋𝓚𝓮𝓲𝓼𝔂𝓪𝓪🦋	2	682	0	0	2326.3199999999997	2273	\N	0
1769674404	0	ᝯ jevrine	0	6	0	0	0	15	\N	0
5234024525	0	Adél! Lg Cape Mksh	0	1	0	0	0	0	\N	0
6183164667	0	Araa	0	3	0	0	0	1	\N	0
1964141461	0	jjeaa	0	54	0	0	0	56	\N	0
5250374953	0	LILY | #CALMINPS	0	3	0	0	0	0	\N	0
1780270844	0	achi	0	2	0	0	0	7	\N	0
5390673610	0	penot	0	4	0	0	0	2	\N	0
5240903243	0	ningaong	0	133	0	0	6.740000000000009	844	\N	0
1224671187	0	͜͡𝑪𝑩 caroline	0	2	0	0	0	2	\N	0
5312932654	0	Mata(hari)	0	1	0	0	0	0	\N	0
1802172129	0	David W.	0	4	0	0	0	1	\N	0
6870032474	0	jee	0	2	0	0	0	0	\N	0
1961526493	0	z	0	3	0	0	0	0	\N	0
6630262485	0	Jaya	0	3	0	0	0	0	\N	0
5095446847	0	rayn, zicar	0	6	0	0	0	364	\N	0
2068737624	0	Julian	0	7	0	0	0	2	\N	0
1955177850	0	zhafa	0	146	0	0	0	2	\N	0
2121648525	0	jaseb by @testinygrey	0	2	0	0	0	0	\N	0
1663433055	0	F	0	6	0	0	0	2	\N	0
6835808555	0	na	0	1	0	0	0	0	\N	0
1992430707	0	kisaya	0	2	0	0	0	0	\N	0
1709379266	0	b	0	239	0	0	1972.31	53	\N	0
6870587237	0	kei	0	0	0	0	0	0	\N	0
1229956684	0	Nugi Saputra	0	1	1	0	0	18	\N	0
1522351691	0	k	0	6	0	0	0	22	\N	0
6820861992	0	kontol lu	0	2	0	0	190	0	\N	0
1211047427	0	ᴛ𝚁𝚎𝚎𝚔𝚣	0	3	0	0	0	6	\N	0
1843766026	0	liaa ⸆⸉	0	151	0	0	2171.79	177	\N	0
5808899199	0	er	0	3	0	0	956	6	\N	0
1378341450	0	sha	0	1	0	0	0	0	\N	0
6059533597	0	chérie – ʀʀᴡ.𝖇𝖑𝖆𝖈𝖐𝖉.ålgr¹.ਏਓ.ᯂᯮ	0	5	0	0	0	0	\N	0
5535062152	0	stardust	0	104	0	0	15	286	\N	0
6374292620	0	Nanay Masone.	0	1	0	0	0	0	\N	0
1431274309	0	jaa	0	348	0	0	392.5	88	\N	0
6710368043	0	ca	0	2	0	0	0	0	\N	0
5156031375	0	biey	0	1	0	0	0	0	\N	0
6832001178	0	k	0	5	0	0	0	5	\N	0
1603221086	0	just M	0	206	0	0	4158.379999999998	568	\N	0
1744726289	0	veros	0	6	0	0	0	0	\N	0
5399291303	0	?	0	15	0	0	0	1	\N	0
5885111492	0	rest	0	12	0	0	128.08000000000007	1	\N	0
5486431852	0	Nier.	0	349	0	0	9.55999999999949	123	\N	0
1918912562	0	Sakil	0	1	0	0	0	0	\N	0
2018119600	0	Ezar	0	3	0	0	0	0	\N	0
6597283241	0	Pradipta	0	18	0	0	0	2	\N	0
5137106381	0	𝐒𝑱epian	9	17	0	0	1169.7899999999947	60	\N	0
5622292109	0	< ❈ .. Winatara — G V.	0	2	0	0	0	0	\N	0
6290135617	0	zur fsr buangsat	0	1	0	0	22.35	8	\N	0
6980157302	0	L	0	3	0	0	0	1	\N	0
1812981345	0	ayen	0	1	0	0	0	0	\N	0
5059465855	0	𝐌ei¡	0	18	0	0	0	5	\N	0
6495178446	0	Joccyln	0	3	0	0	0	3	\N	0
1784524838	0	fiayeya	0	23	0	0	0	16	\N	0
6785218995	0	-	0	1	0	0	0	0	\N	0
5099672793	0	ly	7	71	0	0	4340.379999999997	740	\N	0
6211165921	0	419 Aca	0	57	0	0	52.879999999999995	111	\N	0
1624374358	0	alex	0	2	0	0	118.69	0	\N	0
5748301133	0	J @jayanaja	0	0	0	0	0	0	\N	0
5430376510	0	— Raefell Argantara Saputra	0	1	0	0	0	0	\N	0
1839323878	0	jabb	0	2	0	0	0	8	\N	0
5303502841	0	Noe.	0	5	0	0	0	1	\N	0
1625196343	0	Sharaèn Brigitte.	0	14	0	0	0	4	\N	0
1788322826	0	—	0	2	0	0	0	13	\N	0
1923823538	0	sä	0	36	0	0	101	82	\N	0
1916456278	0	miwa, ia	0	2	0	0	0	6	\N	0
6900422477	0	961 Elyn	0	4	0	0	0	2	\N	0
5567647772	0	𝕽ʳ Claire Althea H͜͡S	0	8	0	0	240.5	10	\N	0
6219456079	0	c/ba mei rNk isi	0	0	0	0	0	0	\N	0
6816988905	0	naom	0	2	0	0	28	39	\N	0
5118948139	0	nasel	0	27	0	0	0	9	\N	0
2031261737	0	ocee	0	11	0	0	0	36	\N	0
6786696454	0	Latheen.	0	0	0	0	0	53	\N	0
6173012036	0	stfu lol	0	5	0	0	0	0	\N	0
1877599423	0	mahen	0	2	0	0	0	0	\N	0
6081659161	0	𝗻𝗼𝗸𝗼𝘀	0	11	0	0	55	0	\N	0
1581209755	0	Zaki	0	60	0	0	0	174	\N	0
1861179962	0	Ardian	0	313	0	0	7.82999999999987	564	\N	0
1772815550	0	jenna l♡ving jaehyun	0	4	0	0	0	4	\N	0
1740930843	0	!	0	1	0	0	0	0	\N	0
5914686925	0	jena	0	19	0	0	0	0	\N	0
6071338471	0	Dominic	8	15	0	0	534.3000000000001	51	\N	0
1373569525	0	⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣gebek	0	32	0	0	0	313	\N	0
1915836502	0	rest	0	3	0	0	0	0	\N	0
6078475559	0	⌘` Aksagara	0	1	0	0	0	6	\N	0
7002926036	0	ai	0	2	0	0	0	0	\N	0
1906956857	0	a	0	9	0	0	0	0	\N	0
6255538599	0	s	0	5	0	0	0	25	\N	0
1468057474	0	aciw the explorer	0	13	0	0	0	17	\N	0
1858156647	0	Hazelna	0	3	0	0	0	4	\N	0
6553152193	0	Hi	0	2	0	0	0	0	\N	0
1837583482	0	💎Vy	0	18	0	0	0	1	\N	0
7160805861	0	Richie	0	1	0	0	0	0	\N	0
5130105874	0	ravel	0	10	0	0	0	2	\N	0
7136503203	0	Talola E. mls diving dni	0	2	0	0	0	1	\N	0
5852410004	0	α	0	6	0	0	0	0	\N	0
1836681323	0	๑ piyaaa	0	37	1	0	5	4	\N	0
6062446842	0	araa	7	15	1	0	2.67	104	\N	0
5084528985	0	ᴇʟ	0	1	0	0	0	2	\N	0
6951952279	0	razelya. @sser4phic	0	1	0	0	0	0	\N	0
1880576342	0	el	0	2	0	0	0	9	\N	0
6801537725	0	NK.	0	4	0	0	0	0	\N	0
5961043149	0	ibell	0	3	0	0	0	2	\N	0
1000764367	0	m	0	0	0	0	0	0	\N	0
1879978791	0	Seyra🐬🐬 ƬJƧ KAK CHAT AKU DONG	0	112	0	0	915	155	\N	0
6024266981	0	beautifulnight	0	0	0	0	0	0	\N	0
1768281918	0	tamara	0	35	0	0	0	33	\N	0
5397976266	0	el	0	4	0	0	0	0	\N	0
5089455812	0	karin	13	163	0	0	407.75	606	\N	0
5797021017	0	James Santiago.	0	6	0	0	0	27	\N	0
2026730956	0	avrenzy	13	165	0	0	0	190	\N	0
1376003819	0	zaza	0	1	0	0	0	0	\N	0
6120608706	0	karel1st	0	1	0	0	0	0	\N	0
5142722629	0	ira	0	13	0	0	894.1	287	\N	0
5463473618	0	bita	0	0	0	0	561.6800000000002	75	\N	0
5454737743	0	meining	0	4	0	0	0	7	\N	0
5675114254	0	killaa ʚϊɞ	0	0	0	0	0	0	\N	0
6414716498	0	awikawok	0	2	1	0	0	0	\N	0
1993204337	0	zira	0	31	0	0	0	14	\N	0
6055139633	0	azrael	0	1	0	0	0	0	\N	0
5587544687	0	Harry slr	0	10	0	0	0	30	\N	0
1351811754	0	Kanaè	0	1	0	0	0	0	\N	0
6403222625	0	Dex, fsr @Pradipfta	0	2	0	0	0	0	\N	0
6396270934	0	lan	8	2	0	0	1153.6599999999999	184	\N	0
1947209058	0	ꗃ 🦖 ˓ jᎥⱺⱺ arlⱺv ⋆	0	10	0	0	0	40	\N	0
1784634156	0	cc	0	1	0	0	0	0	\N	0
5315284152	0	j	0	578	0	0	2415.5600000000013	6156	\N	0
5405912502	0	lessugar	0	1	0	0	0	0	\N	0
1342504698	0	adara	0	0	0	0	0	0	\N	0
1321821087	0	cia	0	10	0	0	0	264	\N	0
6194752597	0	K.	0	1	0	0	0	0	\N	0
1865606833	0	spidertmk Blaxton G.	0	13	0	0	0	15	\N	0
5301013908	0	andrea	0	1	0	0	0	53	\N	0
1653005616	0	arci	0	87	0	0	0	1263	\N	0
6212516955	0	Sawi	0	226	0	0	463.47000000000037	347	\N	0
2097707437	0	🆙	0	294	0	0	1095.95	10	\N	0
5880668480	0	zenyo. Proses	0	1	0	0	0	0	\N	0
6165902095	0	bil	0	68	0	0	651.820000000001	36	\N	0
6984099690	0	aaa	0	2	0	0	0	0	\N	0
1200202200	0	sava amabel	0	16	0	0	505	56	\N	0
2132696309	0	Bumi	0	4	0	0	0	19	\N	0
6136347717	0	𝐀𝐥𝐨𝐞𝐯𝐞𝐫𝐚 Viu 7m 5k on duty.	0	1	0	0	0	2	\N	0
1902352305	0	revaline	2	9	0	0	2452.4	88	\N	0
5780718477	0	kava @kava1st	0	2	0	0	0	1	\N	0
6329197382	0	hades calon dpr	0	38	0	0	0	2	\N	0
1678746369	0	TETAP GWENCHANAAA	0	31	0	0	0	377	\N	0
6580984927	0	rob	0	4	0	0	0	7	\N	0
6191147125	0	ilham	0	0	0	0	0	54	\N	0
5377088866	0	=)	0	25	0	0	0	112	\N	0
5986593247	0	Cowonya Jennie	0	1	0	0	0	0	\N	0
1859082225	0	ra	0	117	0	0	0	322	\N	0
1873793359	0	Ukiyo	0	0	0	0	0	2	\N	0
1847682322	0	alsha	0	1	0	0	0	0	\N	0
6316239398	0	Nich	0	5	0	0	0	0	\N	0
1985373202	0	Zizi	0	1	0	0	0	4	\N	0
5424513942	0	receh🎈	0	34	0	0	0	14	\N	0
7107977842	0	anyyy	0	8	0	0	0	0	\N	0
5302493621	0	ils	0	1	0	0	0	0	\N	0
1469800038	0	mira	0	1	0	0	0	0	\N	0
6851947924	0	̶̲ ִֶָnacaa	0	5	0	0	0	0	\N	0
1680491423	0	glace	0	7	0	0	0	55	\N	0
6668319884	0	Azura N.	0	2	0	0	0	4	\N	0
1909256243	0	lele	0	25	0	0	0	7	\N	0
6961041573	0	Angga	0	1	0	0	0	3	\N	0
1747456918	0	yayaa	0	10	0	0	0	6	\N	0
1004156247	0	Lulu Diah	0	3	0	0	0	0	\N	0
5129835784	0	ucii	0	1	0	0	0	7	\N	0
6159478222	0	helga chuaksz	0	1	0	0	0	3	\N	0
6046522187	0	chachaaa	0	2	0	0	0	0	\N	0
5712253318	0	lucy	0	6	0	0	0	8	\N	0
6219457324	0	kayeye	9	38	0	0	684.62	369	\N	0
1752735314	0	Sélene Evanè. slowresp	0	3	0	0	0	1	\N	0
5571208512	0	Jeanna.	0	18	0	0	0	18	\N	0
5072361067	0	Yui Mizuno	0	15	0	0	0	117	\N	0
5012590519	0	cespar | open	0	1	0	0	0	3	\N	0
2109383029	0	𝒃𝒊𝒎𝒃𝒊	0	1	0	0	0	1	\N	0
1802580528	0	opal awe	0	31	0	0	500	0	\N	0
6607692270	0	zippa	0	7	0	0	0	1	\N	0
5227870824	0	maverick	0	73	0	0	13371.78999999999	1951	\N	1
5550743506	0	jovanes	0	0	0	0	0	0	\N	0
6133442406	0	Aeryn K.	0	3	0	0	0	4	\N	0
5057481794	0	nop	0	14	0	0	0	171	\N	0
6436021204	0	Celilave	0	2	0	0	0	2	\N	0
5490485977	0	tyty	0	4	1	0	0	2	\N	0
6779038909	0	Tyas.	0	1	0	0	0	5	\N	0
1323157276	0	b	0	127	0	0	560.65	735	\N	0
1741128121	0	sabil	0	19	0	0	0	175	\N	0
1986364946	0	⊹ Katerine E	0	46	0	0	145.23	126	\N	0
5054980182	0	ash	0	5	0	0	0	4	\N	0
6158115480	0	@	0	3	0	0	0	0	\N	0
6563797232	0	mika	0	15	0	0	0	2	\N	0
5368841505	0	Gaby	0	66	0	0	16.620000000000005	1970	\N	0
1301897568	0	zara	0	17	0	0	15.24	529	\N	0
5166871265	0	Yoana E, @iYounjungzz	0	0	0	0	0	0	\N	0
5918774476	0	Hahaha	0	3	0	0	0	0	\N	0
6648736229	0	x	0	125	0	0	0	127	\N	0
5144296796	0	alea.	0	11	0	0	0	13	\N	0
1747293638	0	jae	0	353	0	0	0	0	\N	0
5304913355	0	White	0	7	0	0	0	410	\N	0
5578133161	0	nanaaa	0	14	0	0	0	38	\N	0
6035297738	0	zoumaa	0	1	0	0	0	2	\N	0
6232680268	0	ndi.	0	29	0	0	3.99	93	\N	0
999913843	0	𖹭	0	1	0	0	0	0	\N	0
1619741529	0	sadie	0	6	0	0	0	1	\N	0
6040391596	0	uuu	0	1	0	0	0	0	\N	0
1944020514	0	tirtha	10	245	0	0	87.28999999999998	932	\N	0
5349256537	0	fayè	0	2	0	0	0	0	\N	0
6509831262	0	dyaaa	0	2	0	0	0	0	\N	0
5323342221	0	𝗔𝗡𝗡𝗔, penipu dni	0	2	0	0	0	0	\N	0
2022646014	0	bunny	0	71	0	0	235	104	\N	0
1788447534	0	x	0	11	0	0	0	1	\N	0
5149725558	0	𝐂ᥣαꭉα	0	7	0	0	0	11	\N	0
5134197295	0	han?	0	3	0	0	0	0	\N	0
1676117243	0	시아네타 ꒰Xianetta꒱	1	35	0	0	687.8199999999999	193	\N	0
6136681713	0	ibra	0	1	0	0	0	1	\N	0
6112210937	0	k	0	1	0	0	0	7	\N	0
1475610154	0	.	0	250	0	0	0	63	\N	0
5532667797	0	Ragi!♥️	0	1	0	0	0	0	\N	0
5315806202	0	Narl laquella zh	0	3	0	0	0	1	\N	0
1735247651	0	moci jadi mixue	0	2	0	0	51.71	0	\N	0
6413828390	0	J	0	85	0	0	0	150	\N	0
1763365203	0	shra	0	4	0	0	0	13	\N	0
5951031693	0	Jordan A.	0	1	0	0	0	0	\N	0
6823374212	0	zan	0	11	0	0	0	11	\N	0
1865212998	0	𝓡​arā	0	0	0	0	0	1	\N	0
5519395528	0	arches kena limit	0	9	0	0	0	7	\N	0
1676757479	0	thania salima	0	3	0	0	46.89	50	\N	0
6418966300	0	Reii	0	2	0	0	0	1	\N	0
1967652907	0	g mud	0	3	0	0	0	5	\N	0
6283101229	0	Calief #𝐍𝐄𝐗𝐓𝐆𝐇𝐎𝐒𝐓	0	5	0	0	0	0	\N	0
5153951981	0	Orelnii	0	8	0	0	0	21	\N	0
1422371230	0	nonin	0	2	0	0	0	1	\N	0
7071598914	0	Kim Woo-Bin	0	1	0	0	0	0	\N	0
6731936762	0	Az zeam	0	61	0	0	0	98	\N	0
6956269762	0	kle..	0	3	0	0	0	14	\N	0
1705519710	0	li	0	2	0	0	0	0	\N	0
5049040651	0	karina	0	2	0	0	0	0	\N	0
5430818828	0	Shafaa	0	128	0	0	1601.4899999999998	1136	\N	0
6793536210	0	ge	0	83	0	0	111.74000000000001	308	\N	0
2048878644	0	Marv.	0	1	0	0	0	0	\N	0
6550808375	0	erpan	0	1	0	0	0	0	\N	0
6976776619	0	Zii	0	1	0	0	0	0	\N	0
5015254028	0	arbel	0	2	0	0	0	0	\N	0
1657179626	0	devii	0	47	0	0	1852	9	\N	0
6975580574	0	Dimmm	0	8	0	0	0	1	\N	0
1301849006	0	calyn	0	3	0	0	0	0	\N	0
2078909504	0	Agapē	0	2	0	0	0	0	\N	0
5957333998	0	pijaja	0	131	0	0	2460.770000000001	5220	\N	0
2018341372	0	??	0	1	0	0	0	0	\N	0
6021088113	0	Wiloona	0	125	0	0	345	65	\N	0
5663242832	0	Moeëyra #loveedadaf	0	1	0	0	0	0	\N	0
6109924571	0	Kéysha @iOrdinaryy	0	1	0	0	0	4	\N	0
5421756467	0	fia.	0	1	0	0	0	2	\N	0
5448728033	0	A	0	51	0	0	323.92999999999995	149	\N	0
5267445092	0	Prince Ge	7	5	0	0	75.43	263	\N	0
6774177906	0	arshey	0	5	0	0	0	0	\N	0
1463694035	0	Raydan	0	9	0	0	0	1	\N	0
2065132097	0	Jiji suda lelah dgn khidupn	0	2	0	0	0	1	\N	0
6809872999	0	adel	0	4	0	0	0	10	\N	0
6617633035	0	77	0	2	0	0	0	0	\N	0
5068630591	0	raskal	0	247	0	0	575	4151	\N	0
1906099495	0	Keyla.	0	3	0	0	0	0	\N	0
5398988679	0	ryhn galau AURELL	0	27	0	0	306.7	6	\N	0
1702545205	0	.	0	18	0	0	0	2	\N	0
750562653	0	,	0	23	0	0	276.90000000000003	58	\N	0
6508965344	0	d	0	12	0	0	0	28	\N	0
6937148355	0	jayya	0	0	0	0	0	0	\N	0
5074096585	0	Mayleen	0	8	0	0	0	1	\N	0
5990118587	0	Ikay pengen ke hutan	9	107	0	0	90.81000000000131	103	\N	1
6289981922	0	kay	0	6	0	0	0	0	\N	0
6049470130	0	kaii	0	4	0	0	0	16	\N	0
5030620908	0	Alex	0	1	0	0	0	0	\N	0
1659307533	0	camel ego	0	1	0	0	0	13	\N	0
6740225097	0	.	0	73	0	0	2.3499999999999943	49	\N	0
1886937160	0	devaa is a turtle 🐢	0	4	0	0	0	0	\N	0
6635085752	0	sassy	0	0	0	0	0	0	\N	0
1167134750	0	kale.	0	62	0	0	65.78	140	\N	0
5806024729	0	off	0	7	0	0	0	0	\N	0
5171388076	0	ʀᴅs.Kalyne.كالين	0	31	0	0	0	67	\N	0
5545392549	0	oryza. @ibslis gc dni.	0	3	0	0	0	1	\N	0
5114924415	0	D	0	1	0	0	0	0	\N	0
5946800574	0	devore lustify	0	113	0	0	9.100000000000001	114	\N	0
1257310798	0	cIpa	0	13	0	0	0	5	\N	0
6284974104	0	jeremy	0	1	0	0	0	0	\N	0
1426781317	0	i nya imengggg.	0	1704	0	0	226.94	16347	\N	0
5056325979	0	maret	0	1	0	0	0	2	\N	0
6459518008	0	jøbra	0	0	0	0	0	0	\N	0
1462558368	0	bold	0	89	0	0	10.91	16	\N	0
2090331131	0	h	0	1	0	0	0	0	\N	0
5761250762	0	vale	0	76	0	0	0	37	\N	0
6444178506	0	Ichann	0	1	0	0	0	1	\N	0
2117619666	0	matcha matwous	0	14	0	0	0	7	\N	0
1859203724	0	RIZKY	0	22	1	0	0	3	\N	0
1919772215	0	Suna.	12	130	0	0	6990.95	636	\N	1
6659753941	0	𝓛	0	1	0	0	0	2	\N	0
1763249156	0	gilsha	0	2	0	0	0	0	\N	0
1696248818	0	Raka	0	1	0	0	0	0	\N	0
5516621094	0	Lily kinda inact	0	7	0	0	0	28	\N	0
6104519446	0	calma	0	8	0	0	0	2	\N	0
1864558371	0	129 Lùby, The Preattiest.	0	2	0	0	200	11	\N	0
5978240694	0	gizell	0	14	0	0	0	0	\N	0
1802126182	0	aka	14	832	0	0	39840.96999999999	328	\N	1
2056337618	0	Hakim	0	2	0	0	0	0	\N	0
6386537922	0	hm	0	3	0	0	0	0	\N	0
1860569223	0	aydëra loanjing	0	3	0	0	0	3	\N	0
6591741126	0	Gaby	0	2	0	0	0	0	\N	0
6522781545	0	Egi	0	2	0	0	0	0	\N	0
5760032850	0	shey mau jadi strawberry	0	1	0	0	0	0	\N	0
6297645078	0	vien	0	53	0	0	0	1	\N	0
5601756076	0	Dalbith.	0	12	0	0	0	48	\N	0
6870018627	0	a	7	13	0	0	0	34	\N	0
6823805670	0	v	0	17	0	0	0	15	\N	0
6989224732	0	a	0	10	0	0	0	0	\N	0
1975689401	0	Esa, Annchi Hiza.	1	220	0	0	1742.4899999999996	452	\N	0
1831562731	0	j	0	365	0	0	0	564	\N	0
5780373346	0	Jergas slwscorf	0	31	0	0	0	7	\N	0
6680191389	0	Boboiboy	0	6	0	0	0	5	\N	0
5911307200	0	Boy	0	3	0	0	0	2	\N	0
6520966256	0	Elena.	0	2	0	0	0	0	\N	0
5873728193	0	kitsune	0	36	0	0	0	28	\N	0
1763891971	0	...	0	3	0	0	0	0	\N	0
6866286909	0	malaa minole.	0	1	0	0	0	1	\N	0
1671943639	0	Princesha	0	0	0	0	0	0	\N	0
6166672111	0	uccy 127	0	0	0	0	0	0	\N	0
5243608012	0	Oliver C.	0	81	0	0	0	43	\N	0
1705255954	0	218	0	44	0	0	45.31	220	\N	0
1839813507	0	nakesyaa	0	1	0	0	0	0	\N	0
5173481489	0	Kala	0	0	0	0	0	11	\N	0
1645095800	0	jela swift 📴	11	2	0	0	3429.4099999999994	411	\N	0
5717879225	0	ajen 11 batu	0	2	0	0	0	0	\N	0
5162053623	0	aii	0	1	0	0	0	3	\N	0
5149379807	0	science site	0	650	0	0	13.800000000000011	1140	\N	0
1889109600	0	Adzky,,ncaaa	3	30	0	0	0	1	\N	0
5637163214	0	.	0	19	0	0	0	6	\N	0
5219982130	0	artha	0	307	0	0	13.71	869	\N	0
5332587968	0	ethan	0	4	0	0	0	2	\N	0
5572318141	0	Digo	0	42	0	0	0	38	\N	0
5533376560	0	chi. cafek ente	0	2	0	0	0	0	\N	0
6484719923	0	naaa galo	0	0	0	0	0	0	\N	0
7025697417	0	dua	0	1	0	0	0	0	\N	0
5164580429	0	urboy	0	2	0	0	0	1	\N	0
5411368654	0	active.	0	15	0	0	0	0	\N	0
5765326844	0	ᝯ Calliope/slr	0	1	0	0	0	0	\N	0
5063468810	0	Ashlane M	0	8	0	0	0	0	\N	0
1711789693	0	i Y i	0	19	0	0	0	31	\N	0
6677426536	0	3	0	1	0	0	0	0	\N	0
5710986742	0	acha	0	0	0	0	0	0	\N	0
1832262882	0	shindi	0	216	0	0	0	867	\N	0
5533776675	0	ri	0	4	0	0	0	4	\N	0
1982929135	0	Abim	0	20	0	0	0	0	\N	0
1580120129	0	io	0	0	0	0	0	1	\N	0
1822334197	0	g	0	16	0	0	0	1	\N	0
5280630054	0	˙ 𖥦 ⪧ ◟R - Shei Shalovea ˒ ˶ 𖠗 🐇 𝗔𝗘ᵗᶦᵒⁿ	0	48	0	0	0	305	\N	0
2076254208	0	yesasa	0	1	0	0	0	0	\N	0
5826810348	0	K.faleesha :D	0	2	0	0	0	0	\N	0
2142440293	0	yorr	0	1	0	0	0	1	\N	0
1328772229	0	navyra	0	16	0	0	0	6	\N	0
1894262400	0	a	0	7	0	0	0	0	\N	0
1754531971	0	k	0	1	0	0	0	0	\N	0
1656448381	0	gina	10	448	0	0	107.54999999999967	4302	\N	1
6488161190	0	mishel	0	3	0	0	0	2	\N	0
1890674729	0	Archava	0	77	0	0	7.18	72	\N	0
6164944958	0	na	0	3	0	0	0	5	\N	0
6010440567	0	ge	0	6	0	0	0	2	\N	0
1825374350	0	andres	0	19	0	0	0	1	\N	0
1713511937	0	caca mari ca hoyhoy	0	1	0	0	0	0	\N	0
2073262472	0	N	0	9	0	0	280	589	\N	0
1227263664	0	kacang	0	1	0	0	0	12	\N	0
6618856722	0	kenneth	0	14	0	0	0	0	\N	0
1598954011	0	raka.	4	5524	0	0	351.74999999999875	4738	\N	0
5950805940	0	Hayes. D	0	3	0	0	0	2	\N	0
5626149968	0	Haven	0	25	0	0	0	20	\N	0
5823404211	0	◐ aureliaa	0	10	0	0	0	53	\N	0
5534525672	0	✙ᵈᵒᶜᵗᵒʳ Emilie, Sp.A ცɱʂʰᵒˢᵖⁱᵗᵃˡˢ	4	265	0	0	634.5	386	\N	0
1933353945	0	b	0	2	0	0	0	0	\N	0
1859601393	0	beeeeee (taylor's version)	0	95	0	0	1199.38	9	\N	0
1891297728	0	Jeremy's lil kitten, Lia.	0	38	0	0	85	29	\N	0
5707013928	0	j	0	8	0	0	0	0	\N	0
1917892982	0	cewwww	0	453	0	0	7.990000000000002	133	\N	0
6020879458	0	Zoel	0	55	0	0	0	0	\N	0
5040114713	0	Arge	0	5	0	0	0	3	\N	0
5370827922	0	anyaa	0	2	0	0	0	2	\N	0
6476216637	0	Caxx	0	1	0	0	0	1	\N	0
1627743196	0	Keinará M.	0	13	0	0	0	70	\N	0
1890395159	0	ghepiaa	0	46	0	0	14.880000000001601	13	\N	0
5804271033	0	Rose	0	1	0	0	0	0	\N	0
5457254337	0	nayaa cape nt	0	0	0	0	0	31	\N	0
1644228877	0	eric aldan sadewa	0	17	0	0	0	13	\N	0
5680410847	0	d	0	1	0	0	0	0	\N	0
1409879684	0	ultra	0	1	0	0	0	0	\N	0
6416343188	0	rauna	0	2	0	0	0	14	\N	0
1858071890	0	cinta (taylor's ver)	0	1	0	0	0	7	\N	0
1876807518	0	k	0	15	0	0	0	0	\N	0
6517124897	0	Jerick	0	6	0	0	0	0	\N	0
6672197922	0	scx. ashA	0	1	0	0	0	0	\N	0
5729889394	0	zenayaa	0	1	0	0	93.35	45	\N	0
5130785358	0	berlin	0	2	0	0	0	133	\N	0
1651592692	0	Abhienanda D 912	0	3	0	0	0	2	\N	0
2028040210	0	🆗🆗	0	9	0	0	0	0	\N	0
6010021475	0	nilooo off	0	3	0	0	0	0	\N	0
1734582971	0	Sophia	0	58	0	0	0	0	\N	0
5569579750	0	Theozra algabara	0	6	0	0	0	3	\N	0
1961797064	0	L	0	1	0	0	0	0	\N	0
1984310510	0	rrr	0	66	0	0	0	97	\N	0
5520977300	0	06	0	3	0	0	0	0	\N	0
6470211524	0	Kuma	0	14	0	0	0	58	\N	0
5032652559	0	rolleya,	0	1	0	0	0	10	\N	0
5394040750	0	AaarR	0	1	0	0	0	0	\N	0
6637178045	0	nNara	0	93	0	0	205.73000000000002	30	\N	0
6803844377	0	Kupu Kupu	0	7	0	0	0	22	\N	0
1872062366	0	Ryan Abrar.	0	1	0	0	0	0	\N	0
1695416104	0	OhJune	0	3	0	0	0	9	\N	0
6095735369	0	cicie ?	0	2	0	0	0	0	\N	0
2098523552	0	lwkt	0	143	0	0	0	0	\N	0
1611502586	0	elisaaa	0	1	0	0	0	0	\N	0
5156941498	0	Abby	0	0	0	0	0	0	\N	0
6004250872	0	ge	0	2	0	0	17.34	0	\N	0
5876993710	0	kameelaa fast respon	0	1	0	0	0	2	\N	0
6324964131	0	liyaaa	0	5	0	0	20.91	8	\N	0
5903008673	0	Zefa	0	247	0	0	1527.4700000000003	26	\N	0
5293395309	0	fahmi	0	2	0	0	0	7	\N	0
6907854744	0	Vielea.	0	8	0	0	0	5	\N	0
1843122985	0	ㅤㅤ	0	1	0	0	0	2	\N	0
1254134510	0	do not interact.	0	11	0	0	0	90	\N	0
5082291421	0	belabell	0	22	0	0	0	8	\N	0
6115061449	0	sean 4twenty	0	3	0	0	0	3	\N	0
6648416358	0	Merleay	0	27	0	0	0	20	\N	0
6931335272	0	nia	0	1	0	0	0	0	\N	0
6531358550	0	?	0	2	0	0	0	2	\N	0
6789584659	0	upiii	0	4	0	0	0	3	\N	0
6123397309	0	vio	0	8	0	0	0	3	\N	0
1766427379	0	rachel	0	39	0	0	519.3700000000002	372	\N	0
1704254456	0	kat's	0	5	0	0	0	3	\N	0
5328561594	0	sac.	0	147	0	0	0	32	\N	0
6156136774	0	michie.	2	36	0	0	1257.36	880	\N	0
1278818155	0	Daph	0	4	0	0	0	0	\N	0
1338487097	0	chivé.	0	0	0	0	0	0	\N	0
6579767522	0	Azuraa	0	1	0	0	0	0	\N	0
6301369452	0	sher	0	4	0	0	0	0	\N	0
5977297007	0	bbe	0	2	0	0	0	0	\N	0
1701646436	0	c	0	183	0	0	2.52999999999993	145	\N	0
6501981598	0	dith	0	102	0	0	0	76	\N	0
5939074947	0	eila	0	1	0	0	0	1	\N	0
5381447766	0	Etheral’s sunshine! Mila.	0	450	0	0	158.7	1000	\N	0
1305358761	0	hellena	0	17	0	0	0	17	\N	0
1234492890	0	Miami heat	0	13	0	0	0	8	\N	0
6305640476	0	Biéllaa.	0	4	0	0	0	0	\N	0
6079231233	0	Riky	0	9	1	0	0	5	\N	0
1835213778	0	miaw.	0	6	0	0	0	7	\N	0
5379828831	0	sa	0	0	0	0	0	0	\N	0
6878297398	0	abrar	0	66	0	0	131	398	\N	0
5960878719	0	0.01	0	7	0	0	0	10	\N	0
6440819179	0	zeer	0	2	0	0	0	0	\N	0
1786445369	0	965. ma'am awabek	0	3	0	0	0	4	\N	0
1750892525	0	Velasya. S	0	65	0	0	0	0	\N	0
5403338060	0	galenn	0	1	0	0	0	0	\N	0
1932556597	0	i	0	25	0	0	500	2	\N	0
5924202306	0	andreee	0	9	1	0	0	6	\N	0
1906479663	0	dey	0	9	0	0	0	2	\N	0
6063242789	0	me	0	12	0	0	0	5	\N	0
1929549902	0	ta	0	109	0	0	0.060000000000002274	141	\N	0
1757352031	0	cyrillo	0	3	0	0	0	43	\N	0
6854720918	0	Madina	0	2	0	0	0	2	\N	0
2068977241	0	Soga	0	1	0	0	0	0	\N	0
1996252776	0	Rexxy	0	1	0	0	0	2	\N	0
5982906054	0	wiloo: ( no Qriss	0	8	0	0	484.57	145	\N	0
1669524333	0	logout	0	1	0	0	0	0	\N	0
5888307311	0	jesayu	0	3	0	0	0	0	\N	0
2005521881	0	kdp	0	3	0	0	0	8	\N	0
6199682684	0	Dandy	0	2	0	0	0	0	\N	0
5303788684	0	vegan	0	1	0	0	0	0	\N	0
1947427735	0	farrma	0	40	0	0	0	16	\N	0
6240048802	0	P	0	1	0	0	0	0	\N	0
1749093438	0	keya	0	2	0	0	0	6	\N	0
6014015598	0	rere	0	1	0	0	0	0	\N	0
1961029803	0	slr	0	2	0	0	0	4	\N	0
5487879647	0	.	0	74	0	0	16.08	21	\N	0
5508048692	0	abbie	0	1	0	0	0	0	\N	0
6876486152	0	lili	0	1	0	0	0	1	\N	0
2023179533	0	jergo	0	4	0	0	0	1	\N	0
6892122266	0	amouraa	0	0	0	0	0	0	\N	0
1406000028	0	Bara	0	1	0	0	0	0	\N	0
2069368404	0	nasya	0	57	0	0	0	0	\N	0
5443386816	0	Jay	0	1	0	0	0	5	\N	0
1832625732	0	Lulu	0	1	0	0	0	0	\N	0
1992490546	0	acaa	0	630	0	0	3.310000000000091	270	\N	0
6942977634	0	Lean ♞	0	2	0	0	0	0	\N	0
1717376924	0	lenee	0	1	0	0	0	0	\N	0
6102108103	0	nas	3	82	0	0	0.3699999999999761	271	\N	0
5748560238	0	haru	0	23	0	0	0	11	\N	0
6052782781	0	hlo	0	28	0	0	0	6	\N	0
1344227489	0	.	0	13	0	0	0	38	\N	0
6476563680	0	manca	0	1	0	0	0	0	\N	0
5419829065	0	secci	0	129	1	0	20.0799999999997	57	\N	0
5277251742	0	a	0	53	0	0	310	48	\N	0
1840486569	0	aliceEe.	0	22	0	0	0	234	\N	0
1777546255	0	jorrie! (CRA)	0	1	0	0	0	0	\N	0
1967965894	0	刀	0	5	0	0	0	21	\N	0
1222572133	0	sammy	0	193	1	0	98.89000000000001	41	\N	0
6681360563	0	Kentut	0	1	0	0	0	0	\N	0
1767912750	0	v	0	7	0	0	0	1	\N	0
2080623057	0	kᧉίkⱺ	0	1	0	0	0	20	\N	0
6295364272	0	ø	0	23	0	0	1683.75	15	\N	0
2131356515	0	jiii	0	19	0	0	7.29	50	\N	0
5224001565	0	rubyjane	0	62	0	0	321.02000000000004	237	\N	0
1190953272	0	miu	0	4	0	0	34	0	\N	0
6884944778	0	kiki	0	1	0	0	0	0	\N	0
1963481138	0	kariel	0	2	0	0	0	0	\N	0
6552923391	0	clau lebah🐝🐝	0	15	0	0	356.32000000000005	134	\N	0
1705398051	0	Ollie :]	0	5	0	0	0	2	\N	0
5303605509	0	mil	0	30	0	0	0	30	\N	0
1369390901	0	Jo	0	0	0	0	0	0	\N	0
1971004676	0	senju	0	1	0	0	0	0	\N	0
5833583946	0	marlo	1	41	0	0	510.3899999999999	201	\N	0
1423016201	0	ss	0	37	0	0	0	0	\N	0
1560666013	0	jepi	0	4	0	0	0	0	\N	0
6107621061	0	vara	0	0	0	0	0	1	\N	0
5769669855	0	fathur	0	10	0	0	0	4	\N	0
6857696552	0	kia ᴹᴸc³⁴¹テ	0	2	0	0	0	0	\N	0
1910870545	0	Matsuri.	0	4	0	0	0	2	\N	0
1357598595	0	Hello	0	9	0	0	0	9	\N	0
1801844346	0	zize	0	4	0	0	0	0	\N	0
5833720547	0	el	0	45	0	0	0	1	\N	0
5946667451	0	G	0	0	0	0	0	0	\N	0
5928447202	0	sea.	0	24	0	0	0	70	\N	0
1775824675	0	kie	0	1	0	0	0	0	\N	0
6396782878	0	jichu lucu	0	18	0	0	0	27	\N	0
2045407143	0	Raga A.	0	42	0	0	0	1474	\N	0
6386029132	0	kitten	0	1	0	0	0	0	\N	0
5149451387	0	rades	0	1	0	0	0	0	\N	0
6709760174	0	彼女 | aura 7	0	0	0	0	0	0	\N	0
5414489924	0	helda kentala	0	13	0	0	0	6	\N	0
5336911839	0	r	0	62	0	0	38.57	302	\N	0
1931070346	0	niva	0	2	0	0	0	12	\N	0
5760737944	0	Yasaka	12	313	2	0	2964.8600000000006	4935	\N	1
5189738483	0	kanay #BARUDAKMANGE	0	50	0	0	2381.2199999999993	207	\N	1
1174462096	0	haikal aja	0	1	0	0	0	0	\N	0
1706418969	0	july, dni	0	10	0	0	897.74	338	\N	0
5490119421	0	Just fely!?	0	4	0	0	0	0	\N	0
5701328874	0	le ʕ•ε•ʔ	0	15	0	0	7.59	87	\N	0
2079748400	0	keiraa	0	94	0	0	1883.2100000000005	22	\N	0
6262924591	0	ㅤ	14	237	0	0	2318.65	235	\N	1
5642877042	0	hafi	0	5	0	0	0	80	\N	0
1882682628	0	Not Available.	0	128	0	0	100	152	\N	0
1682860167	0	Jarrel Da'arast	0	1	0	0	0	0	\N	0
6112726553	0	ciaa	0	59	0	0	12.11	12	\N	0
6832192065	0	kirei	0	2	0	0	0	2	\N	0
1799245140	0	YOHAN.	0	1	0	0	0	0	\N	0
5412330154	0	ZS	0	15	0	0	0	4	\N	0
2074423495	0	.	0	11	0	0	0	1	\N	0
1941227725	0	ada	0	2	0	0	0	3	\N	0
7154622335	0	marjoliē	0	1	0	0	0	0	\N	0
6875034054	0	😍😍😍	0	4	1	0	0	2	\N	0
1140514793	0	rex	0	9	1	0	0	1	\N	0
5608019284	0	bibel	11	19	0	0	3421.02	59	\N	0
1655834970	0	Sky.	0	89	0	0	0	284	\N	0
6066979034	0	Valbeee. (Close joki)	0	100	0	0	14.019999999999982	58	\N	0
1260675981	0	lily	0	2	0	0	0	0	\N	0
1874386154	0	Abernathy Sellica.	12	399	0	0	1694.52	5545	\N	0
6133310207	0	sasa	0	248	0	0	188.86	22	\N	0
1916424968	0	caca	0	466	0	0	5.949999999999999	37	\N	0
6625401996	0	R.	0	0	0	0	0	0	\N	0
1993674222	0	Yvonne	0	2	0	0	0	1	\N	0
5504717394	0	a	0	1	0	0	0	0	\N	0
6298395836	0	aghi	0	17	0	0	0	17	\N	0
5564125260	0	renjana #DEGEMAVGIOS	0	0	0	0	0	0	\N	0
1919475771	0	୭ ֯₊ 🎀🥼“ o: naquenzë ৎ୨𓂂 ๋	0	11	0	0	0	11	\N	0
1150436170	0	— ぎょもりえ	0	1	0	0	0	0	\N	0
1421992256	0	bimsalabim	0	7	0	0	0	11	\N	0
1488624251	0	abelia	0	8	0	0	0	0	\N	0
5170105767	0	Len ( Taylor's Version )	0	18	0	0	112.94	34	\N	0
5436091722	0	calcifer	12	147	0	0	0	278	\N	0
1104365971	0	Megananda	0	6	0	0	0	2	\N	0
5859200489	0	Biyaa	0	0	0	0	0	0	\N	0
6451991069	0	kinan.	0	1	0	0	0	0	\N	0
6968792336	0	mayerr	0	6	0	0	0	4	\N	0
1454084309	0	sky	0	2	0	0	16	0	\N	0
1526392508	0	c	0	17	0	0	0	28	\N	0
6975699589	0	ellaa	0	4	0	0	0	3	\N	0
5073218708	0	evelyn	0	56	0	0	0	42	\N	0
5821101527	0	kay	0	0	0	0	0	0	\N	0
1787678841	0	kaissha	0	189	0	0	0	462	\N	0
5566027385	0	Opall	0	25	0	0	536.9	61	\N	0
6049660127	0	laaaalaaaa	0	9	0	0	78	7	\N	0
5291577009	0	Alen	0	2	0	0	0	0	\N	0
6565635462	0	zen	0	1	0	0	0	0	\N	0
7114128773	0	leo	0	2	0	0	0	0	\N	0
5032067019	0	vegas	6	9	0	0	522.92	112	\N	0
2036665020	0	orang	0	6	0	0	0	1	\N	0
2097158473	0	lnnn	0	0	0	0	0	0	\N	0
5308481781	0	ash	0	1	0	0	0	0	\N	0
2015572030	0	arienn.	0	1	0	0	0	10	\N	0
5685220384	0	adam.	0	8	0	0	0	5	\N	0
1688747652	0	Harlizan A.	0	1	0	0	0	2	\N	0
1462515918	0	beaa	0	3	0	0	0	0	\N	0
6510151604	0	.	0	18	0	0	0	0	\N	0
6130176673	0	nadinè	0	4	0	0	0	0	\N	0
5804743937	0	caca	0	26	0	0	0	624	\N	0
1645378720	0	depa	0	21	0	0	0	0	\N	0
5536822045	0	vaaa	0	4	0	0	0	7	\N	0
1731892342	0	kazeera	0	1	0	0	0	0	\N	0
5097994001	0	ryani ririi(RAGU MU RUGIMU)	0	1	0	0	0	0	\N	0
1839143366	0	iseell	0	19	0	0	0	0	\N	0
6094774927	0	lyoo	0	1	0	0	0	3	\N	0
5852092556	0	Lala	0	1	0	0	0	5	\N	0
5028043525	0	J. Nazier	0	1	0	0	0	0	\N	0
5973880623	0	rissa	0	15	0	0	0	6	\N	0
5814774179	0	A	0	21	0	0	0	8	\N	0
5559494893	0	ja	0	60	0	0	0	8	\N	0
6934544294	0	ig : @RifqianDannn	0	1	0	0	0	130	\N	0
6608386368	0	dafa	0	5	0	0	0	0	\N	0
5736035158	0	Andro	0	25	0	0	0	57	\N	0
5400690112	0	kinaa	0	13	0	0	0	7	\N	0
1423246048	0	Bebeqdlu slowrep	0	1	0	0	179.47	3	\N	0
6814412870	0	arashaa ,rbio.	0	3	0	0	0	0	\N	0
1935970461	0	kipli	0	14	0	0	0	1	\N	0
5631436437	0	lyshè	0	4	0	0	0	0	\N	0
1757770704	0	renzi algicer	0	3	0	0	0	0	\N	0
5649503158	0	Ciyooo >^•^<	0	1	0	0	0	0	\N	0
6769636103	0	Nja	0	134	0	0	15.3	131	\N	0
6490668049	0	orbit	0	139	0	0	322.05000000000086	663	\N	0
1626003587	0	mel	0	47	0	0	434	88	\N	0
1724728826	0	aldrich	0	3	0	0	0	1	\N	0
1830522084	0	nokos O2	0	1	0	0	0	0	\N	0
1426808867	0	ㅤㅤㅤㅤ	0	13	0	0	0	425	\N	0
5310493176	0	Katra. 🇵🇸	13	365	0	0	1107.7499999999995	1015	\N	0
1722056255	0	Caeth	0	96	0	0	18.96	24	\N	0
5445681053	0	jora.	0	34	0	0	0	36	\N	0
5383858059	0	m	0	36	0	0	0	0	\N	0
1774278851	0	kang	0	370	0	0	853.22	659	\N	0
6128607737	0	isell ausarta hr matwous	0	39	0	0	8.44999999999932	40	\N	0
5282068275	0	Kenzi	0	2	0	0	0	1	\N	0
5034436253	0	bunga	0	5	0	0	0	9	\N	0
6957211862	0	nezo	0	2	0	0	0	1	\N	0
641132097	0	zi	0	1	0	0	0	0	\N	0
5372470067	0	ziaa	0	187	0	0	5	655	\N	0
5574013767	0	bitch	0	1	0	0	0	0	\N	0
1814286586	0	dikapres	0	2	0	0	0	16	\N	0
6130091931	0	january, d.	0	5	0	0	0	0	\N	0
5363653782	0	wrong	0	208	0	0	0	0	\N	0
2084038926	0	Al. 𝒜𝓃𝓉𝒶𝓇𝑜𝑜𝓂ᵖˡᵘˢˢ	0	1	0	0	0	0	\N	0
1491478131	0	zwa	0	159	0	0	45.5	1	\N	0
1236769536	0	J	0	1	0	0	0	0	\N	0
5267098233	0	Just Man Like Coding	0	5	0	0	0	19	\N	0
5834132169	0	...	0	10	0	0	0	0	\N	0
5328676165	0	Adhisti Mataram, zaskia hr	0	7	0	0	0	39	\N	0
5420032484	0	Katya D.	0	13	0	0	0	149	\N	0
6551368860	0	juan, @puctus	6	22	0	0	85.83	291	\N	0
1351480909	0	Moniccc	0	140	0	0	0	22	\N	0
1409548656	0	6	0	153	0	0	240.66000000000025	142	\N	0
6046285316	0	Đrey	0	4	0	0	0	0	\N	0
5096133784	0	Wirangga P.	0	12	0	0	0	60	\N	0
5968698149	0	ʀᴅᴡɴ	0	1	0	0	0	0	\N	0
1736258850	0	💎bianca	0	3	0	0	0	11	\N	0
1320690184	0	falco¹ Calandra	0	1	0	0	0	0	\N	0
5356023529	0	a	0	210	0	0	322.74	610	\N	0
5220966847	0	i	0	33	0	0	705.6500000000001	106	\N	0
1344160293	0	aripp.	0	8	0	0	0	2	\N	0
2069275393	0	kciD	0	23	2	0	0	10	\N	0
1802936529	0	chan	0	7	0	0	0	5	\N	0
6257076269	0	Pejas	0	0	0	0	0	3	\N	0
1650272573	0	👩🏻‍🦯👩🏻‍🦯	0	136	0	0	37	1	\N	0
1980601740	0	jesha	0	1	0	0	0	0	\N	0
2067182825	0	user S	0	13	0	0	0	0	\N	0
1631640229	0	Cessa	0	16	0	0	0	15	\N	0
6094557523	0	raya.	0	1	0	0	0	3	\N	0
1658878750	0	deadly	0	79	0	0	4492.5	204	\N	0
2014838556	0	411 Le #𝐒𝐆𝐌 #MCHstan	0	127	0	0	139	3	\N	0
1198791327	0	cil	0	66	0	0	0	0	\N	0
1674048850	0	zea	0	34	0	0	0	65	\N	0
5231636867	0	cesaaa	0	107	0	0	22.119999999999855	920	\N	0
5721139804	0	keyy	0	29	0	0	109	55	\N	0
5887658149	0	Tauf	0	2	0	0	0	20	\N	0
5992999807	0	Seika Fellousy.	0	1	0	0	0	0	\N	0
6929122869	0	rowr kiss	0	1	0	0	0	0	\N	0
5256294779	0	Debbie	0	2	0	0	0	0	\N	0
5528909657	0	666	9	32	0	0	663.8199999999999	83	\N	0
6317369159	0	jeyi rayosdelsol	0	9	0	0	500	378	\N	0
1359062560	0	nalendra	0	16	1	0	0	19	\N	0
5126770370	0	Alenia	0	2	0	0	0	59	\N	0
5351881141	0	Unknown	0	30	0	0	288	17	\N	0
5534599807	0	fely.	0	7	0	0	0	27	\N	0
1647784949	0	shhhhh	0	52	0	0	0	122	\N	0
1276063139	0	jihan	0	4	0	0	0	0	\N	0
1024127209	0	Isabel.	0	0	0	0	0	0	\N	0
5896704358	0	🌷	0	2	0	0	0	0	\N	0
5724250049	0	on resting.	0	61	0	0	983.8699999999999	221	\N	0
5056250096	0	kiya anak bunda	0	12	0	0	8.34	4	\N	0
5899350504	0	Ｊ𝐞Ň𝐈𝐞𝐞🌷	0	1	0	0	0	0	\N	0
5513203425	0	mila cikieir	0	3	0	0	0	9	\N	0
6253716107	0	awa	0	2	0	0	0	0	\N	0
5495103979	0	Brykal offpc	0	29	0	0	0	0	\N	0
1829517114	0	Ve	0	1	0	0	0	0	\N	0
6065189024	0	kelly	12	824	1	0	4960.560000000014	1190	\N	0
1294536485	0	私 ー 𝐌𝐫𝐬 ፝֯֟𝐒𝐭𝐞𝐟𝐚𝐧𝐢 𝐀𝐠𝐚𝐭𝐡𝐚 𝐯𝐞𝐫𝐧𝐞𝐳𝐳𝐚	0	3	0	0	0	6	\N	0
5812390815	0	.	0	6	0	0	0	1	\N	0
5943403520	0	hanni si hiu gendut!	0	5	0	0	0	36	\N	0
1962486578	0	Embun.	0	2	0	0	0	0	\N	0
5002572799	0	joy	0	0	0	0	0	0	\N	0
6337152937	0	chEerr	0	1	0	0	0	0	\N	0
5405203651	0	Luicy	0	8	0	0	0	30	\N	0
5922619123	0	Billy.	0	1	1	0	0	2	\N	0
6843681117	0	bibuu bibuuu	0	18	0	0	0	251	\N	0
5739348975	0	Kevin	0	15	0	0	0	0	\N	0
666685999	0	rob	0	4	0	0	0	6	\N	0
5562861594	0	Theresa	0	1	0	0	0	0	\N	0
6341033432	0	miyubi	0	5	0	0	0	1	\N	0
6271155181	0	Tiann	0	2	0	0	100	2	\N	0
6290246105	0	dena	0	12	0	0	0	20	\N	0
5106705655	0	Akun	0	5	0	0	0	0	\N	0
6185263892	0	bayu	0	3	0	0	25.84	1	\N	0
5479109947	0	Gege J.	0	1	0	0	0	5	\N	0
1593980144	0	shavia @chaekisses	0	41	0	0	0	1	\N	0
1916628626	0	Milea	0	6	0	0	0	0	\N	0
6049525739	0	Viera	0	1	0	0	0	0	\N	0
6205363580	0	Jericho E.	0	4	0	0	0	0	\N	0
5721150424	0	Bapak	0	238	3	0	1087.9899999999964	388	\N	0
1902829460	0	🦢🩰 ५◦ raw - lee (๑´ㅂ`๑) 𓂃	0	19	0	0	0	1	\N	0
1693128474	0	viona grazella	0	6	0	0	0	8	\N	0
5455850880	0	Jericrod	0	161	0	0	0	13	\N	0
1193852042	0	For You	0	1	0	0	0	3	\N	0
5395822837	0	Me	0	1	0	0	100	6	\N	0
5873543409	0	btnstr. Alvea	0	2	0	0	0	1	\N	0
5280272354	0	R	0	4	0	0	78	0	\N	0
1365291451	0	yujjinn	0	1	0	0	0	4	\N	0
6500090519	0	1	0	1	0	0	0	0	\N	0
2094645632	0	mac	0	14	0	0	0	30	\N	0
5833567515	0	Vyyynn #zeelovers	0	3	0	0	0	4	\N	0
1816363597	0	hanif. avail inrush	0	0	0	0	0	0	\N	0
1914636256	0	Miss Independent	0	2	0	0	0	0	\N	0
6040072141	0	Jyeesha K. #CØLV72h	0	7	0	0	0	63	\N	0
1810403510	0	windaa	0	1	0	0	0	0	\N	0
5811800410	0	rijane.	0	12	0	0	0	23	\N	0
5956522305	0	M	0	2	0	0	0	4	\N	0
5638595099	0	jaoying	0	12	0	0	0	12	\N	0
5607349384	0	c	12	170	0	0	286.33999999999975	44	\N	0
5854353912	0	keyy slr.	0	1	0	0	0	5	\N	0
1629470677	0	Miku	0	5	0	0	0	41	\N	0
1527357131	0	eve	0	19	0	0	0	1052	\N	0
6068406485	0	rfl	0	2	0	0	0	1	\N	0
1987300385	0	Millen 🎈	0	6	0	0	14.780000000000001	33	\N	0
5888149113	0	c i a 🌸	0	48	0	0	0	9	\N	0
5057553222	0	🤔	0	303	0	0	126.5	429	\N	0
6130197682	0	c	0	20	0	0	0	1	\N	0
5001896337	0	a	0	1	0	0	0	17	\N	0
1410504358	0	Alpen well	0	2	0	0	0	0	\N	0
1912667138	0	sheilla	0	33	0	0	0	0	\N	0
1954980928	0	keeyara khadeeja	0	3	0	0	0	1	\N	0
6724688344	0	venca	0	13	0	0	0	0	\N	0
6121301076	0	.	0	3	0	0	0	13	\N	0
6482276162	0	aunty ayaaa	0	58	0	0	2.1299999999999955	577	\N	0
1718104469	0	me	0	47	0	0	396	61	\N	0
5461520057	0	keilli	0	2	0	0	0	1	\N	0
6353336141	0	P	0	21	0	0	0	0	\N	0
5263938539	1	Elzan	0	19	0	0	0	5	\N	0
1833701388	0	k/ia - nael	0	2	0	0	0	17	\N	0
1444632886	0	loulou	12	7	0	0	2498.81	8874	\N	1
6367085936	0	K	0	0	0	0	1300	1	\N	0
1841655309	0	Arsyana Patrescheé	0	11	0	0	0	236	\N	0
5107200548	0	M. phoenixx	0	6	0	0	0	4	\N	0
6514295664	0	dinnn	0	2	0	0	0	0	\N	0
1943760116	0	arsenio.	0	43	0	0	0	18	\N	0
5288181193	0	Aya	0	32	0	0	0	3	\N	0
2051315272	0	K	0	80	0	0	0	3	\N	0
1959816857	0	ana	0	85	0	0	0	2	\N	0
6637757873	0	kevin	0	4	0	0	0	8	\N	0
5738507699	0	Pandu 441	0	3	0	0	0	0	\N	0
2090506177	0	chel	0	3	0	0	0	0	\N	0
6329296419	0	Audrey	0	1	0	0	0	0	\N	0
1619162940	0	J	0	191	0	0	0	13	\N	0
5597554540	0	apa	0	45	0	0	0	4	\N	0
5912495338	0	Do	0	2	0	0	1900	3	\N	0
6777381005	0	Kaivan.	0	3	0	0	0	1	\N	0
1397930049	0	m	0	1	0	0	0	2	\N	0
5019290787	0	ejaa	0	80	0	0	62.5	18	\N	0
1257339080	0	vian	0	8	1	0	0	3	\N	0
5269568075	0	아미	0	2	0	0	0	12	\N	0
1744682472	0	Laurona.	0	1	0	0	0	0	\N	0
5115397239	0	Cava	0	8	0	0	11.98	10	\N	0
1212508863	0	necassa	0	10	0	0	0	0	\N	0
6181495610	0	Ga pengen dikenal karna uang	0	1	0	0	0	2	\N	0
5060261015	0	Al	0	6	0	0	0	6	\N	0
6306080994	0	leunorA	0	1	0	0	0	0	\N	0
5427565913	0	reno yoga	0	0	0	0	0	16	\N	0
6962607647	0	Jova	0	2	0	0	0	2	\N	0
6405051233	0	?	0	1	0	0	0	0	\N	0
1677310120	0	micaela	0	8	0	0	0	1	\N	0
6074218899	0	rk	0	20	0	0	0	14	\N	0
1266081984	0	shaa	0	7	0	0	0	1	\N	0
6553418392	0	sya	0	13	0	0	0	42	\N	0
2030279974	0	a	0	35	0	0	0	6	\N	0
6123031028	0	branciou	0	1	0	0	0	463	\N	0
5602583220	0	stebii	0	0	0	0	0	0	\N	0
6929690650	0	Rayyu🌷	0	2	0	0	0	0	\N	0
5524273241	0	gap	0	7	0	0	0	0	\N	0
1724569182	0	rainy xeypatyh	0	1	0	0	0	1	\N	0
5690521613	0	aura	3	72	0	0	0	3	\N	0
5960599827	0	Anya.	0	7	0	0	0	4	\N	0
1763301828	0	pie	0	29	0	0	0	252	\N	0
6200537348	0	𖧷..> ℒa beauté naomi ◌ ִ ׄ ദ	0	6	0	0	111.6	39	\N	0
6925852062	0	Finkan	0	1	0	0	0	0	\N	0
1734854936	0	Arsh	0	1	0	0	0	2	\N	0
1788770836	0	k/ia. Pio! ★___<	0	12	0	0	495	31	\N	0
5340137068	0	ayaa wikky	0	7	0	0	0	0	\N	0
6793769208	0	sa	0	10	0	0	0	64	\N	0
1820402420	0	juan	0	97	0	0	676.8200000000002	2027	\N	0
6616081711	0	ershak open freelance	0	1	0	0	0	0	\N	0
5223241711	0	Doll	0	57	0	0	483.33	2144	\N	0
6358291202	0	cc . #pds	0	6	0	0	34.17	0	\N	0
1775563028	0	Darka galau	0	1	0	0	0	0	\N	0
1239879105	0	a	0	0	0	0	0	0	\N	0
6486613836	0	Fazer	0	6	0	0	0	2	\N	0
6339178472	0	── èupyy𐙚 ݁ ˖	0	8	0	0	0	3	\N	0
1607601123	0	ar	0	7	0	0	0	8	\N	0
1798257969	0	lienza	0	5	0	0	0	12	\N	0
1489370147	0	aca	0	20	0	0	0	0	\N	0
5129071494	0	Jam	0	180	0	0	0	342	\N	0
1761305995	0	aFFFIII, rep otomatis sm bot	0	11	0	0	346.3300000000001	175	\N	0
6810676524	0	Nenesya 4twenty	0	27	0	0	0	27	\N	0
2013648376	0	jogar	0	0	0	0	0	0	\N	0
1884263477	0	a	0	122	0	0	0	102	\N	0
6761248197	0	タバコ	0	12	0	0	0	1	\N	0
1946237450	0	lily	0	1	0	0	0	0	\N	0
1931638665	0	zz	0	121	0	0	603.39	6	\N	0
5633164546	0	amel⑅	0	118	0	0	727.34	197	\N	0
6131813870	0	.	0	11	1	0	0	0	\N	0
6250476267	0	shirleys	0	0	0	0	0	0	\N	0
5896905613	0	ven	0	30	0	0	206.57	41	\N	0
1872273729	0	jeje	0	1	0	0	0	0	\N	0
5514860321	0	sha	0	112	0	0	27.820000000000007	691	\N	0
6005003787	0	raka.	0	2	0	0	0	0	\N	0
6275573895	0	Shalum.	0	1	0	0	0	7	\N	0
5802007734	0	sei	0	305	0	0	17.62999999999984	1221	\N	0
6356500992	0	syahlaa	0	7	0	0	0	9	\N	0
5535255780	0	g	0	4	0	0	0	0	\N	0
5215057172	0	— bored // ella R.	9	281	0	0	637.1999999999998	780	\N	0
5066797005	0	Zaza	0	152	0	0	2.5	2996	\N	0
1862301293	0	Ayana.	0	1	0	0	0	0	\N	0
5909805046	0	Mahiro Algiri.	0	2	0	0	0	0	\N	0
5837911607	0	bellaAa❓❗	0	1	0	0	0	5	\N	0
6429848081	0	aiii	0	16	0	0	0	32	\N	0
1899180097	0	sabrina Open ୨୧	0	39	0	0	72.65	40	\N	0
1760411163	0	Naràlia.	0	2	0	0	0	0	\N	0
6004400832	0	zaraa	0	17	0	0	0	10	\N	0
6295667171	0	shiren	0	182	0	0	147.14999999999736	937	\N	1
5786574061	0	The Duxcite. Alcatus	0	108	0	0	-4.140000000001052	0	\N	0
5220395903	0	𝓽𝓲𝔁𝔁𝔁𝓪	0	14	0	0	0	182	\N	0
6247133240	0	aemi ertyue.	0	9	0	0	24.8	25	\N	0
5897420616	0	Portgas D	0	2	0	0	0	10	\N	0
5705969785	0	Charusélla.	0	20	0	0	0	17	\N	0
2112254408	0	ibel	0	9	0	0	0	1	\N	0
1737905161	0	ext kajo brpw	0	1	0	0	0	3	\N	0
1630864754	0	Sekar, b10.	12	58	0	0	302.2	230	\N	0
1962245667	0	ㅤㅤmoilarien	0	19	1	0	0	13	\N	0
5206976330	0	Sumanto	0	3	0	0	0	0	\N	0
6375598728	0	aishaa draco girlfriend	0	12	0	0	0	2	\N	0
5115585929	0	baron	0	3	0	0	0	3	\N	0
5280787497	0	x	0	6	0	0	0	0	\N	0
5875064384	0	Agaa	0	1	0	0	0	5	\N	0
5138707679	0	jae	0	16	0	0	0	0	\N	0
5575083119	0	steve	0	3	0	0	0	8	\N	0
1913533543	0	.	0	32	0	0	0	0	\N	0
6738046366	0	reinall	0	2	0	0	0	2	\N	0
5769734445	0	n	0	9	0	0	0	0	\N	0
2010898741	0	r	0	17	0	0	53.61999999999973	43	\N	0
1781146337	0	anyaa	0	48	0	0	0	69	\N	0
5960600773	0	na	0	25	0	0	0	5	\N	0
2032535710	0	Ghauri Bannedict	0	12	0	0	0	9	\N	0
2022019748	0	S a p u t	0	1	0	0	0	0	\N	0
1881008125	0	Enbe	0	1	0	0	0	0	\N	0
7024251069	0	DNI.	0	1	0	0	0	0	\N	0
5884519869	0	花江	0	1	0	0	0	3	\N	0
6512362310	0	ray	0	1	0	0	0	0	\N	0
6025130725	0	yyota!	0	0	0	0	0	0	\N	0
5554801960	0	jiyye	0	24	0	0	0	0	\N	0
6363465306	0	prilia.	0	24	0	0	0	92	\N	0
5761966390	0	Viyaa.	0	5	0	0	0	56	\N	0
5328581360	0	.	0	201	0	0	6.5	1161	\N	0
1685700816	0	ㅤㅤ	0	13	0	0	0	4	\N	0
6625941077	0	Estrellä	0	2	0	0	0	1	\N	0
5048451364	0	Kane Nt Bro Wk	0	1	0	0	0	0	\N	0
1990668616	0	triaa	0	2	0	0	0	0	\N	0
1417997222	0	jjívey zeaa`•SLR	0	11	0	0	0	7	\N	0
5950660149	0	𝓛exie	0	9	0	0	0	23	\N	0
2102542140	0	#𝐋𝐕.atin close	0	10	0	0	490	109	\N	0
1806727012	0	Dea ayu	0	20	3	0	17	19	\N	0
5722931892	0	pir 🍐	0	7	0	0	0	29	\N	0
1182971960	0	୨୧ : Anna!	8	1	0	0	0	19	\N	0
6303919549	0	𝟐𝟏𝟒.𝖈𝖑𝖆𝖎𝖗𝖆	0	1	0	0	0	0	\N	0
7073856787	0	jeannnn	0	10	0	0	0	5	\N	0
1661392502	0	Adam Iskandar	0	3	0	0	0	5	\N	0
1742390369	0	rest	0	18	0	0	0	0	\N	0
5249720518	0	?	0	563	0	0	15.090000000000003	31	\N	0
6181368184	0	ℋ• sze bieber.	0	4	0	0	57.61	34	\N	0
7068095936	0	kaje, dni bentar	0	27	0	0	0	75	\N	0
1847168469	0	𐙚˙Vern	0	555	0	0	250.5399999999995	2062	\N	0
2135340895	0	L	0	25	0	0	0	7	\N	0
5294270747	0	Hanss	0	3	0	0	0	1	\N	0
5047005191	0	b	0	28	0	0	0	2907	\N	0
5911955681	0	Chijæiī ōtsukiryu	0	20	0	0	0	8	\N	0
1107605212	0	chesa	0	24	0	0	0	0	\N	0
6472923489	0	zheta.	0	75	1	0	127.94	435	\N	0
2029843917	0	﹢˚🎧﹒gisella？ꜝ▨	0	2	0	0	0	0	\N	0
5933839674	0	ar rafi	0	2	0	0	0	0	\N	0
6507347150	0	tasà dystōpia 🇱🇷	0	6	0	0	0	2	\N	0
5122911009	0	ayaa	0	18	0	0	0	0	\N	0
6201276660	0	awikawok	0	2	0	0	0	0	\N	0
1934923333	0	jepa DNI	0	64	0	0	1420	52	\N	0
5291834212	0	.	0	0	0	0	0	0	\N	0
1360378388	0	s	0	1	0	0	0	4	\N	0
1658346090	0	h.	0	8	0	0	7.13	55	\N	0
5755991307	0	L	0	17	0	0	0	59	\N	0
5164404117	0	kiki	0	1	0	0	0	1	\N	0
1776957298	0	al ²nd	0	4	0	0	1010	0	\N	0
5288998046	0	dischA	0	0	0	0	0	14	\N	0
1845671199	0	acarisa gi galau	0	4	0	0	0	8	\N	0
6078034844	0	abiezua drxt	0	2	0	0	0	3	\N	0
1731551725	0	chessy	0	6	0	0	0	0	\N	0
6719324023	0	Lia	0	4	0	0	0	1	\N	0
6144929819	0	Miyako Cho	0	6	0	0	0	0	\N	0
5683448025	0	Jeff	0	2	0	0	0	0	\N	0
5885146350	0	n	0	3	0	0	0	0	\N	0
5749932802	0	.	0	6	0	0	0	3	\N	0
6491807812	0	c	0	2	0	0	0	0	\N	0
5139376351	0	D'Maxel. @ewsbol	0	96	0	0	343.94000000000017	1566	\N	0
1456419586	0	Hi pips	0	5	0	0	0	2	\N	0
6334192826	0	se	0	1	0	0	0	0	\N	0
5750122382	0	Jastara M.	0	4	0	0	28.31	0	\N	0
1317985704	0	laveindear	0	2	0	0	0	0	\N	0
1357855381	0	Oliv	0	18	0	0	0	2	\N	0
2141122438	0	Duta	0	56	0	0	7	450	\N	0
5026622179	0	ㅤㅤㅤㅤ	0	236	0	0	62	9	\N	0
5447039405	0	Cynn Athanasiáa.	0	7	0	0	0	18	\N	0
1255378393	0	🝳... {meriethye odoelin}	0	3	0	0	0	0	\N	0
1354237522	0	Juanika.	0	6	0	0	0	0	\N	0
1962475452	0	Bubu Ke 2	0	153	0	0	0	325	\N	0
6605967436	0	rachell	0	2	0	0	0	0	\N	0
5751957336	0	Naddy	0	4	0	0	0	1	\N	0
1793048556	0	fazzy	0	86	0	0	0	1316	\N	0
1879233782	0	lil	0	2	0	0	0	1	\N	0
6302821889	0	panii	0	2	0	0	178	3	\N	0
2028257025	0	Re, fsr plss.. (ngejam, sabarr)	0	1	0	0	0	0	\N	0
1486204833	0	vvv	0	3	0	0	0	7	\N	0
1298767087	0	𝐆𝐚𝐛𝐫𝐢𝐞𝐥𝐥𝐚 𝐋𝐨𝐯𝐚𝐧𝐝𝐫𝐚	0	281	0	0	157.86	16	\N	0
2066979754	0	H.	0	2	0	0	0	0	\N	0
1787175699	0	pp	0	1	0	0	0	0	\N	0
6573076774	0	nitaaaaaaaa✞ ⛧	6	117	0	0	668.3700000000001	250	\N	0
1388338366	0	Myoyan	0	0	0	0	0	1	\N	0
1847778805	0	04	0	30	0	0	5	0	\N	0
1861618437	0	f	0	2	0	0	0	2	\N	0
1918750981	0	.	0	8	0	0	0	0	\N	0
6503119697	0	vete agy bete	0	8	0	0	0	7	\N	0
5600347230	0	— Lily	0	26	0	0	0	49	\N	0
1708418945	0	kwek kwek	5	164	0	0	4113.860000000001	1910	\N	0
6235601620	0	marvin	0	2	0	0	0	0	\N	0
1115133884	0	A, Yocelyn	0	2	0	0	0	0	\N	0
1312549822	0	Liam	0	25	0	0	0	10	\N	0
1998739839	0	raa	0	31	0	0	0	0	\N	0
5875611498	0	Malv	0	37	0	0	85.63	10	\N	0
1444265771	0	Bil	0	10	0	0	0	40	\N	0
5567416443	0	Kenji	0	0	0	0	0	5	\N	0
5359591953	0	Gabut	0	2	0	0	0	0	\N	0
2008995921	0	jevay	0	0	0	0	0	11	\N	0
5827869406	0	Alarick.	0	57	0	0	181.96000000000004	1250	\N	0
1388011249	0	S̷	0	5	0	0	0	18	\N	0
5155753254	0	Reona.	0	2	0	0	0	71	\N	0
5867579414	0	abian alistàir.	4	3	0	0	0	0	\N	0
6628274757	0	nara	0	28	0	0	0	4	\N	0
1588750149	0	piciii	0	51	0	0	8.310000000000002	28	\N	0
6156422388	0	Moymoy	0	1	0	0	0	0	\N	0
5305975737	0	aca	0	3	0	0	0	3	\N	0
1991910419	0	.	8	0	0	0	424.64000000000004	3	\N	0
7119601081	0	wonnie🤍	0	13	0	0	0	4	\N	0
5781439711	0	lauvely ^___^	0	3	0	0	0	13	\N	0
6196866186	0	aa kasep ceunah	0	37	0	0	0	7	\N	0
5976405014	0	laura	0	0	0	0	0	3	\N	0
5212599572	0	Naku.	0	7	0	0	0	23	\N	0
1685965361	0	zaa	0	28	0	0	0	1	\N	0
1110781676	0	dixxa	0	2	0	0	0	0	\N	0
6209851601	0	Gea	0	4	0	0	0	0	\N	0
6908360103	0	j	0	5	0	0	0	0	\N	0
5245181766	0	Jaegar.	0	7	0	0	0	524	\N	0
6730224305	0	kirana Return Wlonyoung to me	0	3	0	0	0	1	\N	0
5934354985	0	bibell	8	220	0	0	3544.5300000000025	1292	\N	0
5667765383	0	Liz	0	1	0	0	0	1	\N	0
5491192635	0	Clamentines M.	0	7	0	0	0	482	\N	0
1667484955	0	Maisha.	0	2	0	0	0	66	\N	0
5180069859	0	naa	0	2	0	0	0	4	\N	0
6822434890	0	.	0	5	0	0	0	0	\N	0
1685765840	0	slctv. rakaˢˡʳ	0	3	0	0	0	4	\N	0
5562418169	0	eyin	0	17	0	0	0	14	\N	0
5030944055	0	Rere ー A.	0	1	0	0	0	0	\N	0
5298406259	0	bia	0	2	0	0	0	67	\N	0
6035015552	0	je	0	1	0	0	0	17	\N	0
1654194989	0	Arunala M.	0	16	0	0	0	0	\N	0
1679042964	0	Alayna.	0	302	0	0	1725	77	\N	1
2137074121	0	rista PENDING	0	326	0	0	17.5	111	\N	0
6193331498	0	migu	10	81	0	0	654.83	1020	\N	0
1272698974	0	s	0	89	0	0	0	1	\N	0
1884048619	0	mndaa, i love you heeseung :c	0	91	0	0	0	107	\N	0
1839780616	0	laxverᴴᴸ	0	1	0	0	0	2	\N	0
1768712066	0	Gavin	0	182	0	0	880.04	94	\N	0
6524745149	0	𐙚 .. 사랑 ` Lié Poebe.	0	1	0	0	0	0	\N	0
1809031888	0	tuuu	0	1	0	0	0	0	\N	0
6161052166	0	vynn	0	3	1	0	0	0	\N	0
5491585891	0	Möcalmē - shana	0	23	0	0	410	236	\N	0
1735099400	0	lalaa 🚨	0	2	0	0	0	2	\N	0
5380347752	0	Hmzz	0	1	0	0	0	3	\N	0
5498683940	0	qwep	0	21	0	0	0	5	\N	0
5775340831	0	Shearliest	0	2	0	0	6978	1	\N	0
6616159025	0	❀.. o’ seraphic! hiranya, k.	0	14	0	0	0	4	\N	0
1907319865	0	Eric J.	0	18	0	0	0	22	\N	0
5693631229	0	Nana isi r&k	0	24	0	0	80.96	40	\N	0
5662034351	0	Alya	0	1	0	0	0	1	\N	0
1946456360	0	Chaeyyu.	0	230	0	0	0	48	\N	0
5566095687	0	ci	0	180	0	0	7362.969999999996	83	\N	1
7099075642	0	kelin	0	1	0	0	0	35	\N	0
5198719164	0	aska	0	58	0	0	0	11	\N	0
1761857497	0	ㅤニオ.nio	0	21	0	0	0	9	\N	0
1608505801	0	Yorukia	0	3	0	0	0	0	\N	0
1960202160	0	j	0	7	0	0	0	0	\N	0
7190340276	0	imel	0	1	0	0	0	1	\N	0
5140608627	0	ajis`ʰˢ	0	5	0	0	0	5	\N	0
5866314346	0	ian	4	26	0	0	2.880000000000109	14	\N	0
5285067885	0	عزوً	0	1	0	0	0	0	\N	0
5441101035	0	`	0	10	0	0	0	6	\N	0
1733545456	0	lal	0	1	0	0	0	0	\N	0
5712761549	0	Rama	0	27	0	0	0	6	\N	0
5091228159	0	Olzm	0	6	0	0	0	0	\N	0
6253128401	0	Kafsa	0	0	0	0	0	0	\N	0
5225196713	0	ayaa, argan's slut.	0	5	0	0	0	55	\N	0
1555551774	0	velo	0	129	0	0	0	571	\N	0
5601262737	0	Tuan muda, Samories.	0	2	0	0	0	1	\N	0
1446652300	0	A.	0	0	0	0	0	0	\N	0
1862967712	0	Giuseppe	0	5	0	0	0	0	\N	0
5133141062	0	Nina Helgia.	0	1	0	0	0	1	\N	0
1852718796	0	atha	0	2	0	0	0	0	\N	0
7052540273	0	gale	0	1	0	0	0	0	\N	0
5434913374	0	Kaluna A.	0	43	0	0	0	63	\N	0
5701877339	0	• C A N D U •™	0	4	0	0	0	178	\N	0
6736416494	0	geez !!	0	4	0	0	0	0	\N	0
5448680633	0	T	0	12	0	0	0	2	\N	0
5838176592	0	a	0	1	0	0	0	1	\N	0
6203655897	0	Dhny	0	5	0	0	0	6	\N	0
5379833418	0	Jasjus.	0	45	0	0	12.5	182	\N	0
5812020212	0	littyyy	0	16	0	0	0	3	\N	0
2061530599	0	Chie.	0	8	0	0	0	0	\N	0
6487588141	0	tsy	0	2	0	0	0	2	\N	0
1922590550	0	logout.	0	25	0	0	0	15	\N	0
6794536674	0	R	0	1	0	0	0	0	\N	0
5078728242	0	mochi	0	7	0	0	480	52	\N	0
1496637054	0	apda	0	6	0	0	1624.39	1059	\N	0
2045964080	0	jesselino	0	4	0	0	0	1	\N	0
6267943561	0	mäisha	0	1	0	0	0	2	\N	0
5043448780	0	aya	0	66	0	0	0	99	\N	0
5092317785	0	euis Ezäbeth	0	52	0	0	0	10	\N	0
6660895159	0	Ralph	0	2	0	0	0	12	\N	0
5265832769	0	panii	0	1	0	0	0	4	\N	0
1658688650	0	nayael	12	146	0	0	7750.440000000002	9179	\N	1
1961263315	0	raa	0	3	0	0	0	1	\N	0
5633172529	0	Taro	0	32	0	0	0	2	\N	0
5814993502	0	cA	0	29	0	0	0	11	\N	0
5356473529	0	zae	0	71	0	0	0	0	\N	0
6264896168	0	Kaatiya Aysele	0	3	0	0	0	0	\N	0
6623400997	0	1/2	0	44	0	0	58.58999999999995	95	\N	0
5796316379	0	spiderjono	0	9	0	0	0	36	\N	0
5224725314	0	Piuww	0	19	0	0	0	2	\N	0
5278004355	0	aca salima	0	47	0	0	3498.4800000000005	349	\N	0
1945710683	0	mr.Stamp	0	5	0	0	0	4	\N	0
1355947822	0	blairina’s 💋	0	96	0	0	241.41000000000008	206	\N	0
5222208138	0	rara neverlus"	0	19	1	0	0	3	\N	0
5026720913	0	Yi	0	1	0	0	0	1	\N	0
6187582992	0	ä	0	77	2	0	0	18	\N	0
7148145697	0	Celestine	0	131	0	0	8.84	2523	\N	0
5049466854	0	night	0	8	0	0	0	10	\N	0
6774984440	0	Rana. ⚯͛	0	1	0	0	0	0	\N	0
6139313058	0	Lunar 🌕	0	3	0	0	0	0	\N	0
6951586240	0	Vira	0	1	0	0	0	0	\N	0
2037897561	0	daēlláw	0	111	0	0	0	39	\N	0
6713085421	0	i	0	4	0	0	0	0	\N	0
1376289448	0	🥤	0	0	0	0	0	0	\N	0
1512335757	0	R	0	42	0	0	304.13000000000005	0	\N	0
2106298697	0	ᮃᮊ ᮆᮜ᮪	0	8	0	0	0	25	\N	0
1499337064	0	Akira	0	2	0	0	0	0	\N	0
944323853	0	duta sampo ajaib	0	3	0	0	0	3	\N	0
5957079394	0	Steve	0	6	0	0	0	7	\N	0
1248558638	0	ㅤ	0	7	0	0	0	10	\N	0
1340230934	0	Achélla.	0	33	0	0	0	46	\N	0
2073353599	0	nanda	0	3	0	0	0	0	\N	0
5583313287	0	k for kalea nayeshaa..	0	2	0	0	0	4	\N	0
5393544722	0	Kalandra	0	2	0	0	0	0	\N	0
5299945777	0	4cloy〻jerry balak	0	8	0	0	0	2	\N	0
5228037394	0	Zenia pacar Winwin	0	1	0	0	0	1	\N	0
2124790842	0	Christabelle // open	0	10	0	0	522.38	1	\N	0
5846797773	0	honam -____-	0	3	0	0	0	0	\N	0
2014881819	0	Jeanne	0	195	1	0	550.55	2	\N	0
598014642	0	Dean	0	23	0	0	0	495	\N	0
1719702361	0	nini	0	1	0	0	0	0	\N	0
6083954535	0	Solusi tugasmu ~ || open	0	17	0	0	1.68	0	\N	0
5914158707	0	leilaaa	1	4	0	0	213.26	0	\N	0
5098769318	0	callea	0	1	0	0	0	0	\N	0
7078944732	0	Toko	0	331	0	0	0	115	\N	0
5205377369	0	V	0	0	0	0	0	0	\N	0
1399192196	0	ge	0	2	0	0	0	0	\N	0
5032443759	0	keca	0	1	0	0	0	0	\N	0
6519475291	0	zahraptrr	0	0	0	0	0	0	\N	0
1237500652	0	p	0	4	0	0	0	0	\N	0
5623220491	0	arga	0	0	0	0	0	0	\N	0
1850317271	0	ercan mabok fisika cigeziـُ๋ࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣧࣧࣧࣧࣧࣧࣧࣧࣧࣧࣧࣧࣧ͡	0	4	0	0	0	0	\N	0
1330203665	0	glav	0	0	0	0	0	1	\N	0
1829075641	0	Lala	0	11	1	0	0	1	\N	0
5528217944	0	cipaa isn't mood	0	0	0	0	0	0	\N	0
6223302894	0	🎀ʝαριʝα🎀	0	10	0	0	0	38	\N	0
5279759907	0	lady	0	49	0	0	600	66	\N	0
5769207664	0	Gyyyy	0	2	0	0	0	7	\N	0
1348332635	0	Julian	0	21	0	0	0	0	\N	0
1952732250	0	Agas.	0	3	0	0	0	0	\N	0
6632879631	0	eci g mut	0	1	0	0	0	2	\N	0
7136141066	0	ezza	0	1	0	0	0	0	\N	0
5831159538	0	ㅤ	0	5	0	0	91.52	3	\N	0
5826276825	0	Breena	0	1	0	0	0	3	\N	0
2103100842	0	tyas	0	483	0	0	55.25999999999999	44	\N	0
5361223099	0	er	0	292	0	0	303.64	1380	\N	0
1386282398	0	yis	0	5	0	0	0	1	\N	0
1562387775	0	bunji	0	7	0	0	0	0	\N	0
6464752820	0	…	0	1	0	0	0	0	\N	0
6537882364	0	.	0	5	0	0	200	1	\N	0
5398567984	0	ace	0	3	0	0	0	1	\N	0
880616630	0	Mr. D	0	0	0	0	0	2	\N	0
6291632435	0	Jane	0	13	0	0	0	3	\N	0
1717966423	0	— Ⓐnetta 🧚🏻‍♀ @aicew. Always	0	3	0	0	0	17	\N	0
1859217170	0	A	0	1	0	0	0	0	\N	0
5047716578	0	kiw	0	1	0	0	16	0	\N	0
5620574015	0	kez	0	0	0	0	0	1	\N	0
5565513511	0	Aka.	0	2	0	0	0	0	\N	0
5003205205	0	rayv	0	3	0	0	0	5	\N	0
1998935231	0	liam	0	2	0	0	0	2	\N	0
5316525253	0	r	0	1	0	0	0	0	\N	0
1460461369	0	anya	0	9	0	0	0	5	\N	0
1927462431	0	leya off	13	8	0	0	44.92	16	\N	0
6065485689	0	jidan	0	2	0	0	0	2	\N	0
5051105928	0	lipiya	0	1	0	0	0	0	\N	0
5800773705	0	Fayarä S. 𝗩𝗥𝗙𝗛𝗜𝗥𝗧𝗘𝗔𝗠	0	1	0	0	0	0	\N	0
2024097553	0	kyan	0	13	0	0	0	1	\N	0
5392629394	0	frans	0	1	0	0	0	0	\N	0
1645581386	0	aza	0	23	0	0	1473.0200000000002	543	\N	0
1709811079	0	Cie, open teleprem 22k εїз	0	1	0	0	0	0	\N	0
5468394046	0	elleora`	0	2	0	0	0	1	\N	0
7191055177	0	S. Wilandra	0	2	0	0	0	0	\N	0
1205282606	0	G	0	4	3	0	0	0	\N	0
6715037147	0	iza	0	18	0	0	0	0	\N	0
6417398828	0	Nabillzeyyen	0	4	0	0	0	9	\N	0
7103779878	0	4	0	6	0	0	0	0	\N	0
5912311321	0	ceyy	0	1	0	0	0	1	\N	0
5119903305	0	J	0	2	0	0	0	0	\N	0
5733675630	0	ruby meow	0	52	0	0	0	136	\N	0
1879448199	0	queen	0	12	0	0	0	12	\N	0
5096522131	0	Adyamecca Tsabina	0	0	0	0	0	0	\N	0
5425345338	0	naya 朋友•	0	2	0	0	0	2	\N	0
5201035193	0	Ayesha	0	3	0	0	0	1	\N	0
5428239442	0	n	0	1	0	0	0	0	\N	0
1895182267	0	gariel awr	0	191	0	0	565.95	3220	\N	0
2143023669	0	gebby	0	41	0	0	351.86	12	\N	0
6116847831	0	Hendry	0	9	0	0	0	36	\N	0
6303597069	0	chiecill gengster kecil	0	1	0	0	0	0	\N	0
1246518444	0	kathya	0	0	0	0	0	0	\N	0
540941608	0	tomawosky	0	9	0	0	0	1	\N	0
6454328688	0	୨୧ ۰ ۪۫۫ risha ༉‧	0	2	0	0	0	0	\N	0
5125286825	0	Gizzele morena.	11	154	0	0	619.88	72	\N	0
5016960001	0	L	0	163	0	0	19.319999999999993	79	\N	0
521272926	0	ian	0	1	0	0	0	4	\N	0
6022647760	0	nayesha	0	2	0	0	0	0	\N	0
1605235616	0	ian	0	7	0	0	0	2	\N	0
1954923815	0	Kerlina.	3	532	0	0	10886.849999999999	166	\N	0
5937004711	0	cyrs	0	34	0	0	257.71	91	\N	0
1989510043	0	navarro loanjing ℬ4₲🇦🇱⁴	0	25	0	0	0	0	\N	0
5073122699	0	ichi ocha	0	2	0	0	0	0	\N	0
5137708953	0	chaèrys	0	7	0	0	0	2	\N	0
6179734114	0	Yohana	0	1	0	0	0	0	\N	0
6877010463	0	hanniee	0	1	0	0	0	1	\N	0
1967176658	0	Arjuna.	0	1	0	0	0	1	\N	0
1729817726	0	qira	0	3	0	0	0	16	\N	0
1479949924	0	indomie	0	1	0	0	0	0	\N	0
1848786406	0	Alana	0	65	0	0	0	22	\N	0
1961286202	0	⍺̶ׁꭉᥲִᲮֹə𝗹𝗹ִ𐐼 𐑈ׁ𝐭𐐫͟ꭉᥱˑ˖	0	2	0	0	0	0	\N	0
6091101332	0	wilona	0	4	0	0	0	2	\N	0
5931574439	0	ayunda (taylor's version)	0	78	0	0	26.42	4	\N	0
2119662586	0	Ming	0	1	0	0	0	0	\N	0
1165130258	0	168. akasaka mirel!	0	0	0	0	0	0	\N	0
1888566734	0	Sheerin	0	5	0	0	0	1	\N	0
5213944523	0	Rie	0	10	0	0	0	16	\N	0
2096357296	0	jay stak master	0	4	0	0	0	0	\N	0
6538541986	0	a	0	1	0	0	0	0	\N	0
2098468153	0	resha	0	1	0	0	0	0	\N	0
5996276222	0	reva	0	1	0	0	0	0	\N	0
1193489712	0	raya	0	198	0	0	228.0700000000001	119	\N	0
1339666217	0	ִ	0	2	0	0	0	0	\N	0
5050512445	0	Larc	0	13	0	0	0	0	\N	0
5015236011	0	.	0	3	0	0	0	0	\N	0
5689809039	0	najmiiii bakso segitiga	0	6	0	0	0	9	\N	0
1912484919	0	alena	0	51	0	0	0	427	\N	0
6451972619	0	-Y-	0	7	0	0	0	136	\N	0
1948810848	0	Dimas	0	1	0	0	0	0	\N	0
5597990523	0	Gabriel.	14	11	0	0	9621.73	7660	\N	1
1694791408	0	ㅤaiueo	0	15	0	0	0	0	\N	0
6050229760	0	rezā	0	10	0	0	0	0	\N	0
1463194795	0	ayumie	0	149	0	0	0	164	\N	0
1828930996	0	kael.	0	239	0	0	11.039999999999964	78	\N	0
1744443218	0	kila	0	4	0	0	0	11	\N	0
6425769502	0	..	0	3	0	0	0	0	\N	0
1726091497	0	yesA	0	6	0	0	386.99999999999994	830	\N	0
7122402899	0	zeta	0	10	0	0	0	0	\N	0
1514835287	0	nicole	0	12	0	0	0	518	\N	0
5843241237	0	per	0	13	0	0	215	2	\N	0
6634963645	0	tshaaav	0	1	0	0	0	1	\N	0
1891005432	0	lake	0	2	0	0	0	4	\N	0
5033338823	0	jeremy	6	98	0	0	2117.6	2006	\N	0
6637305389	0	Faaaa	0	6	0	0	0	122	\N	0
6011016591	0	naonaonao	0	2	0	0	500	16	\N	0
5871711234	0	asdfghjk	0	10	0	0	0	0	\N	0
1373596907	0	yosea.	0	8	0	0	0	0	\N	0
6032242799	0	jeqira	0	0	0	0	0	0	\N	0
6186816698	0	laa	0	3	0	0	7	0	\N	0
1747925781	0	─ Leσn pacar raka	0	3	0	0	0	4	\N	0
6795402415	0	blubuk	0	6	0	0	0	11	\N	0
1153324860	0	love bomb	0	544	0	0	415.385	598	\N	0
5195341545	0	ᴀɴᴅʀᴇꜱꜱᴀ	0	17	0	0	0	19	\N	0
6048497752	0	𝑹𝒆𝒚	0	21	0	0	0	4	\N	0
5585574702	0	ᴄʜᴀɴᴅ	0	3	0	0	0	10	\N	0
6372560956	0	Ndofo	0	4	0	0	0	0	\N	0
1430360205	0	egik	0	43	3	0	305.28999999999996	313	\N	0
5732540610	0	𝐍𝐲𝐚𝐢. 𝐊𝐚𝐣𝐨𝐱	0	10	0	0	0	1	\N	0
1873432441	0	àlin	0	1	0	0	0	0	\N	0
5918715811	0	shelli	0	0	0	0	0	8	\N	0
2012367247	0	E.	0	48	0	0	0	61	\N	0
6127890016	0	Nzaa	0	1	0	0	0	0	\N	0
5200036368	0	💤	0	3	0	0	0	1	\N	0
1389765168	0	Bz	0	1	1	0	0	1	\N	0
5102609473	0	tamaya	0	8	0	0	88.82	140	\N	0
6197229248	0	Aurora.	13	0	0	0	0	3	\N	0
1310445011	0	z	0	175	1	0	0	5	\N	0
2027958134	0	sarash.	0	11	0	0	0	16	\N	0
7168268627	0	plum	0	2	0	0	0	4	\N	0
5447298813	0	Nāelyn.	0	1	0	0	0	64	\N	0
6848688775	0	piiia	0	1	0	0	0	0	\N	0
5271870647	0	Clovarine.	0	1	0	0	0	1	\N	0
1551623761	0	berl kīd	0	81	0	0	1469.76	243	\N	0
5778632832	0	El	0	16	0	0	5.29	341	\N	0
2037209770	0	lauren	7	57	0	0	969.23	174	\N	0
6457941080	0	jargoy‘𝒮𝒽𝒶	0	1	0	0	0	0	\N	0
6789784241	0	ㅤㅤㅤㅤㅤㅤㅤ	0	2	0	0	0	0	\N	0
5503853687	0	Sherena.	0	7	0	0	0	10	\N	0
1983922906	0	almahira	0	4	0	0	27.39	0	\N	0
5229518457	0	Briel	0	37	0	0	0	2	\N	0
5329500430	0	Ŕaquel	0	5	0	0	0	0	\N	0
6645647792	0	Ren	0	4	0	0	0	0	\N	0
1329409071	0	me?	0	5	0	0	0	2	\N	0
1251746293	0	Mera.	0	4	0	0	25.51	900	\N	0
1091339763	0	caca	0	2	0	0	0	0	\N	0
1445596589	0	enaii	0	1	0	0	0	0	\N	0
1547795559	0	Delion RA bukan RP sorry (jokes, jangan hujat)	0	32	0	0	0	2390	\N	0
5914703347	0	ᴇɴᴠᴏ̷̷ʟᴇʀ - dai	0	9	0	0	0	48	\N	0
6866270781	0	nay	9	7	0	0	0	14	\N	0
5365016347	0	# αkiko hαrinο — 針野明子	0	9	0	0	0	0	\N	0
5400402250	0	a	0	1	0	0	0	1	\N	0
5284401097	0	zèe.	0	3	0	0	478	9	\N	0
2067461949	0	𝓩aravᵉˢʸᵃ @S3xu4l69	0	2	0	0	0	0	\N	0
1327186705	0	user	0	127	0	0	0	1317	\N	0
6090363603	0	nana not nanas	0	3	0	0	501.55	398	\N	0
5395539298	0	rei. @zh_anghao	0	3	0	0	2673.73	185	\N	0
5014692900	0	Majew, Nachi —K.	0	32	0	0	0	120	\N	0
5993112117	0	Freyana V.	0	0	0	0	0	0	\N	0
1819870922	0	C. (Taylor's version)	0	2	0	0	0	4	\N	0
5424433857	0	Zayn	0	38	0	0	13.819999999999993	10	\N	0
5448649774	0	j	0	7	0	0	0	124	\N	0
5765439891	0	ayya	0	59	0	0	0	91	\N	0
2009936110	0	;	0	3	0	0	0	0	\N	0
2126716463	0	[rest] sena	0	50	0	0	45.30000000000001	73	\N	0
1653199331	0	nA	0	1	0	0	0	0	\N	0
6406871312	0	gsenank dek 🤓🤓	0	2	0	0	0	1	\N	0
6273188717	0	K/IA. ꒰𑁬. nacyva’s! ੭ ⊹ ֺ ִ	0	13	0	0	0	13	\N	0
5635431110	0	anjay	0	10	0	0	0	22	\N	0
5119128876	0	caca 🪻	0	69	0	0	11.969999999999999	131	\N	0
5748808128	0	𝖆𝖓𝖎𝖑	0	13	0	0	0	5	\N	0
1603649909	0	.	0	95	0	0	0	8	\N	0
6127462611	0	୨୧︩︪˖ׄ 𖥻 ִ αϑorαblᧉ lᧉᧉn	0	8	0	0	0	0	\N	0
1470717925	0	𝕽ajendra.	0	4	0	0	0	0	\N	0
5208113965	0	🇨🇰. kayin	0	1	0	0	0	0	\N	0
2054881949	0	Yesa	0	14	0	0	0	0	\N	0
5521113219	0	oyi	0	0	0	0	0	0	\N	0
6207177370	0	Swanz	0	39	0	0	655	21	\N	0
1840698473	0	rai	0	54	0	0	1579.1500000000005	477	\N	0
5787610906	0	elaa	0	49	0	0	8.23	1	\N	0
6650717185	0	v	0	10	0	0	0	3	\N	0
6934754422	0	b	0	4	0	0	0	6	\N	0
5063264465	0	-	0	4	0	0	0	0	\N	0
521575786	0	🎂kusnadi	0	7	0	0	0	4	\N	0
1883469093	0	♡．Lã ～ féith . . 𓄹 ࣪ਏਓ	0	0	0	0	0	0	\N	0
5665601537	0	nathan	0	5	1	0	0	6	\N	0
1523150121	0	Jinanda	0	1	0	0	0	0	\N	0
5423795244	0	olivia ameline's	12	140	0	0	4559.1100000000015	499	\N	1
1885398083	0	Echa bjir	0	7	0	0	2.56	22	\N	0
6074432656	0	rajen	0	31	0	0	0	14	\N	0
5035399606	0	˶	0	54	0	0	0	4	\N	0
1703694799	0	🐳	0	7	0	0	521.51	30	\N	0
5292997218	0	seathérny cintá	0	0	0	0	0	0	\N	0
1411477070	0	k	0	0	0	0	0	0	\N	0
5688217469	0	yüriko bm beratt	0	2	0	0	0	10	\N	0
1844139092	0	Jaeinne is busyyyyy	0	0	0	0	0	3	\N	0
5005299029	0	haikal	0	2	0	0	0	0	\N	0
1878447444	0	c [BA]	0	35	0	0	0	5	\N	0
6035312853	0	raisa ButuhUank	0	10	0	0	50.910000000000004	21	\N	0
1243582747	0	Cessy	0	242	0	0	0	8	\N	0
6829103621	0	aloraa, PENDING BGT BGST	0	3	0	0	0	1	\N	0
1438935222	0	gua puput lu siapa?	0	8	0	0	0	21	\N	0
5726619556	0	asdfghjklgjgkssnj	0	0	0	0	0	0	\N	0
2043119619	0	none.	0	21	0	0	0	10	\N	0
1646816569	0	ale.	0	15	0	0	0	19	\N	0
2138406627	0	audy	0	78	0	0	861.13	1	\N	0
6706314245	0	lynnn anak baikk	0	1	0	0	0	0	\N	0
6084903665	0	kamari’s	0	91	1	0	26.77	314	\N	0
7152079370	0	stfu	0	18	0	0	6	2	\N	0
1286465327	0	cellia/jepa	0	0	0	0	0	0	\N	0
6236563577	0	karis	0	1	0	0	0	0	\N	0
1301259468	0	𝒮erli	0	340	0	0	7.379999999999967	33	\N	0
1834404600	0	unknown.	0	94	0	0	2171.55	582	\N	0
5059809563	0	kazuya fanbase	0	1	0	0	0	1	\N	0
5191731388	0	salwa digidaw	0	192	0	0	461.34	506	\N	0
6631808563	0	neyra	0	3	0	0	0	7	\N	0
1350926404	0	Kéyyza!	0	2	0	0	0	0	\N	0
6512513362	0	Evelyn	0	5	0	0	0	0	\N	0
6153755144	0	A - rest.	0	3	0	0	0	1	\N	0
6140961718	0	zamora	0	2	0	0	0	2	\N	0
2085413353	0	Raja	0	28	0	0	0	0	\N	0
2135986068	0	fin	0	4	0	0	0	11	\N	0
6843542834	0	greisell	0	1	0	0	0	0	\N	0
5181369515	0	justin	14	59	0	0	807.6000000000004	116	\N	1
6569734460	0	15	0	1	0	0	0	0	\N	0
1650188565	0	tasaa	0	88	0	0	0	7	\N	0
6058514948	0	Joe.	0	2	0	0	0	13	\N	0
5398698060	0	Jeki	0	3	0	0	0	4	\N	0
5569254407	0	faye	0	152	0	0	472.5799999999999	971	\N	0
5069226327	0	keith ɞ ́ˎ˗	0	1	0	0	0	0	\N	0
1289139726	0	Aca	0	0	0	0	0	0	\N	0
1994804905	0	Hirana 🧚	0	622	0	0	0	0	\N	0
5938870010	0	liya.	0	27	0	0	1158.2	70	\N	0
5057238893	0	nat	0	2	0	0	0	0	\N	0
1842460052	0	Derick	0	5	0	0	0	15	\N	0
5856013566	0	iev	0	0	0	0	0	11	\N	0
6716013523	0	zico	0	106	0	0	2023.409999999999	552	\N	0
5228700372	0	mei	0	36	0	0	4869.0199999999995	390	\N	0
6606253405	0	laellé 𓆩♡𓆪	0	3	0	0	0	8	\N	0
6399782410	0	myst	0	1	0	0	0	0	\N	0
1391018576	0	a	0	0	0	0	0	0	\N	0
1677791253	0	.	0	32	0	0	3754	133	\N	0
1775655706	0	nadishaa	0	86	0	0	0	92	\N	0
1990928694	0	y	0	1	0	0	0	2	\N	0
6630154200	0	666: Helena	0	25	0	0	0	65	\N	0
6183074406	0	Joel.	13	18	0	0	77.95000000000081	159	\N	0
5923923890	0	yuzaa	0	0	0	0	0	9	\N	0
2057413522	0	k/sia. rebecaaAa	0	27	0	0	0	0	\N	0
1391478095	0	Nararwww	0	3	0	0	0	0	\N	0
1685146187	0	ri	0	12	0	0	0	0	\N	0
7151531978	0	Na	0	1	0	0	0	0	\N	0
6034897846	0	velirec.	0	10	0	0	0	35	\N	0
1711623629	0	dazz	0	0	0	0	0	0	\N	0
2067639112	0	juli	0	128	0	0	0	1	\N	0
5532925940	0	cindii	0	0	0	0	0	0	\N	0
6553200600	0	aca	0	1	0	0	0	0	\N	0
2004015564	0	senziee	0	6	0	0	0	12	\N	0
5413266990	0	berry	0	2	0	0	0	2	\N	0
5450732124	0	tanti	0	52	0	0	0	81	\N	0
2027403351	0	Ayasa	0	14	0	0	0	0	\N	0
1745442073	0	claa	0	25	0	0	0	18	\N	0
1557861578	0	R	0	128	0	0	156.55	218	\N	0
6034914403	0	ᥲᥙᑲᑲіᥱ 🩰🎀	0	22	0	0	156.93	21	\N	0
1140840004	0	Gilinase	0	1	0	0	0	0	\N	0
1972380481	0	S pcr mark lee	0	0	0	0	0	3	\N	0
1615237584	0	183. CHINENNN	0	70	0	0	0	64	\N	0
5379502228	0	kesyaaa. rest	0	0	0	0	0	0	\N	0
6107786865	0	l	0	2	0	0	0	0	\N	0
1127956247	0	petrichorrr 2	0	26	0	0	0	30	\N	0
1805327453	0	klo emoji nanti gabisa main mafia	0	337	0	0	0	610	\N	0
6615259215	0	Afey	0	6	0	0	0	57	\N	0
5097041510	0	ren	0	2	0	0	0	1	\N	0
6628398755	0	cece	0	2	0	0	0	8	\N	0
1285524288	0	victor silalahi	0	3	0	0	0	21	\N	0
1361848815	0	skiz	0	3	0	0	155	3	\N	0
6814166427	0	graco. return @upervert.	0	22	0	0	0	239	\N	0
5188658545	0	cassie, teleprem 50k	0	43	0	0	860.8100000000001	587	\N	0
5220565973	0	awa	0	6	0	0	0	4	\N	0
5819108918	0	DNi. qilaa emsss	0	32	0	0	130	245	\N	0
5143575708	0	yoel	0	7	0	0	328	10	\N	0
5893644746	0	Yakshá ─	0	1	0	0	0	0	\N	0
5167676914	0	onnie	0	2	0	0	0	0	\N	0
5353307705	0	taraa	0	116	0	0	8	68	\N	0
5356056696	0	iaa the explorer	0	13	0	0	0	18	\N	0
6224246313	0	Axel	0	5	0	0	0	0	\N	0
1623030610	0	llr	0	4	0	0	0	2	\N	0
1765108937	0	phila	0	45	0	0	0	8	\N	0
5267304205	0	kaje	0	2	0	0	0	0	\N	0
5799560369	0	E.	0	233	0	0	9.58999999999952	268	\N	0
2080083748	0	piw cpiderman	0	27	0	0	0	50	\N	0
6674688981	0	andra	0	1	0	0	0	0	\N	0
6106095035	0	shá	0	11	0	0	0	1	\N	0
5213273970	0	jay	12	265	0	0	7287.360000000001	81	\N	1
6209433811	0	💋	0	3	0	0	0	0	\N	0
1144878835	0	.	0	3	1	0	0	0	\N	0
6664484621	0	Bangcan!	0	2	0	0	0	1	\N	0
6267557594	0	Ama.	0	1	0	0	0	0	\N	0
1722188291	0	orion	0	24	0	0	24	5	\N	0
5908278517	0	kelaa	0	1	0	0	0	0	\N	0
1878679686	0	cess	0	4	0	0	0	16	\N	0
5240889980	0	d	8	210	0	0	221.24000000000046	798	\N	0
5865248282	0	Ana	0	31	0	0	0	0	\N	0
1694272134	0	kana	0	2	0	0	0	0	\N	0
6361494843	0	cherryys	0	0	0	0	0	2	\N	0
1465478049	0	Déanne.	0	1	0	0	0	0	\N	0
5331137557	0	gera	0	64	0	0	0	31	\N	0
1909378110	0	cegil premium	0	42	0	0	0	56	\N	0
2070949245	0	bil	0	5	0	0	5.43	1	\N	0
5450588175	0	Hyesol DNI.	0	3	0	0	0	7	\N	0
1823661037	0	kay	0	14	0	0	0	8	\N	0
6275924342	0	อับดุลรับบี	0	3	0	0	0	0	\N	0
6554043393	0	dimas anggora	0	24	0	0	1771	37	\N	0
6198391972	0	hajel	0	22	0	0	0	0	\N	0
1553038615	0	ayu	0	119	0	0	0	275	\N	0
5687653272	0	Demonic	0	0	0	0	0	0	\N	0
1974918371	0	ㅤㅤ𝔏iaa openg	10	282	0	0	824.18	124	\N	0
1955498763	0	Claa.	0	1	0	0	0	66	\N	0
5194033670	0	u fav boi	0	1	0	0	0	1	\N	0
6715632173	0	rel	0	30	0	0	0	161	\N	0
5567259750	0	delvin	0	5	0	0	0	7	\N	0
6753571783	0	nadine	0	3	0	0	0	0	\N	0
1323434735	0	cavenus	0	5	0	0	0	0	\N	0
6063517019	0	JieN	0	4	0	0	0	3	\N	0
5290733572	0	priku	0	8	0	0	0	132	\N	0
5075078662	0	davina	0	68	0	0	0	206	\N	0
6558317551	0	Ur'	0	1	0	0	0	0	\N	0
1003154060	0	pidin	0	8	0	0	0	0	\N	0
5263930143	0	Joshua.	0	3	0	0	0	0	\N	0
5763507478	0	a	0	3	0	0	0	1	\N	0
5828049301	0	aryath - yg anti toxic dni	0	5	0	0	0	97	\N	0
1672715510	0	marco	0	6	0	0	0	2	\N	0
1641385948	0	ace	0	2	0	0	0	0	\N	0
1401680092	0	Cii	0	2	0	0	0	1	\N	0
1810759549	0	LILY	0	1	0	0	0	22	\N	0
2091002634	0	r	0	2	0	0	0	20	\N	0
1928099351	0	ashee	0	33	0	0	709.71	8	\N	0
5672037827	0	Dayu	0	5	0	0	0	4	\N	0
5090285979	0	jena	0	207	0	0	0	55	\N	0
5112551235	0	Alastair	0	2	0	0	0	5	\N	0
6694502295	0	p	0	19	0	0	0	1	\N	0
6815898376	0	Z	0	15	0	0	0	2	\N	0
1551251233	0	abiyu	0	5	0	0	500	0	\N	0
1855537111	0	kecii	0	1	0	0	0	0	\N	0
5725100407	0	T	0	12	0	0	0	2	\N	0
5474555972	0	Cagias	0	22	0	0	0	3	\N	0
6616823936	0	delon	0	2	0	0	0	0	\N	0
1846400956	0	Maddison.	0	0	0	0	0	0	\N	0
1852225840	0	ian hehe	0	2	0	0	662.15	3	\N	0
1724730286	0	sherly	0	70	0	0	6.680000000000007	23	\N	0
6255699793	0	Senara Ardian.	0	1	0	0	0	0	\N	0
1893906711	0	kacan	0	17	0	0	566	25	\N	0
5491669659	0	Usnaysbeekis	0	2	0	0	0	12	\N	0
2091401761	0	S.A	0	5	0	0	0	92	\N	0
1626075234	0	who's M?	0	7	0	0	0	0	\N	0
1946921634	0	jeano	0	1	0	0	0	1	\N	0
1124790751	0	f	0	73	0	0	0	0	\N	0
5107992752	0	kath?? miaw!!	0	2	0	0	0	17	\N	0
1659661720	0	L	0	3	0	0	0	14	\N	0
6939873008	0	nara.	0	8	0	0	0	143	\N	0
5295589425	0	in	0	12	0	0	0	2	\N	0
1606523036	0	azel	0	102	0	0	5	32	\N	0
1680226967	0	.	0	4	0	0	0	0	\N	0
6603002860	0	joyy	0	17	0	0	0	62	\N	0
5972655085	0	Jashter Dermione	0	1	0	0	0	0	\N	0
1666335382	0	cacapie 🩰	0	3	0	0	1978	6	\N	0
6394250132	0	nau	0	1	0	0	0	0	\N	0
1322778658	0	R.	0	5	0	0	0	0	\N	0
1319404512	0	terumi	10	10	0	0	1564.4199999999998	108	\N	0
1320450905	0	Kelvin	0	2	0	0	0	0	\N	0
1601345072	0	kalea	0	15	0	0	0	0	\N	0
6735017072	0	Utami. A	0	3	0	0	0	3	\N	0
5203922963	0	Lyodra	0	2	0	0	0	0	\N	0
1786719304	0	Ariel Tatum	0	11	0	0	0	7	\N	0
1356398336	0	cyaa	0	1	0	0	0	0	\N	0
5300752161	0	bebel	0	34	0	0	0	232	\N	0
5160849738	0	blubbies	0	466	0	0	44.55	44	\N	0
5340864586	0	its	0	6	0	0	0	1	\N	0
5857910313	0	wigen not wijen	0	12	0	0	0	1	\N	0
6730690155	0	melda	0	0	0	0	0	0	\N	0
1954481654	0	Kay.	0	4	0	0	0	1	\N	0
1906548685	0	nat :0	0	6	0	0	0	38	\N	0
5125328826	0	s	0	2	0	0	0	0	\N	0
1859951606	0	carolyn	0	4	0	0	0	8	\N	0
1792292370	0	rescha	0	47	0	0	0	200	\N	0
1707706235	0	Willian #CALMEMBAWR	0	10	0	0	0	181	\N	0
1834109306	0	cii.	0	101	0	0	710.4300000000002	245	\N	0
1708493449	0	asa. off	0	12	0	0	0	0	\N	0
5551720244	0	tita 🤺	0	6	0	0	0	11	\N	0
5450213889	0	.	0	62	0	0	207.53	13	\N	0
1758776616	0	zia	0	5	0	0	0	0	\N	0
5226590380	0	Wirangga Pra.	0	22	0	0	0	201	\N	0
1739446057	0	lalatot	0	6	0	0	0	6	\N	0
6644906661	0	Dicko	0	5	0	0	0	0	\N	0
1367419561	0	D	0	65	0	0	17.639999999999997	808	\N	0
1696789544	0	Bungaaa	0	2	0	0	0	512	\N	0
1865851894	0	ㅤ	0	0	0	0	0	6	\N	0
6741100913	0	Ca	0	1	0	0	0	1	\N	0
2041882579	0	j	0	6	0	0	0	10	\N	0
1749445341	0	.	0	2	0	0	0	0	\N	0
1272121907	0	rynala	0	35	0	0	0	8	\N	0
1948053334	0	sak	0	33	0	0	0	1	\N	0
5728220894	0	𝑸𝑬¹ sharph.	0	7	0	0	0	123	\N	0
1441364203	0	Revan.	0	55	0	0	0	132	\N	0
5106852811	0	Ran	0	2	0	0	0	0	\N	0
5097255123	0	mimi	0	9	0	0	0	27	\N	0
5962586536	0	ayam ayam	0	137	0	0	5.740000000000208	60	\N	0
6758675179	0	Aleesha ⋆˙⟡♡	0	2	0	0	200	9	\N	0
6234177021	0	Jack	0	4	0	0	338.19	51	\N	0
1843835815	0	.	0	0	0	0	0	0	\N	0
1505264466	0	013nagea	0	33	0	0	0	1	\N	0
6841741335	0	𝑺𝑵 vei	0	1	0	0	0	0	\N	0
5794120786	0	𓆩𝖙𝖍𝖊 𝖒𝖆𝖏𓆪 azhaaar in here	0	21	1	0	0	20	\N	0
6176541190	0	J.	0	59	0	0	0	5	\N	0
1561653054	0	💤	0	11	0	0	0	1	\N	0
5771497226	0	Jjoxiell matwous ph	2	585	0	0	1.3400000000000887	216	\N	0
5835329890	0	rukaa	0	102	0	0	1.2600000000000193	186	\N	0
6139138524	0	Ryujin	0	105	0	0	10.539999999999964	56	\N	0
1644507767	0	O$	0	1	0	0	0	0	\N	0
1701495864	0	ㅤㅤㅤㅤㅤ	0	667	0	0	4.5	104	\N	0
6422065714	0	Avelià Vordexrop . 🇧🇷	0	1	0	0	0	0	\N	0
5378622974	0	j	0	10	0	0	0	101	\N	0
6220621161	0	rakk	0	15	0	0	0	146	\N	0
6595684037	0	Ethes	0	6	0	0	0	0	\N	0
5084187529	0	sasy	0	8	0	0	0	1	\N	0
6752457817	0	Ashley.	0	8	0	0	434	28	\N	0
5218131760	0	val	0	1	0	0	0	0	\N	0
6066368950	0	jjj	0	3	0	0	0	0	\N	0
5528812131	0	155 marchelle	0	29	0	0	146.75999999999976	85	\N	0
5238534916	0	casyaa ʷᶜⁿ¹	0	1	0	0	0	2	\N	0
1813315603	0	rizam	0	1	0	0	0	0	\N	0
2041391601	0	a	0	1	0	0	29.339999999999918	7	\N	0
6120261619	0	Rakha A.	0	16	0	0	0	0	\N	0
1125992632	0	Key	0	39	0	0	0	18	\N	0
1157104805	0	i'm	0	2	0	0	0	2	\N	0
2073172558	0	ま𝐓𝐡𝐩𝐱 ´ ec	0	0	0	0	0	0	\N	0
6622100836	0	ejaaaaa Lagi Galau	0	2	0	0	0	0	\N	0
6246341765	0	P	0	45	0	0	0	0	\N	0
1708776217	0	158. nanaa	0	3	0	0	0	1	\N	0
5159762225	0	mabel	0	3	0	0	0	0	\N	0
6647203756	0	짱이라고행	0	0	0	0	0	0	\N	0
5464068958	0	𝐌ara.	0	13	0	0	0	22	\N	0
2101534395	0	Elcy	0	9	0	0	0	32	\N	0
5875995872	0	jekas ctr	0	2	0	0	0	0	\N	0
5328968652	0	sacaría	0	3	0	0	0	14	\N	0
1892837284	0	lili simp4 Ian	0	2	0	0	0	1	\N	0
1722175737	0	Nalan	0	0	0	0	0	0	\N	0
1785029556	0	deon rdslsgk	0	33	0	0	166.33	43	\N	0
1810759096	0	annisaaa	4	31	0	0	52.5	13	\N	0
1930232824	0	sam	0	311	0	0	11	394	\N	0
6970395457	0	jepaa	0	0	0	0	0	7	\N	0
5840033894	0	Andre kinda hiatus	0	8	0	0	0	31	\N	0
6068893905	0	Azkia Hassan	0	428	0	0	310.3600000000006	1361	\N	0
6131510128	0	n	0	5	0	0	0	3	\N	0
5938557951	0	Arkan Bradikara	0	0	0	0	0	0	\N	0
1989868143	0	eleenn	0	0	0	0	0	0	\N	0
5667942254	0	k. dnfi!	0	0	0	0	0	2	\N	0
5718925032	0	ungaaaaa𝑸𝑬¹	0	8	0	0	0	11	\N	0
6557642389	0	A—Nuraga.	0	4	0	0	0	0	\N	0
1088862533	0	aci	0	150	0	0	0	676	\N	0
1728543244	0	t	0	13	0	0	0	0	\N	0
917228160	0	luna	0	0	0	0	0	0	\N	0
5900111835	0	albiey	0	1	0	0	0	0	\N	0
6802029898	0	(𝐆𝐆𝐓)¹killy	0	18	0	0	0	2	\N	0
1931927116	0	abah	0	13	0	0	0	1	\N	0
6049376438	0	mǣ	0	6	0	0	37.67	39	\N	0
5295970838	0	.	0	1	0	0	0	0	\N	0
5591895136	0	.	0	3	0	0	0	0	\N	0
6380589450	0	gele berdikari	0	39	0	0	403	60	\N	0
5764465909	0	NGIDAM NAMJOON :((((	0	4	0	0	189.55	9	\N	0
1845424920	0	zazà	0	7	0	0	0	2	\N	0
5488349360	0	apis	7	370	0	0	621.9399999999999	4485	\N	0
5926728228	0	Lucya	0	12	0	0	78	62	\N	0
5057060019	0	K	0	2	0	0	0	0	\N	0
6483128943	0	OSIH	0	1	0	0	0	1	\N	0
6011466034	0	kaikaikai	0	7	0	0	0	26	\N	0
7144900891	0	.	0	2	0	0	0	0	\N	0
1389174214	0	c	0	44	0	0	0	30	\N	0
5712045651	0	renatta claudine's	0	13	0	0	0	63	\N	0
5835201915	0	nana	0	6	0	0	0	1	\N	0
6132900354	0	𝕾𝕺𝕸𝕰𝕺𝕹𝕰🎱💥	0	3	0	0	0	5	\N	0
5871684218	0	Byibel.	0	14	0	0	0	0	\N	0
1775702774	0	M	0	6	0	0	0	12	\N	0
1978878584	0	tashaa (?)	0	45	0	0	20	45	\N	0
6250049840	0	onyy	0	1	0	0	0	0	\N	0
6283233138	0	lala	0	5	0	0	0	0	\N	0
5102366447	0	:)	0	4	0	0	0	1	\N	0
5873965457	0	neeebula	0	16	0	0	0	44	\N	0
1743217940	0	charlotte	0	6	0	0	0	0	\N	0
5032978265	0	🌱 RATNA	0	9	0	0	0	3	\N	0
5911155886	0	Sherinna.	0	3	0	0	0	7	\N	0
5091376154	0	halooo	0	9	0	0	0	4	\N	0
1719937160	0	nad	0	149	0	0	0	33	\N	0
1952118515	0	J.	0	7	0	0	0	0	\N	0
5228519042	0	cherlyy	0	96	0	0	-0.40000000000000036	7	\N	0
1925228333	0	Aichn	4	437	0	0	77.23	154	\N	0
6408648351	0	zendaya	0	1	0	0	0	0	\N	0
1592035590	0	medéia.	0	1	0	0	0	0	\N	0
5380905066	0	L	0	139	0	0	0	68	\N	0
6569629237	0	Erick willson.	0	15	0	0	0	2	\N	0
6471674061	0	macaw	0	13	0	0	28	9	\N	0
5986078151	0	Aira | Open fsr	0	3	0	0	0	0	\N	0
6557645018	0	Arikαα	0	44	0	0	961.69	418	\N	0
5977809643	0	cookiie	0	2	0	0	0	19	\N	0
2079791140	0	shevaa.♡	0	2	0	0	0	1	\N	0
6818054599	0	syakuill	0	1	0	0	0	0	\N	0
2060471855	0	ini ari.	0	2	0	0	0	0	\N	0
6353779954	0	🧚🏻‍♀️	0	1	0	0	0	0	\N	0
2097185276	0	arion	0	29	0	0	0	11	\N	0
5766195279	0	kaiyla !	0	151	0	0	448.34999999999997	154	\N	0
1694242484	0	eca	0	0	0	0	0	0	\N	0
5325493877	0	b	0	7	0	0	0	8	\N	0
2084243350	0	al	0	0	0	0	0	0	\N	0
6142006314	0	mimi, move	0	15	0	0	0	16	\N	0
1733528845	0	raka	0	3	1	0	0	0	\N	0
1751459073	0	Maisadipta R.	0	23	0	0	0	0	\N	0
5489678359	0	‎⋆ mixed signal era	0	55	0	0	342.68	327	\N	0
1218763502	0	Aye	0	1	0	0	0	4	\N	0
6844980101	0	Juan	0	2	0	0	0	9	\N	0
1694153284	0	Orville.	0	5	0	0	0	50	\N	0
2009160929	0	Dex.	0	78	0	0	0	176	\N	0
6549940509	0	caltheia	0	1	0	0	0	0	\N	0
5306617659	0	DNI. jean	0	2	0	0	0	11	\N	0
2133323582	0	menfess bot	0	155	0	0	0	51	\N	0
1699621416	0	.	0	7	0	0	0	0	\N	0
1870083406	0	Leuventa!	0	2	0	0	0	0	\N	0
1517280769	0	Real	0	4	0	0	0	0	\N	0
5056944416	0	Riel K	0	24	0	0	0	25	\N	0
5294256331	0	avianz	0	8	0	0	0	10	\N	0
6209746215	0	002.eja	11	81	0	0	2768.8099999999995	911	\N	0
5978701228	0	joe	0	2	0	0	0	1	\N	0
5923835595	0	Aluna. @blackoriov	0	29	0	0	408.82	292	\N	0
5293857951	0	Shiwan	0	1	0	0	0	23	\N	0
6946260506	0	A	0	1	0	0	0	0	\N	0
5976993195	0	lost me	0	3	0	0	0	1	\N	0
6366634073	0	cia	0	10	0	0	0	29	\N	0
6280925282	0	hasa	0	1	0	0	0	0	\N	0
6079973633	0	adeyaraa.	0	11	0	0	4.02	3	\N	0
6781868805	0	Raf	0	0	0	0	0	3	\N	0
1271548912	0	𝐀𝐍𝐒𝐘𝐑.	0	0	0	0	0	0	\N	0
5112714382	0	jar	0	442	0	0	16	22	\N	0
6555683426	0	Kevinz	0	1	0	0	0	1	\N	0
5847185457	0	👤HannaAa	0	10	0	0	96.56	8	\N	0
1936240537	0	keith valèry	0	1	0	0	0	1	\N	0
2070122931	0	Jaden	0	29	0	0	0	94	\N	0
1489715358	0	Javiér taehyung's gf	0	8	0	0	0	20	\N	0
1482371311	0	putra pdr	0	4	0	0	0	6	\N	0
1992112632	0	Kaluna E.	0	3	0	0	0	0	\N	0
5360597679	0	Sz's.	0	20	0	0	0	100	\N	0
5357760078	0	wa	0	20	0	0	0	8	\N	0
5561435127	0	me ?	0	3	0	0	0	2	\N	0
1653176084	0	naomi	0	284	0	0	0	361	\N	0
6379307477	0	L	0	50	0	0	103	45	\N	0
1667681856	0	Azika.	0	3	0	0	0	7	\N	0
6532361545	0	Nandar	0	5	0	0	0	7	\N	0
7189425678	0	Memey	0	64	0	0	712.25	287	\N	0
1213432564	0	AJI	0	2	0	0	0	0	\N	0
5053010795	0	fuyu	0	9	0	0	0	30	\N	0
6507391248	0	vanne	0	6	0	0	0	3	\N	0
5477862945	0	Kevv	0	1	0	0	0	7	\N	0
6025327222	0	key	0	2	0	0	0	0	\N	0
6430916820	0	eleänor	0	1	0	0	0	3	\N	0
1038334508	0	tyo	0	1	0	0	0	7	\N	0
5272909006	0	justin	0	6	0	0	0	0	\N	0
5953658507	0	daniel open selalu	0	4	0	0	0	0	\N	0
6930127114	0	bulan	0	5	0	0	0	0	\N	0
6276862635	0	samudra pysefic	0	9	0	0	15.48	26	\N	0
1898232270	0	viola	9	92	0	0	3112.88	27	\N	0
6560993187	0	lareina	0	0	0	0	0	0	\N	0
6205385434	0	Zasha	0	2	0	0	0	1	\N	0
5547138931	0	user K	5	129	1	0	149.31000000000176	15	\N	0
6034018926	0	Kia	0	13	0	0	101.28	38	\N	0
1375138064	0	kyeom	0	2	0	0	0	2	\N	0
1669976235	0	🫅🏻	0	7	0	0	0	0	\N	0
1858801057	0	Seyraa	0	14	0	0	0	25	\N	0
1256275191	0	Ajisaka.	0	2	0	0	0	0	\N	0
1834685196	0	- ᴠ	0	4	0	0	10	0	\N	0
1752140087	0	z	0	4	0	0	0	0	\N	0
6733215973	0	nɑ	0	1	0	0	0	0	\N	0
5493382945	0	läla salimawikky	0	1	0	0	0	9	\N	0
5242845099	0	dio	0	6	0	0	55.230000000000004	23	\N	0
1466754759	0	ale	0	23	0	0	0	62	\N	0
6258964389	0	leaving	0	13	0	0	328.64	60	\N	0
6849050363	0	qeyreina	0	2	0	0	0	0	\N	0
6220015509	0	Ophelia READ = NGEJAM	0	5	0	0	87.97	52	\N	0
1772936039	0	.	0	1	0	0	0	0	\N	0
2057359903	0	olivia #onlinemalam	6	329	0	0	4614.55	128	\N	0
5806110272	0	Kiya.	0	24	0	0	0	17	\N	0
6195813868	0	veyya	0	0	0	0	0	0	\N	0
6185953802	0	ra.	0	1	0	0	0	1	\N	0
1973459567	0	Rafhly	10	5	0	0	0	166	\N	0
5845881328	0	kalula itu adyaaa	12	16	0	0	11.300000000000011	1	\N	0
1288245726	0	biaa.	0	100	0	0	0	0	\N	0
1402745134	0	Deliana.	0	46	0	0	1313.19	46	\N	0
5925510847	0	Aretha	0	8	0	0	0	17	\N	0
6962233041	0	bie	0	11	0	0	0	3	\N	0
6675761989	0	u	0	4	0	0	0	0	\N	0
5954038280	0	abylienne	0	13	0	0	0	2	\N	0
5439423127	0	i	0	16	0	0	0	1	\N	0
5690145935	0	degan	0	2	0	0	0	26	\N	0
6316907744	0	azizi	0	2	0	0	2.53	304	\N	0
5433141471	0	j	0	111	0	0	0	15	\N	0
5329530569	0	farsa	13	201	0	0	83.66000000000014	41	\N	0
5509708260	0	𖥔 ִֶָ Rubieca ʚɞ ⁺˖	2	257	0	0	246.36000000000024	1856	\N	0
5874186969	0	cici	0	89	1	0	12.990000000000123	99	\N	0
6779903041	0	.	0	6	0	0	0	9	\N	0
6560571586	0	z	0	3	0	0	0	1	\N	0
5081839559	0	💭⋆୨୧˚𝓜ꪱko	0	30	0	0	0	190	\N	0
1714977959	0	💎	0	37	0	0	0	4	\N	0
2117075395	0	Kalila, Busy.	0	3	0	0	0	0	\N	0
6576306883	0	caca	0	0	0	0	0	1	\N	0
5135110890	0	38 Victor سيد النصر	0	5	0	0	0	3	\N	0
6867535242	0	sena	0	3	0	0	0	0	\N	0
5193566377	0	paloy	0	2	0	0	0	6	\N	0
5099284326	0	.	0	148	0	0	0	16	\N	0
5916697176	0	cal	0	3	0	0	0	0	\N	0
1995229653	0	gi	0	1	0	0	0	0	\N	0
5576396220	0	rararara	9	510	0	0	3574.010000000001	3276	\N	0
5135931898	0	yina	0	1	0	0	0	3	\N	0
5251332056	0	Az	10	72	0	0	353.3399999999999	5	\N	0
6512009039	0	Geza	0	7	0	0	0	0	\N	0
5311453222	0	aldeas	0	4	0	0	0	5	\N	0
1828052754	0	𝐌irei ♡ing 𝐉𝐢𝐡𝐨𝐨𝐧	0	2	0	0	0	5	\N	0
1748325124	0	.	0	20	0	0	0	0	\N	0
1846328771	0	ayesa	0	6	0	0	0	0	\N	0
2128073513	0	ayà	9	19	0	0	26.18	220	\N	0
5617907910	0	ver	0	2	0	0	0	1	\N	0
1445375547	0	꧁ℭ℟Åℤ¥༒₭ÏḼḼ℥℟꧂,◡̈💎🏀	0	2	0	0	0	3	\N	0
6288306876	0	Azel	0	35	0	0	0	51	\N	0
1756875987	0	men 2	9	1	0	0	455.8699999997589	0	\N	1
5462355366	0	aster	0	1	0	0	0	0	\N	0
1339890110	0	Deja vu DNI.	0	106	0	0	0	15	\N	0
1456675244	0	pyy	0	326	0	0	1012.69	12	\N	0
5137024048	0	none	0	36	0	0	0	59	\N	0
5757600448	0	Yan. ga di rep kurmin	5	940	0	0	12.009999999998058	14029	\N	1
6003527774	0	ㅤㅤㅤㅤㅤnaa	0	5	0	0	0	7	\N	0
6338991205	0	Narcy.	0	6	0	0	0	0	\N	0
6842402829	0	Jan	0	0	0	0	0	20	\N	0
1559866167	0	Zaki	0	0	0	0	0	0	\N	0
5554460491	0	abian	0	49	0	0	0	17	\N	0
5405770470	0	tama	0	7	0	0	0	17	\N	0
6280956453	0	sachie 🪞🩰	0	1	0	0	0	12	\N	0
5435121363	0	seybille ⚝ ׁ	0	15	0	0	0	4	\N	0
1606020281	0	Khadavi K.	0	108	1	0	0	3	\N	0
1947941249	0	nèrajevcha	0	0	0	0	0	0	\N	0
1839925282	0	Riaa'slr	0	18	0	0	0	0	\N	0
2122142551	0	L	0	98	0	0	0	2	\N	0
5948604357	0	t	0	4	0	0	0	0	\N	0
6208702810	0	mange, ameett 9tz 〻.	0	0	0	0	0	0	\N	0
1818471522	0	Ryana	0	122	0	0	5.289999999999999	359	\N	0
6559591947	0	kuro	0	2	0	0	0	2	\N	0
6604750913	0	ian	0	2	0	0	0	0	\N	0
1853542026	0	pp	0	4	0	0	0	4	\N	0
6121474742	0	Atlas	0	7	0	0	0	0	\N	0
6111883884	0	Kristan	0	2	0	0	0	1	\N	0
6145182065	0	minesss	0	86	0	0	0	176	\N	0
5751454472	0	i	0	11	0	0	0	3	\N	0
5335319362	0	ᴍᴠɴ. 𐙚 ׁ yaâraa's.	0	2	0	0	0	6	\N	0
6510487149	0	doni	0	1	0	0	0	18	\N	0
5161099139	0	Morëno kinda inactive.	0	8	0	0	0	224	\N	0
1294986247	0	bieloora ellièsta	0	150	0	0	1489.7000000000003	361	\N	0
1881287221	0	MJ	0	1	0	0	0	2	\N	0
1236316226	0	nana(s)	0	1	0	0	0	0	\N	0
6178575649	0	Achaa	0	100	0	0	3.8100000000000023	50	\N	0
6125469726	0	Lacya	0	40	0	0	117.54000000000002	31	\N	0
5150613790	0	ifaaa	0	7	0	0	0	0	\N	0
1631556807	0	dni	0	1	0	0	0	0	\N	0
6048958522	0	icel	0	1	0	0	0	0	\N	0
7198180025	0	lucella gemas	0	7	0	0	0	1	\N	0
6217463237	0	𝐖cs𝐂𝐋1𐂂.zize	0	1	0	0	0	0	\N	0
5092963709	0	b	0	12	0	0	500	6	\N	0
1751671403	0	leii	0	30	0	0	0.7099999999999795	4	\N	0
6168503459	0	@	0	3	0	0	0	0	\N	0
1782676827	0	ies	0	206	0	0	500	279	\N	0
5594669188	0	.	0	1	0	0	0	0	\N	0
1963268411	0	s	0	247	0	0	9.86	41	\N	0
1917825446	0	zee	0	25	0	0	64.81	162	\N	0
5166600129	0	A	0	1	0	0	0	0	\N	0
5040615338	0	cacil	0	78	0	0	2456.99	47	\N	0
5613380519	0	G	0	23	0	0	0	12	\N	0
1771146048	0	Jo 🐄	0	498	0	0	0	16	\N	0
5494633342	0	baha	3	544	0	0	2631.1399999999994	3159	\N	0
6188292927	0	Mourthine's Candidate, ghïselle aurellié	0	26	0	0	0	1	\N	0
5498536492	0	Nazasya Aldevhyra.	0	39	0	0	0	1	\N	0
5406421797	0	< bocill >	0	4	0	0	0	0	\N	0
5129013918	0	$	0	285	0	0	646.82	1723	\N	0
5526862426	0	lelee minimal fsr balik cuyy	0	1	0	0	0	0	\N	0
5792300051	0	𝕚𝕫𝕫	8	136	0	0	5505.589999999998	1670	\N	1
5203929222	0	san_	0	324	0	0	4.480000000000132	38	\N	0
1874452881	0	aiueo	0	13	0	0	152.78000000000006	23	\N	0
6903422030	0	hanniah arabella Hyeon𓅯	0	2	0	0	0	0	\N	0
6591696355	0	renjani.	0	145	0	0	0	24	\N	0
6964203994	0	Ancaaa.	0	7	0	0	18.4	27	\N	0
6814701989	0	003.	0	3	0	0	0	4	\N	0
6289698065	0	killaa suka matcha	0	1	0	0	0	1	\N	0
6252320942	0	k, cléowsie	0	4	0	0	0	22	\N	0
1723937354	0	nayaa ( ijeong's gf ).	14	311	0	0	2599.51	983	\N	0
6390570492	0	ourellie	0	4	0	0	0	11	\N	0
6313481118	0	doy	0	0	0	0	0	0	\N	0
2029486712	0	ajiélo's lover, maraka	0	8	0	0	0	12	\N	0
2081244669	0	:v	0	9	0	0	0	1	\N	0
5887063325	0	Jeirene.	0	5	0	0	0	20	\N	0
1231702225	0	ann	0	9	0	0	480	12	\N	0
1482478555	0	darrel	0	18	0	0	0	3	\N	0
1849818519	0	Hello stalker	0	0	0	0	0	0	\N	0
6811849427	0	musticattus	0	0	0	0	50	61	\N	0
1728831739	0	aelyn	10	982	0	0	3.1799999999987847	2532	\N	1
1778057353	0	Raka	0	5	0	0	0	0	\N	0
1694507258	0	Zzz	2	52	0	0	176.62	447	\N	0
1966398779	0	cici pusing besok mau jadi apa	0	23	0	0	0	357	\N	0
1378690099	0	Hr	0	8	0	0	0	287	\N	0
1474541285	0	Estherina	0	2	0	0	0	2	\N	0
5224536184	0	ubeyy	0	4	0	0	0	10	\N	0
5527414774	0	celo	0	15	0	0	30.200000000000003	68	\N	0
1794893185	0	ael	0	7	0	0	34.68	12	\N	0
6231983439	0	fany	0	2	0	0	0	7	\N	0
1307104310	0	xixi	0	18	0	0	0	0	\N	0
1926490906	0	Starmiya 💐	0	1	0	0	0	6	\N	0
1522462888	0	FEBB	0	32	0	0	487	47	\N	0
1485383038	0	jinggaa	0	3	0	0	0	1	\N	0
5281149172	0	oxa	0	3	0	0	0	2	\N	0
6200099317	0	Juna	0	4	0	0	0	6	\N	0
5607735005	0	filip	0	43	0	0	0	25	\N	0
2050483473	0	Aldara	0	0	0	0	0	0	\N	0
1817786775	0	langit	0	2	0	0	0	1	\N	0
6199617175	0	yola	0	3	0	0	0	2	\N	0
6203661564	0	leaving.	0	2	0	0	0	0	\N	0
6772460875	0	song 威尔|	0	2	0	0	0	0	\N	0
5196973522	0	𝐃𝐘 marvelio.	0	5	0	0	0	3	\N	0
6240991145	0	Ejip done diving	0	1	0	0	0	0	\N	0
6285933106	0	lustify	0	57	0	0	0	89	\N	0
1858725782	0	el	0	27	0	0	0	3	\N	0
5701047270	0	yox	0	3	0	0	0	4	\N	0
5943020484	0	zean	0	11	0	0	0	1	\N	0
5559290245	0	gaby	0	3	0	0	0	0	\N	0
6772806019	0	c	0	3	0	0	0	19	\N	0
6296172461	0	lesya	0	6	0	0	0	0	\N	0
1947187900	0	ᴋᴇʏ ɢᴀᴠʀɪᴇʟ	0	87	0	0	40.51000000000015	92	\N	0
6078288420	0	Anka	0	6	0	0	56.270000000000095	1	\N	0
1799545284	0	Ki	0	68	0	0	10.36	101	\N	0
5346757089	0	Cairo Oswald.	0	4	0	0	0	0	\N	0
5371207564	0	kayra	0	3	0	0	0	0	\N	0
5449765001	0	cc	0	0	0	0	0	0	\N	0
6293471643	0	Ferryld J’Kennard	0	1	0	0	0	1	\N	0
6162581355	0	de	0	1	0	0	0	0	\N	0
5469321407	0	oceanblvd	0	3	0	0	0	0	\N	0
6412826738	0	jean	0	6	0	0	0	2	\N	0
1985660167	0	nat 🦖	0	4	0	0	0	1	\N	0
5772476395	0	hannah	0	39	0	0	1535.0900000000001	28	\N	0
5704613144	0	Kenan	0	26	0	0	0	3	\N	0
1601667721	0	Jandia Giriajri.	0	16	0	0	9.86	550	\N	0
5921422382	0	❤️‍🔥	0	5	0	0	0	14	\N	0
6130071810	0	jes	0	1	0	0	0	2	\N	0
5233145369	0	bloom	0	30	0	0	694.4799999999999	227	\N	0
1302822614	0	.	0	12	0	0	0	2	\N	0
1808208261	0	vanyaa	0	25	0	0	390	2	\N	0
5964150599	0	Sanchez	0	65	0	0	0	5	\N	0
6046621947	0	luna	0	72	0	0	-4.279999999999859	215	\N	0
5153658108	0	ashel	0	1	0	0	0	2	\N	0
6211262476	0	GAUSAH GANGGU GUA UTBK. CLOSE YA SAYANG.	0	59	0	0	0	15	\N	0
6007706959	0	yahiko vermi 3pā	0	2	0	0	0	0	\N	0
2095812972	0	Kenandra A.	0	12	0	0	0	0	\N	0
6688132151	0	mika, slow PENDING	0	6	0	0	0	0	\N	0
1955946646	0	🎀	0	52	0	0	9.960000000000008	4	\N	0
1623814116	0	🎀	0	1	0	0	0	0	\N	0
6532961812	0	𝐉emian keyyen	0	0	0	0	0	0	\N	0
6294195676	0	sesil	0	1	0	0	0	0	\N	0
5967489978	0	Luckyrooo	0	0	0	0	0	14	\N	0
6201129656	0	alice	0	23	0	0	53.039999999999964	36	\N	0
5193071665	0	picaa	0	1	0	0	0	0	\N	0
1152868818	0	nabil	0	0	0	0	0	0	\N	0
5307696455	0	.	0	10	0	0	0	84	\N	0
6610099278	0	Will	0	5	0	0	0	0	\N	0
5876580517	0	azealea	10	415	0	0	278.82000000000323	4593	\N	0
5688847659	0	nathea___<	0	1	0	0	0	0	\N	0
1448346606	0	Nino J. Moriarty	12	887	1	0	1848.1500000000005	22244	\N	1
5394496964	0	Erika	0	1	0	0	0	0	\N	0
5506247685	0	Jergard M.	1	6	0	0	655.87	1	\N	0
1899734383	0	Piyaaa	0	2	0	0	0	2	\N	0
2008751413	0	Biana	0	18	0	0	0	1	\N	0
5016245901	0	el	0	1	0	0	0	0	\N	0
5826183341	0	Jax	0	2	0	0	0	0	\N	0
5216373024	0	Zailane, slowrep	0	4	0	0	0	0	\N	0
6314586440	0	shaa	0	8	0	0	0	1	\N	0
5763689723	0	dhawis	0	0	0	0	0	0	\N	0
2052021817	0	R	0	1	0	0	0	4	\N	0
5427621560	0	jexy	0	74	0	0	3446	2	\N	0
6065355845	0	ayi	0	66	0	0	0	9	\N	0
5234786144	0	zetta	0	52	0	0	0	4	\N	0
6057778829	0	Bita.	0	3	0	0	46.61	48	\N	0
1282616576	0	user f	0	1	0	0	0	1	\N	0
6501839505	0	Giksa Open, garansi cek ch	0	7	0	0	0	1	\N	0
6672034942	0	•!ʟꜱ`eja 𝐃Λ.	0	1	0	0	0	3	\N	0
1718131424	0	gabby syg lele	0	80	0	0	936.8	129	\N	0
6061490241	0	jo k/ia	0	6	0	0	0	0	\N	0
1912596924	0	el	0	1	0	0	19.66	37	\N	0
6214298562	0	Nikooo	0	11	0	0	0	11	\N	0
1818110139	0	jena	0	5	0	0	5.9	21	\N	0
1920249202	0	az	0	94	0	0	0	63	\N	0
5438836965	0	kayin	14	139	0	0	1594.1499999999996	18	\N	0
1756454512	0	Bell.	0	2	0	0	0	4	\N	0
6396223664	0	airainn	0	3	0	0	0	3	\N	0
1872343483	0	rie	0	21	0	0	0	6	\N	0
1754255397	0	fajar	0	3	0	0	0	0	\N	0
6237177079	0	bj. k4mal	0	12	0	0	0	10	\N	0
1425287541	0	⾕ ⑅ 𝗡𝗮𝘁𝗮𝘀𝘆𝗮 𖥻𓈒 ᥴᥳȶꫀ ˖⭖֠	0	1	0	0	0	2	\N	0
6016076644	0	Jekay	0	0	0	0	0	0	\N	0
5426983702	0	cas	0	10	0	0	0	11	\N	0
1513923393	0	paus	0	159	0	0	1276.1899999999998	1215	\N	0
6578041790	0	anya.	0	4	0	0	0	3	\N	0
6557969977	0	mary jane.	0	30	0	0	0	1176	\N	0
5683824022	0	.	0	1	0	0	0	0	\N	0
6437348551	0	ayaa	0	22	0	0	0	15	\N	0
1808333647	0	lil `choco Alexander Graham	0	5	0	0	0	7	\N	0
6296109537	0	Fxny	0	11	0	0	0	0	\N	0
6528379043	0	Cavynna??	0	7	0	0	434	1	\N	0
5510641110	0	Malford.	0	0	0	0	726.79	60	\N	0
725895221	0	Daniel	0	1	0	0	0	2	\N	0
2129385580	0	samuel	0	3	0	0	0	4	\N	0
5220784935	0	el	0	6	0	0	0	4	\N	0
865882059	0	ansel	0	1	0	0	0	0	\N	0
6238036406	0	Heidy	0	1	0	0	0	43	\N	0
6974792634	0	N	0	32	0	0	0	13	\N	0
5468133528	0	jeyhaaa	0	21	0	0	0	29	\N	0
6503920687	0	.	0	19	0	0	0	1	\N	0
1903321892	0	Diajeng K. zevoust	0	335	0	0	0	724	\N	0
5219260345	0	papepape	0	130	0	0	14.730000000000102	511	\N	0
1939874948	0	refreshie.	0	752	0	0	12	2101	\N	0
5367443356	0	.	0	6	0	0	58.29	9	\N	0
6480799575	0	kaerav	0	1	0	0	0	9	\N	0
5416057425	0	Jane	0	21	0	0	0	3	\N	0
5455404458	0	.	0	2	0	0	0	1	\N	0
5848863781	0	rafli	0	23	0	0	0	62	\N	0
5148746654	0	Awéka ||MODE IN RUSH nokos	0	5	0	0	0	0	\N	0
6559679465	0	Key	0	0	0	0	0	2	\N	0
7174406154	0	JER.	0	4	0	0	0	166	\N	0
5765777062	0	COCOOO	0	7	0	0	0	4	\N	0
5611556858	0	kael	0	2	0	0	0	17	\N	0
6133377441	0	Valentine Rutheford.	0	7	0	0	0	7	\N	0
6145263118	0	c	0	3	0	0	0	0	\N	0
6197070147	0	Akmal.	0	1	0	0	0	0	\N	0
5840197888	0	rania	0	2	0	0	78	15	\N	0
1426301217	0	Nick'𝖕𝖓𝖝 (On Buat Party)	0	36	0	0	33.97	61	\N	0
5678689272	0	Raina STOP MANGGIL GUA TETEH	6	56	0	0	1979.1899999999998	434	\N	0
6129516141	0	𝐀rshenna, mLs	0	3	0	0	0	1	\N	0
5345425740	0	saa, sfs sudah bisa	0	11	0	0	0	2	\N	0
5535728954	0	Han	0	1	0	0	0	3	\N	0
1050376182	0	e	0	30	0	0	-11	0	\N	0
1979793331	0	shira paul 🍉	7	59	0	0	249.26999999999316	5332	\N	0
2062102189	0	•-•	0	115	0	0	864	2082	\N	0
5407306898	0	Maddy A.	0	1	0	0	0	0	\N	0
5253996029	0	yuu	0	8	0	0	0	1	\N	0
5956289951	0	farel	0	5	0	0	201.28	102	\N	0
1787009772	0	aliaa	0	5	0	0	1000	9	\N	0
6189645898	0	rei	0	125	0	0	1749.24	345	\N	0
5437807716	0	skylar	0	1	0	0	0	0	\N	0
6145706240	0	lily	0	1	0	0	0	0	\N	0
1957667022	0	Fazza	0	20	0	0	0	1	\N	0
5776502398	0	Bulann	0	0	0	0	0	2	\N	0
5018863178	0	¡	0	4	0	0	0	0	\N	0
1250776893	0	obsessed w f1	0	254	0	0	11.51999999999964	5415	\N	0
6981433489	0	Michael H.	0	2	0	0	0	0	\N	0
6010263887	0	ta	0	35	0	0	0	17	\N	0
6751993978	0	Aurora pacar boboiboy	0	1	0	0	0	1	\N	0
5248907621	0	cassie kedua dari @tanjgirou	0	14	0	0	0	9	\N	0
1363757198	0	winonà	0	1	0	0	0	0	\N	0
1753510156	0	isa 155	0	16	0	0	0	0	\N	0
2078689495	0	-	0	1	0	0	0	8	\N	0
6055308027	0	Hihihi : >	0	0	0	0	0	0	\N	0
6439538372	0	cell	0	2	0	0	0	0	\N	0
6838985069	0	mika	0	2	0	0	0	4	\N	0
5885286800	0	tiara	0	2	0	0	0	3	\N	0
6587306430	0	Logout	0	7	0	0	0	0	\N	0
6064224599	0	zara ni cuy	0	3	0	0	0	10	\N	0
2050560661	0	rinnnn	0	3	0	0	0	10	\N	0
6640737299	0	l for lann	0	5	0	0	0	2	\N	0
5420393553	0	zwetya	14	149	0	0	2568.1700000000014	6359	\N	0
5343806743	0	Daphne amora. ♡゙	0	20	0	0	12	9	\N	0
6254844223	0	abi	0	22	0	0	0	13	\N	0
5011211527	0	Brown	0	1	0	0	0	13	\N	0
5082981473	0	rakaa	0	1	0	0	0	0	\N	0
1624657344	0	arthaann	0	5	0	0	0	33	\N	0
1676913010	0	Trivio Filbert.	0	2	0	0	0	20	\N	0
5528362645	0	Lang	0	44	0	0	1297.5	37	\N	0
6260804218	0	arin waduh	0	15	0	0	0	69	\N	0
5649507099	0	p	0	0	0	0	0	0	\N	0
1278482184	0	dalena ( 𝖅༉)	0	6	0	0	0	6	\N	0
5610281439	0	kecAA 💥	0	258	0	0	422.3799999999999	125	\N	0
6445313462	0	D	0	138	0	0	303.85	271	\N	0
6510858640	0	Luna	0	1	0	0	0	3	\N	0
5500748488	0	falelele	0	9	0	0	0	18	\N	0
5144868096	0	🌷 ˑ ִֶ 𓂃⊹	0	93	0	0	282.43	28	\N	0
6134708912	0	cica, 🫥	0	6	0	0	0	29	\N	0
1416381892	0	xi	0	30	0	0	0	61	\N	0
6284890735	0	eca ngejam CLOSE	0	15	0	0	0	20	\N	0
5579817070	0	nana	0	171	0	0	2.919999999999959	576	\N	0
6821692964	0	Denara	0	1	0	0	0	0	\N	0
1774606138	0	mecca.	0	0	0	0	0	27	\N	0
1961287501	0	ana	0	74	0	0	0	133	\N	0
1727623599	0	bel.	0	13	0	0	0	5	\N	0
5407149686	0	Syopidic	0	0	0	0	0	0	\N	0
1860553386	0	R. Rottweiler	0	2	0	0	0	0	\N	0
6157806714	0	Aneisha Yuki	0	1	0	0	0	0	\N	0
5002299606	0	astra	7	86	0	0	2143.5400000000177	788	\N	0
6360060861	0	𐎵᠂⃟ʟsx˚ ꝛɪs ꭙ͢ ᴄᴏʟᴏɴɪʌ̸ʟ¹²⁶⚡	0	1	0	0	0	0	\N	0
1791438016	0	rapaa	0	7	0	0	0	21	\N	0
1399946892	0	graciá	0	1	0	0	0	0	\N	0
5412893832	0	ale	0	10	0	0	0	0	\N	0
1503572072	1	nataaa	0	7	0	0	0	1	\N	0
1991238717	0	agagagagag	0	3	0	0	0	0	\N	0
1689011450	0	kev	0	7	0	0	0	0	\N	0
1741238239	0	ale	0	0	0	0	0	0	\N	0
1858367324	0	a	0	1	0	0	0	0	\N	0
6696834235	0	j	0	1	0	0	0	0	\N	0
1204377886	0	p	0	3	0	0	0	1	\N	0
6756596761	0	ɴꜰꜱᴡ . lili	0	1	0	0	0	0	\N	0
1640093844	0	Jo	0	1	0	0	0	3	\N	0
5825314813	0	hānif 6mild 🇹🇲	0	0	0	0	0	3	\N	0
5996425702	0	aleshá	0	5	0	0	0	3	\N	0
5453080067	0	Audy	0	59	0	0	0	1182	\N	0
6254794057	0	Juergen	0	1	0	0	123.97000000000003	23	\N	0
1243608890	0	Baileeey💨	0	42	0	0	0	714	\N	0
2008742317	0	chae bs	0	5	0	0	0	1	\N	0
1728409392	0	yash	0	64	0	0	894.3199999999999	488	\N	0
6284591215	0	han	0	1	0	0	0	0	\N	0
5408886893	0	zerick	0	54	0	0	66.13000000000011	10	\N	0
6462334710	0	islllllll	0	2	0	0	0	0	\N	0
1182770073	0	Zirra	0	11	0	0	0	10	\N	0
6994377341	0	qs	0	1	0	0	0	0	\N	0
5196516719	0	Cath !3	0	9	0	0	0	1	\N	0
5193191904	0	912 ian pout #𝐏𝐎𝐓𝐄𝐍𝐓𝐈𝐄𝐋𝐒𝟖𝟕𝟏	0	2	0	0	0	0	\N	0
1385362130	0	Sahara.	0	11	0	0	0	23	\N	0
6310264653	0	ecaaa	0	4	0	0	0	0	\N	0
1742900526	0	rbio.rejan - fsr	0	1	0	0	0	4	\N	0
7050859398	0	raorrrr	0	6	0	0	0	0	\N	0
5501823459	0	bbbbb	0	9	0	0	0	0	\N	0
5938793070	0	?	0	280	0	0	5.749999999999972	144	\N	0
5288903768	0	ale ale	0	120	0	0	0	134	\N	0
1699560792	0	le	0	4	0	0	0	2	\N	0
6985217275	0	𝟕𝟗𝟗.Rara	0	1	0	0	0	1	\N	0
1861821753	0	Kapt, Danudirja. @bonjoev	0	1	0	0	0	1	\N	0
5460563318	0	nayaw	0	2	0	0	0	25	\N	0
5090504465	0	Arga	0	7	0	0	0	137	\N	0
2139022951	0	Fino prtma	0	32	0	0	0	49	\N	0
6900670535	0	zeajg	0	3	0	0	0	0	\N	0
5920069696	0	chandra.	0	3	0	0	0	3	\N	0
5573513704	0	111. Belsky pcrnya vicidior	0	63	0	0	1166.22	1242	\N	0
6545141723	0	Safiraa.	0	9	0	0	0	7	\N	0
1863028715	0	njaa	0	4	0	0	0	4	\N	0
6849461135	0	she	0	65	0	0	6.330000000000041	96	\N	0
6248203203	0	Javiero.	0	1	0	0	0	2	\N	0
1883021909	0	valkā	0	7	0	0	0	5	\N	0
1355122438	0	ceisyy	0	204	0	0	55	187	\N	0
7101575948	0	-	0	1	0	0	0	0	\N	0
914235413	0	valenn.	0	1	0	0	0	0	\N	0
5046437170	0	whoo	0	5	0	0	0	15	\N	0
2021720449	0	Anourà	0	3	0	0	0	14	\N	0
5502554340	0	K	0	21	0	0	0	69	\N	0
5244134114	0	chiraa	0	170	0	0	20.779999999999973	234	\N	0
1647472137	0	hanabi	0	9	0	0	0	8	\N	0
1421884653	0	rexa	0	6	0	0	0	5	\N	0
5069662982	0	Kue	0	1	0	0	0	0	\N	0
6225863266	0	stev	0	13	1	0	0	3	\N	0
1270049563	0	Fess	0	1	0	0	0	0	\N	0
1422858440	0	S	0	2	0	0	0	0	\N	0
2063815883	0	rvn	0	1	0	0	0	3	\N	0
1922250076	0	pia. open, slr	0	126	0	0	529.63	878	\N	0
5281220046	0	ocii	0	17	0	0	0	34	\N	0
5275287334	0	anna	0	19	0	0	0	42	\N	0
6422934413	0	Shalea leovarnost	0	12	0	0	6.02	16	\N	0
1930693801	0	Kikoyy	0	2	0	0	0	0	\N	0
1591890240	0	ay	0	1	0	0	0	7	\N	0
6296353508	0	al	7	282	0	0	2530.6600000000035	509	\N	0
1764982077	0	dni	0	6	0	0	0	1	\N	0
5463596326	0	dipaa ꭙ	0	1	0	0	0	0	\N	0
7097529163	0	.. sparkle! <aventurine3	0	2	0	0	0	0	\N	0
5526168093	0	n⋆	0	2	0	0	0	0	\N	0
5733507186	0	kajes	0	73	0	0	215.89999999999998	9	\N	0
1608359107	0	zwe	0	1	0	0	0	0	\N	0
5931300491	0	fio	0	66	0	0	0	13	\N	0
5284263515	0	rest	0	93	0	0	0	14	\N	0
1722457078	0	nanaaa	0	203	0	0	0	402	\N	0
1587615922	0	Akara	0	3	0	0	0	3	\N	0
6301596088	0	j	0	11	0	0	0	12	\N	0
2018030691	0	bryan	0	0	0	0	2.68	8667	\N	0
5037500192	0	Noraa.	0	1	0	0	0	0	\N	0
427723242	0	k	0	2	0	0	0	2	\N	0
5149561286	0	nyet	0	48	0	0	63.05	12	\N	0
5228664875	0	Eric	0	35	0	0	0	0	\N	0
6064710583	0	kalea. @pembealap	0	3	0	0	0	5	\N	0
5591752410	0	Aksa	0	27	0	0	0	14	\N	0
6936665279	0	A	0	1	0	0	500	21	\N	0
6012121258	0	᠆᠆ ✽ Rheamor,	0	246	0	0	9.849999999999909	72	\N	0
1857514219	0	Shuleiya	0	63	0	0	0	8	\N	0
1759634741	0	Ai	0	43	0	0	2.739999999999995	8	\N	0
6138766026	0	cimeng	0	1	0	0	0	9	\N	0
5051192118	0	𝐓𝐑≛𝐏𝐒 ` chii 𝑺𝑵	0	10	0	0	0	144	\N	0
6697577621	0	𝐝𝐫𝐱𝐰.kàryl	0	1	0	0	0	1	\N	0
5204906097	0	..	0	3	0	0	0	0	\N	0
2102871613	0	r	0	38	0	0	0	23	\N	0
5931563568	0	jasonnnnn	0	1	0	0	0	0	\N	0
7125535286	0	rynaa	0	1	0	0	0	2	\N	0
5145246691	0	celine	0	52	0	0	19.430000000000007	3078	\N	0
6203348681	0	julio	0	22	0	0	0	18	\N	0
5313374505	0	biel	0	16	0	0	0	0	\N	0
1590973577	0	Oceana	0	2	0	0	0	1	\N	0
2090920822	0	fio	8	486	0	0	2973.9199999999983	797	\N	0
5142770664	0	nana	0	4	0	0	0	0	\N	0
1771854889	0	al	0	3	0	0	0	1	\N	0
7018207405	0	a	0	2	0	0	0	0	\N	0
1831693617	0	Azka	0	13	0	0	0	18	\N	0
6879937836	0	Ilaa	0	14	0	0	0	1	\N	0
5892037095	0	KArinn!?	0	4	0	0	0	11	\N	0
1874951579	0	𝓐xe	0	43	0	0	0	16	\N	0
7076075083	0	Arèl	0	14	0	0	0	7	\N	0
1709830591	0	Icell	0	2	0	0	0	4	\N	0
5004973699	0	𝕽akatOd	0	1	0	0	0	0	\N	0
5055204309	0	biwa	0	25	0	0	0	22	\N	0
6237644287	0	Isaiah	0	1	0	0	0	0	\N	0
6103139707	0	Fuck Mooi	0	9	0	0	0	1	\N	0
6973591136	0	𝐆𝐑𝟐𝟐ᵀᵉᵃᶜʰᵉʳ 𝕽ʳVankaaaa	0	0	0	0	0	9	\N	0
6932456550	0	cya	0	0	0	0	0	0	\N	0
6097354896	0	asaa	10	19	0	0	696.17	294	\N	0
5802759016	0	flaka	0	53	0	0	549.78	497	\N	0
6252982840	0	Jo	0	1	0	0	0	45	\N	0
5842131586	0	Selena	0	30	0	0	0	11	\N	0
1753039242	0	KEYLaa	0	1	0	0	0	0	\N	0
5860772864	0	༆𝚠𝚕𝚜`ᴀ‌ᴘ‌ʀ‌ᴅ‌›‌ ovk 𝐦𝐢𝐤𝐞𝐥𝐥 [𝐒𝐕𝐇𝟑𝟏]ᴰ³ ˊˎ- lstify	0	47	0	0	0	29	\N	0
5457663241	0	Percy Jackson	0	3	0	0	0	0	\N	0
6086896897	0	karin	0	12	0	0	3.280000000000001	7	\N	0
5272470477	0	bey	0	0	0	0	0	0	\N	0
5651954296	0	Faye	0	24	0	0	0	62	\N	0
1125317740	0	Michelle	0	3	0	0	0	0	\N	0
6002157964	0	osya	0	1	0	0	0	0	\N	0
5724037766	0	Xander	0	5	0	0	0	0	\N	0
5643708360	0	Nico.	0	5	0	0	0	252	\N	0
7166569699	0	glez 🍓	0	3	0	0	0	4	\N	0
1480776936	0	kazura	0	9	0	0	0	38	\N	0
5508233351	0	bukan meimeii 👧🏻	0	1	0	0	0	1	\N	0
996777718	0	ryua	0	18	0	0	0	3	\N	0
1613539700	0	Bian	0	114	0	0	0	1796	\N	0
5694270257	0	💀	0	13	0	0	519.91	171	\N	0
1897226699	0	piwaa	12	76	0	0	5527.330000000002	800	\N	1
5429886774	0	k	0	3	0	0	0	0	\N	0
5018703824	0	iw	0	36	0	0	0	25	\N	0
1963810895	0	nauu	0	1	0	0	0	0	\N	0
6686773058	0	೫➛kudanil	0	1	0	0	0	17	\N	0
1883498212	0	biya	0	18	0	0	0	97	\N	0
1107973308	0	.	0	3	0	0	0	0	\N	0
5022494378	0	Ameyra	0	10	0	0	0	0	\N	0
5951333590	0	Yegachiyakaka	0	28	0	0	0	0	\N	0
1712824906	0	olaf ⛄️	0	108	0	0	3114.57	187	\N	0
5001069398	0	nad	0	2	0	0	0	4	\N	0
6742703958	0	𝐃¹㍿ . vei	0	72	0	0	500	29	\N	0
5616637086	0	rest dl	0	8	0	0	0	5	\N	0
1634022853	0	nini_	0	0	0	0	0	0	\N	0
1808614372	0	⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣	0	7	0	0	0	3	\N	0
6375666533	0	Fiyca	0	0	0	0	0	0	\N	0
5393646142	0	raela , pending	0	11	0	0	0	2	\N	0
5741750128	0	nayaraa	0	24	0	0	0	1	\N	0
1817564991	0	mikasa	13	321	0	0	7870.619999999999	1009	\N	0
2131119567	0	ziǝlɑ kull girl	0	26	0	0	0	2	\N	0
7040483705	0	ram	0	1	0	0	0	0	\N	0
6379500449	0	Rama👩🏻‍🎤	0	10	0	0	0	4	\N	0
5338267023	0	Hermes M.	0	5	0	0	0	13	\N	0
5933557722	0	kenn	0	10	0	0	0	12	\N	0
1636225353	0	k	0	22	0	0	0	2	\N	0
5000633346	0	yaya	0	1	0	0	0	0	\N	0
6394700698	0	ʜᴀɴꜱᴇɴ	0	3	0	0	0	0	\N	0
5287970650	0	𝐃Λ. sam	0	20	0	0	0	8	\N	0
5615514092	0	Canva	0	18	0	0	100.32000000000001	102	\N	0
1942584714	0	cAyyies	0	211	0	0	805.2800000000003	921	\N	0
1630921412	0	j	0	81	0	0	0	43	\N	0
1558654769	0	ㅤ nAyya?!!	0	63	0	0	0	5	\N	0
1954993568	0	.	0	1	0	0	0	0	\N	0
5049919968	0	Rbio. kia	0	15	0	0	0	21	\N	0
1817488355	0	Uzumaki Akem	0	0	0	0	0	7	\N	0
2065454451	0	zozo	0	31	0	0	0	0	\N	0
7026615752	0	reg	0	1	0	0	0	0	\N	0
1740563021	0	Mada	4	150	0	0	14616.290000000006	23226	\N	0
1006669493	0	axi redfield	0	1	0	0	0	1	\N	0
5103388185	0	69	0	1	0	0	0	1	\N	0
5451148237	0	prj.ftr	0	1	0	0	0	2	\N	0
1615679119	0	Sarah꣹۫🐰🎀₊ ˚	0	1	0	0	0	0	\N	0
1855031833	0	Abizar	0	3	0	0	0	2	\N	0
6208437541	0	Ian	0	5	0	0	0	7	\N	0
6257264036	0	iiiiiii	0	18	0	0	0	6	\N	0
5825528213	0	🅰️len	0	5	0	0	0	4	\N	0
1390101549	0	Tyra	0	3	0	0	0	0	\N	0
5310519561	0	lolz	0	15	0	0	0	45	\N	0
5497331186	0	z	0	29	0	0	137.23	95	\N	0
6793978425	0	Hana	0	21	0	0	0	17	\N	0
1745360906	0	rest 🪧	0	1	0	0	0	1	\N	0
5455496245	0	cacacacaca🐋	0	32	0	0	10.42	113	\N	0
5885157168	0	jo;)	0	1	0	0	0	0	\N	0
1806711890	0	nayara	0	657	0	0	488.56999999999994	522	\N	0
1728129047	0	Ale (Beli akun)	0	1	0	0	0	0	\N	0
1805604765	0	ror	0	2	0	0	0	0	\N	0
1120405841	0	yaya	0	4	0	0	0	3	\N	0
5390623392	0	moli	1	6	0	0	24.05	62	\N	0
5446848961	0	𝓢𝓯𝓼 J. fwrs²¹ᴬᴴ	0	4	0	0	2302.71	17	\N	0
1241319516	0	Daa who?	0	0	0	0	0	7	\N	0
6109225466	0	njuuu	0	91	0	0	5.480000000000004	58	\N	0
1929598379	0	.	0	10	0	0	0	0	\N	0
5304573263	0	saf	0	17	0	0	0	0	\N	0
5829263573	0	nicollá	0	75	0	0	0	305	\N	0
1414021302	0	n	0	75	0	0	226.57000000000005	520	\N	0
5060697797	0	Ninaa	0	10	0	0	269.2	129	\N	0
6294119781	0	gsh sfs an klo unsubs ajg.	0	1	0	0	0	0	\N	0
1415057058	0	Noxious	0	1	0	0	0	32	\N	0
1559047448	0	Ethernal D.	0	0	0	0	0	0	\N	0
1617120520	0	aping	0	49	0	0	122.49	9	\N	0
1564409492	0	absen 6	0	2	0	0	0	0	\N	0
6113263882	0	prancisss	0	196	0	0	4682.67	168	\N	0
1843063765	0	aka	0	1	0	0	0	0	\N	0
5565493958	0	-	0	35	0	0	0	0	\N	0
2135163595	0	☁️	0	13	0	0	0	0	\N	0
5094324778	0	Mal.	0	516	0	0	13.39	178	\N	0
6005061379	0	sha	0	19	0	0	31.82	191	\N	0
6299421182	0	Xara	0	1	0	0	0	3	\N	0
1858067495	0	ㅤㅤ	0	53	0	0	615.1999999999998	359	\N	0
5346421373	0	Norio	0	11	0	0	0	9	\N	0
1719112767	0	falyreia.	0	9	0	0	0	5	\N	0
1605550286	0	B10. Anin	0	0	0	0	0	0	\N	0
5073702566	0	Ehtisham ōtsuki	0	0	0	0	0	0	\N	0
6425804041	0	cibeeyy	0	6	0	0	0	59	\N	0
6133018509	0	syel	0	2	0	0	0	0	\N	0
6253190390	0	fvxy	0	0	0	0	0	0	\N	0
2131734276	0	feii 𖹭	0	134	0	0	189	25	\N	0
6136175375	0	dick y	0	4	0	0	0	4	\N	0
5895689612	0	abi	0	9	0	0	0	3	\N	0
6278821305	0	papi rigèl	0	5	0	0	0	19	\N	0
5667044869	0	Ravancy	0	1	0	0	0	0	\N	0
1351427375	0	novi	0	136	0	0	13.32	12	\N	0
6369760270	0	keira	0	13	0	0	0	9	\N	0
5255821699	0	192 jian	0	6	0	0	0	11	\N	0
6575505373	0	CARLOS.	0	14	0	0	0	250	\N	0
5233236773	0	Lusi	0	142	0	0	166	21	\N	0
6070715403	0	kevin	0	14	3	0	0	14	\N	0
1975713304	0	Frisca ://	0	10	0	0	0	156	\N	0
5795668756	0	b	0	37	0	0	0	6	\N	0
2132315865	0	:pp ayennnn	0	2	0	0	0	0	\N	0
5659631330	0	kiyo in dda happy mood	0	5	0	0	0	0	\N	0
6033886138	0	Crapslock°	0	30	0	0	25.049999999999997	14	\N	0
1930705278	0	ᥣׁׅ֪ᨵׁׅꭈׁׅꫀׁׅܻꪀׁׅ ☁️	0	56	0	0	173.96999999999997	454	\N	0
1378716225	0	anya	0	6	0	0	0	0	\N	0
6340566062	0	trixie	0	1	0	0	64.62999999999988	40	\N	0
1980018039	0	asha	0	6	0	0	0	0	\N	0
6556076363	0	Raa	0	9	0	0	0	52	\N	0
5052362212	0	Gerrard Agares	0	5	0	0	0	138	\N	0
1955812333	0	io	0	8	0	0	21.32	44	\N	0
2002853682	0	who	0	14	0	0	0	11	\N	0
6194342966	0	DELLNANZ	0	1	0	0	0	4	\N	0
7017260675	0	pocha	0	10	0	0	0	44	\N	0
6922327820	0	gisselle	0	1	0	0	0	0	\N	0
1710507292	0	c	0	208	0	0	446.59999999999997	43	\N	0
2004561305	0	mikayrie :0	0	2	0	0	0	0	\N	0
1729781446	0	Rara	0	1	0	0	0	0	\N	0
1223112499	0	Muhammad	0	4	0	0	0	10	\N	0
1928548027	0	m	0	24	0	0	0	0	\N	0
1739064180	0	Cath	0	1	0	0	0	0	\N	0
6746414914	0	yayaa.	0	2	0	0	0	0	\N	0
1717215377	0	f.	0	2	0	0	0	0	\N	0
5862690829	0	bulan	0	29	0	0	0	16	\N	0
1504426345	0	Sya	0	0	0	0	0	0	\N	0
6570276208	0	nazuuu	0	1	0	0	0	1	\N	0
1634404246	0	Langit. #ᗪᑎᒪՏ ˢʷ¹⁸ ²¹⁺	0	31	0	0	46	20	\N	0
6354008803	0	Jemma Twyla	0	5	0	0	0	2	\N	0
5050266321	0	danielle	0	1	0	0	0	1	\N	0
1760433360	0	hi	0	10	1	0	0	1	\N	0
2060337621	0	Christian Yu's Favourite, Rue!	0	15	0	0	0	1763	\N	0
1934294642	0	Gabby	0	1	0	0	0	0	\N	0
5338773563	0	Leleine 🐬	0	4	0	0	0	20	\N	0
1799670379	0	awa akun satunya limit	0	1	0	0	0	1	\N	0
5376572798	0	gre	0	1	0	0	0	0	\N	0
5049884997	0	Rvyn?	0	2	0	0	0	6	\N	0
6096550162	0	DIEGO	0	7	0	0	0	0	\N	0
1762378819	0	oy¡p ૮ - ﻌ - ა	0	0	0	0	0	0	\N	0
5768748406	0	Kai	0	26	0	0	0	12	\N	0
1947503945	0	Zaniel.	0	5	0	0	0	176	\N	0
6399020655	0	L	0	1	0	0	0	0	\N	0
1984056934	0	disha	0	1	0	0	0	1	\N	0
6678443954	0	♡𝆬‌ ︩︪ꔫ ayaa ୧ ׄׄ 𝅄 ⛅️🎀 ׅ	0	0	0	0	0	0	\N	0
1883311441	0	vel	0	2	0	0	0	0	\N	0
7148508172	0	monyet	0	2	0	0	0	0	\N	0
5610580167	0	dhipa	9	838	0	0	3355.9499999999985	842	\N	1
5004511162	0	gleadis'c	14	77	0	0	51.35	3	\N	0
1159621404	0	j	0	1	0	0	0	2	\N	0
6515621524	0	karel	0	0	0	0	0	0	\N	0
6815459816	0	k	0	1	0	0	0	0	\N	0
5867505750	0	alis(a)	0	1	0	0	0	0	\N	0
1640712519	0	_	0	7	0	0	0	0	\N	0
1785482133	0	bbi	0	2	0	0	0	0	\N	0
1082310532	0	🦋✨️	0	1	0	0	0	0	\N	0
1798376137	0	ꪀׁׅɑׁׅ֮zׁׅ֬ꫀׁׅܻᥣׁׅ֪ɑׁׅ֮	0	1	0	0	0	0	\N	0
1985168600	0	Awrin	0	2	0	0	0	0	\N	0
1731296044	0	ㅤ	0	234	0	0	61	166	\N	0
6777492765	0	H	0	1	0	0	0	0	\N	0
6518747157	0	ᥲуᥲᥒᥲᥲ ᥲᥣzᥱrᥲ	0	0	0	0	0	0	\N	0
1187368829	0	el	0	7	0	0	0	1	\N	0
5062788416	0	bintang	0	419	0	0	393.76000000000045	348	\N	0
1707149267	0	It's Me	0	3	0	0	0	10	\N	0
5865938054	0	218,	0	1	0	0	0	0	\N	0
1496730970	0	SssOofft	12	25	0	0	15.760000000000048	32	\N	0
5403945190	0	Abrhm	11	506	1	0	2798.3799999999997	138	\N	1
1895423513	0	Nand	0	21	0	0	0	0	\N	0
6684118794	0	elana	0	1	0	0	0	1	\N	0
6181409416	0	suaaa	0	0	0	0	0	0	\N	0
5968393574	0	Mine	0	59	1	0	104.91	115	\N	0
5588199967	0	azora	0	13	0	0	0	13	\N	0
5401562823	0	aselewoeoweow	0	15	0	0	0	63	\N	0
6684205306	0	kitty♡	0	4	0	0	0	2	\N	0
1182337611	0	𝐿𝒶𝓁𝒶	0	13	0	0	0	1	\N	0
5476380560	0	isllll	0	7	0	0	0	0	\N	0
5374917188	0	mooow	0	1	0	0	0	0	\N	0
6661088676	0	meiska	0	0	0	0	0	0	\N	0
5070895701	0	Harsa B	0	3	0	0	0	0	\N	0
5214541694	0	ɑׁׅ֮ᯅ	0	5	0	0	0	2	\N	0
5407884072	0	David Pierre	0	190	0	0	0	182	\N	0
1823102220	0	JoJa	0	2	0	0	10000	48	\N	0
6572176560	0	Dera	0	5	0	0	0	9	\N	0
5355963766	0	el lelah	0	3	0	0	0	0	\N	0
6225914994	0	5’Nakendrá	0	1	0	0	0	0	\N	0
996509519	0	Jiyel	0	3	0	0	0	0	\N	0
5542022132	0	toji	0	11	0	0	0	54	\N	0
6113542043	0	slctv. Damian	0	132	0	0	2	5	\N	0
6607256457	0	jihanna	0	1	0	0	0	0	\N	0
1926358191	0	Déhan	0	3	0	0	0	378	\N	0
1530577991	0	Owen	0	19	0	0	240	591	\N	0
1924732992	0	bi.	0	16	0	0	0	108	\N	0
1389713763	0	U D I N	0	0	0	0	0	0	\N	0
1195639013	0	zhxieel	0	18	0	0	0	10	\N	0
6139780929	0	zaeraaa	0	0	0	0	0	0	\N	0
2075486733	0	Inactive.	0	5	0	0	0	0	\N	0
1812608317	0	meow	0	1	0	0	0	0	\N	0
5935332470	0	𝕊𝕖𝕢𝕦𝕠𝕚𝕒🍒	0	236	0	0	553.44	454	\N	1
5851411320	0	Y	0	1	0	0	0	1	\N	0
1790374008	0	bb. loanjingdg	0	11	0	0	370.48	14	\N	0
6657202633	0	kasheera	0	29	0	0	0	46	\N	0
5862688711	0	vara	0	14	0	0	0	0	\N	0
6263534013	0	765 pepeyyyyy	0	6	0	0	0	7	\N	0
1893266673	0	sand	0	30	0	0	260.61	22	\N	0
5325800826	0	cea	0	2	0	0	0	0	\N	0
5357770669	0	프리마	0	31	0	0	279.83	45	\N	0
1808614916	0	fttt	0	84	0	0	43.04	28	\N	0
6362214632	0	bim	0	8	0	0	0	5	\N	0
1821844777	0	nay	0	0	0	0	0	0	\N	0
6431449751	0	s	0	25	0	0	11.25	49	\N	0
1705983728	0	EvilBoyy	0	17	0	0	3.56	24	\N	0
2105230672	0	miaw —	0	39	1	0	604.48	43	\N	0
1941582523	0	alara`cvs²	0	20	0	0	0	181	\N	0
1369455222	0	Char	0	18	0	0	0	12	\N	0
6199895718	0	imut lucu dan bergizi	0	5	0	0	0	1	\N	0
1597629121	0	Kayyara	0	4	0	0	0	329	\N	0
5483656685	0	Ama	0	14	1	0	15.55	1	\N	0
1974015019	0	C	0	7	0	0	0	4	\N	0
1772423776	0	elsyara	0	1650	0	0	813.5199999999995	687	\N	0
6772160679	0	🕷	0	2	0	0	0	0	\N	0
1192861233	0	Darrel	0	0	0	0	0	0	\N	0
1448815281	0	A	0	1	0	0	0	0	\N	0
6991828450	0	adell sinyal lowbet✌🏻✌🏻	0	2	0	0	0	0	\N	0
1266096294	0	l	0	12	0	0	0	8	\N	0
5576874055	0	kiara	7	1066	0	0	11.039999999999566	5129	\N	0
5312801419	0	namaku liyaa	0	10	0	0	0	37	\N	0
5006167096	0	adan	0	1	0	0	0	5	\N	0
6950036359	0	46. Kaikoura	0	5	0	0	0	1	\N	0
1925397780	0	grey	0	4	0	0	0	5	\N	0
5725251081	0	Rad	0	2	0	0	0	0	\N	0
6248092464	0	Neda(la) Heloise.	0	4	0	0	0	28	\N	0
7039750950	0	cewek cakep #CALMINRLEE	0	2	0	0	0	3	\N	0
1877795080	0	Crushyouu	0	2	0	0	0	2	\N	0
5050567853	0	Ralio.	0	2	0	0	334.24	64	\N	0
2036242968	0	jek salimawikky B10	0	264	0	0	34.58	119	\N	0
5471482116	0	157. gavini sadérx 🇹🇲	0	12	0	0	0	34	\N	0
1674945124	0	Asha	0	0	0	0	0	0	\N	0
5721609591	0	cila	0	3	0	0	0	0	\N	0
1612275701	0	arshana	0	0	0	0	0	0	\N	0
1866015222	0	Almahyra.	0	8	0	0	0	4	\N	0
5045686592	0	la	5	382	0	0	380.74000000000024	524	\N	0
1930748668	0	rayhan	0	51	1	0	0	58	\N	0
5770969920	0	naa🐢	0	0	0	0	0	9	\N	0
2134478776	0	kallei mw jadi fiksi	0	4	0	0	0	21	\N	0
1828332398	0	malya	0	36	0	0	35.68000000000012	27	\N	0
1701349713	0	Elmeca Kabylette	0	2	0	0	0	0	\N	0
1653366800	0	Sabina	0	3	0	0	0	0	\N	0
5769484454	0	Kailee.	0	156	0	0	0	139	\N	0
1872595469	0	Okha	0	5	0	0	0	1	\N	0
5625157270	0	radis	9	591	0	0	1222.4699999999998	1342	\N	0
902108366	0	kathleen monroe.	0	1	0	0	0	5	\N	0
1638928641	0	nayv	0	6	0	0	0	9	\N	0
5783849142	0	F......	0	4	0	0	0	1	\N	0
2052260539	0	Athena	0	717	0	0	277.42999999999984	4594	\N	0
5190865285	0	.	0	59	0	0	5	21	\N	0
1770041542	0	Deacon B.	14	16	0	0	189.94	235	\N	0
6271042136	0	bibill	0	8	0	0	56	19	\N	0
6713397078	0	s444	0	9	0	0	2000	21	\N	0
5069397116	0	Lala.	0	50	0	0	0	93	\N	0
5241183909	0	Nowel	0	3	0	0	0	5	\N	0
1918088305	0	sweetpancake	0	2	0	0	0	2	\N	0
1974015590	0	je	0	1	0	0	0	2	\N	0
5997862443	0	꒰ ♡ ꒱ ✧	0	3	0	0	0	19	\N	0
1330172075	0	raa	13	159	0	0	6799.209999999998	354	\N	0
5176199534	0	raph maw coklat	0	221	0	0	0	436	\N	0
6302161918	0	𖦁ׅ ࣪ ׂ 𝓡𝓮𝓲𝔃𝓾灵津ᴴᴸمبت៵ 🐇 ࣪ ִֶָ ⋆𓍢 ִ ໋🌷 ִֶָ 𖥔 ࣪˖	0	8	0	0	0	9	\N	0
2091721436	0	Lala cuantiq nan imoet	0	1	0	0	0	1	\N	0
2110898621	0	laaa.	0	33	0	0	1446.7499999999998	101	\N	0
1730003284	0	bob	0	2	0	0	0	1	\N	0
5618452396	0	chamy	0	6	0	0	0	8	\N	0
6439494336	0	.	0	5	0	0	0	0	\N	0
2143612330	0	h	0	12	0	0	0	0	\N	0
6179624283	0	jeno's pretty kitten, karin #OPMEMVK	8	528	1	0	326.9999999999887	1084	\N	0
6336037304	0	Evi	0	25	0	0	0	12	\N	0
6568986986	0	millie	0	1	0	0	0	8	\N	0
5361584670	0	NYrs	0	1	0	0	0	0	\N	0
5999682542	0	chy	0	0	0	0	0	1	\N	0
5186622045	0	.	0	4	0	0	0	5	\N	0
5088906114	0	zee	0	2	0	0	0	1	\N	0
1605453136	0	key	0	2	0	0	0	21	\N	0
7002274968	0	gatau	0	2	0	0	0	2	\N	0
5620669119	0	Riasha sabreena	0	64	0	0	15	141	\N	0
1821437984	0	Ryusei Shido.	6	942	0	0	8.169999999999959	247	\N	0
6092384454	0	jesa	2	71	0	0	1079.9499999999994	4927	\N	0
1795893673	0	Maverick M.	0	9	0	0	0	7	\N	0
1788595548	0	dise	0	2	0	0	0	20	\N	0
1888797020	0	hujan	0	37	0	0	0	76	\N	0
6682425087	0	Zie	0	1	0	0	0	0	\N	0
5027967771	0	Arista	0	38	0	0	0	265	\N	0
1773770267	0	chindii	0	0	0	0	0	0	\N	0
5868601785	0	sa	0	3	0	0	0	0	\N	0
5002359346	0	🍒	0	8	0	0	679.02	217	\N	0
6493080709	0	abcczvd	0	14	0	0	0	17	\N	0
5800220416	0	????	0	2	0	0	0	10	\N	0
1970289328	0	nolá	0	15	0	0	0	0	\N	0
1407757002	0	Anindya	0	73	0	0	0	17	\N	0
1932770968	0	Dni	0	1	0	0	0	0	\N	0
1718781284	0	zouu sbux,,,	0	0	0	0	0	1	\N	0
1026206207	0	forger	0	1	0	0	0	3	\N	0
5565295105	0	dudul	0	3	0	0	0	0	\N	0
1776676360	0	Amina Hele.	0	27	0	0	629.7600000000001	1070	\N	0
1903187076	0	elgar.	0	1	0	0	0	0	\N	0
2095169493	0	violet	0	6	0	0	0	18	\N	0
5685460546	0	Kalednra.	0	6	0	0	0	1	\N	0
6175002007	0	mixue`	0	1	0	0	0	1	\N	0
5369859095	0	K	0	6	0	0	9000	0	\N	0
5718036723	0	Eden.	0	3	0	0	0	1	\N	0
1418942260	0	saski	0	5	0	0	0	3	\N	0
2076093510	0	𝐓𝐑≛𝐏𝐒 Ragas	0	1	0	0	0	25	\N	0
6904570270	0	lynna	0	6	0	0	0	8	\N	0
5861272664	0	ian disini	0	2	0	0	0	1	\N	0
1632727233	0	jejee	0	5	0	0	0	377	\N	0
2074340442	0	H	0	2	0	0	0	0	\N	0
5365795153	0	sierra	0	17	0	0	0	29	\N	0
7030754323	0	Asha	0	3	0	0	0	0	\N	0
5505507811	0	tmrw	0	29	0	0	1104.1399999999999	14	\N	0
5626749337	0	ipenn ᴀʀᴄʜᴀɴɢᴇʟs	0	2	0	0	0	11	\N	0
5581192429	0	Sera A.	0	46	0	0	410.89	150	\N	0
6018514830	0	adit	0	10	0	0	0	1	\N	0
1423237705	0	lala #fake pm jing	0	28	0	0	0	0	\N	0
5427948128	0	h	0	2	0	0	0	20	\N	0
5475244604	0	Rayden.	0	18	0	0	2.2200000000000273	54	\N	0
5694794310	0	nakayya loanjing ℬ4₲🇦🇱⁴	0	23	0	0	0	0	\N	0
5641324822	0	El.	0	1	0	0	0	0	\N	0
1813802022	0	i dunnoo	0	19	0	0	0	2	\N	0
5863346118	0	aca, dni	0	944	0	0	-3.669999999999618	3320	\N	0
6605290492	0	.	0	4	0	0	0	0	\N	0
6760233577	0	ara	0	1	0	0	0	1	\N	0
1797320387	0	C/BA pina	0	30	0	0	0	12	\N	0
6945330171	0	a	0	2	0	0	0	0	\N	0
6244891078	0	its bell	0	1	0	0	0	0	\N	0
1617842629	0	iyang	0	1	0	0	0	0	\N	0
5188190083	0	sha	0	135	0	0	612.84	675	\N	0
1634013081	0	࣪˖ ִֶָ𐀔 miawggie @jROBlN 🎀	0	155	0	0	340.45000000000005	215	\N	0
1678945551	0	Mira	0	0	0	0	0	2	\N	0
5890132984	0	bie ( taylor's version )	0	4	0	0	1154.42	0	\N	0
2115510403	0	ビュー	0	26	0	0	0	56	\N	0
5352861105	0	ᅠ	0	1	0	0	0	0	\N	0
6606623752	0	Dey	0	3	0	0	0	0	\N	0
6780085230	0	racheellynn	0	3	0	0	0	3	\N	0
5137372687	0	adii	0	0	0	0	0	5	\N	0
5374576300	0	jessie	0	6	0	0	15	5	\N	0
1867513700	0	💟🛼.♡𝗥𝗔𝗠𝗨𝗗𝗔:𝟥 !! @ramudaZ	0	14	0	0	0	3	\N	0
1566395062	0	rira little pony lagi	0	15	0	0	0	3	\N	0
6963355819	0	Ley (klik link di bio dulu	0	0	0	0	0	0	\N	0
5063626292	0	Gia’s feeling unmood	0	202	0	0	6.510000000000446	176	\N	0
5844356250	0	umi aleni	0	84	0	0	0	28	\N	0
5489583372	0	siput	0	1	0	0	0	0	\N	0
5848654988	0	reaa	0	9	0	0	51.06	6	\N	0
5667973556	0	naka	0	5	0	0	0	1	\N	0
1723531449	0	tala	0	2	0	0	0	0	\N	0
799383777	0	bylen	0	7	0	0	0	4	\N	0
5222588911	0	Joves D.	0	23	0	0	0	8	\N	0
6251191019	0	ryina	0	3	0	0	0	0	\N	0
2099311194	0	Sabiel, ain’t replying	0	1	0	0	0	0	\N	0
2002906669	0	abEEd	0	10	0	0	0	2	\N	0
861593383	0	Fandi	0	3	0	0	0	5	\N	0
6363589997	0	z	0	1	0	0	0	0	\N	0
6336840646	0	K	0	26	0	0	229.89999999999998	88	\N	0
5018872216	0	jiaa	0	1	0	0	0	0	\N	0
6241233182	0	arkan	0	4	1	0	0	0	\N	0
6204237143	0	Issa	0	4	0	0	0	1	\N	0
6992528204	0	読む, C.	0	1	0	0	0	0	\N	0
1658765343	0	Reiga 𝕽ʳ	0	6	0	0	0	19	\N	0
1753725863	0	eleena	0	10	0	0	0	3	\N	0
5092922619	0	neaᵏᵈᵒ	0	4	0	0	0	0	\N	0
1846695469	0	k	0	7	0	0	0	2	\N	0
1853808706	0	xx	0	6	0	0	0	0	\N	0
6013397899	0	C, Ame.	0	1	0	0	0	0	\N	0
1790003631	0	K.	0	1	0	0	0	0	\N	0
1944214973	0	bbbblaire	0	8	0	0	0	10	\N	0
5963837871	0	nayaa	0	14	0	0	0	2	\N	0
1774943253	0	heney	0	1	0	0	0	0	\N	0
6218885543	0	K. @lHoshinoAi	0	4	0	0	336.23	187	\N	0
6286816031	0	abi	0	0	0	0	0	3	\N	0
6039043923	0	vel	0	84	0	0	0	9	\N	0
1944568360	0	leaving for a while	0	3	0	0	0	0	\N	0
1925092381	0	Elloise	0	4	0	0	0	9	\N	0
5059588472	0	baby	0	2	0	0	0	1	\N	0
6085597049	0	b	0	2	0	0	0	1	\N	0
1723765315	0	someone	0	4	0	0	0	4	\N	0
5510670409	0	Ell	0	8	0	0	0	3	\N	0
1801214434	0	6 hari terakhir prem, Dg.	0	16	0	0	0	78	\N	0
1715223251	0	edis	0	15	0	0	691	61	\N	0
7074708917	0	nael	0	1	0	0	0	0	\N	0
1455060161	0	raysya	0	2	0	0	0	3	\N	0
1671307759	0	jenOo	0	0	0	0	0	6	\N	0
6925785800	0	floryn!	0	1	0	0	0	0	\N	0
1670743488	0	Ur Favorite Boy	0	3	0	0	0	7	\N	0
6226435700	0	Valee(y)	0	2	0	0	956	3	\N	0
5227130998	0	628. jeano close	0	61	0	0	0	8	\N	0
6027593668	0	luka.	0	4	0	0	0	11	\N	0
6478489361	0	anjaniww	0	3	0	0	0	2	\N	0
1235572524	0	agatha, c	0	7	0	0	0	1	\N	0
2079304363	0	van	4	690	0	0	1152.11	9	\N	0
7058346639	0	len	0	2	0	0	0	1	\N	0
6073101714	0	cry	0	21	1	0	0	8	\N	0
5765217242	0	n	0	77	0	0	155.87999999999994	27	\N	0
2053238924	0	tataa #CALMEMBNEBSTONE	0	25	0	0	0	96	\N	0
1185130639	0	᥅ꫀׁׅܻ ꩇׁׅ݊ϐׁׅ֒υׁׅᥣׁׅ֪ɑׁׅ֮ꪀ	0	1	0	0	0	2	\N	0
5970379308	0	kalila	0	4	0	0	0	0	\N	0
1901441447	0	Alice	0	5	0	0	0	49	\N	0
5711574978	0	J	0	10	0	0	0	2	\N	0
5735881263	0	nayaa	0	2	0	0	0	0	\N	0
1941455823	0	𝐒elynd	0	6	0	0	0	22	\N	0
7121967472	0	𝐓𝐑≛𝐏𝐒 ` Naa	0	0	0	0	0	0	\N	0
1830640724	0	exzel	0	1	0	0	0	0	\N	0
6912864337	0	mellow	0	1	0	0	0	2	\N	0
1207650450	0	A	0	1	0	0	0	1	\N	0
5694534779	0	t	0	1	0	0	0	0	\N	0
5764478472	0	pelis jawab pesanku	0	44	0	0	62.57000000000002	29	\N	0
5274920577	0	Railyy	5	28	0	0	32.31000000000017	95	\N	0
1713229330	0	zky	0	6	0	0	0	0	\N	0
5912197507	0	elga spiderwomen	0	1	0	0	0	3	\N	0
1378492680	0	lora suka ngewink,makannya dapet winkwink	0	1	0	0	0	0	\N	0
6721452495	0	.	0	2	0	0	0	0	\N	0
5320560225	0	muthia	0	85	0	0	0	58	\N	0
7184010150	0	rez piscat	0	0	0	0	0	0	\N	0
6499057475	0	yeabro	0	54	0	0	0	267	\N	0
5835279595	0	meh ʳʳʷ	0	6	0	0	0	0	\N	0
5814984521	2	al	0	9	0	0	0	0	\N	0
6615680010	0	(5) lolla (gausa curang, mentang" subs lu byk tolol)	8	105	0	0	1741.5299999999997	87	\N	0
5837124338	0	karina	0	5	0	0	0	13	\N	0
1919158416	0	Isheyla	0	532	0	0	0	131	\N	0
2030822960	0	feyy	0	9	0	0	0	6	\N	0
1802718445	0	Michièlā Z	0	3	0	0	0	2	\N	0
6708112113	0	vajora	0	7	0	0	0	0	\N	0
1998097054	0	jeki	0	16	0	0	0	0	\N	0
6679135516	0	hah?	0	8	0	0	0	4	\N	0
6539552898	0	𐙚kiran #studyacc	0	18	0	0	283.82	970	\N	0
1300273601	0	Pancakes	0	24	0	0	0	108	\N	0
1843683062	0	zi	0	4	0	0	0	11	\N	0
1910067899	0	百合花 🦊	0	20	0	0	1003.3199999999999	728	\N	0
6202650054	0	Amaia.	0	3	0	0	0	0	\N	0
6208948095	0	zeyra	0	34	0	0	4.5	8	\N	0
6788287223	0	by	0	10	0	0	0	3	\N	0
5929645222	0	ai	0	2	0	0	0	1	\N	0
2070769755	0	c	0	7	0	0	0	0	\N	0
2116561043	0	— ärin	0	19	0	0	0	8	\N	0
6012949383	0	NANA OPEN VIP ᪣⃔͜҉̥⁩𝙾𝙳𝚈𝚂¹⁸⁺	0	0	0	0	0	0	\N	0
5858672926	0	Madam Olive	0	1	0	0	0	0	\N	0
2143580100	0	xny	0	1	0	0	0	0	\N	0
1880587040	0	Rãka A. Scot @TEAM0RAKA	0	5	0	0	0	0	\N	0
6171321355	0	drickk.bøcriz	0	1	0	0	0	0	\N	0
1815375704	0	ChevAaAAaaAAaA	0	2	0	0	0	9	\N	0
1899477715	0	caca??!!	0	2	0	0	0	0	\N	0
1949130630	0	iaa	0	0	0	0	0	320	\N	0
1719428648	0	dawn.	0	1	0	0	0	6	\N	0
5677512213	0	moana	0	4	0	0	0	128	\N	0
5219636024	0	Raii	0	2	0	0	0	0	\N	0
5260289687	0	ᨀ ʟɴʀ.Kasugano	0	1394	0	0	29.879999999997665	13353	\N	0
5962106892	0	𝗿𝗶𝗻𝗮	0	0	0	0	0	0	\N	0
1435474351	0	Leav	0	10	0	0	0	7	\N	0
5305048344	0	hazel	0	8	0	0	0	1	\N	0
5931755410	0	estheria	0	114	0	0	317.75	19	\N	0
1984785599	0	rere	0	42	0	0	0	8	\N	0
6646487647	0	mel	0	1	0	0	0	0	\N	0
5879888314	0	Cherin's sunshine, Jeros.	0	6	0	0	0	0	\N	0
6061276648	0	Krys	0	2	0	0	0	27	\N	0
5326728307	0	Naku pacarnya haka!	0	1	0	0	0	6	\N	0
6080143670	0	🦋	0	4	0	0	0	2	\N	0
1971014538	0	Bia, DNFI.	0	16	0	0	75.55000000000034	59	\N	0
5997871637	0	Vaness	0	1	0	0	0	3	\N	0
1840569354	0	c	0	64	0	0	0	9	\N	0
5539819212	0	renja dni.	0	3	0	0	0	0	\N	0
5700018176	0	Vanessa	0	0	0	0	0	1	\N	0
2090108727	0	Kai	0	10	0	0	0	8	\N	0
1874525513	0	cala	0	3	0	0	0	80	\N	0
1795211011	0	Hazel G.	0	12	0	0	0	35	\N	0
1252815871	0	jey	0	40	0	0	0	12	\N	0
6645016804	0	Ben work	0	1	0	0	0	0	\N	0
1749838754	0	˚ ｡⋆ ୨୧ hierfa	0	50	0	0	927.0600000000001	1	\N	0
5554816140	0	affh	0	8	0	0	0	0	\N	0
2099309890	0	H	0	1	0	0	0	0	\N	0
1910180513	0	Broja	0	8	0	0	0	0	\N	0
5889749358	0	x	0	6	0	0	0	1	\N	0
1012436188	0	𝐉odem	0	1	0	0	0	0	\N	0
2036441849	0	.	0	63	0	0	23.07	124	\N	0
1824740769	0	Kenma NGEJAM	0	2	0	0	0	0	\N	0
6097612356	0	doz'e	0	4	0	0	0	62	\N	0
1809489029	0	Abeel.	0	3	0	0	0	5	\N	0
5431413791	0	𝐂asha	0	2	0	0	0	0	\N	0
6159850669	0	@mahatviryo	0	0	0	0	0	1	\N	0
6864507210	0	katharina	0	0	0	0	0	7	\N	0
6934601859	0	cinay	0	7	0	0	0	14	\N	0
1982817652	0	Maeve.	0	1	0	0	0	0	\N	0
6120651753	0	hil	0	1	0	0	0	0	\N	0
1970671038	0	Zea	0	10	0	0	0	2	\N	0
5217850100	0	eccc	0	1	0	0	0	0	\N	0
1882077296	0	Chae	0	1	0	0	0	1	\N	0
6169358052	0	b	0	6	0	0	0	0	\N	0
5600814602	0	cyaa	0	3	0	0	0	5	\N	0
5491410277	0	Ale	0	0	0	0	0	4	\N	0
6465895350	0	ᴀᴅᴇɴᴀ s/ia	0	6	0	0	0	0	\N	0
5178992169	0	millyyy	0	66	0	0	0	8	\N	0
6505084381	0	Ivan	0	0	0	0	0	2	\N	0
5652384719	0	zefran	0	11	0	0	0	0	\N	0
5648614545	0	?	0	16	0	0	0	1	\N	0
6597080276	0	Sasha.	0	1	0	0	0	0	\N	0
5404360536	0	as-sari	0	101	0	0	7383.6600000000035	527	\N	1
5344876732	0	Aileen	0	3	0	0	0	4	\N	0
5852756491	0	୨♡୧ ออโรร่า	0	17	0	0	308.14	88	\N	0
1929244717	0	kenzii	0	14	0	0	0	1	\N	0
2054512567	0	hanzie	0	2	0	0	0	442	\N	0
6101106728	0	shabeellll 🦢	0	1	0	0	0	14	\N	0
994592057	0	juan	0	0	0	0	0	0	\N	0
5507482430	0	୭୧ sha de amourette	0	11	0	0	0	1029	\N	0
7087744668	0	Jeje	0	7	0	0	0	14	\N	0
5329028802	0	j	0	2	0	0	0	0	\N	0
6167066430	0	kirey 𓇼	0	3	0	0	0	0	\N	0
2003474258	0	coba tanyain namanya	0	30	0	0	0	42	\N	0
5721756920	0	aeris	8	5	0	0	67.90000000000002	16	\N	0
6566132615	0	chigeri wts id	0	7	0	0	5.920000000000002	16	\N	0
6713907543	0	𝘻𝘦𝘺𝘯𝘢	0	1	0	0	0	0	\N	0
5365865922	0	Fab	0	1	0	0	0	0	\N	0
1949693354	0	who's there?	0	23	0	0	0	44	\N	0
6274494002	0	Maisél. #SPICY	0	25	0	0	3	137	\N	0
5002333546	0	ciciiw	0	22	0	0	92	1	\N	0
1867505551	0	.	0	3	0	0	0	8	\N	0
5370924306	0	Morgan.	0	91	0	0	125.93	5	\N	0
5079768130	0	kensas	0	6	0	0	0	7	\N	0
5676189244	0	A	0	4	0	0	0	1	\N	0
6332462626	0	G.	0	1	0	0	0	0	\N	0
1773271566	0	n🅰ℹ️	7	117	0	0	102.26000000000067	59	\N	0
1468283268	0	Gideon	0	3	0	0	0	0	\N	0
2007633942	0	erin, return @rsunghoon to me	3	49	0	0	4601.399999999999	4851	\N	0
6661818374	0	kyla	0	55	0	0	19	6	\N	0
2123679374	0	mila	0	60	0	0	0	1262	\N	0
1968829998	0	n	0	0	0	0	0	1	\N	0
1144190666	0	nat	0	2	0	0	0	0	\N	0
1468321745	0	Aska.	0	8	0	0	0	5	\N	0
6405522292	0	rudal gulung 4twenty	0	10	0	0	0	2	\N	0
6523645508	0	Luciano	0	1	0	0	0	3	\N	0
5289988489	0	N	0	0	0	0	0	0	\N	0
5910817921	0	beyaw	0	1	0	0	0	0	\N	0
7121380628	0	🐈🐈	0	12	0	0	0	2	\N	0
5125928186	0	syahdan.	0	1	0	0	0	0	\N	0
6127497812	0	A. Maverick	0	3	0	0	0	0	\N	0
1880697356	0	draco - open joki tugas	0	1	0	0	38.85	12	\N	0
1772753428	0	Alice	0	43	0	0	0	10	\N	0
1894316746	0	apa	0	0	0	0	0	0	\N	0
6706576379	0	tiaaa	0	0	0	0	0	0	\N	0
5689317789	0	Zoro Land	0	2	0	0	0	0	\N	0
1618790108	0	āchaa	0	1	0	0	0	0	\N	0
1273881472	0	salimawikky	0	19	0	0	363.61999999999995	679	\N	0
5545437943	0	wl	0	4	0	0	0	12	\N	0
1684984383	0	aAaLL?!!	0	5	0	0	0	2	\N	0
5843926286	0	— utii	0	1	0	0	0	0	\N	0
5957585833	0	Cucuucoklat	0	1	0	0	0	0	\N	0
6797413914	0	By	0	4	0	0	0	8	\N	0
5940788739	0	meyou 🪅	0	14	0	0	838.9799999999999	665	\N	0
6317246386	0	zׁׅ֬ꪱׁׅ	0	2	0	0	0	0	\N	0
1430896724	0	afiYY	0	11	0	0	0	87	\N	0
5124787276	0	y	11	54	0	0	1108.8599999999997	273	\N	0
6344872089	0	evaa	0	108	0	0	790.8999999999999	87	\N	0
5386286165	0	ccaa	0	4	0	0	0	1	\N	0
5164000363	0	L'manuel J.	0	7	0	0	0	0	\N	0
6881530169	0	Buntull	0	5	0	0	0	0	\N	0
5323791127	0	cay	0	6	0	0	0	55	\N	0
6084943311	0	okta🦋	0	27	0	0	0	285	\N	0
6513743124	0	Billa	0	21	0	0	360	150	\N	0
1776676866	0	oice	0	0	0	0	0	100	\N	0
6630427355	0	Laa	0	5	0	0	0	2	\N	0
6974042203	0	A	0	3	0	0	0	1	\N	0
7094496142	0	ㅤ	0	22	0	0	0	12	\N	0
6145552460	0	el	0	2	0	0	125.7	78	\N	0
5825673285	0	ㅤㅤㅤㅤ	0	22	0	0	56	542	\N	0
5291929871	0	javas	0	5	0	0	0	1	\N	0
1874613058	0	rendra	0	20	0	0	0	1	\N	0
958197820	0	bogep	0	67	0	0	1400.21	2924	\N	0
5681324367	0	Jay Altair	0	2	0	0	0	38	\N	0
1539350398	0	Deya	0	7	0	0	67.82	12	\N	0
1776905531	0	belvy	0	8	0	0	0	1	\N	0
2089365035	0	Chayyya	0	9	0	0	68.96	4	\N	0
1777948507	0	G	0	15	0	0	0	7	\N	0
6278067846	0	Faye. •|| kinda slctv ||•	0	38	0	0	0	21	\N	0
6178706659	0	.	0	55	0	0	1.9599999999999937	27	\N	0
6054690972	0	arazey	0	5	0	0	0	0	\N	0
5007458897	0	amarabel	0	22	0	0	80	11	\N	0
1719483740	0	qil	0	178	0	0	8.299999999999955	186	\N	0
6946012644	0	sasaaa	0	4	0	0	0	67	\N	0
5170724870	0	naava	0	6	0	0	0	13	\N	0
1458249971	0	0%	2	4	0	0	1075.13	2	\N	0
5060216253	0	ayya	0	3	0	0	500	11	\N	0
1623762946	0	k's	0	25	0	0	0	26	\N	0
5383981883	0	ini azel	0	7	0	0	0	11	\N	0
1934671014	0	shalsa	0	23	0	0	242.5	16	\N	0
6379609572	0	arion.	0	1	0	0	0	0	\N	0
6581566332	0	erisakk	0	1	0	0	0	0	\N	0
6496303325	0	kya	0	22	0	0	0	0	\N	0
1999854656	0	Nay	0	0	0	0	0	4	\N	0
5565215297	0	Taeyang태양	0	54	3	0	0	4	\N	0
1890723432	0	dni	0	15	0	0	0	5	\N	0
6043467855	0	Maha	0	0	0	0	0	0	\N	0
1827988218	0	bops	9	564	0	0	706.3	454	\N	0
5203090587	0	Dimas	6	108	0	0	833.4200000000001	38	\N	0
6573860134	0	Dean. LGBTQ+ DNI.	0	31	0	0	146.05	20	\N	0
5179877243	0	VASTAR.	0	1	0	0	0	0	\N	0
5561057352	0	pers. lenn	0	2	0	0	0	1	\N	0
1652705893	0	cle	0	1	0	0	0	0	\N	0
5326739966	0	punow	0	6	0	0	0	0	\N	0
5321280926	0	chelia	0	1	0	0	0	1	\N	0
5306573724	0	G. Abigale	0	11	0	0	0	0	\N	0
1759482210	0	alza @llouverruki	0	43	0	0	98	1	\N	0
1723075305	0	Anin	0	16	0	0	0	4	\N	0
1193787809	0	K	0	1	0	0	0	2	\N	0
1514775205	0	ᥫ᭡ • Lareina de Winter`	0	4	0	0	59.849999999999994	23	\N	0
5572618788	0	c	0	1	0	0	0	1	\N	0
1126018342	0	𝐀lz	0	104	0	0	0	221	\N	0
5270199972	0	tara's beloved, nayera.	0	5	0	0	0	1	\N	0
5801150481	0	.	0	1	1	0	0	0	\N	0
2083783514	0	Rafly.	0	4	0	0	0	3	\N	0
5848637802	0	uwahh	0	185	1	0	87.59000000000016	144	\N	0
1351843186	0	Jjesslyn	0	0	0	0	0	8	\N	0
6684929552	0	Acel.	0	6	0	0	0	3	\N	0
1898551288	0	DNI	0	1	0	0	0	0	\N	0
1789719284	0	Marseille 😬✌🏻	0	6	0	0	0	6	\N	0
1963791937	0	aish	0	12	0	0	0	16950	\N	0
1601335525	0	𝐘𝐨𝐚𝐧	0	32	0	0	0	133	\N	0
6228976580	0	revaline	0	133	0	0	19.17999999999995	59	\N	0
1884152224	0	⁫	0	1	0	0	0	0	\N	0
6862848134	0	Яho’s Tourist. ☾ .. forwyn dorina”	0	4	0	0	0	0	\N	0
7129874944	0	sza	0	7	0	0	0	39	\N	0
1009796301	0	sakiyla	0	4	0	0	0	0	\N	0
5671819715	0	Alex	0	20	0	0	215.1	7	\N	0
5060548934	0	haki bøcriz	0	20	0	0	0	44	\N	0
5625955787	0	cubeyya	0	2	0	0	0	0	\N	0
1643573011	0	Gunwook's 911, Zira.	0	15	0	0	0	31	\N	0
6041811289	0	puputt	0	7	0	0	454.37	95	\N	0
6390239946	0	meong	0	11	0	0	371.42	2	\N	0
5916019671	0	me	0	0	0	0	0	31	\N	0
6020960928	0	Abil	0	3	0	0	0	2	\N	0
6420160650	0	⊹ ִᣞ yumiie o’delysia 𔘓ᣞ	0	0	0	0	0	1	\N	0
1952040382	0	c	0	306	0	0	0	26	\N	0
5189871749	0	ㅤ	0	11	0	0	0	1	\N	0
5321615263	0	jae	0	1	0	0	0	0	\N	0
5371584063	0	naa	0	0	0	0	0	5	\N	0
6129140052	0	.	0	57	0	0	12	12	\N	0
928799846	0	ci	0	2	0	0	0	2	\N	0
5331387507	0	Kana	0	31	0	0	52.99000000000024	6	\N	0
1975925114	0	cutiepie	0	63	0	0	0	9	\N	0
5678952334	0	MG, Jasper Marc. 🇺🇸	0	24	0	0	0	60	\N	0
2008288778	0	achel pake H???	0	104	0	0	1651.0875	14529	\N	0
1769296908	0	eL	0	3	0	0	0	0	\N	0
957875669	0	ziwaa	0	1	0	0	0	256	\N	0
7079419829	0	.For @gueezky	0	2	0	0	0	0	\N	0
2146871199	0	Math.	0	1	0	0	0	0	\N	0
6276923066	0	abey	0	0	0	0	0	16	\N	0
5357405625	0	fab	0	1	0	0	0	0	\N	0
5577073770	0	ayleen.	0	59	0	0	293.8	57	\N	0
1481618796	0	D C	0	1	0	0	0	4	\N	0
5730122195	0	aya	13	2	0	0	25.06	54	\N	0
6505610770	0	jiAaaa	0	1	0	0	0	0	\N	0
5157815199	0	natasha.	9	594	0	0	78.11999999999989	5838	\N	0
5052497349	0	bill	6	5	0	0	3142.2899999999995	591	\N	0
6807081288	0	Love_11	0	10	0	0	0	20	\N	0
1267279431	0	---	0	5	0	0	0	10	\N	0
5143687160	0	willi	0	8	0	0	0	8	\N	0
5460338862	0	essie	0	68	0	0	11	612	\N	0
5469946013	0	Key 🔑	0	2	0	0	0	1	\N	0
2092508391	0	evander	0	1	0	0	2236.23	16	\N	0
5940978582	0	🧚🏻‍♀️ffael✧°₊·♡∗ˈ‧₊	0	204	0	0	1.3400000000000034	1181	\N	0
2020255586	0	ital	0	19	0	0	0	2	\N	0
1815805077	0	sazea owner	0	53	0	0	0	5	\N	0
5936929511	0	mimi	0	1	0	0	0	0	\N	0
5346811709	0	rin - OPEN FREELANCE	0	1	0	0	0	0	\N	0
6659186068	0	shanaya	0	20	0	0	0	13	\N	0
1999811240	0	Alan	0	20	0	0	0	1	\N	0
2031727242	0	582. Sheilla	0	2	0	0	0	15	\N	0
5777821450	0	r	0	32	0	0	50	2	\N	0
1439279005	0	naia	4	95	0	0	143.39000000000001	85	\N	0
1107546013	0	lucille	0	3	0	0	0	12	\N	0
5200319038	0	jeno	0	215	0	0	0	0	\N	0
6279657675	0	Needassiss	0	1	0	0	0	0	\N	0
5398068793	0	abel 🎅🏻🎄	0	3	0	0	0	0	\N	0
5146704907	0	lira	0	1	0	0	0	0	\N	0
5119251261	0	Fire	0	310	0	0	3791.2299999999987	3596	\N	0
6261852310	0	f	0	6	0	0	0	5	\N	0
1848403445	0	oW	0	18	0	0	2692.5699999999997	300	\N	0
5146461339	0	seena	0	50	0	0	0	0	\N	0
6635398978	0	𝟐𝟏𝟏. Ruby S'envoler	0	2	0	0	0	0	\N	0
5950955905	0	戦ᴍᴛᴢɪ mirachel.	0	0	0	0	0	0	\N	0
2130974885	0	abel	0	277	0	0	0	54	\N	0
5603804234	0	ᛃ ѕ c н α т z ɪ	0	1	0	0	0	0	\N	0
5583146704	0	ash	0	56	0	0	0	31	\N	0
1624561287	0	maja	0	2	0	0	0	0	\N	0
7096619775	0	dara	0	9	0	0	0	14	\N	0
5127191754	0	Asist	0	83	0	0	11.090000000000146	44	\N	0
6866380515	0	narea	0	7	0	0	0	0	\N	0
7086297277	0	kana	0	5	0	0	0	0	\N	0
6612491264	0	Rajash	0	2	0	0	0	1	\N	0
1809311886	0	Kia	0	75	0	0	0	276	\N	0
2109069198	0	jijeyy @wawanx	0	201	0	0	954.81	350	\N	0
6032448060	0	shaaa	0	2	0	0	0	0	\N	0
5289043797	0	A. Benneth	3	192	0	0	0	90	\N	0
1816806674	0	duyungg🧜‍♀	0	3	0	0	0	1	\N	0
5613970960	0	kavrinE.	0	14	0	0	0	0	\N	0
5389599511	0	Aluna	0	10	0	0	0	0	\N	0
1275021891	0	Ab	0	26	0	0	0	0	\N	0
1947147481	0	Kahilya, e	0	0	0	0	0	0	\N	0
5334130446	0	rakas	0	1	0	0	0	0	\N	0
6105938405	0	ca	0	197	0	0	3192	9	\N	0
6457060633	0	nayle	0	1	0	0	0	0	\N	0
6191933847	0	rde – sojurist. aleaa fluttershy	0	5	0	0	0	0	\N	0
5486903568	0	.	0	14	0	0	0	117	\N	0
1644229028	0	ziggy suh	0	30	0	0	591.7700000000004	1420	\N	0
1912113674	0	69 pènis	0	3	0	0	0	6	\N	0
1866769887	0	wystle	0	14	0	0	106.16	144	\N	0
1791009418	0	Darex.	0	2	0	0	0	0	\N	0
1761881304	0	🫀	0	156	0	0	5.819999999999993	837	\N	0
6577092583	0	𝐀𝐥𝐚𝐧𝐚	0	5	0	0	0	1	\N	0
6432790773	0	Lutfi	0	38	0	0	187.83999999999997	251	\N	0
5495036558	0	God	0	2	0	0	0	6	\N	0
1690768331	0	Arjuna	0	2	0	0	0	1	\N	0
1685115780	0	🩷	7	579	0	0	12912.999999999998	4211	\N	0
1342532512	0	Ruby A.	0	1	0	0	0	0	\N	0
1796096204	0	.	0	8	0	0	0	3	\N	0
2133486058	0	xen	0	3	0	0	0	0	\N	0
5678313903	0	na	0	1	0	0	0	2	\N	0
7019203110	0	zellaa	0	10	0	0	0	8	\N	0
5313760658	0	Kalva	0	69	0	0	0	0	\N	0
1726351720	0	Paulina, clinically insane.	0	14	0	0	0	25	\N	0
1838389246	0	Kay	0	84	0	0	0	402	\N	0
5177163366	0	RENZ	0	1	0	0	0	1	\N	0
6251606475	0	.Bilaaa Slowrespon	0	23	0	0	0	19	\N	0
2128429374	0	jel	0	16	0	0	0	24	\N	0
5558233784	0	dena.baca bio	0	5	0	0	0	0	\N	0
1657350437	0	nikuo	0	0	0	0	0	1	\N	0
2084598442	0	vena	0	3	0	0	0	7	\N	0
1754277319	0	Gitaa.	0	81	0	0	110	198	\N	0
5215752864	0	kania	0	16	0	0	0	18	\N	0
5511960801	0	mariebelle :b	0	3	0	0	0	21	\N	0
907821459	0	Lyn	0	103	0	0	312.87	32	\N	0
5154924031	0	æther	4	362	0	0	1636.6800000000003	454	\N	0
1846689881	0	🐪	0	1	0	0	0	0	\N	0
1850744361	0	vyn	11	395	0	0	4090.639999999999	2090	\N	1
5395565052	0	itil	0	1	0	0	0	0	\N	0
5452422689	0	AfriL	0	2	0	0	0	1	\N	0
1592074404	0	dhira	0	373	0	0	4114	36	\N	0
6562014235	0	firly	0	2	0	0	0	3	\N	0
5362961590	0	andh	0	65	0	0	0	171	\N	0
1529881238	0	❦. - ᴇʀʀɪᴄᴀ	0	6	0	0	25.84	165	\N	0
1642271935	0	🪩	0	190	0	0	0	35	\N	0
1154340130	0	.	0	1	0	0	0	0	\N	0
6949520303	0	Keitha	0	4	0	0	0	1	\N	0
1689639162	0	reynie.	0	1	0	0	0	0	\N	0
1337111494	0	22_Alya rahmani_SRM	0	39	0	0	0	15	\N	0
5340788411	0	padli	0	4	0	0	0	19	\N	0
6528198823	0	ane	0	8	0	0	0	16	\N	0
5667514208	0	Rest. A J	0	65	0	0	215.44	80	\N	0
5218008809	0	rex	0	6	0	0	0	0	\N	0
5827875147	0	everything is bajingan	0	1	0	0	0	0	\N	0
5124036078	0	caroline	0	121	0	0	0	51	\N	0
1457305839	0	Jey ausarta	0	10	0	0	2652.1499999999996	28	\N	0
5513294159	0	ephemeral	0	32	0	0	512.6	72	\N	0
1303100961	0	Ardil van meijir	0	6	0	0	0	48	\N	0
1612963522	0	b	0	69	0	0	55.52000000000009	17	\N	0
5717484444	0	kami	0	28	1	0	0	9	\N	0
5889156307	0	kiran 💢	0	9	0	0	0	4	\N	0
6334694150	0	Arth	0	4	0	0	0	19	\N	0
1861470111	0	Chezy.	0	2	0	0	0	0	\N	0
6916388611	0	fitrii	0	1	0	0	0	0	\N	0
5824823378	0	rez	0	3	0	0	0	23	\N	0
1621540401	0	Ast	0	3	0	0	0	0	\N	0
5805256711	0	J [pending slr]	12	75	0	0	157.97999999999985	182	\N	0
6851149438	0	dpi	0	2	0	0	0	0	\N	0
5396075025	0	dim	0	1	0	0	0	0	\N	0
5470426977	0	zzzar	0	6	0	0	0	0	\N	0
1904098945	0	Joy, rest.	0	2	0	0	0	2	\N	0
6631822130	0	cals	0	1	0	0	0	1	\N	0
6820217697	0	ailee	0	4	0	0	0	1	\N	0
1198842030	0	🦕 iijen	0	48	0	0	0	229	\N	0
1489872101	0	el	0	1	0	0	0	1	\N	0
1931006015	0	Hey	0	3	0	0	0	0	\N	0
6745071238	0	ᴀᴛᴠ¹ Aιεαα ❀❀	0	1	0	0	0	0	\N	0
1709016052	0	sha	0	8	0	0	0	2	\N	0
5908812310	0	Ardzz	0	1	0	0	0	1	\N	0
6886548829	0	hey	0	24	0	0	696.07	480	\N	0
6541105947	0	nay	0	3	0	0	0	0	\N	0
6909536021	0	Syifa	0	2	0	0	0	0	\N	0
5235756514	0	a	0	26	0	0	0	7	\N	0
1821037504	0	jen's guardian.	0	9	0	0	0	0	\N	0
1771189240	0	pik	0	516	0	0	326.3	105	\N	0
6951385921	0	𝐚𝐭𝐫𝐞𝐮𝐬!	0	1	0	0	0	42	\N	0
5232704854	0	dama, nt pride 😞	0	2	0	0	0	72	\N	0
6477003651	0	bitaaa loafs kaa doy	0	7	0	0	0	11	\N	0
5559113499	0	abibb	0	1	0	0	0	7	\N	0
5351093268	0	dira	0	3	0	0	0	0	\N	0
6405782969	0	lana	0	4	0	0	100	11	\N	0
5494758974	0	ebby.n	0	4	0	0	0	0	\N	0
1951045048	0	neru/milaa ★🇿🇲	0	1	0	0	0	39	\N	0
6013108444	0	Sullivan	0	0	0	0	0	1	\N	0
5477115972	0	[] Harlayn. upin sm yucil cakep bgt gsih? vibesnya pcr aku bgt	0	4	0	0	0	11	\N	0
6238501694	0	:9	0	5	0	0	0	0	\N	0
5370503679	0	nana isn't mood.	0	15	0	0	0	10	\N	0
6150775735	0	nakev	0	27	0	0	0	1	\N	0
5011786282	0	keisha	0	39	0	0	0.5	10	\N	0
5508521242	0	{ 𖤝 o'Madame! } Jéna	0	9	0	0	0	10	\N	0
1900395556	0	hesiella	0	19	0	0	0	0	\N	0
1653644936	0	aftersex	0	105	1	0	0	556	\N	0
6535861084	0	Ali #event	0	6	0	0	4.12	10	\N	0
1343999713	0	ziudithᵈⁿⁱ🦙	2	217	0	0	5888.14	6670	\N	0
6301345645	0	kaniaa ✧	0	1	0	0	0	0	\N	0
1246190184	0	Nathan 𝔍𝔦𝔩𝔩𝔰	0	2	0	0	0	4	\N	0
1878231604	0	Z	0	4	0	0	0	4	\N	0
1920566768	0	al	0	15	0	0	0	0	\N	0
1727695916	0	A	0	15	0	0	0	12	\N	0
5948491849	0	.	0	0	0	0	0	0	\N	0
1891697048	0	ᶻ 𝗓 𐰁	0	88	0	0	23	304	\N	0
1664316339	0	ecaaa.	0	1	0	0	0	17	\N	0
2082492710	0	napir rvg¹	0	13	0	0	0	14	\N	0
1756501555	0	kiarra, f	0	32	0	0	0	5	\N	0
1618877460	0	Ed	0	276	0	0	0	2	\N	0
6269642652	0	𐙚 ׅ ֹ nazeea	0	0	0	0	0	1	\N	0
5011442094	0	rapadeu	0	1	0	0	0	2	\N	0
6597360313	0	Sean	0	2	0	0	0	2	\N	0
6014166553	0	Kjs. Amtala	0	2	0	0	0	0	\N	0
6229911444	0	nad	0	2	0	0	0	0	\N	0
1989249342	0	.	0	6	0	0	0	6	\N	0
6755077922	0	?	0	2	0	0	0	3	\N	0
5164703633	0	aza	0	4	0	0	0	12	\N	0
1756543357	0	*fufufufufu* 😢😢😢	0	2102	0	0	4.669999999999618	41	\N	0
5994264557	0	Jon	0	9	0	0	0	20	\N	0
1736600676	0	イ. jeca	0	10	0	0	0	1	\N	0
6081848739	0	𝗠íllα	0	10	0	0	0	0	\N	0
1885294335	0	Kei	0	1	0	0	0	0	\N	0
1817371906	0	≽ܫ≼	0	26	0	0	0	1	\N	0
6027402639	0	narra	0	7	0	0	0	4	\N	0
2044205830	0	anony	0	23	0	0	0	73	\N	0
5514779582	0	c	0	48	0	0	0	11	\N	0
5916718291	0	j	0	0	0	0	0	0	\N	0
1693032628	0	dyeés here, dārl !	0	24	0	0	0	5	\N	0
5809932543	0	bulaa	0	227	0	0	17.519999999999992	77	\N	0
6149924918	0	Aiden H.	0	1	0	0	0	0	\N	0
5544570509	0	cēcyu	0	15	0	0	0	2	\N	0
1910441235	0	Amoura	4	50	0	0	4373.08	1992	\N	1
1896799126	0	Aerish Jewesrty	0	4	0	0	0	2	\N	0
6586248344	0	Kate Middleton	0	1	0	0	0	11	\N	0
1609918901	0	Arda	0	5	0	0	0	4	\N	0
6180149649	0	cintari ，	0	1	0	0	0	0	\N	0
6853452531	0	vere	0	5	0	0	0	0	\N	0
5231704293	0	ay, balik logout.	0	2	0	0	0	0	\N	0
6983889012	0	Gwén, Jeno's gf.	0	1	0	0	0	0	\N	0
7060012020	0	aissy	0	0	0	0	0	0	\N	0
6084355190	0	ila 😴	0	190	0	0	0	1	\N	0
1746553878	0	cel mengsenang	12	172	0	0	51.03000000002794	904	\N	1
5762816154	0	Pi	0	26	0	0	0	1	\N	0
1725328066	0	Arye	0	1	0	0	0	0	\N	0
2133950074	0	nāyess	0	92	0	0	12	239	\N	0
7118304927	0	.	0	7	0	0	0	5	\N	0
5267001663	0	Kanaya	0	6	0	0	928.8799999999999	33	\N	0
6101856649	0	mccaa	0	10	0	0	0	60	\N	0
5937958017	0	.	0	58	0	0	0	1	\N	0
1237104496	0	.	0	3	0	0	0	0	\N	0
6450605239	0	vmor² Nara	0	163	0	0	1541.0700000000002	577	\N	0
5195439143	0	sky 🪽	0	22	0	0	0	46	\N	0
5865292888	0	Rakiel 🆒️	0	5	0	0	0	1	\N	0
1769981410	0	ᴅᴇꜰᴛᴀ	0	2	0	0	0	8	\N	0
1687569891	0	maieera.	0	2	0	0	0	68	\N	0
6803138776	0	vierraa	0	2	0	0	0	9	\N	0
5095433601	0	𝐑ex's(e).	0	13	0	0	0	27	\N	0
1123728424	0	ardit	0	2	0	0	0	0	\N	0
1281806735	0	WineryWinter	0	25	0	0	0	6	\N	0
1650213681	0	077 th. Denata	0	0	0	0	0	0	\N	0
5487219198	0	.	0	24	0	0	131.74	40	\N	0
5777687010	0	yuka	0	1	0	0	0	0	\N	0
5624559171	0	Sabile	0	2	0	0	0	4	\N	0
5175651779	0	dann	0	62	0	0	0	1	\N	0
5683033592	0	Khavi.	0	7	0	0	0	0	\N	0
1472839591	0	Kaleee	0	1	0	0	100	42	\N	0
5155490848	0	issa	0	5	0	0	420	1	\N	0
1771263038	0	ashaa	12	154	0	0	3147.4900000000007	1120	\N	1
5901755432	0	.	0	272	0	0	1.1800000000082065	212	\N	0
1322909493	0	!?!!1?! 🎅	0	22	0	0	0	10	\N	0
6100012409	0	maica	0	32	0	0	0	20	\N	0
2028587126	0	emang baby namanya	0	119	0	0	324.69	429	\N	0
1683687213	0	pika, loanjingsuicy	0	9	0	0	0	0	\N	0
5261670986	0	slvna	0	70	0	0	1120	274	\N	0
6310704845	0	m capres 🚬	0	20	0	0	0	20	\N	0
6628500022	0	Anastasia Beverly.	0	6	0	0	0	7	\N	0
5575268562	0	syenaa	0	3	0	0	0	5	\N	0
1175103736	0	alin	0	1	0	0	0	0	\N	0
6344749306	0	yolaa anak kuceng ʀʀᴡ	0	15	0	0	0	13	\N	0
1409593691	0	a	0	3	0	0	0	0	\N	0
2098574754	0	+62	0	0	0	0	0	0	\N	0
1122546495	0	berselisih	0	19	0	0	0	0	\N	0
5243111188	0	noelle.	0	15	0	0	0	5	\N	0
2017212937	0	r	0	564	0	0	13.720000000000027	81	\N	0
5477562702	0	Bluesky	0	1	0	0	0	1	\N	0
5339803922	0	jericho	0	2	0	0	0	155	\N	0
1207307767	0	Bara	0	18	0	0	0	21	\N	0
2106282866	0	JiRO 😎	0	7	0	0	0	0	\N	0
5604725639	0	ydf	0	28	0	0	0	0	\N	0
1744219246	0	ωαωααα	0	1	0	0	0	1	\N	0
6597017243	0	yaya	0	0	0	0	0	1	\N	0
6773786097	0	el 🦕🌺	0	1	0	0	0	0	\N	0
5091532575	0	MA | ráa, off.	0	16	0	0	46.31	29	\N	0
1765925045	0	railee	0	2	0	0	0	7	\N	0
6220727121	0	Skay	0	4	0	0	0	0	\N	0
6824757160	0	senaa	0	6	0	0	0	1	\N	0
1623797618	0	ran?	0	12	0	0	0	28	\N	0
5088710506	0	Fang	0	1	0	0	17.33	55	\N	0
2133730447	0	SolSolSol! <3	0	2	0	0	0	0	\N	0
2131716233	0	j	0	3	0	0	0	9	\N	0
5720833588	0	logout	0	10	0	0	0	0	\N	0
1714629578	0	vara	0	1	0	0	0	0	\N	0
5501269332	0	𝐕enom	0	9	0	0	0	2	\N	0
5285606993	0	c	0	14	0	0	0	8	\N	0
6492625229	0	ai	0	2	0	0	0	8	\N	0
5954607381	0	Agha	0	143	0	0	9.93	33	\N	0
5305440608	0	sheeer	0	62	0	0	0	0	\N	0
1312177348	0	pinong 2	0	45	0	0	0	0	\N	0
1349513799	0	antika‧₊˚✧	9	63	0	0	2888.91	55	\N	0
5458690370	0	𖨁. xineys mãcek 🇸🇿	0	3	0	0	0	28	\N	0
1660776735	0	Erico.	0	17	0	0	0	26	\N	0
1589582707	0	Ci	0	29	0	0	0	1	\N	0
6262631878	0	al teamvgu. bucin giselle	0	0	0	0	0	0	\N	0
6666333574	0	echaa	0	3	0	0	0	44	\N	0
1803053490	0	𝐓𝐑≛𝐏𝐒 `chiko	0	3	0	0	0	6	\N	0
6593118173	0	𝐊𝐞𝐧–𝐬𝐡𝐢𝐧.	0	1	0	0	0	2	\N	0
1651888940	0	Nakael-Artleight.	0	2	0	0	0	652	\N	0
6399491170	0	emillie d'nicole	0	1	0	0	0	0	\N	0
1928929575	0	rey	0	2	0	0	0	7	\N	0
6977754035	0	p	0	1	0	0	0	2	\N	0
5000738564	0	🎧 keeyara	0	1	0	0	0	17	\N	0
6421124950	0	mba	0	3	0	0	0	2	\N	0
6312514463	0	—T	0	0	0	0	0	2	\N	0
2084142012	0	zzzz	0	9	0	0	0	1	\N	0
1604058068	0	Jriiiiiiiiiiiiiiiiiiiiiiii	0	1	0	0	0	1	\N	0
6820477397	0	azna	0	3	0	0	0	5	\N	0
2110345634	0	NAA	0	1	0	0	0	9	\N	0
1635466955	0	Damōra van Houten.	0	1	0	0	0	0	\N	0
1312208956	0	nakomi🥡 ݈݇	0	0	0	0	0	0	\N	0
5290193799	0	N. 🪩	0	3	0	0	9.149999999999999	20	\N	0
6049479850	0	caa	8	41	0	0	0	53	\N	0
7007413990	0	eng	0	1	0	0	0	0	\N	0
5009006593	0	Abip	0	8	0	0	0	27	\N	0
5846139360	0	Magani Yasa.	0	0	0	0	0	14	\N	0
5908725002	0	Wle	0	1	0	0	0	0	\N	0
6009321154	0	keithara	0	2	0	0	0	0	\N	0
1804311148	0	myiesha	0	3	0	0	0	1	\N	0
5566269186	0	k	0	6	0	0	0	0	\N	0
6376121316	0	ezra 𝕽ʳ	0	0	0	0	0	3	\N	0
1696738322	0	jossie's busy.	0	297	1	0	226.5	3825	\N	0
1427742246	0	Jolyne	0	18	0	0	0	57	\N	0
6629459322	0	-	0	6	0	0	0	1	\N	0
1817244153	0	Ƥєʏʏ	0	1	0	0	0	0	\N	0
6067474005	0	Ch	0	2	0	0	0	2	\N	0
1282576183	0	van.	0	13	0	0	0	106	\N	0
1889444826	0	rajas	0	2	0	0	0	0	\N	0
2015006700	0	P	0	0	0	0	0	0	\N	0
6563815945	0	Anin	0	1	0	0	0	0	\N	0
6291677685	0	micel	0	4	0	0	0	31	\N	0
6688507762	0	hilmi	0	1	0	0	0	2	\N	0
1779257385	0	darafférla	0	10	0	0	0	1	\N	0
5695435578	0	Sheila Mintherenia.	0	1	0	0	0	0	\N	0
2082367694	0	cla	0	0	0	0	0	0	\N	0
1504417994	0	zavy	0	0	0	0	0	0	\N	0
2105446846	0	aLEsha berfire 💥🔥🔥🔥🔥🔥	0	2	0	0	0	16	\N	0
1460118439	0	Moriss.	0	15	0	0	120	0	\N	0
6516259814	0	困 ᴊᴇɴᴅʀᴀʟ. mara(h)	0	3	0	0	0	0	\N	0
6224483582	0	sisil wcs	0	18	0	0	367	4	\N	0
1906346900	0	zy.	11	524	0	0	2439.0199999999995	220	\N	0
7118723202	0	Lovelyy🧚‍♀	0	1	0	0	0	1	\N	0
5299967705	0	alin	0	14	0	0	0	3	\N	0
6256292670	0	Shaka.	0	8	0	0	0	0	\N	0
6258123445	0	maé	0	9	0	0	0	132	\N	0
5832191585	0	neyra	0	106	0	0	11.539999999999992	285	\N	0
6089463232	0	Ravendzk	0	1	0	0	0	0	\N	0
1996701442	0	𝕮𝐞𝐥𝐚	12	50	0	0	1000.12	219	\N	0
5495993450	0	glenca MDNI	0	10	0	0	0	29	\N	0
1965976975	0	agesyaa	0	76	0	0	117	14	\N	0
2100861750	0	Shafa	0	1	0	0	0	1	\N	0
5070162867	0	Lea	0	0	0	0	0	0	\N	0
1723163555	0	nr	1	303	0	0	2143.49	5	\N	0
1457528407	0	Na.	0	107	0	0	0	447	\N	0
5641666298	0	Arga	13	82	0	0	218.4299999999996	372	\N	0
5477745778	0	kKayyin.a	0	84	0	0	648	15	\N	0
2113930328	0	Jiona	0	25	0	0	0	8	\N	0
1477390102	0	J.	0	9	0	0	0	2	\N	0
5304916226	0	S	12	845	0	0	1.0500000000000007	35	\N	0
5751881373	1	Ayden V. Sedgewick	0	10	0	0	0	1	\N	0
5347781679	0	Yayaaa	0	67	0	0	489.9	113	\N	0
1802859080	0	Amy.	0	2	0	0	0	10	\N	0
6169871132	0	ubiii`	0	29	0	0	0	17	\N	0
1758095718	0	Bregasta Wirasena	0	1	0	0	0	0	\N	0
5588213941	0	asyaa	0	85	0	0	4.33	94	\N	0
6784274644	0	LiBiea S.	0	2	0	0	0	0	\N	0
5484984779	0	Karine M. Jeannette	0	3	0	0	0	0	\N	0
1400648136	0	Julio	0	1	0	0	0	0	\N	0
6299875577	0	🅰️🅰️lika	0	19	0	0	0	15	\N	0
1785203574	0	ryu	0	1	0	0	0	0	\N	0
6573003832	0	Mormaid, D	0	6	0	0	0	36	\N	0
2095930238	0	なʜᴅꜱ alee	0	10	0	0	0	91	\N	0
1766703950	0	M, Rodriguez	0	1	0	0	0	35	\N	0
2066791410	0	kaYana off	12	48	0	0	1441.7399999999989	242	\N	1
1756984320	0	kina	0	2	0	0	0	0	\N	0
5177721724	0	stelanne	0	160	0	0	8.5	1085	\N	0
5913957812	0	igi	0	1	0	0	0	12	\N	0
1721869609	0	anya	0	2	0	0	0	0	\N	0
1984326412	0	𝐏𝐫𝐞𝐭𝐭𝐢𝐞𝐬𝐭 𝐳𝐨𝐦𝐛𝐢𝐞,𝐛𝐢𝐧𝐛𝐢𝐧🧟‍♀️	0	3	0	0	0	40	\N	0
5351335238	0	Haneelie-Mour :]	0	2	0	0	0	1	\N	0
1916672899	0	kaii	0	8	0	0	0	8	\N	0
6162537480	0	ilmuan	11	5	0	0	987.92	31	\N	0
6200337992	0	blues	0	2	0	0	0	0	\N	0
5965863713	0	Jerry	0	1	0	0	0	7	\N	0
5067784426	0	Abraham	0	7	0	0	0	12	\N	0
1692994200	0	kylie	0	24	0	0	419	20	\N	0
1886681217	0	DiVα	0	25	0	0	0	189	\N	0
1838109114	0	daren x31 𝒅'𝒊𝒓𝒆🇦🇸	0	2	0	0	0	4	\N	0
839135988	0	En	0	2	0	0	0	0	\N	0
6967655993	0	aná	0	1	0	0	0	39	\N	0
5063819427	0	j	0	1	0	0	0	1	\N	0
2092247365	0	XEULGISA	0	1	0	0	0	1	\N	0
5081787982	0	raa hr²	0	1	0	0	363	1	\N	0
6381309863	0	rizu	0	2	0	0	0	11	\N	0
1710121167	0	D	0	7	0	0	0	8	\N	0
1100980150	0	azaraa	0	49	0	0	0	303	\N	0
6764160177	0	Alfha.	0	14	0	0	0	0	\N	0
6551709369	0	ʸᵒᵘʳ 𝕬𝖘𝖙𝖆𝖆🚩	0	4	0	0	0	3	\N	0
5407918310	0	bie	0	68	0	0	9	234	\N	0
6118583569	0	Bo¥°°	0	1	0	0	0	2	\N	0
6158221755	0	𝐜𝐫𝐯𝐳⁵ Aysele drxt²	0	1	0	0	0	0	\N	0
1631641625	0	ayaa bm dragon 😰	3	357	0	0	4565.79	3244	\N	0
1177330192	0	aii	0	58	0	0	0	350	\N	0
1361150429	0	𝟗𝟏𝟐`auntie nanaé	0	61	0	0	14.899999999999977	85	\N	0
6353262496	0	ㅤㅤ	0	4	0	0	0	36	\N	0
1442302431	0	m i k a = mikako	0	1	0	0	0	5	\N	0
1888306110	0	zia	0	2	0	0	0	1	\N	0
6773326811	0	⤜ awa ݁ ֢	0	2	0	0	0	0	\N	0
5859395636	0	lg ga mood	0	61	0	0	263.09000000000003	70	\N	0
6229921056	0	ur gf	0	39	0	0	0	20	\N	0
6193425224	0	ᴊᴇɴᴅʀᴀʟ. kimi	0	10	0	0	0	0	\N	0
6809575312	0	˘ ♡̸ — 𝐀𝗿𝘂𝗻𝗮 𝐏𝐫𝐚oe𝗱𝗶𝘁𝗮 ˖	0	2	0	0	0	1	\N	0
1397169850	0	jule skaye	0	5	0	0	0	118	\N	0
864731969	0	November	0	29	0	0	0	207	\N	0
5322689129	0	ajeyy	11	800	0	0	861.5700000000006	8436	\N	0
5012557467	0	ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ	0	215	0	0	1476.8700000000001	36	\N	0
7181368746	0	zell	0	15	0	0	0	90	\N	0
1809248560	0	taura	11	104	0	0	67	132	\N	0
6304551164	0	mother is nude	0	1	0	0	0	404	\N	0
6006943209	0	grey despise the moon	14	446	0	0	35.17999999999978	2464	\N	0
6165749338	0	anjell	0	2	0	0	0	0	\N	0
5334251840	0	Kara M.	0	1	0	0	0	1	\N	0
1850208485	0	A.	0	1	0	0	0	0	\N	0
1793314277	0	jerashka	0	751	0	0	240.10750000000007	6371	\N	0
1301663011	0	Noelle J.	0	1	0	0	0	0	\N	0
1614714584	0	R̵͕͓̍̇̃̉̂͠E̴̢̨̛̼͎͚̝̰̓N̸̛̗̣̞̟̟̯̫͂͋́͜D̷͇́̕Y̶̅̒̕ ̪̹͈̪̻̠͕̑͋̑͋͘͝	0	1	0	0	0	3	\N	0
1907841230	0	.	0	6	0	0	0	1	\N	0
6971523980	0	abay🇱🇸	0	71	0	0	0	23	\N	0
5125108944	0	viole-ta! loving kak pedri :D	0	1	0	0	0	0	\N	0
1422155151	0	naeva	0	1	0	0	0	0	\N	0
5195768609	0	Athan.	0	4	0	0	18.72	6	\N	0
1608565868	0	Mikaéra.	0	0	0	0	0	3	\N	0
5197239649	0	pacar wonwoo kw 2	12	1088	0	0	1413.3500000000445	6608	\N	1
5247394967	1	Yourgirl	0	42	0	0	0	46	\N	0
6269710160	0	.	0	0	0	0	0	0	\N	0
6945476658	0	fer ᴴᴸ	0	2	0	0	0	13	\N	0
6534802367	0	Roses yuk join ch!	0	1	0	0	0	1	\N	0
5470451125	0	waru	0	270	0	0	0	400	\N	0
5567560354	0	lay	0	81	0	0	12.950000000000003	53	\N	0
5127553603	0	ɴᴧᴛʜᴧɴɪᴧ •[𖤝]	0	1	0	0	0	35	\N	0
5021900963	0	Arles,#𝐍𝐄𝐖𝐀𝐆𝐄𝐍𝟖𝟕𝟏,ᶜᵒʳᵉ𝗇𝖾o	0	0	0	0	0	0	\N	0
5804405689	0	sasaa	0	1	0	0	0	0	\N	0
1464236024	0	f	0	1	0	0	0	0	\N	0
6381779067	0	J	0	2	0	0	0	0	\N	0
5314656223	0	Denzel	0	2	0	0	0	9	\N	0
6204127450	0	katya	0	7	0	0	0	4	\N	0
1527313178	0	Reygav Alrazez A.	0	1	0	0	0	0	\N	0
5556246343	0	jiwangga	0	62	0	0	0	37	\N	0
5427376593	0	bby nnaaa	0	1	0	0	0	4	\N	0
1211381941	0	erash	4	96	0	0	439.4400000000001	55	\N	0
5411752850	0	🦁	0	27	0	0	1.5199999999999818	11	\N	0
846700646	0	ette	0	476	0	0	158.72999999999956	2411	\N	0
5231039096	0	Noah	0	2	0	0	0	1	\N	0
6827257126	0	𝐓𝐑≛𝐏𝐒 ` jagrs☫²⁴²⁴ drw	0	2	0	0	0	1	\N	0
5510536992	0	aethaaa ♡	0	107	0	0	26.899999999999935	250	\N	0
6757462653	0	ka	0	1	0	0	0	0	\N	0
6474558597	0	✧ᴄʜᴇʀʏʟ	0	10	0	0	0	26	\N	0
1904594326	0	gtr	0	24	0	0	0	1	\N	0
5811570619	0	bina.	0	3	0	0	0	0	\N	0
5311877141	0	adzlan	0	3	0	0	0	3	\N	0
5475428209	0	Cherish	13	26	0	0	734.250000000001	146	\N	0
5050848496	0	yaya	0	2	0	0	0	2	\N	0
1750526733	0	Zoora Almouré.	0	12	0	0	14.89	14	\N	0
6130753863	0	Panggil aja anin	0	1	0	0	0	2	\N	0
5387569610	0	dipp	0	3	0	0	0	0	\N	0
6286392388	0	anaaa	0	27	0	0	0	39	\N	0
1923516776	0	atlas	0	80	0	0	90	15	\N	0
5092929072	0	Haec.	0	0	0	0	0	10	\N	0
5187310786	0	bblu	0	4	0	0	0	0	\N	0
2096897932	0	d	0	1	0	0	0	0	\N	0
1639590246	0	estela	0	1	0	0	0	0	\N	0
1506716437	0	𝓡yxxenly	0	47	0	0	0	97	\N	0
1895074361	0	Nini wrwrwrwr	0	79	0	0	0	173	\N	0
6603499164	0	Johnathan	0	15	0	0	0	39	\N	0
5415021416	0	Juan Arkanellio.	0	43	0	0	0	333	\N	0
5038983620	0	bebe	0	1	0	0	0	3	\N	0
1214651431	0	Filipo	0	4	0	0	0	13	\N	0
1540319599	0	Aish	0	1	0	0	0	0	\N	0
6271896021	0	levon	0	1	0	0	0	7	\N	0
6274796672	0	69 Haqeel.	0	2	0	0	0	0	\N	0
5932843602	0	معرفة	0	1	0	0	0	0	\N	0
1888063415	0	A	8	61	0	0	646.8500000000001	59	\N	0
5668205820	0	𝕭𝖙𝖓𝖘𝖙𝖗. Iraa	0	2	0	0	0	2	\N	0
1730866109	0	meiyyy still diving!	0	3	0	0	0	0	\N	0
1702881226	0	Kailaa.	0	0	0	0	0	0	\N	0
1787052487	0	harsyiiii	0	45	0	0	3060.53	463	\N	0
5998750235	0	୧ Gideona, J	0	3	0	0	0	0	\N	0
1841411273	0	k/sia Jackson	0	1	0	0	0	0	\N	0
6155025220	0	ilham	0	8	0	0	0	0	\N	0
6490013250	0	𝐓𝐑≛𝐏𝐒 `nata	0	3	0	0	0	2	\N	0
6744422589	0	jeeyA	0	1	0	0	0	0	\N	0
6521447811	0	ta	0	2	0	0	0	2	\N	0
1862673431	0	Pinkish Delight.	0	7	0	0	254.29	4	\N	0
947533463	0	archie wakanda	0	1	0	0	78	1	\N	0
765532371	0	kojek	0	7	0	0	0	0	\N	0
5987213097	0	firaa 🦋	0	1	0	0	0	0	\N	0
6027145753	0	Kim Hwa Sa.	0	13	0	0	0	0	\N	0
1839457705	0	rafi	0	1	0	0	0	0	\N	0
5424286390	0	Geraldy	0	19	1	0	0	11	\N	0
6178535522	0	aileen bisnis	0	1	0	0	0	0	\N	0
5902196059	0	vga	0	1	0	0	0	0	\N	0
5299771953	0	miki	9	20	0	0	1205.920000000002	7134	\N	0
5873868828	0	<33	0	1	0	0	0	1	\N	0
1750818476	0	˖ ֹ ꔫ Zynlyn	0	10	0	0	0	9	\N	0
1821470346	0	erick	0	13	0	0	0	0	\N	0
5658278875	0	thespian	0	12	0	0	0	17	\N	0
1761722329	0	A	0	9	0	0	0	2	\N	0
5200802415	0	arthur	0	57	0	0	0	304	\N	0
5260165046	0	vica	0	0	0	0	0	0	\N	0
6477472278	0	Luka Beckham	0	0	0	0	0	7	\N	0
1713681692	0	flaw	0	3	0	0	0	0	\N	0
5363582023	0	Hon€y	0	0	0	0	0	0	\N	0
1781161339	0	Ka! Ga! Mi! Kagami!	0	3	0	0	0	3	\N	0
6937563154	0	Ashiel G.	0	13	0	0	0	0	\N	0
5031785910	0	Ghifari Armes.	0	28	0	0	0	1377	\N	0
5857047365	0	cici	0	47	0	0	553.1299999999999	80	\N	0
5826341201	0	f	0	240	1	0	-8.539999999999718	81	\N	0
6648186657	0	Tiffany.	0	8	0	0	0	7	\N	0
5177446077	0	isel	0	1	0	0	0	0	\N	0
6084400622	0	Dom	0	52	0	0	0	3	\N	0
6408459327	0	Elrain's private bodyguard, Kalandra.	0	1	0	0	0	0	\N	0
5566706349	0	Jaxen	0	24	0	0	231.25	9	\N	0
5757765523	0	#V91. ꫟ Danzel warkop wcs¹ 🇿🇼	0	64	0	0	0	18	\N	0
1160300141	0	DIT	0	4	0	0	0	0	\N	0
6810219395	0	.A	0	1	0	0	0	0	\N	0
5479265872	0	leir	0	20	0	0	0	36	\N	0
1476105922	0	Rooor	0	32	0	0	0	7	\N	0
6648638493	0	melna	0	59	0	0	61.04	17	\N	0
5268400029	0	nope	0	111	0	0	0	5	\N	0
5352802824	0	Ꭾgs¹. Eri	0	3	0	0	200	0	\N	0
6641901558	0	a litte fairy, clar ʚɞ	0	0	0	0	0	0	\N	0
5046091233	0	jennaish.	0	3	0	0	0	0	\N	0
5132290219	0	JAEHYUN.	0	7	0	0	0	0	\N	0
6304952610	0	lody	0	14	0	0	0	36	\N	0
1580482926	0	𝐌etaraa	0	129	0	0	10.74	376	\N	0
2054513159	0	shenna aubrey.	0	29	0	0	0	36	\N	0
1431070338	0	xo	0	2	0	0	0	1	\N	0
5309065102	0	maca	0	9	0	0	0	0	\N	0
1898874607	0	celecew	0	3	0	0	0	1	\N	0
7062676813	0	sena	0	6	0	0	0	29	\N	0
1787413545	0	al	0	1	0	0	0	0	\N	0
902283760	0	jepa	0	2	0	0	15.8	11	\N	0
5597912341	0	angga	0	3	0	0	0	1	\N	0
5774288327	0	Nojeet	0	24	0	0	0.20000000000000284	330	\N	0
1795298804	0	Jojo	0	2	0	0	0	0	\N	0
1851415662	0	🦋	0	2	0	0	0	0	\N	0
1624848801	0	znnieeal	0	1	0	0	0	0	\N	0
1239598129	0	hanu	14	812	0	0	351.21250000000146	11701	\N	0
1772216590	0	neana.	0	37	0	0	775.46	37	\N	0
6542433301	0	esha lovin oliver	0	0	0	0	0	252	\N	0
5517540404	0	jovka open order hui	0	30	0	0	0	14	\N	0
5277041645	0	A	0	25	0	0	0	48	\N	0
6621091266	0	pani suka pink 💕	0	5	0	0	0	4	\N	0
6236859040	0	lionel yan | VVIP START FROM 8K	0	3	0	0	0	27	\N	0
1953889081	0	.	0	5	0	0	0	14	\N	0
6127707873	0	ayass	0	1	0	0	0	1	\N	0
2126528879	0	darrel	0	31	0	0	539.48	220	\N	0
5653327813	0	shea	0	2	0	0	0	2	\N	0
7027222693	0	Lambe Turah srikintillah	0	1	0	0	0	0	\N	0
5368283726	0	Calliope.	0	2	0	0	0	0	\N	0
5844448664	0	morana	0	2	0	0	0	1	\N	0
1041310722	0	Hizkia	14	104	0	0	553.49	129	\N	0
5813945609	0	kiri sully's.	0	1	0	0	0	0	\N	0
5038167852	0	SHIAGA	0	0	0	0	0	7	\N	0
5442509543	0	Zell.	0	0	0	0	0	15	\N	0
2146174051	0	.	0	311	0	0	0	516	\N	0
1654669592	0	NBA 🏀	0	5	0	0	0	1	\N	0
6057555887	0	cassy	0	1	0	0	10.15000000000005	0	\N	0
1948718490	0	Jecasa	0	0	0	0	0	0	\N	0
1604301123	0	sea	0	6	0	0	0	18	\N	0
5404094473	0	Noah Hawthorne	0	33	0	0	0	240	\N	0
6655246389	0	celi	0	26	0	0	0	63	\N	0
1398605645	0	kenya	0	2	0	0	0	2	\N	0
5920645632	0	seno†	9	669	0	0	3807.059999999993	4686	\N	1
5995743908	0	fii	0	1	0	0	0	1	\N	0
1897434618	0	ranggaa	0	11	0	0	0	0	\N	0
1793516342	0	atx.Mèrs	0	339	0	0	0	580	\N	0
5577537931	0	active.	0	39	0	0	0	2	\N	0
1920255861	0	iy²	2	1	0	0	21.81999999999971	0	\N	0
6879469107	0	Agam	0	2	0	0	0	7	\N	0
5562469288	0	N	0	129	0	0	0	87	\N	0
5085584466	0	jopiannnㅤㅤ	4	191	1	0	27.219999999999914	785	\N	0
6814533879	0	Kafka.	0	14	0	0	0	10	\N	0
5088418819	0	raka	0	32	0	0	0	0	\N	0
2062539851	0	tiann dying..	0	20	0	0	0	27	\N	0
5263630239	0	becca tolong rbio dulu	0	1	0	0	0	0	\N	0
5474123575	0	onaa	11	824	0	0	2278.209999999997	9265	\N	1
5698408354	0	-dde guritaa	0	2	0	0	0	29	\N	0
5340399655	0	𝐃evante #CSVKCAND	0	19	0	0	0	182	\N	0
5525593905	0	jira	0	59	0	0	329	508	\N	0
6231565372	0	alsa	0	4	0	0	1.1400000000000006	18	\N	0
1772905886	0	cece	0	5	0	0	0	1	\N	0
5059948390	0	sha	0	2	0	0	0	1	\N	0
6150052985	0	Zahrotusyita	0	2	0	0	0	0	\N	0
2018409308	0	Kaye	0	4	0	0	0	0	\N	0
2037170396	0	ulgi	0	2	0	0	0	2	\N	0
7121822150	0	$K	0	1	0	0	0	2	\N	0
6196778098	0	kiki	0	1	0	0	0	0	\N	0
5456574168	0	Dede Km	0	20	0	0	0	5	\N	0
5958324946	0	Arjaya	0	2	0	0	0	0	\N	0
5904631963	0	𖠌 Ken.	0	2	0	0	0	2	\N	0
6469633036	0	nokos	3	70	0	0	647.04	43	\N	0
6127395877	0	maja	0	1	0	0	0	4	\N	0
5849842275	0	dan	0	2	0	0	0	43	\N	0
1619411124	0	#pecinta woman💋💋	0	2	0	0	0	0	\N	0
1877185168	0	axter	0	28	0	0	0	64	\N	0
5879839367	0	Ajar	0	3	0	0	0	309	\N	0
7096918395	0	iikann	0	1	0	0	0	0	\N	0
1399490792	0	j	0	7	0	0	0	4	\N	0
1660465973	0	ᥕіᥣ᥆᥆	0	3	0	0	0	3	\N	0
6113797136	0	Onala marah bngt victoryking⁷	9	50	0	0	21.319999999999993	230	\N	0
6820725547	0	S	0	3	0	0	0	0	\N	0
6747953690	0	.	0	2	0	0	0	0	\N	0
1528006728	0	odelyn	0	3	0	0	0	4	\N	0
5420489873	0	mabok jimin	0	49	0	0	250	360	\N	0
6118511110	0	Kugisaki.	0	1	0	0	0	2	\N	0
5577805185	0	btnsr`förtis j !i	0	7	0	0	0	9	\N	0
5980990073	0	leaure	10	815	0	0	2602.5599999999995	3658	\N	1
5067154033	0	Mazella's.	0	56	0	0	0	29	\N	0
6326032235	0	tan	0	1	0	0	0	0	\N	0
1550496779	0	Abinaya.	0	5	0	0	0	2	\N	0
5552931059	0	LA	0	4	0	0	0	10	\N	0
6736163913	0	miche : ฅ @tadyeon y21 r2	0	3	0	0	0	17	\N	0
5383725822	0	acel	0	2	0	0	0	3	\N	0
2130158226	0	ceceee!	0	1	0	0	0	0	\N	0
1614196911	0	Ela	0	300	0	0	0	13	\N	0
6779765496	0	Jannè V	0	29	0	0	321.7	3	\N	0
1350824013	0	𐙚’ BETHny, h.	0	1	0	0	0	0	\N	0
5017997114	0	jean	0	4	0	0	0	0	\N	0
6605728602	0	Pizza	0	2	0	0	456	1	\N	0
5553399395	0	Zeninaaaa	0	2	0	0	0	0	\N	0
1831370759	0	yanyan	0	1	0	0	0	2	\N	0
2049502747	0	Yaksa.	0	1	0	0	0	0	\N	0
1225324869	0	𝐗𝐳𝐞𝐧 𝐃 𝐀𝐥𝐚𝐬𝐤𝐚𝐫	0	4	0	0	0	0	\N	0
6470480544	0	chioko	0	47	0	0	1.0399999999999991	61	\N	0
6101556630	0	Eve	0	3	0	0	0	9	\N	0
5897421181	0	Langit.	0	2	0	0	0	0	\N	0
1899614418	0	dudul jelek 𓅷	0	1	0	0	0	9	\N	0
1570671673	0	rey	0	0	0	0	0	0	\N	0
6355040739	0	rbio lah, ngejam	0	6	0	0	0	3	\N	0
6346958179	0	.	0	3	0	0	0	3	\N	0
7082896670	0	sossocc	0	3	0	0	0	1	\N	0
1277195745	0	Tama	0	0	0	0	0	0	\N	0
5858710808	0	nanadd	0	47	0	0	13	98	\N	0
1842653466	0	dveinnie.	0	116	0	0	1600.5600000000002	2216	\N	0
1939951004	0	ndut	0	0	0	0	35.49	3	\N	0
1093416705	0	Nebula	0	2	0	0	0	0	\N	0
2007582857	0	Ed	0	0	0	0	0	0	\N	0
1477285503	0	norea	1	131	0	0	12.560000000000002	219	\N	0
5159794678	0	Yaya	0	3	0	0	0	2	\N	0
1852474727	0	vanka not kavan	0	2	0	0	0	13	\N	0
5651105337	0	RYU.	0	3	0	0	0	0	\N	0
1787434973	0	Lavienna a.a	0	2	0	0	0	4	\N	0
6111644836	0	indi	0	13	0	0	0	4	\N	0
5005349099	0	ㅤㅤ	0	3	0	0	0	3	\N	0
1217532756	0	.	0	1	0	0	0	0	\N	0
1992769862	0	rxtassie	0	5	0	0	0	1	\N	0
6598043308	0	cia 1	0	4	0	0	0	0	\N	0
5543840031	0	MALKA.	0	3	0	0	0	189	\N	0
1124661718	0	Alth.	8	74	0	0	2640.850000000001	281	\N	0
2006407741	0	Nara	0	1	0	0	0	0	\N	0
5805189837	0	firgi parvez	0	6	0	0	150	47	\N	0
5805398143	0	K.	4	70	0	0	581.66	1086	\N	0
1719989884	0	die.	0	33	0	0	0	2	\N	0
2110093849	0	always make art 🧎🏻‍♀️	0	4	0	0	0	0	\N	0
6525962143	0	estaa.	0	1	0	0	0	0	\N	0
1795598255	0	Charles	0	8	0	0	0	0	\N	0
5906557272	0	Onyx ganteng	0	112	0	0	0	1026	\N	0
1621769565	0	sarah	0	6	0	0	0	48	\N	0
1301815927	0	elliot	0	1	0	0	0	0	\N	0
5393826132	0	262chesy mangemomekmãsex	0	3	0	0	0	7	\N	0
1829753249	0	chasè	0	0	0	0	0	1	\N	0
1854454869	0	defan	0	8	0	0	0	15	\N	0
6367969021	0	ᵀᵈᵖ charinee	0	4	0	0	0	1	\N	0
1453631367	0	kirra¹⁵⁴³	0	2	1	0	0	0	\N	0
5662726628	0	merry	0	1	0	0	0	1	\N	0
1827516577	0	Nnae, Sadulan.	0	1	0	0	0	0	\N	0
5092444374	0	nanAs’ yg msih butuh rechat	0	13	0	0	0	1	\N	0
5960340010	0	Naraaw	0	8	0	0	0	2	\N	0
5184847237	0	sha	0	1	0	0	0	0	\N	0
6610665733	0	Airish	0	1	0	0	78	0	\N	0
2116928615	0	R48, Ki	0	7	0	0	60.9700000000001	0	\N	0
1833270394	0	sachiko	0	5	0	0	0	937	\N	0
1829063693	0	Jovanka.	0	2	0	0	0	38	\N	0
5975966747	0	f	0	1	0	0	0	0	\N	0
6383011427	0	Vee	0	30	0	0	409.27	228	\N	0
5437622078	0	Asyä jev.	0	3	0	0	0	4	\N	0
6180830213	0	kanaya 🧿〰️🧿	0	4	0	0	0	41	\N	0
5317520799	0	GrimmJack	0	75	0	0	10	1	\N	0
949485167	0	Bnm	0	1	0	0	0	0	\N	0
1719597499	0	yiyi	0	2	0	0	0	0	\N	0
1760789058	0	agam	0	3	0	0	0	1	\N	0
5497568610	0	L`oraa	0	1	0	0	0	0	\N	0
6659789568	0	alleyul	0	18	0	0	0	22	\N	0
5845338469	0	langit	0	114	0	0	1456.98	37	\N	0
1530223950	0	asey	0	3	0	0	0	0	\N	0
5033917212	0	keith salimaw¡kky	0	1187	0	0	2041.9050000000002	520	\N	0
5085863824	0	Bara	0	0	0	0	0	1	\N	0
5032138484	0	kanja	0	9	0	0	741.3	44	\N	0
5949470293	0	ayey wikky salima	0	22	0	0	49.989999999999995	2	\N	0
1977100410	0	jeff	0	8	0	0	0	39	\N	0
6727771917	0	🎀 ۫ ୧ ᵖᵒᵖⁱ #𝐩wₑ𝚝ᵢₑz ׅ ֹ ꒱	0	24	0	0	0	11	\N	0
5467877597	0	soft	0	0	0	0	0	0	\N	0
5238220966	0	Rivera	0	2	0	0	0	0	\N	0
6939214016	0	ᯂᯮ tacy	0	35	0	0	0	5	\N	0
1460397884	0	joency	0	2	0	0	0	1	\N	0
1926222378	0	zeeya	0	36	0	0	79	25	\N	0
2081576680	0	pissknot	0	1	0	0	0	0	\N	0
1992670414	0	nazel	0	3	0	0	0	2	\N	0
963967347	0	kesa	0	26	0	0	0	10	\N	0
1623089432	0	kenzy	11	6	0	0	5549.52	110	\N	0
5696995084	0	Dimas	0	15	0	0	0	4	\N	0
5679392938	0	Cendana	0	1	0	0	0	1	\N	0
1233196083	0	Jav.	0	0	0	0	0	1	\N	0
5035352084	0	Apa iyah	0	29	0	0	-9	31	\N	0
5820934284	0	Abimanyu Prathama	0	1	0	0	0	0	\N	0
6624977211	0	𝐃hiɑjɘng 𝐀birɑyɑ	0	2	0	0	0	1	\N	0
6177112916	0	༊. th'majestic, mumuu <🦢>	0	8	0	0	0	34	\N	0
6394309962	0	𝕾𝖇𝖎~Gracella~	0	0	0	0	0	2	\N	0
1588689014	0	grv, Edgar L.	0	19	0	0	0	0	\N	0
5504745980	0	ㅤㅤㅤㅤㅤ	0	3	0	0	0	2	\N	0
5841650225	0	joileen	0	119	0	0	1.1200000000000045	52	\N	0
1846049772	0	rv	0	10	0	0	0	11	\N	0
5110423320	0	vallennie	0	29	0	0	0	3	\N	0
1330452826	0	naze	0	6	0	0	0	1	\N	0
1765126855	0	xzbli	0	4	0	0	0	35	\N	0
6230567205	0	r	0	5	0	0	0	0	\N	0
1530430037	0	nara	0	35	0	0	0	11	\N	0
5123626661	0	Jenny	0	1	0	0	0	0	\N	0
5838881481	0	ai🧍🏻‍♀	0	17	0	0	0	32	\N	0
6613897136	0	a	0	3	0	0	0	0	\N	0
1902573483	0	Delio	0	3	0	0	0	4	\N	0
1977118542	0	ca.	0	14	0	0	0	52	\N	0
1776521875	0	Wawa	0	75	0	0	0	386	\N	0
6108982295	0	ɐlᴉʞ	0	7	0	0	0	182	\N	0
1715011431	0	Calova	0	13	0	0	0	0	\N	0
5920852562	0	Fien [𝐒𝐕𝐇𝟑𝟏]ᴰ¹	0	5	1	0	0	110	\N	0
5401341286	0	.	0	27	0	0	252.3799999999997	114	\N	0
1102767683	0	Valle.	0	149	0	0	75	34	\N	0
1971119548	0	Nini	0	4	0	0	0	0	\N	0
5104272886	0	raY	4	380	1	0	28.009999999999877	2244	\N	0
729432161	0	Rara	0	1	0	0	0	9	\N	0
1247472545	0	bumi	0	18	0	0	0	21	\N	0
914080256	0	albraga	0	23	0	0	0	1	\N	0
1900871505	0	Raf	0	2	0	0	0	0	\N	0
1838304546	0	buttercupp wrg	0	1	0	0	0	0	\N	0
2077913314	0	Lagi strees	0	3	0	0	0	1	\N	0
6105065712	0	yola	0	43	0	0	0	14	\N	0
1498409098	0	User z	0	17	0	0	0	0	\N	0
2003692971	0	Bimæ dua	0	2	0	0	0	0	\N	0
6300905936	0	Unknown.	0	5	0	0	0	0	\N	0
5465921607	0	jidan	0	1	0	0	0	0	\N	0
5773933731	0	Papayon	0	3	0	0	0	0	\N	0
2092745120	0	Jordan	0	22	0	0	0	3	\N	0
5707774986	0	enriko 🐲	0	17	0	0	50.82	6	\N	0
1753618089	0	kale	0	117	0	0	55.67999999999938	845	\N	0
6088998971	0	aji	0	2	0	0	0	0	\N	0
5872359158	0	Kharaa	0	11	0	0	0	7	\N	0
5199384861	0	J	0	3	0	0	0	0	\N	0
6266320295	0	nanda @sugaqr	0	267	0	0	829.5699999999998	366	\N	0
1989873003	0	D	0	3	0	0	0	1	\N	0
1691558801	0	ywdah	0	52	2	0	87.83999999999996	0	\N	0
5998250578	0	ꜰ͢ᴅ`. viby	0	18	0	0	0	149	\N	0
6026272965	0	Aphrodde	0	5	0	0	0	0	\N	0
5406547237	0	Romy	0	2	0	0	0	2	\N	0
5925854954	0	nimos	12	199	0	0	647.4899999999992	100	\N	0
1751336232	0	vinaa loving jekeyy	0	2	0	0	0	2	\N	0
1652521032	0	dina	0	3	0	0	0	0	\N	0
6303413374	0	c	0	1	0	0	0	0	\N	0
6262638495	0	amel⑅	0	187	0	0	328.25	481	\N	0
1705124709	0	Giscaella, D.	7	149	0	0	1951.0200000000264	4982	\N	1
2127310212	0	kyyy	0	3	0	0	278	0	\N	0
6980373245	0	fr	0	2	0	0	0	3	\N	0
1777097729	0	ִִ֗ 𝐐𝐮𝐞𝐞𝐧 𝐆𝐚𝐛𝐫𝐢𝐞𝐥𝐥𝐚 𝐌𝐨𝐫𝐚𝐧𝐚 𝐁𝐞𝐥𝐥𝐨𝐧𝐚	0	2	0	0	0	6	\N	0
6040281207	0	Sharon	0	18	0	0	9.64	18	\N	0
6430145810	0	feerdi	0	57	0	0	7	6	\N	0
6280623903	0	Nara	0	47	0	0	0	4	\N	0
5883773007	0	hunter sec akun	3	374	0	0	46.83999999999969	8609	\N	0
1609527458	0	cila sdg stress	0	22	0	0	0	4	\N	0
6566273612	0	syahla 🇸🇰	0	2	0	0	0	0	\N	0
5213952875	0	maki	0	1	0	0	0	0	\N	0
5867983955	0	G	0	17	0	0	0	72	\N	0
5611366449	0	kevin bukan? bukan	0	25	0	0	0.3900000000000041	24	\N	0
1241788017	0	aQasia	0	1	0	0	0	0	\N	0
6475177514	0	Mirrane	0	1	0	0	0	9	\N	0
6557312249	0	𝐟𝐥𝐨𝐫𝐞𝐧𝐜𝐞	0	1	0	0	0	0	\N	0
2096220649	0	cylalalala salimalokalies	0	36	0	0	0	9	\N	0
1805113092	0	最漂亮, naae!	0	1	0	0	0	0	\N	0
1635266278	0	Imanuel	2	448	0	0	1955.6	1123	\N	0
5928624524	0	ren	0	12	0	0	384.46	6	\N	0
6249064126	0	Kamal	0	3	0	0	2500	1	\N	0
6045483930	0	Nala, A.	0	1	0	0	0	14	\N	0
6816866922	0	asya wifey	0	4	0	0	0	1	\N	0
1448098432	0	a	0	1	0	0	0	0	\N	0
1265835008	0	ra	0	2	0	0	0	0	\N	0
6168539527	0	issabelle	0	51	0	0	0	1	\N	0
5306893372	0	jemima	0	0	0	0	0	0	\N	0
1310838767	0	kaila	0	6	0	0	0	218	\N	0
5405647581	0	mingki cassa	0	1	0	0	0	2	\N	0
5750701060	0	K	0	109	0	0	0	65	\N	0
5143742320	0	nara	0	19	0	0	0	13	\N	0
5370531936	0	zageVà	5	23	0	0	105.22999999999999	26	\N	0
1920010770	0	dainty mau wolf	0	8	0	0	2710.660000000001	1398	\N	0
5182392739	0	Nadisha <♡>	0	5	0	0	0	0	\N	0
6642595039	0	Milieèn	0	37	0	0	0	4	\N	0
5745407251	0	𐙚 ׁ Kajesha.	0	1	0	0	0	0	\N	0
1462324292	0	FlyMoon👣	0	16	0	0	0	19	\N	0
5962541730	0	- N	0	6	0	0	0	20	\N	0
2013163568	0	Nav	0	1	0	0	0	1	\N	0
1501465600	0	Leya	0	9	0	0	0	4	\N	0
7137885852	0	🎃	0	24	0	0	0	11	\N	0
1129595955	0	Nao	11	125	1	0	674.8500000000001	158	\N	0
6505153603	0	Haennara blubup blubup 🫧	0	2	0	0	0	1	\N	0
6894273811	0	Bláir Artēmis	0	1	0	0	0	0	\N	0
5643154871	0	Shane	0	125	0	0	0	735	\N	0
2023021797	0	mikasa	0	1	0	0	0	6	\N	0
5756834458	0	3	0	3	0	0	0	55	\N	0
5709700985	0	Beri	4	69	0	0	26.25	52	\N	0
998504779	0	j	4	228	0	0	2189.34	273	\N	0
2104006466	0	leci a.	0	2	0	0	0	109	\N	0
1639041815	0	Anda	0	30	0	0	36.44999999999999	58	\N	0
6654805407	0	ejaa	3	2	0	0	80.08	50	\N	0
6610214231	0	Clra.	0	3	0	0	0	1	\N	0
5330028834	0	⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣soke bahtera	0	12	0	0	0	8	\N	0
6561159268	0	Kathleen Mikhailova.	0	7	0	0	0	17	\N	0
5835304448	0	Babyboyyy	0	3	0	0	0	2	\N	0
6016130849	0	Louis Fernando	0	5	0	0	0	5	\N	0
1876271877	0	Iren ren	0	22	0	0	280	7	\N	0
1710038380	0	je	0	169	0	0	9.889999999999986	1461	\N	0
1780807325	0	gavvvv	0	23	0	0	0	0	\N	0
1941668137	0	cris srz	0	0	0	0	0	0	\N	0
6451641347	0	raii	0	5	0	0	0	16	\N	0
7008677417	0	rest. 𝐍𝐚𝐨𝐦𝐢	0	12	0	0	0	89	\N	0
1785519749	0	zenaa	12	999	0	0	72834.83000000002	4198	\N	1
2064008627	0	aku nana.	0	1	0	0	0	9	\N	0
1696135894	0	Jirooooo	0	3	0	0	0	7	\N	0
1840840710	0	196 marcom	0	3	0	0	0	2	\N	0
1894647941	0	Indra	0	23	0	0	0	7	\N	0
6068707305	0	varrel	0	87	1	0	0	9	\N	0
6852105807	0	lauren	0	26	0	0	0	41	\N	0
5116607287	0	Lin	0	3	0	0	0	2	\N	0
6103668495	0	hagi	0	13	1	0	0	3	\N	0
5001349821	0	ryukk gfll 💭	0	4	0	0	0	6	\N	0
5741625031	0	uci	0	8	0	0	0.3500000000000014	30	\N	0
5280767145	0	Mary	0	1	0	0	0	0	\N	0
6394016410	0	jedo 𓃮𝖕𝖗𝖆𝖙𝖚 𝖊𝖍𝖒𝖆 𝐒l𝙨ˡᵉᵃʳⁿᵉʳ 𝐌odel⃟≛	0	51	0	0	9.230000000000004	92	\N	0
5873357040	0	cessa.	0	2	0	0	0	7	\N	0
1454970938	0	reja	0	100	0	0	425.1699999999997	95	\N	0
1745986712	0	Shen as seller	0	3	0	0	0	0	\N	0
5396837244	0	Ara.	0	4	0	0	0	1	\N	0
5685008706	0	kacey 4twenty	0	10	0	0	0	49	\N	0
6155144819	0	V, jangan ke rc kalo ga disuruh.	0	4	0	0	0	18	\N	0
5004189205	0	bubu	0	15	0	0	0	2	\N	0
1918653034	0	Jé	0	99	0	0	0	274	\N	0
6837856602	0	sabiéel 🎀	0	1	0	0	0	0	\N	0
5392496573	0	btnstr. exa	0	1	0	0	0	12	\N	0
2094066551	0	Jid	0	16	0	0	393.34	3	\N	0
6453939406	0	auraa	0	7	0	0	0	5	\N	0
5460706113	0	𝓐𝓵	0	6	0	0	0	0	\N	0
6686624917	0	Mr	0	1	0	0	0	0	\N	0
6138627089	0	Tara	5	368	0	0	62.57000000000744	531	\N	0
1804356193	0	Gastara.	0	240	0	0	64.4100000000004	66	\N	0
6325938027	0	fasa	0	1	0	0	0	1	\N	0
5027573592	0	lay	0	1	0	0	0	0	\N	0
6587399354	0	N	0	1	0	0	0	0	\N	0
1154543504	0	Ad 🇮🇩	0	1	0	0	0	0	\N	0
5774832911	0	shaki	0	1	0	0	0	1	\N	0
6594625549	0	👩‍💼	0	1	0	0	0	0	\N	0
1722616656	0	rxx	0	8	2	0	0	1	\N	0
5450614015	0	ちんたにゃ	0	4	0	0	0	8	\N	0
5036139161	0	abi	0	1	0	0	0	17	\N	0
5973515977	0	àsha🎟️🩰🕯️	0	2	0	0	0	1	\N	0
5981847303	0	Denis	0	4	0	0	0	0	\N	0
1895239389	0	.	0	178	0	0	78.44	1800	\N	0
6950260224	0	𖠗 🐇 ꞋꞌꞋ zeline anastasya 🎀 𓄹 . ִ ֗:	0	5	0	0	0	5	\N	0
1527902181	0	riri	0	6	0	0	0	5	\N	0
1953418481	0	icy.	0	0	0	0	0	0	\N	0
6470956532	0	Vann Dé tensei Winael Kanza	0	19	0	0	-7.32	3	\N	0
6358738706	0	al 🐞 lama? uns	0	0	0	0	0	0	\N	0
2006392183	0	rafka	0	2	0	0	0	4	\N	0
1808377129	0	Ciwaaa	0	96	0	0	0	41	\N	0
5939365956	0	æs	0	222	0	0	2.900000000000091	806	\N	0
6628322071	0	bella	0	0	0	0	0	2	\N	0
1624674994	0	r	0	119	0	0	0	112	\N	0
5685507833	0	killà	0	64	0	0	852.7200000000001	260	\N	0
5440941709	0	𝖔𝖗𝖉𝖎𝖓𝖆𝖗𝖞𝖇𝖔𝖞	0	1	0	0	0	1	\N	0
6002437510	0	ca	0	8	0	0	0	0	\N	0
5037877022	0	.	0	1	0	0	0	5	\N	0
5745716870	0	jordaniel	0	8	0	0	0	1	\N	0
6154237615	0	mbul	0	8	0	0	0	0	\N	0
6521796347	0	Ashquïn L.	0	2	0	0	0	1	\N	0
5423083144	0	Masapapppp	0	115	3	0	0	9	\N	0
6417346851	0	salsa	0	2	0	0	0	0	\N	0
5206325733	0	syuu	0	2	0	0	0	1	\N	0
1733046858	0	Elsputrii	0	0	0	0	0	0	\N	0
5067540308	0	mysel	14	1800	0	0	9.119999999999749	1818	\N	1
1939269131	0	j	0	6	0	0	10.34	30	\N	0
6361682735	0	jaden	0	2	0	0	0	1	\N	0
1116794073	0	Gading.	0	11	0	0	0	3	\N	0
6016529570	0	Guinevere	0	0	0	0	0	24	\N	0
1659740058	0	Nastar	0	6	0	0	0	3	\N	0
5170769721	0	@#$&!?	0	1	0	0	0	0	\N	0
1993983973	0	∂ Libe	0	135	0	0	5	0	\N	0
1439143095	0	Abrar E.	0	1	0	0	0	0	\N	0
5156702143	0	th¡	0	4	0	0	0	36	\N	0
5694604915	0	isaaa	0	8	0	0	6	11	\N	0
6687646174	0	shine	0	9	0	0	0	0	\N	0
1782451804	0	𝐙𝐢𝐚𝐧	0	2	0	0	0	3	\N	0
628052146	0	JoanÃ #CALMINJRT	0	2	0	0	4.41	10	\N	0
5331367012	0	miau	0	484	0	0	-0.5	1402	\N	0
1729986446	0	raa.	0	1	0	0	0	0	\N	0
5125947467	0	rean	0	4	0	0	0	16	\N	0
5252763032	0	Rodney hiat	0	13	0	0	0	39	\N	0
5014714828	0	acc jaseb	0	42	0	0	0	0	\N	0
6231722112	0	fyy	0	0	0	0	0	0	\N	0
6742089613	0	ⓘ.. “智者.”, o`Sagé 𓇼	0	4	0	0	0	7	\N	0
5750673412	0	a	0	8	0	0	0	30	\N	0
6563810746	0	⁉️⁉️	0	19	0	0	0	171	\N	0
6237341309	0	vèe	14	20	0	0	1766.32	586	\N	0
6107827161	0	lau	0	1	0	0	0	0	\N	0
5947066329	0	laresha.	0	1	0	0	0	0	\N	0
1785662005	0	Nayora avors	7	119	1	0	2225.6800000000003	544	\N	0
1405648282	0	ㅤ kansa	0	0	0	0	162.91	24	\N	0
5464423847	0	Javas.	12	416	0	0	944.1800000000001	878	\N	0
5917916106	0	gigi gondrong	0	1	0	0	0	0	\N	0
5493198271	0	f	0	21	0	0	0	6	\N	0
5048334763	0	hani	0	7	0	0	0	2	\N	0
1870668215	0	Meng	8	304	0	0	29034.95000000003	857	\N	1
1784993283	0	eza	12	547	0	0	52602.78000000001	1515	\N	1
5874028929	0	Dylan	0	1	0	0	0	0	\N	0
6289358302	0	y	0	3	0	0	0	0	\N	0
5022835940	0	ㅤㅤㅤㅤㅤ	0	26	0	0	179.38	636	\N	0
5206351393	0	εїз 🙇🏻‍♀ đyıns !𝟹 ੭ ⋆﹗	0	15	0	0	0	1	\N	0
1395931093	0	shiki	0	6	0	0	0	1	\N	0
5308484507	0	127. chiisea	0	1	0	0	0	52	\N	0
1945966541	0	sunny, kæris luff jeno	0	17	0	0	0	8	\N	0
6434971144	0	Agak laen	0	8	0	0	0	53	\N	0
6375158285	0	eulalia	0	0	0	0	0	0	\N	0
1963543718	0	Eiya.	0	7	0	0	0	27	\N	0
834757853	0	t	0	10	0	0	0	0	\N	0
6275541926	0	syahla	0	1	0	0	0	0	\N	0
5693272398	0	Mai	9	923	0	0	11304.489999999998	8274	\N	1
7094552046	0	jeán kind!	0	3	0	0	0	0	\N	0
5930922625	0	Human	0	3	0	0	0	44	\N	0
1414822179	0	anna	0	83	0	0	1.2199999999999989	29	\N	0
6092314039	0	chocoo	0	182	0	0	12.82	18	\N	0
1238924102	0	Revaya Valencia	0	1	0	0	0	0	\N	0
5363865901	0	machi	0	27	0	0	0	228	\N	0
1401747284	0	Nathaniel	0	5	0	0	0	28	\N	0
5454906818	0	araa	0	1	0	0	0	2	\N	0
5540933340	0	fayew	0	39	0	0	221.68	1283	\N	0
6761420157	0	Reo	0	3	0	0	0	0	\N	0
2126237279	0	isa	0	1	0	0	0	0	\N	0
5766880241	0	676.1us hauzan	0	9	0	0	0	9	\N	0
5176939320	0	given	0	10	0	0	0	0	\N	0
6420819810	0	jenit	0	33	0	0	0	195	\N	0
1507944316	0	Ningtyas pacar jijel	0	3	0	0	0	4	\N	0
1559864759	0	Lanavy	0	7	0	0	0	0	\N	0
1704186489	0	` aya	0	16	0	0	0	0	\N	0
6201975006	0	salsaaa	0	7	0	0	0	3	\N	0
1633781989	0	TriAna	0	23	0	0	0	0	\N	0
5832446846	0	flOo	0	7	0	0	0	43	\N	0
6667436171	0	丂ｲム mamiiy.	0	4	0	0	0	12	\N	0
2002663613	0	ᥲᥱrіі @choccmint	0	1	0	0	0	0	\N	0
6098007015	0	♱ Elyza V. Cath	0	6	0	0	0	67	\N	0
2030931056	0	ℒeabèth Adela–M'S.	0	1	0	0	0	0	\N	0
5241809021	0	ㅤ	0	1	0	0	0	0	\N	0
5053441949	0	Ganesja 🇵🇸	0	1	0	0	0	0	\N	0
2106901206	0	ᴀʀᴛʜᴜʀ	0	81	3	0	0	3	\N	0
1776998307	0	syaa	0	3	0	0	0	0	\N	0
6505590789	0	naylaa	0	33	0	0	149.4	199	\N	0
1957956219	0	abraham	0	77	0	0	0	3713	\N	0
6602035798	0	h	0	6	0	0	0	0	\N	0
1903489941	0	jejen ikan 𓆝 𓆟 𓆞 𓆝	0	43	0	0	0	7	\N	0
5730239096	0	wakwaw	0	8	0	0	0	16	\N	0
5630929224	0	lumiere	0	21	0	0	0	0	\N	0
1836280760	0	chamatcha	0	3	0	0	0	0	\N	0
1419286044	0	dni.	0	940	0	0	296.9599999999999	1217	\N	0
6266476937	0	a	0	15	0	0	414.94	5	\N	0
5152103288	0	𝐄𝔠𝔲𝔩 ³² 🩰🦢 ᴰᵂ ' ᴮᴷᴿ `ʰˢ `ᴿᴳᶜ	0	3	0	0	0	0	\N	0
2065756913	0	m	0	11	0	0	0	0	\N	0
5693024257	0	marcelo jo.	0	0	0	0	0	38	\N	0
6881009236	0	Cowonya Nadin	0	11	0	0	0	0	\N	0
1817126885	0	Caltha, dfrect	0	2	0	0	0	0	\N	0
1337985323	0	shafaa	0	3	0	0	0	7	\N	0
6204065524	0	oliver	4	43	0	0	1126.5200000000004	227	\N	0
5382339617	0	jen	0	68	0	0	7.5	109	\N	0
5415951696	0	Hendra	0	1	0	0	56.44	0	\N	0
5601381291	0	Seraw	0	5	0	0	0	1	\N	0
1723425717	0	Jerome Ha	0	3	0	0	0	48	\N	0
5088449234	0	ordinary	12	10	0	0	88.7	6	\N	0
1376502597	0	c	0	85	0	0	80.21000000000025	214	\N	0
1849787051	0	l	0	1	0	0	0	0	\N	0
1745250446	0	angel~	0	13	0	0	0	5	\N	0
5060226063	0	Devil	0	15	0	0	2.0800000000001546	0	\N	0
6540532580	0	Len	0	1	0	0	0	0	\N	0
6274877191	0	karunya	0	2	0	0	0	0	\N	0
5529712437	0	Scrambler	0	3	0	0	0	2	\N	0
1590944881	0	🇮🇲 𓁿ʟɪʟ• ᴡɪʟʟʏ ᶜᵃᵇᵘˡ	14	2	0	0	77.78	16	\N	0
6414127126	0	Vaa	0	9	0	0	12.06	38	\N	0
5429731174	0	sacha	0	4	0	0	0	0	\N	0
2106612454	0	nio	0	0	0	0	0	1	\N	0
1075635040	0	f	0	7	0	0	0	0	\N	0
5193415693	0	Segga West	0	121	0	0	63	93	\N	0
5313683474	0	n.	0	1	0	0	0	1	\N	0
1656352871	0	rey	0	6	0	0	0	0	\N	0
6111532256	0	D.O.S	0	1	0	0	0	0	\N	0
1922673162	0	evaa #lOovingmygf <3	7	499	0	0	4241.750000000001	630	\N	0
5664425405	0	kaye	0	1	0	0	0	2	\N	0
1876026455	0	Sajiwa A.	0	26	0	0	0	66	\N	0
5139156493	0	ben	0	22	0	0	890	20	\N	0
1793402436	0	buyut nio	0	14	0	0	0	11	\N	0
1842288711	0	unknow	0	2	0	0	0	0	\N	0
5712639287	0	Scorpio	0	8	0	0	0	24	\N	0
5460473289	0	maset	0	113	1	0	1290	0	\N	0
2131248611	0	sadie — ᧔♡᧓ ݁ ׅ	0	12	0	0	0	9	\N	0
1305013919	0	;	0	8	0	0	0	0	\N	0
2055232369	0	yasel	10	10	0	0	546.71	166	\N	0
5401561129	0	Azara	0	4	0	0	0	0	\N	0
1080564443	0	Dejoi,	0	10	0	0	0	2	\N	0
5258760363	0	Anva	0	18	0	0	0	13	\N	0
5258843190	0	—J	0	1	0	0	0	6	\N	0
1945338044	0	S	0	79	0	0	0	32	\N	0
6985663758	0	n	0	0	0	0	8.21	29	\N	0
5271123480	0	lexx	0	2	0	0	0	1	\N	0
5929297594	0	naaev	0	1	0	0	0	0	\N	0
6040844685	0	#E845	0	45	0	0	0	7	\N	0
2006372157	0	f	0	17	0	0	0	121	\N	0
6932785121	0	s	0	7	0	0	0	0	\N	0
5852717757	0	asha	0	1	0	0	0	0	\N	0
5272410336	0	Gam.	0	204	0	0	717.89	16	\N	0
1212228009	0	alfreda	0	1	0	0	0	17	\N	0
5641875484	0	al	0	0	0	0	0	0	\N	0
5454652209	0	aldetra	0	0	0	0	0	6	\N	0
5781417754	0	mike	0	1	0	0	0	0	\N	0
5657772592	0	kak ros	0	24	0	0	0	27	\N	0
5111537448	0	maya.	0	1	0	0	0	1	\N	0
635879061	0	ekil	0	4	0	0	0	1	\N	0
5417502735	0	eca betmut se dunia	0	2	0	0	9.79	0	\N	0
1341846685	0	UJANG SHELBY	0	9	0	0	0	6	\N	0
1688908140	0	ayaa	0	1	0	0	0	0	\N	0
6539747342	0	meimei	0	4	0	0	72.25	95	\N	0
5322558755	0	abbey	0	10	0	0	0	0	\N	0
1405605825	0	Velo	0	0	0	0	0	0	\N	0
6816457179	0	na	0	35	0	0	248	101	\N	0
2043675966	0	cece	0	16	0	0	0	11	\N	0
2061883233	0	Apiiii	0	4	0	0	0	19	\N	0
6068112446	0	lavie	0	1	0	0	0	1	\N	0
2016204383	0	悪ガキ	0	79	0	0	29.73	203	\N	0
1769236346	0	kala	0	4	0	0	0	0	\N	0
1698084127	0	d	0	261	0	0	0	2	\N	0
6199255855	0	faaz.	0	5	0	0	0	0	\N	0
1695503552	0	jepa 🇬🇧	0	13	0	0	0	30	\N	0
7183424531	0	ᴊᴇᴠᴀɴ	0	8	0	0	4	1	\N	0
6271523487	0	hmmm	0	6	0	0	120.45	5	\N	0
6452778090	0	gracia	0	2	0	0	0	1	\N	0
1436025934	0	.	0	1	0	0	0	0	\N	0
1847797739	0	Jeyya M.	0	20	0	0	0	156	\N	0
1848234232	1	yureei	0	603	0	0	8.06000000000006	422	\N	0
6093879987	0	k for kendal	0	9	0	0	0	0	\N	0
6796629423	0	R	0	10	0	0	0	11	\N	0
1201962619	0	pls return the @ /ᐠ - ˕ -マⳊ	0	2	0	0	0	1	\N	0
5963345984	0	arabella	0	9	0	0	0	0	\N	0
6947248315	0	rama	0	4	0	0	0	9	\N	0
5450603710	0	keaaauu	0	0	0	0	0	0	\N	0
1230069401	0	Winter.	0	159	0	0	25.27	650	\N	0
6110880503	0	kangen kamu, arsha.	0	2	0	0	0	0	\N	0
1898912084	0	Gadis	0	1	0	0	0	2	\N	0
6550062099	0	nadisha	0	1	0	0	0	0	\N	0
6203518784	0	🎀 > nαsyαα !! ♡ ____< 🩰	0	73	0	0	0	27	\N	0
1436399308	0	jisha	0	3	0	0	0	85	\N	0
6538989301	0	kiara	0	60	0	0	0	11	\N	0
5329569735	0	K.	0	78	0	0	318.71	63	\N	0
7100714497	0	Ninaa	0	2	0	0	0	0	\N	0
5984550035	0	farka	0	2	0	0	0	0	\N	0
1479016798	0	Mitsuki, 月亮.	0	4	0	0	0	426	\N	0
6570765488	0	prama	0	0	0	0	0	9	\N	0
1916800966	0	srchaa	0	7	0	0	0	3	\N	0
2030953255	0	L	0	15	0	0	0	0	\N	0
6186299197	0	јᧉssꪱᧉ	0	49	0	0	20	0	\N	0
5554070154	0	...	0	2	0	0	0	0	\N	0
5368085429	0	Ferdi	0	0	0	0	0	3	\N	0
5396664300	0	Rakael.	0	165	0	0	0	23	\N	0
5749596192	0	᥀ ִ ׁ ઇઉ ﹫cibey	0	72	0	0	447	92	\N	0
5368382943	0	𖦞 . . th'kaileen.🍁🫕	0	32	0	0	214.22000000000003	20	\N	0
6562109953	0	jovytha	10	223	0	0	8194.630000000001	1978	\N	0
1641585237	0	nanaa	0	7	0	0	0	1	\N	0
1714961252	0	leyren	0	1	0	0	0	0	\N	0
7169099026	0	hirayä, b.	0	19	0	0	0	100	\N	0
5563266925	0	Sad	0	1	0	0	0	0	\N	0
2016371963	0	Loka	0	46	0	0	0	274	\N	0
5486612727	0	.	0	346	1	0	102.5	75	\N	0
1757955444	0	neyy	0	2	0	0	0	2	\N	0
5251401879	0	vgz. bie ksl sm Riham eek	0	12	0	0	0	28	\N	0
5253430210	0	nio	0	31	0	0	0	3	\N	0
6323122292	0	rian	0	4	0	0	0	3	\N	0
5217354199	0	syafa	0	3	0	0	0	38	\N	0
5715409114	0	nathy	0	4	0	0	0	7	\N	0
1192353561	0	Nzoo	0	2	0	0	0	0	\N	0
1642842247	0	tea	0	287	0	0	0	34	\N	0
5237331661	0	Githa	0	304	0	0	4.75	1164	\N	0
1975953492	0	Louiis	0	0	0	0	0	0	\N	0
6615238281	0	Jannet.	0	6	0	0	0	9	\N	0
1310233569	0	Cicak gepengg	0	51	0	0	100	167	\N	0
1648103353	0	kayes	0	5	0	0	0	37	\N	0
5120029962	0	KENAL AYA?	0	4	0	0	0	0	\N	0
6086821621	0	bella	9	30	0	0	796.3499999999999	355	\N	0
6161679087	0	jevana	0	100	0	0	1300.6299999999997	764	\N	0
6726005997	0	s	0	1	0	0	0	0	\N	0
1749496976	0	dd	0	6	0	0	0	92	\N	0
1820361544	0	ital	0	41	0	0	0	403	\N	0
5749788144	0	Zerasha	0	5	0	0	63.980000000000004	774	\N	0
2100527542	0	Pers. Jesayaa	0	202	0	0	17.150000000000006	173	\N	0
5819618815	0	luke	0	0	0	0	2.12	0	\N	0
761003526	0	MiWa.	9	26	0	0	349.1900000000001	109	\N	0
6370377447	0	Mirabelle #GAMMABAJING	0	21	0	0	13.579999999999984	1	\N	0
1662352588	0	🪪	0	34	0	0	0	41	\N	0
1761176654	0	aryeyeyeyeye	0	8	0	0	0	3	\N	0
6500549959	0	who's lady	0	60	0	0	3	174	\N	0
5429767882	0	ce	0	7	0	0	0	0	\N	0
6464995376	0	elinnn	0	1	0	0	0	1	\N	0
6031607018	0	mikael	0	15	0	0	10.850000000000001	17	\N	0
2030632798	0	aleenaa	0	15	0	0	0	0	\N	0
1615300889	0	aile	0	26	0	0	23.35	32	\N	0
6057110971	0	lin	0	2	0	0	0	4	\N	0
5759004210	0	ana	0	32	0	0	25.98	52	\N	0
1640416522	0	Jendral	0	0	0	0	0	10	\N	0
5045871932	0	N	0	0	0	0	0	0	\N	0
6784377109	0	bill	0	2	0	0	0	4	\N	0
1599861008	0	.	0	9	0	0	0	107	\N	0
1267360756	0	oca kailov 0__0	0	2	0	0	0	8	\N	0
7199803688	0	nayara	0	3	0	0	1800	0	\N	0
6862088816	0	Cadée	0	9	0	0	0	0	\N	0
6059439061	0	cals	0	39	0	0	495.18	69	\N	0
1222535460	0	ㅤㅤㅤㅤㅤㅤㅤ	0	1	0	0	0.5	0	\N	0
6571359429	0	ubiii`	0	9	0	0	0	5	\N	0
1521057830	0	k	0	0	0	0	0	0	\N	0
5323107949	0	ril	0	6	0	0	0	1	\N	0
5024456012	0	nnattawin	0	60	0	0	0	14	\N	0
5975320248	0	jane	0	3	0	0	0	21	\N	0
1206251084	0	na2	0	5	0	0	0	10	\N	0
1920069081	0	iora	0	84	0	0	21.629999999999995	43	\N	0
5287957365	0	.	0	0	0	0	0	0	\N	0
5846673450	0	jiwo	0	3	0	0	0	42	\N	0
1552872955	0	a	0	1	0	0	0	4	\N	0
1940255250	0	Ryder.	0	4	0	0	0	0	\N	0
6292855442	0	lil-calt #thekidcardo	0	24	0	0	0	17	\N	0
1754504785	0	Serena aMourav.	0	65	0	0	0	2	\N	0
1839605976	0	piaa is here	0	1	0	0	0	0	\N	0
5732661984	0	issa ꔛ	0	10	0	0	0	9	\N	0
5808335609	0	Ranggaroy	0	27	0	0	0	9	\N	0
6773525470	0	Clarence	0	1	0	0	0	1	\N	0
7169867021	0	Felllzzzz	0	0	0	0	0	0	\N	0
5011264097	0	𝐑aini	0	478	0	0	2742.6	551	\N	0
5972466396	0	yhahaha	9	21	0	0	51.07000000000007	133	\N	0
1551786488	0	jeje	0	56	1	0	0	1	\N	0
1370648439	0	juuy	0	23	0	0	0	2	\N	0
5987613466	0	makhluk mars	0	158	0	0	181.76	158	\N	0
1400496565	0	gian	0	15	0	0	0	5	\N	0
5069703898	0	𝐿	0	2	0	0	0	1	\N	0
6346953043	0	m	0	6	0	0	0	3	\N	0
2042226309	0	jojooo	0	2	0	0	0	2	\N	0
1437389702	0	pacar Bipa	0	277	0	0	537.1599999999997	497	\N	1
6217825410	0	el	0	13	0	0	0	0	\N	0
1951470576	0	052 B8S costa	8	27	0	0	1465.3899999999999	2193	\N	0
6009380848	0	u	4	117	0	0	9.56000000000006	232	\N	0
1836648202	0	kia	0	2	0	0	0	0	\N	0
1720936009	0	KeV	0	1	0	0	0	0	\N	0
1712159281	0	Ararinee.	0	22	0	0	0	6	\N	0
5982124113	0	Kei	0	3	1	0	0	0	\N	0
5350869197	0	Athena.	0	1	0	0	0	0	\N	0
7187029384	0	Levanya Anasera	0	3	0	0	0	0	\N	0
2040872733	0	z	0	292	0	0	0	10	\N	0
6329288206	0	tata	9	333	0	0	1897.92	759	\N	0
6606109982	0	winata	0	1	0	0	0	0	\N	0
6587624628	0	Bel	0	2	0	0	0	1	\N	0
1704953014	0	manusia	0	24	0	0	0	119	\N	0
1809459505	0	jvariel	0	1	0	0	0	32	\N	0
1616545963	0	las	0	4	0	0	179	1	\N	0
5114156154	0	First name	0	86	0	0	59.25999999999995	24	\N	0
5199318469	0	pacar dpr ian	0	171	0	0	1218.1	346	\N	0
5565736994	0	Arya	0	1	0	0	0	8	\N	0
1890829821	0	Anastasha	0	1	0	0	0	1	\N	0
1865523262	0	k	0	2	0	0	0	1	\N	0
5307956018	0	aRaceLl	0	1	0	0	0	0	\N	0
5064961891	0	Briella	11	86	0	0	16156.45	617	\N	0
1258879519	0	LiLyanna	0	0	0	0	0	133	\N	0
6442358060	0	vinny	0	1	0	0	0	1	\N	0
1277584220	0	Rrrrrr	0	38	1	0	0	19	\N	0
6745673744	0	Zhou Yi	0	9	0	0	0	15	\N	0
1701139919	0	lishyaa	0	2	0	0	0	0	\N	0
6476152953	0	jia i lop bobo	0	12	1	0	0	63	\N	0
6091448470	0	aL	0	0	0	0	0	0	\N	0
5128090941	0	Chelsea.	0	87	0	0	943.1100000000001	717	\N	0
5624088071	0	Jecoullins Abrigiatte	0	45	0	0	58.19	45	\N	0
5119650653	0	G	0	2	0	0	0	0	\N	0
1773840797	0	rei	0	8	0	0	0	404	\N	0
1197909253	0	‎ ‎ 🅰mara	0	56	0	0	54.11	39	\N	0
5247373335	0	???	0	2	0	0	0	0	\N	0
5812549411	0	el	0	1	0	0	0	0	\N	0
6002175332	0	BeauxiEe Anne — Morthian	0	3	0	0	0	4	\N	0
1612648028	0	k, nayésha,	0	14	0	0	0	3	\N	0
1446230876	0	kamayraaa	0	1	0	0	167.08	19	\N	0
1032422767	0	jo.	0	48	0	0	0	118	\N	0
1819846482	0	treketek	0	48	0	0	1467.13	935	\N	0
6365241769	0	2209	0	1	0	0	0	0	\N	0
6441721545	0	n	0	0	0	0	0	0	\N	0
6338637960	0	ila	0	1	0	0	0	2	\N	0
5834230300	0	cha.	0	2	0	0	0	0	\N	0
2044491012	0	ara	0	6	0	0	0	0	\N	0
5566113274	0	s	0	149	0	0	0	8	\N	0
5320483973	0	lyxian	0	3	0	0	0	0	\N	0
6217476687	0	Umii	0	2	0	0	0	1	\N	0
5598911360	0	maureen[𝐒𝐕𝐇𝟑𝟏]ᴰ¹	0	16	0	0	0	12	\N	0
5871703937	0	eL	0	6	0	0	0	5	\N	0
1788940270	0	revall	0	31	0	0	0	71	\N	0
5764113284	0	haiz	0	1	0	0	0	1	\N	0
6725515723	0	Fck	0	2	0	0	0	8	\N	0
1922737328	0	L	0	6	0	0	0	3	\N	0
2114682840	0	jeooo	0	22	0	0	195.82999999999998	16	\N	0
1867480807	0	Scrivens E.	0	3	0	0	0	3	\N	0
1625469267	0	iy dh	0	7	0	0	0	29	\N	0
5500912581	0	acc wtb/s	0	4	0	0	0	0	\N	0
1471686597	0	rrrr	0	1	0	0	0	0	\N	0
5441182922	0	rem	0	111	0	0	223.18	2	\N	0
5431868137	0	.	0	2	0	0	0	5	\N	0
1668901392	0	aveline open	0	0	0	0	0	0	\N	0
6668518094	0	ᴮᵃChio-可愛い🐰	0	0	0	0	0	0	\N	0
5676933092	0	rest, kzwr. kaileën 🇵🇪	0	13	0	0	27.040000000000006	72	\N	0
6883151066	0	Marcho, H.	0	1	0	0	0	1	\N	0
2017604046	0	Heikal	0	3	0	0	0	25	\N	0
5498115938	0	mew	5	27	0	0	0	14	\N	0
1722810389	0	Kãffah	0	28	0	0	0	16	\N	0
5984685571	0	tan	0	4	0	0	0	2	\N	0
2123687190	0	Jap	0	7	0	0	0	2	\N	0
6723025994	0	d	0	1	0	0	0	0	\N	0
5386333602	0	adis	0	13	0	0	0	6	\N	0
5502138785	0	961 amouraa	0	8	0	0	0	24	\N	0
5260364752	0	Gistara	0	152	0	0	964	83	\N	0
1993864500	0	wizi	0	12	0	0	0	1	\N	0
1906153422	0	sky	2	318	0	0	2559.060000000001	1666	\N	0
1865755759	0	kala	0	2	0	0	0	1	\N	0
6865515558	0	ian	0	4	0	0	0	0	\N	0
6536151541	0	Kaiser	0	1	0	0	0	2	\N	0
6184684959	0	Saddam. blm back? rc.	0	1	0	0	0	0	\N	0
1398106035	0	ㅤ	0	15	0	0	232.67000000000002	364	\N	0
1364570970	0	Teman	0	1	0	0	0	0	\N	0
1274958687	0	Caca	0	1	0	0	0	0	\N	0
5353263486	0	Mingyu’s lil kitten, Maurel	0	24	0	0	0	0	\N	0
5361309900	0	madame a	0	45	0	0	0	100	\N	0
1820636271	0	shaaa ! ♡	0	30	0	0	0	0	\N	0
5481400635	0	pretty bella's	0	4	0	0	0	0	\N	0
5107933614	0	ajel powerpuff	0	4	0	0	0	15	\N	0
6191838119	0	Zergan	0	3	0	0	0	3	\N	0
5281109418	0	carlaa	0	81	0	0	0	33	\N	0
5108625677	0	🤨💥	0	4	0	0	10	0	\N	0
6604844241	0	a	0	70	0	0	12.03000000000003	444	\N	0
5480440695	0	TEMP - triev	0	44	0	0	40	23	\N	0
5705298723	0	r	12	267	0	0	2066.2099999999996	1398	\N	1
5327021166	0	beachyitaa	0	44	0	0	0	51	\N	0
1886121271	0	tasyaaaa	0	3	0	0	0	0	\N	0
2146316373	0	ㅤadmnbbn.ray	0	38	0	0	403.57	98	\N	0
6694911329	0	𝐚𝐳𝐞	0	12	0	0	0	23	\N	0
5270178791	0	Zhico	0	4	1	0	0	5	\N	0
2098220912	0	t	0	3	0	0	0	26	\N	0
5609243344	0	Shena.	2	0	0	0	102.8	2	\N	0
5059595342	0	miel the cum enjoyer ૮꒰๑ˊᜊˋ๑꒱ა	8	403	0	0	698.63	516	\N	0
5514178244	0	yayass	0	158	0	0	0	9	\N	0
2006922638	0	unk	0	152	0	0	92	217	\N	0
6793208757	0	˚ vià !¡ ໒꒱ ‧₊˚	0	34	0	0	397	5	\N	0
1930307560	0	gia 🎧	0	10	0	0	0	163	\N	0
1998999875	0	Gheshilya Meeraloka.	0	84	0	0	462.5	100	\N	0
5377974041	0	kenmaxx	0	1	0	0	0	0	\N	0
6117354990	0	kath	0	4	0	0	0	2	\N	0
1623736440	0	aiel	0	1	0	0	0	0	\N	0
6941407210	0	Rushea, @xketat	0	3	0	0	0	1	\N	0
7097810057	0	s	0	2	0	0	0	1	\N	0
1843720808	0	akey	0	18	0	0	30	2	\N	0
5806979273	0	𝖒𝖆𝖎𝖐𝖎	0	0	0	0	0	0	\N	0
2006445919	0	ㅤ	0	3	0	0	0	0	\N	0
1996920762	0	kajeva	0	670	0	0	2092.250000000001	14245	\N	0
6184119295	0	rivi rdl	0	1	0	0	0	1	\N	0
6165191643	0	A.	0	1	0	0	0	6	\N	0
1316499682	0	embull	0	1	0	0	34.3	3	\N	0
6010947196	0	.	0	2	0	0	0	3	\N	0
5645923014	0	laura	0	20	0	0	0	47	\N	0
6223848621	0	payun	14	20	0	0	67.4699999999998	30	\N	1
1268506647	0	.	0	33	0	0	93.57	43	\N	0
1674734866	0	Amarabel	0	1	0	0	0	0	\N	0
1596596812	0	Anhavy.	0	63	0	0	211.88	77	\N	0
1876191800	0	𔒌	0	0	0	0	0	0	\N	0
1178009602	0	vor	0	1	0	0	0	0	\N	0
5358430221	0	.	0	113	0	0	0	438	\N	0
1899512279	0	Rika	0	1	0	0	0	0	\N	0
5716291979	0	👟	0	1	0	0	0	14	\N	0
5514009066	0	Sophia Haddad	0	12	0	0	604.04	343	\N	0
6089197672	0	salwa	0	3	0	0	0	0	\N	0
5095753542	0	Al	0	1	0	0	53.94	5	\N	0
5443888470	0	Ansela	0	7	0	0	0	10	\N	0
5830915472	0	sha	0	3	0	0	0	0	\N	0
5495074234	0	syaaaa. 𝜗𝜚	0	1	0	0	0	0	\N	0
2102605694	0	PPPP	0	302	0	0	329.86	341	\N	0
1442914938	0	camorra	0	22	0	0	0	262	\N	0
6462430228	0	asa	0	29	0	0	276	52	\N	0
6692466071	0	𝜗𝜚ㅤ..ㅤBeautifully Winnysëllaㅤ𖡼 ࣪ 𝅄	0	18	0	0	0	23	\N	0
6927098643	0	Lady. ♥️	0	2	0	0	0	0	\N	0
6186987492	0	sab	0	1	0	0	0	0	\N	0
1700476516	0	.	0	1	0	0	0	0	\N	0
1809573956	0	urreii	0	4	0	0	0	95	\N	0
1534681506	0	bima sakti	0	74	0	0	125.96000000000004	0	\N	0
5924130033	0	bella	0	3	0	0	0	0	\N	0
1145009009	0	nalara, z.	0	22	0	0	653	0	\N	0
5919692821	0	D’Tasya, DNI.	0	1	0	0	0	3	\N	0
6137158968	0	Cathryn Matwous cownls	0	4	0	0	0	0	\N	0
1931208470	0	yeraa — @ yerawsie on ig !	0	3	0	0	0	5	\N	0
1697446334	0	Al.	0	5	0	0	0	0	\N	0
5184691730	0	k ael	0	1	0	0	0	2	\N	0
1794749406	0	% MaRsHaAa!? ₍ ੭ᐢ..ᐢ)੭	0	2	0	0	0	0	\N	0
5404469412	0	Ziko.	0	5	0	0	0	0	\N	0
1122559837	0	sam444	0	93	0	0	6000.179999999999	95	\N	0
5636202380	0	kiben ni mang sape	7	500	2	0	978.4900000000009	1891	\N	0
1786027773	0	Morbidelli	0	12	0	0	1185	28	\N	0
5140133015	0	somay telkomsel:v	0	4	0	0	0	30	\N	0
5656017284	0	raa aja	0	27	0	0	390	10	\N	0
5691554250	0	cebi	0	0	0	0	0	0	\N	0
2072712703	0	jihane salima	0	2	0	0	0	0	\N	0
6778765099	0	ryla	0	59	0	0	0	17	\N	0
1382286606	0	ملاك . amarathine	0	3	0	0	18.21	13	\N	0
5469165184	0	J	0	2	0	0	0	1	\N	0
1507425313	0	M — D I R .	0	1	0	0	0	0	\N	0
6939762671	0	aa	0	2	0	0	0	0	\N	0
6155073147	0	jara	0	2	0	0	0	1	\N	0
1271967146	0	K1nG	0	71	0	0	61	43	\N	0
6788343769	0	a	0	19	0	0	0	5	\N	0
6299731987	0	lili	0	1	0	0	0	0	\N	0
1433131693	0	nael	0	14	0	0	0	0	\N	0
1425669219	0	kinan	4	0	0	0	60.29	2	\N	0
5314349225	0	Who	0	7	0	0	0	33	\N	0
6899937881	0	a	0	12	0	0	0	0	\N	0
5993806829	0	B. Adjie	0	51	0	0	10.39	12	\N	0
5745798251	0	ₐₗdₑ 🇦🇴 • carlie	0	4	0	0	0	3	\N	0
5716323793	0	acel	0	91	0	0	200.4	908	\N	0
6490567076	0	— éylaa	0	5	0	0	0	12	\N	0
6226820744	0	n	0	1	0	0	0	0	\N	0
1018266653	0	Pras	0	15	1	0	0	33	\N	0
6815949841	0	Jo-El	14	21	0	0	710.6499999999999	1147	\N	0
7031265499	0	elodie.	0	9	0	0	0	0	\N	0
5316841500	0	ini oja	0	419	0	0	1030.3399999999997	11599	\N	0
5462227626	0	caca	0	19	0	0	0	107	\N	0
5531796475	0	a	0	18	0	0	0	1	\N	0
1978950764	0	vian	0	154	0	0	3.3999999999999986	0	\N	0
5837007138	0	Yev	0	4	0	0	0	118	\N	0
5448194678	0	kala	0	8	0	0	0	46	\N	0
5997085550	0	Keith	9	55	0	0	109.67	100	\N	0
5376006060	0	lagi lagi kala	0	42	0	0	0	0	\N	0
6200168847	0	allora Matwous	0	1	0	0	0	0	\N	0
2057460550	0	sòvieta	0	2	0	0	0	0	\N	0
6284202884	0	c	0	1	0	0	0	0	\N	0
1424893970	0	Chellia	0	21	0	0	0	58	\N	0
6208013704	0	raine pradivtha	0	17	0	0	2.76	0	\N	0
5438986669	0	asya	0	3	0	0	0	2	\N	0
5281944653	0	jesaya	0	6	0	0	678	172	\N	0
5708888982	0	asha lagi malas diving	0	2	0	0	0	2	\N	0
5408318190	0	Elek	0	5	0	0	0	21	\N	0
1866518189	0	.	0	1	0	0	0	19	\N	0
1689726840	0	Gege	0	12	0	0	0	0	\N	0
7046971385	0	girl	0	6	0	0	0	0	\N	0
1156022805	0	lyshainë	0	3	0	0	0	0	\N	0
1831659222	0	mileee	0	2	0	0	0	0	\N	0
1769137379	0	Kjv	0	60	0	0	0	8	\N	0
5139975321	0	Milaa! ♡︎	0	5	0	0	0	1	\N	0
6312041648	0	faya	11	342	0	0	4262.7800000000025	622	\N	0
5490121271	0	nr	0	3	0	0	0	0	\N	0
5205406772	0	paka	0	50	0	0	0	235	\N	0
5865886006	0	NR	0	22	0	0	313.56	123	\N	0
5084208120	0	lana.	0	2	0	0	0	58	\N	0
6108119191	0	akayin	10	34	0	0	31.049999999999997	31	\N	0
5230765387	0	bie	0	17	0	0	0	872	\N	0
1944914747	0	Salsa	0	15	0	0	0	6	\N	0
5815210231	0	Jeff	0	0	0	0	0	0	\N	0
1802278097	0	jonas	0	153	0	0	579.48	18	\N	0
2092104058	0	a	0	4	0	0	0	6	\N	0
1223800770	0	keyayiyuyeyo	0	41	0	0	434	133	\N	0
1438410477	0	khira	0	19	0	0	485	2	\N	0
1942951529	0	Jiang	0	6	0	0	0	1	\N	0
5331670614	0	t	0	7	0	0	0	0	\N	0
1850648554	0	Farel Alnarenzi	0	144	0	0	1	31	\N	0
5131308258	0	Yochieee	0	3	0	0	0	6	\N	0
7149516899	0	saturn	0	2	0	0	0	0	\N	0
1743304044	0	arjean	0	1	0	0	0	0	\N	0
1723640122	0	dodot	0	1	0	0	0	0	\N	0
1864381362	0	jean cinta kifa (falling in lop era)	0	6	0	0	0	0	\N	0
5386601753	0	S4N	0	2	0	0	0	0	\N	0
6563112423	0	神 sasa	0	4	0	0	0	0	\N	0
6084430547	0	lili	3	1	0	0	482.93000000000006	297	\N	0
5995905308	0	zea	0	2	0	0	0	3	\N	0
5746363819	0	ruelle laverty.	0	4	0	0	0	0	\N	0
5110390122	0	k	0	159	0	0	0	388	\N	0
5472694203	0	asya	0	13	0	0	0	4	\N	0
1401156975	0	ci :3	0	15	0	0	0	3	\N	0
6250597234	0	aratali	0	1	0	0	0	0	\N	0
6862634020	0	sabiru 𝐁𝐒	0	5	0	0	0	26	\N	0
6811714056	0	bilaa	0	8	0	0	0	0	\N	0
949323746	0	RndAmya	0	3	0	0	0	6	\N	0
6078910918	0	M. Knight	6	7	0	0	0	4	\N	0
1617936574	0	atlas	0	1	0	0	0	0	\N	0
5252927211	0	shana	0	2	0	0	0	6	\N	0
5621877026	0	Oalah, Kava Raputra.	0	22	0	0	19	75	\N	0
5572480853	0	𝖐	0	2	0	0	0	0	\N	0
1749109834	0	rasakan serangan paku alam	0	27	0	0	0	105	\N	0
1422163895	0	ⱱgx. gallih victoryking	0	11	0	0	0	29	\N	0
5733980140	0	rain	0	3	0	0	0	5	\N	0
5781917429	0	sesekkk	0	19	0	0	0	0	\N	0
6228529940	0	sheiryn, dnfi lg bobo zZz	0	2	0	0	0	1	\N	0
6936952028	0	rreeyyaa	0	2	0	0	0	0	\N	0
7194112271	0	Adinda	0	4	0	0	29.95	31	\N	0
6486095753	0	hazelnut	0	5	0	0	0	7	\N	0
6273803136	0	Asher	0	15	0	0	61.26	2	\N	0
7089113306	0	🐈. . kittenz，ɑׁׅᧁׁꪱׁׁׁׅׅׅ ⊹̤ ˙֪	0	4	0	0	0	5	\N	0
5536636477	0	pirnando	0	6	0	0	0	5	\N	0
1385248582	0	ila	9	505	1	0	506.81999999999994	981	\N	0
1814773146	0	ti was gone	0	69	0	0	0	40	\N	0
1456296517	0	zelaa	0	3	1	0	0	2	\N	0
5709592128	0	fly	0	26	0	0	0	129	\N	0
1303279641	0	nellaaa	0	0	0	0	0	0	\N	0
6621059167	0	ᵉᵛᵗ Cathy Nicolette 𖧧 ࣪	0	1	0	0	0	3	\N	0
5414766062	0	arsaa, off	0	5	0	0	0	6	\N	0
5898885881	0	abam	0	154	0	0	15.410000000000082	160	\N	0
1650608060	0	bea	0	77	0	0	0	277	\N	0
5559198610	0	Vey	0	1044	0	0	0.3099999999976717	27	\N	0
1501864097	0	Cl	0	16	0	0	0	21	\N	0
1984592220	0	👣	0	43	0	0	0	0	\N	0
6939738808	0	Jaseb otomatis	0	1	0	0	0	0	\N	0
5237238490	0	s	0	12	0	0	0	3	\N	0
2003219160	0	ᶠᵒ𝐏𝐓𝐑🇲🇪 V	0	3	0	0	0	6	\N	0
1885395584	0	Maverick	0	10	0	0	0	3	\N	0
1992247766	0	raaaaadeeennnn	0	275	0	0	15.3299999999997	16	\N	0
1390276933	0	zz	0	6	0	0	0	4	\N	0
6163684293	0	moutry	0	1	0	0	0	0	\N	0
1488730277	0	emily 🧿🕳🧿	13	92	0	0	6103.700000000002	18548	\N	0
1727401067	0	fadel	0	1	0	0	0	2	\N	0
5681836842	0	nieya	0	13	0	0	0	20	\N	0
5409411754	0	ayya	0	1	0	0	0	2	\N	0
5613269739	0	eislynnn	0	6	0	0	0	0	\N	0
5092370953	0	sienna	0	7	0	0	0	33	\N	0
6988680655	0	una	0	35	0	0	750	66	\N	0
1539476678	0	R𝐞𝐧𝐳, still actv	0	2	0	0	0	0	\N	0
7162725597	0	batwoman	0	1	0	0	0	0	\N	0
5844508907	0	Nnnn	0	8	0	0	12.81	1	\N	0
1762410399	0	Klausier Wijaya si duta pinjol	0	2	0	0	0	0	\N	0
6206042027	0	nitaaa	0	6	0	0	0	0	\N	0
5533589716	0	Chandra	0	10	0	0	0	5	\N	0
6849923305	0	kélya(⑉´•˶˶̫˶ •`⑉)♡	0	1	0	0	19.15	7	\N	0
6259224282	0	leila	0	109	0	0	0	7	\N	0
1930161719	0	Jaehyun	0	1	0	0	0	0	\N	0
5918160357	0	Kavin	0	2	0	0	0	0	\N	0
1724449907	0	-cél susah tidur	0	5	0	0	0	6	\N	0
5036477370	0	𝐋eo	0	2	0	0	0	0	\N	0
2065478839	0	rere	0	37	0	0	0	2	\N	0
1783278838	0	૮ ࣪˖ ᒍιֹ̟zᧉᥣֹׄᥣֹׄ zᧉ᮫࣪᥎⍺݂֘ꬼִֺ𐐽ּ࣪⍺݂֘⋆ ꜝꜞ ᳝๑ ࣪	0	6	0	0	0	1	\N	0
1779231926	0	s	1	1405	0	0	8.95999999999168	45	\N	0
6590543866	0	💎- acaa	0	1	0	0	0	0	\N	0
5462118428	0	Isabella H.	0	176	0	0	0	28	\N	0
5462768299	0	berrliiinn	0	0	0	0	0	0	\N	0
1657077909	0	Jergav	0	1	0	0	0	0	\N	0
5786447989	0	thviny	0	284	0	0	126	26	\N	0
5165041366	0	jipa’	0	22	0	0	0	64	\N	0
5435351655	0	R.	0	4	0	0	78	9	\N	0
5760481597	0	cl	0	5	0	0	2839.2699999999986	236	\N	1
6620538084	0	win	0	78	0	0	0	25	\N	0
1851356476	0	pacar mark	0	13	0	0	0	1	\N	0
1764442650	0	Jaki	0	9	0	0	0	7	\N	0
6111741430	0	anasya	0	2	0	0	0	0	\N	0
5288909579	0	에칼 a.k.a ekal	0	4	0	0	34.09000000000001	63	\N	0
1446687171	0	n	0	41	0	0	0	160	\N	0
1013572075	0	acinn	0	4	0	0	0	5	\N	0
1712024595	0	Ayala	0	4	0	0	0	0	\N	0
5686573729	0	Eviana.	0	3	0	0	0	1	\N	0
1451750864	0	biel	0	6	0	0	0	10	\N	0
5004798949	0	wkwkwk	0	12	1	0	980.39	5	\N	0
1597039006	0	n	0	18	0	0	0	0	\N	0
1937287738	0	nanass,	0	1	1	0	0	0	\N	0
1931738675	0	505. evelina	0	25	0	0	0	26	\N	0
6213303332	0	drc. jeanne bimoli	0	1	0	0	0	0	\N	0
1060430415	0	Enzx	0	1	0	0	0	0	\N	0
5482586567	0	raka.	0	0	0	0	0	0	\N	0
5613385249	0	-𝓪𝓻𝓾𝓷𝓲𝓴𝓪 🌷	0	4	0	0	0	1	\N	0
5110738393	0	Erza	0	107	1	0	1813	7	\N	0
1147251017	0	EB	0	1	0	0	0	2	\N	0
5884954854	0	llyra	0	40	0	0	0	1	\N	0
6000837398	0	reyyy world	0	3	0	0	0	10	\N	0
6475188056	0	bomi	0	1	0	0	0	0	\N	0
1738922837	0	she	0	84	0	0	78.65	120	\N	0
5654013757	0	zeta	7	277	0	0	3348.239999999997	14925	\N	1
7009278535	0	𝖉𝖔𝖗	0	5	0	0	0	10	\N	0
1908744352	0	ta. boo !	0	0	0	0	0	177	\N	0
2119150025	0	Ikoo	0	1607	3	0	2565.4500000000016	1427	\N	0
6791769376	0	Lin.	0	6	0	0	0	10	\N	0
5324449760	0	avoid	0	57	0	0	0	25	\N	0
6371057305	0	RYNA D MONKEY	0	0	0	0	0	0	\N	0
5275793088	0	ziyaaa	0	378	0	0	13.780000000000086	137	\N	0
1254956605	0	aaa	0	2	0	0	0	0	\N	0
1268712395	0	jujun	14	8	0	0	209.72	34	\N	0
5045512538	0	Zara.	0	1	0	0	0	4	\N	0
1846500095	0	Biechuya @__@	0	15	0	0	0	2	\N	0
5481644292	0	nokos	0	150	0	0	0	0	\N	0
1575350023	0	ძᥱᥒᥲrᥲ	0	72	0	0	0	0	\N	0
6298980880	0	Jaeravs	0	3	0	0	0	0	\N	0
6362737838	0	ciciii	0	1	0	0	0	0	\N	0
6636396777	0	Aksara	0	2	0	0	17.26	1	\N	0
7169959416	0	Arla	0	8	0	0	193.09	359	\N	0
5579299539	0	anow	0	3	0	0	0	4	\N	0
6074068595	0	ver	0	3	0	0	0	0	\N	0
1812126624	0	Audy Sharma	0	26	0	0	0	53	\N	0
5560548044	0	chiyo cihoyy	0	194	0	0	1450.819999999999	95	\N	0
5230860996	0	.	0	1	0	0	0	4	\N	0
2003653025	0	dylan cathlein.	0	165	0	0	1189.96	151	\N	0
1942395720	0	meka	0	13	0	0	0	1	\N	0
1938925321	0	afifah	0	18	0	0	433	11	\N	0
5546340792	0	s	0	15	0	0	0	7	\N	0
6472530398	0	A.	0	25	0	0	59.349999999999994	85	\N	0
6332244548	0	envio	0	41	0	0	20	1	\N	0
6966938119	0	cleo	0	4	0	0	0	0	\N	0
1710064497	0	?	0	20	0	0	0	102	\N	0
5571118378	0	Sarah	0	1	0	0	0	0	\N	0
6064495870	0	ㅤㅤ	0	0	0	0	0	12	\N	0
7107096031	0	Josh.	0	5	0	0	456	39	\N	0
6417830546	0	de mior todoroki. on rest.	0	11	0	0	4868	9	\N	0
5357951086	0	Alica	0	0	0	0	0	0	\N	0
5932265264	0	Bian	0	10	0	0	1.3900000000000006	97	\N	0
6231690971	0	celestia	0	2	0	0	0	0	\N	0
7177938207	0	RAYYA	0	1	0	0	0	7	\N	0
6286015537	0	p	0	1	0	0	0	6	\N	0
6256995686	0	Nоɑh	0	10	0	0	7.02	235	\N	0
6564458694	0	𝓷	0	0	0	0	0	0	\N	0
5719908033	0	kaira	0	12	0	0	0	4	\N	0
5219573887	0	yourby	0	3	0	0	500	24	\N	0
1658601894	0	clea dni	0	15	0	0	0	0	\N	0
6467657318	0	aruu	0	11	0	0	0	4	\N	0
1905548381	0	b	0	60	0	0	0	145	\N	0
5315703556	0	jopek	0	6	0	0	0	2	\N	0
1946095615	0	nia	0	30	0	0	0	2	\N	0
5391985127	0	nimek	8	247	0	0	195.28999999999996	833	\N	0
2129008969	0	idk	0	3	0	0	0	0	\N	0
5271260248	0	din	0	10	0	0	0	15	\N	0
5334090393	0	jr	0	51	0	0	0	415	\N	0
5033785780	0	mouna s/ia	0	370	0	0	1093.6	5018	\N	0
6739348642	0	C	0	12	0	0	0	72	\N	0
2073934484	0	renessa	0	5	0	0	0	8	\N	0
1614916945	0	ʝυɳҽ⚘	0	0	0	0	0	0	\N	0
1447178681	0	Siapayaa	0	1	0	0	0	0	\N	0
5640133424	0	rezaprianto	0	13	0	0	0	136	\N	0
5488775180	0	ashhery faliq.	0	1	0	0	0	0	\N	0
5065004731	0	Fairyy nan	0	116	0	0	371.4200000000003	26	\N	0
6438763069	0	triaaa	0	48	0	0	8.350000000000001	11	\N	0
6144952473	0	becca	0	2	0	0	0	0	\N	0
1541042650	0	Sincere.	0	0	0	0	0	0	\N	0
6962604290	0	Alikha.	0	3	0	0	0	1	\N	0
6066367143	0	v	0	0	0	0	0	97	\N	0
5217618433	0	Aby	1	82	0	0	336.5499999999997	152	\N	0
5140984118	0	yola	0	1	0	0	0	0	\N	0
5958606916	0	dni.	0	53	0	0	163.42999999999998	43	\N	0
1692857202	0	jack	0	7	0	0	0	5	\N	0
1775036886	0	Yèvanna	0	1	0	0	0	0	\N	0
1763534701	0	Vanes	0	67	0	0	36.55	55	\N	0
5224109659	0	۰ ۪۪۫۫ · 🩰 wawa 𓆩ᥫ᭡𓆪	0	15	0	0	0	11	\N	0
1723434834	0	Oceanee.	0	3	0	0	0	4	\N	0
6282284714	0	iviv 2.	0	1	0	0	0	0	\N	0
5278689574	0	𝐀𝐢𝐲𝐥𝐚.	0	11	0	0	0	65	\N	0
6915780471	0	shahrinz	0	3	0	0	0	0	\N	0
5995770710	0	Dly	1	12	0	0	2764.15	379	\N	0
1805992239	0	keysiiiii	0	5	0	0	0	2	\N	0
6547594735	0	Shabie	0	8	0	0	0	3	\N	0
5872899555	0	abi	0	5	0	0	0	19	\N	0
1761777583	0	kael	0	7	0	0	0	0	\N	0
5078691245	0	Momon	0	1	0	0	0	1	\N	0
5947343446	0	lengkara	0	329	1	0	270.0599999999996	210	\N	0
2031483069	0	tolong fsr ya sayang https://t.me/WOO0RD	0	8	0	0	0	0	\N	0
1509044590	0	el	0	29	0	0	0	8	\N	0
1962456388	0	jipa	0	23	0	0	0	2	\N	0
1802277939	0	d	0	34	0	0	0	402	\N	0
5486720618	0	Viennz.	0	0	0	0	0	0	\N	0
1723365098	0	raya's archives	0	160	0	0	21.669999999999995	39	\N	0
5637054611	0	Juliooo	0	0	0	0	0	0	\N	0
5295786017	0	Niel	0	36	0	0	0	68	\N	0
2101963317	0	angl	0	11	0	0	0	0	\N	0
6970396004	0	— 𝐁eatricé, G. S.	0	0	0	0	0	0	\N	0
2117255089	0	Abi	0	57	0	0	0	15	\N	0
1780386203	0	ㅤkalula.	0	1	0	0	0	0	\N	0
1976911408	0	Jje #18	0	3	0	0	0	0	\N	0
1149679185	0	richard	0	1	0	0	0	0	\N	0
1609453607	0	nadine	0	10	0	0	0	3	\N	0
1705482809	0	auu	0	40	0	0	0	2	\N	0
5304364601	0	Arialyn	0	14	0	0	0	1	\N	0
5249643864	0	seraaa	0	1	0	0	0	0	\N	0
1664353603	0	Lave.	0	10	0	0	0	4	\N	0
6636774419	0	lumeine.	0	2	0	0	0	1	\N	0
5013680802	0	noir	9	14	0	0	1914.7799999999997	1696	\N	0
1716214525	0	jaelf	0	1	0	0	0	0	\N	0
1849425118	0	kalio	0	51	0	0	0	7	\N	0
2130848997	0	di	0	5	0	0	0	0	\N	0
6867033950	0	aliya	0	1	0	0	0	0	\N	0
1828067617	0	iky	0	1	0	0	0	0	\N	0
6659534794	0	irzavy	0	4	0	0	0	24	\N	0
5326359061	0	D	0	1	0	0	0	0	\N	0
1953456294	0	donju	0	8	0	0	0	1	\N	0
5922823630	0	ta	9	76	0	0	53.16	144	\N	0
6302982633	0	putt	0	8	0	0	0	1	\N	0
1483631249	0	Ge	0	409	0	0	1300.02	6392	\N	0
5104654529	0	Bibi	0	6	0	0	0	5	\N	0
5289776736	0	cipa	0	24	0	0	60	160	\N	0
5063904658	0	kane	0	6	0	0	0	0	\N	0
2039458875	0	yakii	0	120	0	0	0	11	\N	0
6154652991	0	Alaric pt. 2	0	1	0	0	0	0	\N	0
5699717779	0	b, maelysha	0	2	0	0	0	0	\N	0
6459719758	0	ძᥱ ᑲіуᥲ	0	4	0	0	0	6	\N	0
6716556255	0	Alfii	0	5	0	0	0	1	\N	0
1463094952	0	ariririri	0	4	0	0	0	0	\N	0
1687514218	0	Sera	0	0	0	0	0	0	\N	0
920071620	0	rosari	0	1	0	0	0	0	\N	0
5148968271	0	V	0	6	0	0	0	0	\N	0
5809039321	0	arthéla.	0	5	0	0	0	158	\N	0
5803789260	0	E.	0	1	0	0	0	0	\N	0
6036121912	0	lo arga?	0	4	0	0	0	4	\N	0
1894430619	0	sz	0	48	0	0	85.19	1210	\N	0
5823691842	0	Noana	13	75	0	0	1506.8600000000001	450	\N	0
6615552818	0	ze	0	2	0	0	0	0	\N	0
1528072584	0	daym	0	77	0	0	0	199	\N	0
1942506554	0	ril	0	1	0	0	0	0	\N	0
6787196093	0	cika	0	3	0	0	0	3	\N	0
6413179416	0	Amaaa	0	1	0	0	0	0	\N	0
1615292541	0	ola	0	35	0	0	0	0	\N	0
5797207418	0	ney	0	233	0	0	564.39	223	\N	0
5395184218	0	dnd	0	117	0	0	130.82	72	\N	0
2077579528	0	kojas	0	11	0	0	0	49	\N	0
1623791012	0	sean	0	4	0	0	0	15	\N	0
5941853630	0	:b	0	5	0	0	0	1	\N	0
6359580109	0	raelz	0	2	0	0	0	2	\N	0
5261822797	0	biwa 🇲🇶	0	63	0	0	0	1416	\N	0
6320026232	0	raraa gf mark lee	0	1	0	0	0	8	\N	0
1914587511	0	arinn	0	72	0	0	0	2	\N	0
7143608956	0	gtw	0	0	0	0	0	1	\N	0
6138306639	0	Na	0	2	0	0	0	2	\N	0
5980755011	0	altaaa	0	0	0	0	0	4	\N	0
1408462961	0	合戦.	0	1	0	0	0	2	\N	0
6819030502	0	gracielle	0	2	0	0	0	0	\N	0
6916474313	0	Dylan	0	1	0	0	0	0	\N	0
2005837287	0	𝖢𝗁𝖺-𝖤𝗌𝖺 return @cigarettte to me	0	15	0	0	500	11	\N	0
1471801614	0	Javier	0	3	0	0	0	1	\N	0
1993113812	0	kanaya	0	2	0	0	0	0	\N	0
7154803820	0	V. Päulsen	0	3	0	0	0	0	\N	0
5905868967	0	s.	0	48	0	0	313	344	\N	0
5005777337	0	CapriBoiiiii	0	10	0	0	0	23	\N	0
5314598282	0	.	0	37	0	0	0	1	\N	0
2019930054	0	heera	0	0	0	0	0	29	\N	0
2034776360	0	Agasa. K	0	2	0	0	0	0	\N	0
7090078608	0	a	0	5	0	0	0	46	\N	0
6605008064	0	bambiya, gausah jbjb.	0	2	0	0	0	0	\N	0
6574222257	0	𝐓𝐑≛𝐏𝐒` Jooadityaa	0	16	0	0	0	0	\N	0
6667117305	0	ian	4	78	0	0	0	0	\N	0
6271924533	0	m	0	3	0	0	4.550000000000001	0	\N	0
2104974853	0	mili	0	3	0	0	181	296	\N	0
5993447621	0	pin	0	1	0	0	0	0	\N	0
6375625411	0	owlyy	0	1	0	0	0	0	\N	0
5815689657	0	cici	0	3	0	0	0	0	\N	0
919453506	0	awl	0	16	0	0	12.11	23	\N	0
1242173748	0	jeksa oi oi	12	1086	0	0	1587.6600000000005	13816	\N	1
1714225593	0	Shalli	12	108	0	0	294.92000000000024	12	\N	0
6251571596	0	.	0	0	0	0	0	1	\N	0
5924049634	0	ganjil cigez	0	21	0	0	21.3	3	\N	0
6652995977	0	arsda	0	2	0	0	0	1	\N	0
5802274347	0	babang el	0	3	0	0	0	0	\N	0
1751341642	0	命8 ninuninu #𝐂𝐑𝐚 #ZLS #jycl #Rismaluv	0	48	1	0	0	5	\N	0
5834148284	0	Arya	0	0	0	0	0	0	\N	0
1464400811	0	Ruby	0	3	0	0	0	0	\N	0
1976530649	0	ᴄᴜᴘɪᴅ ˚✧	0	1	0	0	0	0	\N	0
2128390063	0	Jeremiah, N.	0	21	0	0	0	251	\N	0
6801924641	0	a dixydiè, jcarla	0	0	0	0	0	3	\N	0
2139846764	0	ꨄ︎. 𝐊𝗂𝗆-𝖻𝖾̈𝗋𝗅𝗒𝗇𝖾̀	10	948	0	0	1753.460000000001	5912	\N	1
6103619153	0	royan	0	2	0	0	0	0	\N	0
5292758098	0	Ellen.	0	1	0	0	0	0	\N	0
1776412367	0	Ká	0	91	0	0	1460.13	24	\N	0
5127149205	0	syah	0	4	0	0	0	1	\N	0
5019128481	0	.	0	10	0	0	0	0	\N	0
5461288097	0	van malfoy	0	1	0	0	0	0	\N	0
1903688074	0	alfaqier d	0	88	0	0	5.579999999999998	358	\N	0
1876020645	0	el	3	281	0	0	18.46	57	\N	0
1215010730	0	Rafckinly	0	121	0	0	112	442	\N	0
1579864514	0	renz	0	14	0	0	0	8	\N	0
1979392872	0	Cia loving Lee Haechan	0	530	0	0	0.8400000000000034	65	\N	0
2087777982	0	nana	0	4	0	0	0	3	\N	0
6651586297	0	nooo	0	1	0	0	0	0	\N	0
6360957199	0	𝐃Λ.🦋	0	1	0	0	0	2	\N	0
5336638267	0	ssa	0	45	0	0	0	954	\N	0
6207253137	0	Beloved Nomies, Shiori Chizuru's Warrior	0	5	0	0	0	27	\N	0
5977523591	0	ଘ𓂅๑	0	83	0	0	4.670000000000016	251	\N	0
5447251744	0	rest	0	4	0	0	0	7	\N	0
2129770265	0	A	0	0	0	0	0	7	\N	0
5673565232	0	calzey	0	5	0	0	0	0	\N	0
6670924522	0	Shevarta Ctron	0	2	0	0	0	0	\N	0
1930274196	0	B #SRCHIRMIN	0	2	0	0	0	0	\N	0
5309125081	0	Aya prot pret	0	109	0	0	0	40	\N	0
5092960174	0	may	0	10	0	0	0	2	\N	0
1627448759	0	gisel	0	3	0	0	0	22	\N	0
6118775581	0	eunca	0	4	0	0	0	46	\N	0
1688851738	0	micera	0	1	0	0	0	0	\N	0
1112506978	0	𝔹𝕣𝕚𝕟𝕘𝕖𝕣ℤ	0	5	0	0	0	6	\N	0
6292059012	0	shie	0	11	0	0	0	18	\N	0
5068129576	0	ipuy awr	0	8	0	0	0	3	\N	0
5218212112	0	biee	0	28	0	0	0	0	\N	0
1457100477	0	Janoscar	0	115	0	0	0	23	\N	0
1830339390	0	Carllie	0	26	0	0	112.35	9	\N	0
1316729736	0	Orang susah	0	67	0	0	0	9	\N	0
1356965487	0	galau	0	1	0	0	0	0	\N	0
5172852895	0	grr	0	15	0	0	0	92	\N	0
5481164767	0	ryu	0	14	0	0	0	133	\N	0
1740586042	0	Juan(cok)	0	6	0	0	0	0	\N	0
1921152731	0	🧚🏻‍♀, Liyaa 192.951.b10	0	2	0	0	0	2	\N	0
5854865585	0	ibas	0	2	0	0	0	0	\N	0
6357858618	0	joy44	0	10	0	0	0	4	\N	0
1782784162	0	keyra	0	1	0	0	0	4	\N	0
5381453012	0	Randy	0	2	0	0	0	0	\N	0
5838630899	0	nhl ♧.	13	1	0	0	104.56	113	\N	0
6915917419	0	naira, rarely active.	0	20	0	0	672.26	202	\N	0
1847782930	0	Jemos	0	2	0	0	0	0	\N	0
6710458502	0	jelime	0	1	0	0	0	0	\N	0
5287054335	0	aileen	0	9	0	0	0	4	\N	0
1726118678	0	Ryuhei.	0	1	0	0	0	0	\N	0
5576719716	0	?	0	1	0	0	0	0	\N	0
1706252676	0	✿ estii biasakan baca bio ✿	0	1	0	0	0	0	\N	0
6470332687	0	abel	0	2	0	0	0	0	\N	0
2096170026	0	𝐇aleyca slowresp.	0	2	0	0	0	0	\N	0
1791584963	0	vargo	0	1	0	0	0	0	\N	0
5893527208	0	kay	0	0	0	0	0	2	\N	0
5998884651	0	karamell	0	5	0	0	0	14	\N	0
5876554016	0	d	0	1	0	0	0	2	\N	0
1015249688	0	nabila dido	0	1	0	0	0	0	\N	0
2055823884	0	G	0	33	0	0	81.18	37	\N	0
5134423144	0	zul	0	12	0	0	0	5	\N	0
6206337167	0	.	0	7	0	0	0	19	\N	0
6226905810	0	Najza	0	24	0	0	0	21	\N	0
6792076368	0	ayel	0	1	0	0	0	0	\N	0
5843367437	0	Libra	0	5	0	0	0	9	\N	0
6087284099	0	Fairyya	0	1	0	0	0	0	\N	0
1976143324	0	Jey	0	3	0	0	0	7	\N	0
1896496138	0	chii	0	3	0	0	0	0	\N	0
6078193087	0	.	0	3	0	0	0	0	\N	0
5097028811	0	أوين جرجيون . (owen)	0	3	0	0	103.98	2	\N	0
6885755670	0	A	0	3	0	0	7.19	23	\N	0
1314125887	0	Kanon	0	21	1	0	2925	21	\N	0
5735885120	0	ㅤ	0	11	0	0	0	32	\N	0
6405913240	0	scx. Abby	0	3	0	0	0	0	\N	0
1873557836	0	𝐆earillé,	0	68	0	0	19.8600000000001	116	\N	0
6407753542	0	zyavanca	0	1	0	0	0	0	\N	0
6528570900	0	hares. return @kaisker to shanzo	0	24	0	0	2900.0699999999997	16	\N	0
5386788006	0	shena🧁	0	1	0	0	0	0	\N	0
1900376149	0	ESAA CAPEE BETULLL BROO	0	9	0	0	196.41999999999976	31	\N	0
1406109729	0	Aizzah	0	11	0	0	0	542	\N	0
5018854948	0	𝐕avel	0	3	0	0	0	12	\N	0
2025431716	0	Jiella!	0	31	0	0	0	5	\N	0
1564260867	0	Jyn	0	45	1	0	0	22	\N	0
1797580580	0	alia	0	2	0	0	0	1	\N	0
5498663184	0	A	0	15	0	0	0	1	\N	0
5877927526	0	kana	0	1	0	0	0	0	\N	0
5823324707	0	k.	0	1	0	0	0	0	\N	0
1834578131	0	.	0	2	0	0	0	0	\N	0
6598801008	0	Je.	0	2	0	0	0	0	\N	0
1793063776	0	yp	10	282	2	0	12.439999999999998	455	\N	0
5787266419	0	rafka	0	11	0	0	53.66999999999916	163	\N	0
5598068127	0	ivy	0	30	0	0	879.21	24	\N	0
5497940720	0	vno.ry	0	7	0	0	0	9	\N	0
2072073228	0	Orine, a.	0	8	0	0	0	2	\N	0
1926804525	0	South. 909	0	2	0	0	0	0	\N	0
1832682182	0	clovv	0	4	0	0	0	0	\N	0
1109853581	0	.ㅤㅤ	0	3	0	0	0	0	\N	0
5591363117	0	dksoo	0	1	0	0	0	1	\N	0
1981823184	0	farel the porcupine	0	5	0	0	200	140	\N	0
6655883043	0	n	0	7	0	0	500	0	\N	0
2070176896	0	Tedi	0	1	0	0	0	2	\N	0
1679265070	0	Miguel	0	5	0	0	0	0	\N	0
2061552225	0	Arslan, rarely active	0	40	0	0	38	197	\N	0
6561309670	0	ecaa sukkaaa hiuu	1	12	0	0	283.31	8	\N	0
5422611709	0	a	0	0	0	0	0	2	\N	0
5095243270	0	lili	0	46	0	0	0	65	\N	0
5787088643	0	a	0	83	0	0	34	7	\N	0
5356506278	0	robin	0	1	0	0	0	162	\N	0
5299028491	0	bulan.	0	5	0	0	0	1	\N	0
5584102426	0	Faadhin	0	4	0	0	121.54	54	\N	0
5107604202	0	noc	0	4	0	0	0	0	\N	0
6448999249	0	j	0	65	0	0	939.8699999999999	30	\N	0
6160705303	0	Vansevhour D.	0	5	0	0	0	0	\N	0
1728642490	0	Zhong, Martyr.	0	1	0	0	0	28	\N	0
6985770725	0	TV	0	78	0	0	13	63	\N	0
6761023531	0	Jevalos	0	22	0	0	0	95	\N	0
6231700686	0	Shanne.	0	3	0	0	0	0	\N	0
1686222177	0	Rainly	0	65	0	0	70.94	18	\N	0
6658375023	0	cesa	0	4	0	0	0	0	\N	0
6031215444	0	gistra	0	7	0	0	0	3	\N	0
6149877952	0	Radiohead	0	1	0	0	0	4	\N	0
5819884707	0	vica	0	2	0	0	0	40	\N	0
1555424774	0	user n	0	1	0	0	0	0	\N	0
1641550847	0	282 jarkajinks	0	1	0	0	0	4	\N	0
6893137419	0	reza	0	28	0	0	434	0	\N	0
1858884113	0	jaiii	0	2	0	0	0	0	\N	0
1640616753	0	rere	0	98	0	0	0	266	\N	0
1796004226	0	<3.	0	5	0	0	0	3	\N	0
6108105258	0	mίαη mίαη /⁠ᐠ⁠｡⁠ꞈ⁠｡⁠ᐟ⁠\\	0	1	0	0	0	0	\N	0
1532972024	0	Ganja	0	1	0	0	0	9	\N	0
1873283067	0	ladies	0	6	0	0	0	1	\N	0
2126455607	0	︎︎ ︎︎ ︎︎ ︎︎	14	298	0	0	1512.5299999999993	15118	\N	1
6894643828	0	cesàs	0	11	0	0	1105	10	\N	0
1369905312	0	𝐂(h)alestyn.^eca	0	14	0	0	0	7	\N	0
1620173078	0	iheartjaekyung.	0	15	0	0	0	86	\N	0
6688648190	0	Ryujes	0	3	0	0	0	9	\N	0
1530585192	0	vaaleenn	0	0	0	0	0	0	\N	0
5866434792	0	Ireiii	0	3	0	0	0	4	\N	0
1857913291	0	naraa	0	4	0	0	0	2	\N	0
1635780997	0	Aybel D.	0	1	0	0	0	1	\N	0
6782709993	0	ㅤㅤㅤㅤ	0	3	0	0	0	0	\N	0
6820234701	0	Ranaf || open	0	1	0	0	0	1	\N	0
5674919712	0	z	0	21	0	0	594.22	193	\N	0
1654585336	0	daptor	0	48	1	0	25	64	\N	0
1582797936	0	keshi :p	0	106	0	0	0	2	\N	0
5134653978	0	Naysila	0	12	0	0	0	45	\N	0
5465120657	0	galau	0	10	0	0	0	56	\N	0
1940942244	0	Diphylleia G.	0	181	0	0	5.330000000000004	86	\N	0
6113082935	0	bebel on duty!	12	23	0	0	0	0	\N	0
6187790237	0	Unstable	0	0	0	0	0	1	\N	0
1147700319	0	Rahma|	0	2	0	0	0	2	\N	0
5245200875	0	H. 👽	0	167	0	0	397.4000000000003	2515	\N	0
6020276114	0	𓆰͜͡sx͛ɪᴅ̸☤͜͡ asa	0	1	0	0	0	0	\N	0
6234099883	0	Rest . Elkairo .s	0	5	0	0	671.63	3	\N	0
6949359833	0	K	0	1	0	0	0	0	\N	0
6211049929	0	salma	0	1	0	0	0	0	\N	0
5439535469	0	iyan	0	1	0	0	0	0	\N	0
5709528632	0	...	0	4	0	0	0	1	\N	0
1252618741	0	jejia, sshht 𓂀 ; ୨ৎ.	0	0	0	0	0	2	\N	0
5765352695	0	asghyra siagian	0	81	0	0	20.68000000000029	540	\N	0
6484265871	0	Yoon.	0	1	0	0	0	0	\N	0
1916070378	0	le (=^･^=)	0	66	0	0	0	646	\N	0
7014816575	0	tersahhh.	0	3	0	0	0	1	\N	0
1293836118	0	aya	0	0	0	0	0	0	\N	0
1574105300	0	Fayos	0	655	0	0	3.660000000000224	124	\N	0
5120062498	0	sheesh #bjr	0	1	0	0	0	26	\N	0
6031715768	0	. bian	0	1	0	0	0	0	\N	0
1411452470	0	starsha	0	1	0	0	0	3	\N	0
1690767853	0	𖤝 ࣪˖ magnifique, Jolicya ׂ ഒ ࣪˖	0	1	0	0	0	4	\N	0
1405768476	0	molmol	7	68	0	0	3529.23	1056	\N	0
5207144165	0	shiena	0	6	0	0	0	0	\N	0
5999242063	0	camiore	4	184	0	0	3156.37	385	\N	0
1982581322	0	Dative Orlando.	0	2	0	0	0	5	\N	0
5853660879	0	dedy hndko	0	3	0	0	0	110	\N	0
2023850505	0	ceceww	0	3	0	0	0	122	\N	0
1944909648	0	jones	0	5	0	0	0	1	\N	0
5476070006	0	Bulan 🦖	0	376	0	0	394.199999999998	115	\N	0
1695038540	0	🌖	0	14	0	0	0	6	\N	0
5209413335	0	chelle	0	13	0	0	64.95999999999997	4	\N	0
5877432580	0	elana	0	109	0	0	11.570000000000164	144	\N	0
5144078297	0	amora	0	4	0	0	0	29	\N	0
6483679527	0	cherry blossom's	0	0	0	0	0	3	\N	0
6800031933	0	— raa	0	7	0	0	0	12	\N	0
5866310655	0	uuh	0	1	0	0	0	0	\N	0
2139445664	0	mange	0	5	0	0	0	0	\N	0
1925292854	0	Jaehyun.	0	65	0	0	0	46	\N	0
5956307524	0	иαsyά崸.	0	3	0	0	0	6	\N	0
5125610837	0	Elena.	0	1	0	0	0	10	\N	0
5760958769	0	Aldi Tagor.	0	2	0	0	159.53	76	\N	0
1751213731	0	k/ia. ode salima	0	1	0	0	0	0	\N	0
6166477402	0	ⁱᵐ	0	1	0	0	0	0	\N	0
5898296205	0	jia	0	5	0	0	0	0	\N	0
5457628998	0	Hardan M.	0	3	0	0	0	1	\N	0
1937828948	0	sela	0	14	0	0	0	73	\N	0
1640545311	0	nad (๑•̀ㅂ•́)و✧	0	7	0	0	0	33	\N	0
1058265723	0	pororo	0	68	0	0	7	6	\N	0
5216060349	0	Elvern.	0	1	0	0	0	0	\N	0
5431607063	0	mit	0	1	0	0	0	0	\N	0
5184377893	0	assac	0	2	0	0	0	1	\N	0
2107260677	0	asu	0	3	0	0	0	0	\N	0
2088878086	0	ㅤㅤㅤㅤ	0	37	0	0	0	340	\N	0
1302090439	0	𐙚‧₊ kai sedang sedih T___T	0	26	0	0	52.730000000000004	57	\N	0
1476430379	0	michie	0	250	0	0	5222.630000000001	696	\N	0
5546570363	0	.	0	31	0	0	514.8000000000002	316	\N	0
5854690332	0	keie	0	2	0	0	0	2	\N	0
1473792666	0	Chan	0	80	0	0	816.1300000000001	203	\N	0
6826689100	0	key	0	6	0	0	0	4	\N	0
1411929654	0	alsya	10	218	0	0	272.89000000000004	41	\N	0
1945016288	0	deyy	0	2	0	0	0	6	\N	0
5054559559	0	Sandrina	0	1	0	0	0	0	\N	0
1283424669	0	Fnny	0	119	0	0	456	49	\N	0
5380760626	0	noelle	0	20	0	0	15	0	\N	0
1659693227	0	.	0	3	0	0	0	2	\N	0
1706157711	0	zach	0	2	0	0	0	0	\N	0
5613761262	0	chelaaaaa	0	370	0	0	12.97999999999995	2269	\N	0
1977205934	0	kalkal . sell @ zaylyan !!	0	0	0	0	0	1	\N	0
6250571863	0	zhr	0	0	0	0	0	0	\N	0
5006851811	0	khalep	0	15	0	0	0	2	\N	0
6807409235	0	naresh terbakar 🔥	0	3	0	0	0	13	\N	0
6173157906	0	Gin	0	13	0	0	0	41	\N	0
1566909393	0	Cale	0	2	0	0	0	0	\N	0
5117820319	0	bella	0	8	0	0	0	0	\N	0
5211825985	0	Hethro.	0	4	0	0	0	0	\N	0
2013875227	0	Kh?	0	12	0	0	0	12	\N	0
1742361729	0	chizu	0	1	0	0	0	0	\N	0
5193183656	0	Darien	0	262	0	0	7.5	1387	\N	0
6299384453	0	Bunda corla	0	0	0	0	0	0	\N	0
1745422650	0	Yuuki	0	3	0	0	0	0	\N	0
5206749833	0	ilang	0	0	0	0	0	2	\N	0
5856568667	0	°nia	0	2	0	0	0	0	\N	0
6347333064	0	pamberley	0	10	0	0	0	17	\N	0
1800543261	0	sofi	0	1	0	0	0	0	\N	0
5108625821	0	𝘽𝙡𝙚𝙪 𝘼𝙯𝙪𝙡	0	0	0	0	0	2	\N	0
6885690433	0	Casey	0	0	0	0	0	0	\N	0
5363041677	0	Jinaya.	0	1	0	0	0	0	\N	0
6992466073	0	Jjoviel	0	1	0	0	90	0	\N	0
1787564888	0	miu	0	2	0	0	0	788	\N	0
6265965934	0	nn	0	12	0	0	0	5	\N	0
5427452921	0	narenn the greenest flag	0	4	0	0	0	13	\N	0
1448357538	0	flassy	0	13	0	0	0	158	\N	0
6683499657	0	Nicolette Carlisle	0	1	0	0	0	1	\N	0
6165244316	0	Wide	0	3	0	0	0	7	\N	0
1214075692	0	<ree3	0	32	0	0	10.82	272	\N	0
5569133424	0	riaaa	0	147	0	0	1.3299999999999983	21	\N	0
5853279979	0	cêy	0	5	0	0	0	0	\N	0
5451355507	0	ㅤ	0	11	0	0	0	19	\N	0
1818548009	0	𝐍𝐚𝐦𝐢	0	41	0	0	0	0	\N	0
7174251512	0	jui	0	2	0	0	0	2	\N	0
5952614127	0	jooo	0	1	0	0	0	0	\N	0
5989839461	0	Kelvin	0	49	0	0	0	2	\N	0
5491519700	0	❸҉Ş҉ -X͜͡ Cheona	0	1	0	0	0	0	\N	0
5959886853	0	cece	0	45	0	0	1824	27	\N	0
6396383441	0	nuna	0	4	0	0	0	4	\N	0
5659519861	0	al	0	1	0	0	0	21	\N	0
5805672597	0	zai	11	266	0	0	328.2700000000001	711	\N	1
5855454971	0	zarr	0	2	0	0	0	0	\N	0
1602564737	0	n	0	53	0	0	0	13	\N	0
1072249666	0	LZA	0	1	0	0	0	0	\N	0
5391717939	0	arsh	3	15	0	0	658.0200000000001	24	\N	0
1439530180	0	D jakii	0	32	0	0	0	25	\N	0
1634293140	0	Rafah	0	1	0	0	0	0	\N	0
5180573257	0	a	0	23	0	0	0	1	\N	0
6732319997	0	abeEE	0	0	0	0	0	0	\N	0
6514445383	0	B–Lancaster.	0	4	0	0	0	11	\N	0
5870468105	0	winney	0	15	0	0	133.91	34	\N	0
1835421496	0	florencee	0	47	0	0	0	243	\N	0
1490192630	0	keyy	0	1	0	0	0	3	\N	0
5682530539	0	cia	0	20	0	0	47.56999999999999	1061	\N	0
6947200885	0	kai	0	0	0	0	0	0	\N	0
6246151730	0	Agam	0	2	0	0	0	33	\N	0
6535405394	0	Erick.	0	1	0	0	0	0	\N	0
1434319690	0	iki meow	0	32	0	0	0	379	\N	0
6231646797	0	.	0	8	0	0	724.19	0	\N	0
6348170037	0	zee	0	4	0	0	0	9	\N	0
6359905266	0	jeii	0	3	0	0	0	0	\N	0
1637380593	0	Rudi	0	1	0	0	0	1	\N	0
6915445662	0	J	0	1	0	0	0	0	\N	0
2129589375	0	𓂃 jevanyä angèlique 𔘓 ׅ ۟ ⊹	0	175	0	0	3201.309999999999	561	\N	0
5642942151	0	keca	0	1	0	0	0	41	\N	0
5641345909	0	eLit4	0	64	0	0	57.76	1	\N	0
6564553923	0	van	0	82	0	0	2.6899999999999977	6	\N	0
1969393223	0	kif	0	8	0	0	64.58000000000027	1	\N	0
5724372947	0	V	0	3	0	0	0	0	\N	0
841666387	0	ash	0	3	0	0	0	0	\N	0
6277999119	0	Shanna	0	1	0	0	0	0	\N	0
5665732826	0	kkk	0	82	0	0	21.700000000000045	89	\N	0
1762228627	0	ca	0	0	0	0	0	7	\N	0
1610078480	0	M Aylie.	0	22	0	0	0	30	\N	0
5889223334	0	Dim	0	53	0	0	798.2999999999998	849	\N	0
5917047673	0	ines 𝗿𝗱𝘀³⁰¹朋友#SoDaSBTNKDR	0	1	0	0	0	0	\N	0
5989738282	0	ar	0	1	0	0	0	0	\N	0
5941089695	0	bintang	0	1	0	0	0	0	\N	0
5109721589	0	gatra jarang on	0	2	0	0	0	6	\N	0
6084129552	0	pds jonathan	0	1	0	0	0	0	\N	0
2003901043	0	icell	14	163	0	0	1045.48	1489	\N	0
1403428058	0	kala	0	3	0	0	0	0	\N	0
5249971293	0	Cesaralye	0	9	0	0	0	6	\N	0
5919921909	0	Clare	0	96	0	0	0	0	\N	0
5433446904	0	Sèraphic '♡s.	0	4	0	0	0	218	\N	0
6749051784	0	jey youtlos	0	0	0	0	0	0	\N	0
5442363888	0	Atra	8	42	0	0	3635.7700000000004	1413	\N	0
1795047280	0	𓂋 ׁ 𝓠il, 𝒦ylie ♥️⸼ ꒰꒰ 🦴	0	12	0	0	373.92999999999995	50	\N	0
2080841059	0	J.	0	362	0	0	2.5	13	\N	0
1081597321	0	-	0	1	0	0	0	0	\N	0
1836396627	0	na	0	6	0	0	0	21	\N	0
5601534904	0	Madelta Seymour	0	1	0	0	0	3	\N	0
6815383597	0	t	0	40	0	0	15.939999999999998	15	\N	0
2087443755	0	jess	10	118	0	0	29453.409999999993	4210	\N	1
6584913734	0	Laviarthe	0	1	0	0	0	0	\N	0
1385264169	0	azura❄️	0	35	0	0	0	67	\N	0
5309002271	0	ㅤgishna	0	67	0	0	0	37	\N	0
5374987881	0	Corelio A	0	3	0	0	0	8	\N	0
5942434394	0	𝚊𝚌𝚑𝙰𝚊⚡🪐	0	0	0	0	0	0	\N	0
5475009838	0	Jesshiee, jay's lovetaker	0	2	0	0	0	0	\N	0
6508709065	0	ilo	0	41	0	0	0	4	\N	0
6645195940	0	Lay	0	3	0	0	0	4	\N	0
5734601839	0	kenay	0	9	0	0	50	15	\N	0
1690456684	0	Алекс Хаусан	0	5	0	0	0	0	\N	0
1779852676	0	rapa	0	22	0	0	0	28	\N	0
5121664251	0	reza	0	18	1	0	0	2	\N	0
1432628243	0	Ka.	0	2	0	0	0	0	\N	0
6185629563	0	K.	0	45	0	0	0	21	\N	0
6901799890	0	oni	0	30	0	0	0	5	\N	0
6105215632	0	Harley Meadow, bukan motor!!!	0	11	0	0	0	0	\N	0
1724987435	0	C	0	1	0	0	0	0	\N	0
1295180758	0	reiyss 🎸	0	2	0	0	0	0	\N	0
2124725098	0	raF Galau	0	1	0	0	0	5	\N	0
6109221530	0	n	0	35	0	0	0	3	\N	0
5886535723	0	padel	0	2	0	0	0	0	\N	0
1780757242	0	.	0	1	0	0	0	0	\N	0
5615285841	0	f'aza	0	2	0	0	0	0	\N	0
859427636	0	a	0	10	0	0	0	85	\N	0
2007761417	0	ℓαγκα	0	1	0	0	0	0	\N	0
5981514361	0	Destiny.	0	0	0	0	0	0	\N	0
1425173225	0	Nami.	0	40	0	0	342.50000000000045	228	\N	0
5617174223	0	Artur Jefferson Pradhika	0	1	0	0	0	3	\N	0
5163044872	0	aya	12	645	0	0	2682.349999999998	545	\N	0
1787155411	0	asya	0	6	0	0	0	1	\N	0
6715505411	0	rest lagi R86 megan chiesen 🇨🇺	0	1	0	0	0	4	\N	0
1930207258	0	jennie	0	220	0	0	1434	0	\N	0
5056330788	0	ay ayy kapten	0	8	0	0	0	5	\N	0
2029281123	0	raneva	0	7	0	0	0	0	\N	0
1798247566	0	U	0	14	0	0	0	2	\N	0
1987771759	0	berly	0	29	0	0	0	24	\N	0
1274499007	0	NOBLESSE	0	5	0	0	0	8	\N	0
5128757328	0	Jua	0	1	0	0	0	69	\N	0
1762960069	0	Helga, Sastra - seth.	0	5	0	0	0	1	\N	0
6550438964	0	awarr	0	8	0	0	0	17	\N	0
6408872032	0	shevaya-w, 🕷	0	1	0	0	0	0	\N	0
2071137722	0	Januar	0	4	0	0	0	0	\N	0
6668266130	0	a	0	6	0	0	0	0	\N	0
1476520334	0	Rifky	0	22	0	0	0	17	\N	0
5266877971	0	ghiv	0	5	0	0	0	3	\N	0
6068051411	0	aviska s,	0	1	0	0	0	0	\N	0
6523027676	0	yura	0	1	0	0	0	0	\N	0
6581482370	0	Kaden aja si	0	5	0	0	0	10	\N	0
6802019139	0	bilqisss	0	3	0	0	0	11	\N	0
6124428982	0	ardian	0	1	0	0	0	2	\N	0
1670370126	0	ellen anak bunda	0	1	0	0	0	0	\N	0
2032028970	0	aya not ayam😶‍🌫️	0	47	1	0	0	18	\N	0
6233062426	0	.	0	22	0	0	0	4	\N	0
6530459719	0	sera gf	0	4	0	0	0	0	\N	0
5192196727	0	.	0	6	0	0	0	0	\N	0
2038853312	0	sha	0	14	0	0	0	2	\N	0
1303824087	0	Afifah	0	0	0	0	0	0	\N	0
1943801859	0	geniA	0	29	0	0	0	464	\N	0
6217840620	0	len	0	76	0	0	1308.1200000000001	707	\N	0
6656878828	0	Abell	0	2	0	0	0	1	\N	0
1035349288	0	Lllyubyk21	0	0	0	0	0	0	\N	0
5304443078	0	anya	0	2	0	0	0	0	\N	0
5979230648	0	Arthässie. limit tap	0	4	0	0	0	0	\N	0
2115060191	0	K	0	1	0	0	0	0	\N	0
1976233468	0	nini #like ℐꮺ﹅ഒ𓂅ଘ	0	10	0	0	0	20	\N	0
6228832348	0	abing	0	3	0	0	0	1	\N	0
6453908944	0	lalaa	0	22	0	0	901.38	286	\N	0
5827049103	0	,	0	5	0	0	0	0	\N	0
6256690151	0	Moon Del Rey.	0	5	0	0	0	0	\N	0
5761102974	0	𝐃𝐋ꦿ alger	0	1	0	0	0	0	\N	0
1875406538	0	sedak	0	4	0	0	0	1	\N	0
6668482102	0	owly	0	0	0	0	0	3	\N	0
1908325445	0	p	0	703	0	0	7.11	101	\N	0
6397946606	0	Niamh Orion KR.	0	2	0	0	0	0	\N	0
1872761026	0	🧍‍♂️	0	0	0	0	0	4	\N	0
6868508407	0	xabiru	0	0	0	0	0	0	\N	0
7133582250	0	carla	0	1	0	0	0	0	\N	0
6407185802	0	ま𝐓𝐡𝐩𝐱 feyybi 🇵🇦	0	1	0	0	0	0	\N	0
1518419909	0	elis.	0	5	0	0	10	38	\N	0
6064054368	0	cCiey ❗️LIMIT JANCOK SABAR	0	14	0	0	1.04	2	\N	0
6262135784	0	.al	8	3257	1	0	790.6000000000167	995	\N	1
7091850483	0	zasya	0	1	0	0	0	0	\N	0
1274412702	0	Belva Angelica	5	127	0	0	749.24	715	\N	0
7029691087	0	jepi	0	1	0	0	0	0	\N	0
6887362068	0	jeee	0	1	0	0	0	0	\N	0
5402283391	0	zeinna	0	1	0	0	0	24	\N	0
1975695239	0	ʚ🎀，kinBeLLRy ٭!💿%	0	1	0	0	0	0	\N	0
5066602651	0	ryo's	0	28	0	0	197.45	16	\N	0
5136466781	0	❦ .. Khálid.	0	3	0	0	46.96	0	\N	0
5651155342	0	Bryatta_Ken	7	31	0	0	314.16999999999985	169	\N	0
7047154909	0	chell	0	1	0	0	0	0	\N	0
6788087508	0	Fariska.	0	4	0	0	0	0	\N	0
5030303188	0	jesslyn	0	21	0	0	0	28	\N	0
5305898016	0	Boku Wa	0	1	0	0	0	1	\N	0
6634785946	0	sheyya	0	0	0	0	0	0	\N	0
5132376966	0	mysheeee	0	1	0	0	0	1	\N	0
6202967853	0	jejey @mihssing	0	1	0	0	0	1	\N	0
5282339899	0	zares colim (𝐆𝐆𝐓)¹	0	10	0	0	0	7	\N	0
5863342750	0	Keyvara.	0	2	0	0	0	9	\N	0
5619786944	0	𝓛ⲟ𝓵ⲩ ᴜʀ 🫀	0	0	0	0	0	10	\N	0
2056420704	0	Giorno	0	3	0	0	0	14	\N	0
938714786	0	kia	3	64	0	0	638.3100000000001	138	\N	0
5330985609	0	lea leaa	0	53	0	0	0	3	\N	0
6202597759	0	mek - ngejam	0	1	0	0	0	0	\N	0
2002301442	0	viii	0	1	0	0	0	2	\N	0
5259797047	0	ɑׁׅ֮ᥣׁׅ֪ꫀׁׅܻɑׁׅ֮ɑׁׅ֮👮🏻‍♀️	0	9	0	0	0	3	\N	0
1806054133	0	possums	0	1	0	0	0	0	\N	0
1781690802	0	Jasmine tea	0	3	0	0	0	0	\N	0
6890973843	0	k	0	4	0	0	0	0	\N	0
6153528706	0	cica cek bio	0	7	0	0	0	11	\N	0
6271589389	0	star	0	7	0	0	0	0	\N	0
5034036924	0	.	0	106	0	0	0	491	\N	0
1937030921	0	anya	0	214	0	0	1102.7599999999998	27	\N	0
6709241669	0	coffereine	0	1	0	0	0	0	\N	0
1816238608	0	kàyy	0	98	0	0	57.32	7	\N	0
1912486812	0	kaluna	0	1	0	0	0	0	\N	0
7066278583	0	ᴹяѕ` pinat	0	1	0	0	0	0	\N	0
1695151602	0	ً	0	32	0	0	0	21	\N	0
1492798798	0	N qilla.	0	37	0	0	515.74	1538	\N	0
6694370053	0	kal? sek? alur?	0	78	0	0	928.9300000000001	15	\N	0
5310448780	0	rest.	0	5	0	0	0	4	\N	0
1849378004	0	zamora,	0	0	0	0	0	7	\N	0
6353787835	0	aya	0	10	0	0	0	39	\N	0
1361176879	0	Angga	0	0	0	0	0	1	\N	0
6157987762	0	alora	0	19	0	0	3.66	6	\N	0
1456775690	0	davira kaizhure	0	16	0	0	0	41	\N	0
6293328692	0	arsa buana	14	204	0	0	85.38000000000068	1893	\N	1
1948004440	0	˚｡⋆ 𝑎𝑟𝑢𝑚𝑖 ₊˚.༄	0	100	0	0	2116.71	783	\N	0
2083859801	0	moanster	0	3	0	0	0	16	\N	0
2049108201	0	aCccaAaaa🚀	0	84	0	0	30.35	214	\N	0
6792982207	0	abel ❤️ jay	0	68	0	0	0	68	\N	0
5526631876	0	Z	0	212	0	0	0	0	\N	0
6920959024	0	abip rarely active	0	14	0	0	745	217	\N	0
1391404347	0	Sad	0	0	0	0	0	0	\N	0
5032168399	0	naya	0	50	0	0	749	34	\N	0
5527453490	0	g!n	0	78	1	0	158	17	\N	0
5948128036	0	ra	0	2	0	0	0	0	\N	0
5998739847	0	itinee :3	0	3	0	0	0	0	\N	0
5412331756	0	Vian	0	2	0	0	0	0	\N	0
5962585794	0	麗永 Reii akari🩷	0	9	0	0	9.59	0	\N	0
1839332784	0	quella	0	1	0	0	0	0	\N	0
2142667567	0	michellaaaa	0	10	0	0	0	1	\N	0
6216486497	0	karyn	0	1	0	0	0	6	\N	0
1936954298	0	Kepin	0	57	0	0	0	21	\N	0
6949856993	0	orin	0	7	0	0	0	2	\N	0
1401654680	0	𖣂᤻֗ ִ 𖠗 𐐼ּ𝗿︪︩ׄ𝙖۫ ₍´˶• . • ⑅ ₎ 𝒏𝗰ֹǝ︢	0	297	0	0	6	1977	\N	0
2109605924	0	Nathan	0	13	0	0	0	29	\N	0
6121436429	0	huneeyeyey	0	6	0	0	423.8600000000003	77	\N	0
5929544869	0	jesb	0	2	0	0	0	0	\N	0
5332699496	0	bila	0	8	0	0	0	11	\N	0
1778881869	0	ffabbyan	0	5	0	0	0	1	\N	0
5060482965	0	Seragitha!	0	1	0	0	0	21	\N	0
5853479713	0	kaaanndiicceee! <3	0	0	0	0	0	9	\N	0
6135645843	0	el ngejam	0	0	0	0	0	4	\N	0
6098665331	0	Sera×🚩	0	1	0	0	0	0	\N	0
5647602879	0	Žïŷå ÿæĥ	0	8	0	0	0	2	\N	0
5622106531	0	୨ৎ sanAe	11	378	0	0	4066.7700000000004	719	\N	1
2004206287	0	Madeline	0	3	0	0	0	0	\N	0
1875679834	0	UNRELEVANT	0	4	0	0	0	5	\N	0
1834445580	0	337.rey alexander¹⁷+ᴼⁿˡʸˢᵉˣ💦Hàrvey	0	1	1	0	0	0	\N	0
5199297291	0	rara cewek	0	127	0	0	647.0399999999996	999	\N	0
6774689282	0	Kacyla	0	3	0	0	0	1	\N	0
5741703714	0	…	0	178	0	0	-1.1599999999998545	659	\N	0
5006869963	0	hazel	0	7	0	0	278.38000000000017	29	\N	0
5308391464	0	Arai	0	6	0	0	0	0	\N	0
1687374502	0	a	0	4	0	0	0	11	\N	0
5686836383	0	Dz	0	3	0	0	0	0	\N	0
1841646283	0	Veyn	0	1	0	0	0	0	\N	0
6367149576	0	eaa	0	1	0	0	0	0	\N	0
6358202475	0	Greight	0	3	0	0	0	0	\N	0
5195202956	0	iel menolk sadar	0	1	0	0	0	0	\N	0
6507066083	0	Abby.	0	0	0	0	0	1	\N	0
5160926450	0	Elyn :V	0	1	0	0	0	0	\N	0
1908723891	0	pon	0	1	0	0	0	4	\N	0
6421293016	1	Virgo	0	7	0	0	0	0	\N	0
5271321984	0	Daren ur future husband	0	364	0	0	45.75	3450	\N	0
1525046244	0	dims	0	4	2	0	0	8	\N	0
5565531520	0	脸红.	12	376	0	0	7139.490000000001	12143	\N	1
5122583388	0	Kissu	0	0	0	0	0	1	\N	0
2080687514	0	slv. raga lustify	0	158	0	0	2963.2000000000007	411	\N	0
5544249761	0	esyaa🌀	0	12	0	0	1.66	225	\N	0
5901899966	0	Nte	0	119	0	0	19.069999999999936	3	\N	0
1756714221	0	biarbyurbiarbyur	0	5	0	0	0	13	\N	0
6659672766	0	Raden L.	0	2	0	0	0	0	\N	0
5082009595	0	elang	0	1	0	0	0	1	\N	0
5175809894	0	Eve. jangan unfollow 😡	0	22	0	0	0	43	\N	0
1883933865	0	G	0	4	0	0	0	9	\N	0
6918370327	0	Halana	0	5	0	0	0	0	\N	0
6862539927	0	Flavie	0	0	0	0	0	0	\N	0
1792354402	0	zefor	0	1	0	0	0	1	\N	0
1203847177	0	b	0	87	0	0	1.5	51	\N	0
1604162954	0	Ra.	0	7	0	0	599.5799999999999	158	\N	0
1042259661	0	ciya	0	2	0	0	0	119	\N	0
1094793599	0	Ruffy	0	10	0	0	0	11	\N	0
6270000041	0	Nakael	0	1	0	0	0	0	\N	0
567347340	0	.	0	3	0	0	0	0	\N	0
1775459416	0	Arsap	0	23	0	0	0	0	\N	0
6184483043	0	saci	0	32	0	0	464.9200000000001	150	\N	0
5906468378	0	𝐍inshua	4	177	0	0	34917.90000000001	464	\N	1
1724996057	0	nayy	0	150	0	0	312.7	9	\N	0
6752783624	0	.	0	1	0	0	0	0	\N	0
2028156501	0	ya	0	21	1	0	0	11	\N	0
5350435671	0	hazel	0	3	0	0	0	7	\N	0
5864939647	0	cacaa ebeww	0	2	0	0	0	5	\N	0
6649101623	0	Fk	0	0	0	0	0	0	\N	0
5000456539	0	s	5	10	0	0	370.64000000000027	1	\N	0
1776534014	0	Kael	0	2	0	0	0	2	\N	0
6258666101	0	H	0	68	0	0	14.480000000000004	617	\N	0
1979332362	0	j	0	4	0	0	0	0	\N	0
1900976303	0	Elmirén @onlyparkchae	0	2	0	0	0	0	\N	0
6295064265	0	cel	0	8	0	0	0	9	\N	0
5054855266	0	Waf	0	21	0	0	0	4	\N	0
1741233807	0	.	0	6	0	0	356	0	\N	0
5220653058	0	raden	0	107	0	0	0	244	\N	0
5622356809	0	Geby. S	0	2	0	0	0	30	\N	0
5962321764	0	mrn	0	170	0	0	582.3599999999999	2	\N	0
5893475102	0	reenn	0	4	0	0	0	0	\N	0
1618478637	0	chell	12	362	0	0	3205.19	1868	\N	1
5706544570	0	nay	0	13	0	0	0	11	\N	0
5215592974	0	mauve	0	36	0	0	0	179	\N	0
5715689085	0	Gebu	0	31	0	0	133	177	\N	0
1791466924	0	ane	0	58	0	0	84.70999999999958	365	\N	0
5228997293	0	m	0	3	0	0	0	7	\N	0
1769650604	0	saaa	0	14	0	0	0	10	\N	0
1574621122	0	⁣⁣⁣⁣⁣⁣⁣⁣⁣bela	0	4	0	0	0	0	\N	0
1622734295	0	maeio	0	81	0	0	0	11	\N	0
1919000942	0	Zark	0	2	0	0	0	0	\N	0
5639561302	0	kai♰	0	4	0	0	0	143	\N	0
1829395264	0	kz	0	60	0	0	0	0	\N	0
1980364845	0	oLyn 🐇	0	6	0	0	0	20	\N	0
5321639386	0	J.	0	1065	0	0	463.8900000000001	1640	\N	0
1079453390	0	caa	0	10	0	0	0	27	\N	0
1175895636	0	gvn	0	4	0	0	0	22	\N	0
5555056934	0	alan	0	66	0	0	121.44	75	\N	0
2119965158	0	Gil	0	1	0	0	0	3	\N	0
1668979486	0	asa	0	17	0	0	0	89	\N	0
5012526084	0	Piyu	0	1	0	0	51.47999999999983	1015	\N	0
1890415192	0	Elizabeth Seraphine D.	0	101	0	0	0	234	\N	0
1482622865	0	Nay.	4	62	0	0	100	228	\N	0
6310458992	0	Aksa N.	0	2	0	0	0	5	\N	0
5873375933	0	J	3	187	0	0	1000.3600000000007	38	\N	0
6090606783	0	@wAsasi	0	1	0	0	0	0	\N	0
6612001907	0	carol	10	93	1	0	6573.229999999993	93	\N	1
1700011198	0	Monica Putri	0	1	0	0	0	0	\N	0
1866773299	0	lvy	0	6	0	0	0	1	\N	0
6088012480	0	Aptaghani A.	0	1	0	0	0	0	\N	0
5196660713	0	ka-nna, takut tambah dewasa	0	2	0	0	0	28	\N	0
5837171279	0	Ble	6	65	0	0	1154.4299999999998	346	\N	0
5803762812	0	Ziziziziziiaaaa	0	40	0	0	0	5	\N	0
5365568357	0	dann	0	121	0	0	1120.6699999999998	366	\N	0
6682626141	0	Michelle Lea	0	31	0	0	457	15	\N	0
6848103880	0	pacar iyel	0	84	0	0	12.980000000000004	602	\N	0
5698901109	0	keia	0	9	0	0	2.95	180	\N	0
1536442056	0	wawa atapu jake	0	4	0	0	0	0	\N	0
6758994229	0	vyoo	0	93	0	0	2.490000000000009	238	\N	0
5786848949	0	.	0	40	0	0	63.83	228	\N	0
1898776631	0	cce	0	2	0	0	0	0	\N	0
2134421961	0	Sasa jadi sadgirl:)	0	42	0	0	0	19	\N	0
5947804135	0	bryan	0	1	0	0	0	0	\N	0
7096806204	0	lavanya	0	2	0	0	0	0	\N	0
6132142110	0	غورة	0	61	0	0	207.58	0	\N	0
2049466196	0	...	0	20	0	0	0	0	\N	0
5590647120	0	aiden tr	0	1	0	0	0	2	\N	0
5157813236	0	yuvarie	0	30	0	0	0	1	\N	0
6627466181	0	h	0	5	0	0	0	0	\N	0
5545811623	0	yesha.	0	16	0	0	0	0	\N	0
1732717313	0	Keysha	0	10	0	0	0	7	\N	0
5909501217	0	𝕮𝖎𝖆 𝕮𝖔𝖔𝖑 𝕸𝖆𝖋𝖎𝖆 𝕽𝕻	0	7	0	0	0	4	\N	0
5793354484	0	ester.	0	39	0	0	500	60	\N	0
2144079179	0	liv	0	6	0	0	0	30	\N	0
5498343938	0	eze	0	2	0	0	0	0	\N	0
1774226174	0	khairyn	0	6	0	0	0	0	\N	0
5440500954	0	iluvbento	0	12	0	0	0	0	\N	0
5208679456	0	bielöora pilona.	0	40	0	0	0	23	\N	0
5867820729	0	KIZU	0	108	0	0	1640	105	\N	0
5779889432	0	sc	0	1	0	0	0	2	\N	0
6000748159	0	jena	0	3	0	0	0	2	\N	0
5006137874	0	jemanda	0	3	0	0	0	4	\N	0
6774166788	0	.	0	5	0	0	0	5	\N	0
5699250083	0	emily	5	14	0	0	24175.739999999998	1835	\N	1
1898164313	0	ona cebew	0	191	0	0	0	13	\N	0
5990980513	0	rest . arbi.dias	0	4	0	0	0	0	\N	0
6887241406	0	𝗞𝗮𝘁𝗵𝗲𝗿𝗶𝗻𝗲 𝗣. 𝗦𝘁𝗲𝗹𝗹𝗮𝗻	0	7	0	0	0	8	\N	0
6146779440	0	hazel	0	4	0	0	0	0	\N	0
6920996623	0	ㅤ	0	21	0	0	0	4	\N	0
6796038396	0	ca	0	111	0	0	33.27999999999997	546	\N	0
1963655715	0	cajiii	0	2	0	0	0	0	\N	0
2003281955	0	:D	8	1673	0	0	13198.98	5399	\N	0
6836162680	0	Rize Of Sorteiz, Theo	0	1	0	0	0	0	\N	0
6777121931	0	717 - jose	0	6	0	0	0	48	\N	0
1678796448	0	Ganta.	0	5	0	0	0	0	\N	0
1558400892	0	.	0	4	0	0	0	0	\N	0
1370446243	0	young?	0	125	0	0	0	40	\N	0
5163656200	0	najel	0	3	0	0	596.55	1652	\N	0
2091612371	0	presiden jo	0	8	0	0	0	237	\N	0
1629460169	0	nami.	0	17	0	0	0	0	\N	0
1127606057	0	ceceeee	0	144	0	0	0	207	\N	0
5366327071	0	Rezz	0	1	0	0	0	0	\N	0
7079574654	0	chisy	0	58	0	0	121.36	455	\N	0
5358240226	0	an	0	5	0	0	0	0	\N	0
6124899116	0	jie load berat	0	3	0	0	0	1	\N	0
5878780625	0	ra	0	96	0	0	0	23	\N	0
1842328874	0	u know karin?	13	917	0	0	1207.4500000000019	4613	\N	1
5241307421	0	je 🎅🏻	8	65	0	0	2643.1700000000005	8	\N	0
5231964803	0	.	0	2	0	0	0	1	\N	0
6650620619	0	Cessie	0	5	0	0	0	0	\N	0
5863466103	0	Shreya	0	10	0	0	66.47	46	\N	0
1874923612	0	le?	0	1	0	0	0	0	\N	0
5334361223	0	bellä birthday!	0	6	0	0	0	24	\N	0
1814051840	0	arabella	0	1	0	0	0	46	\N	0
5000096515	0	shaka	0	10	0	0	207.79999999999995	330	\N	0
6279490751	0	ashel	0	2	0	0	0	2	\N	0
1488040557	0	Bethari E-neir	0	2	0	0	0	2	\N	0
1866440269	0	Dreyfus	0	4	0	0	0	1	\N	0
6740010815	0	piko coffee	0	1	0	0	0	0	\N	0
6652397096	0	ezy	0	21	0	0	0	91	\N	0
5583420387	0	⚘͜͡ᴍˢ Kᴏᴢᴀ™	0	8	0	0	0	4	\N	0
2009515194	0	ars	0	1	0	0	0	0	\N	0
1885997913	0	D	0	238	0	0	0	0	\N	0
6397156641	0	biann	0	2	0	0	0	0	\N	0
1443120886	0	raa	0	19	0	0	0	8	\N	0
6283586112	0	Derick K.	0	1	0	0	0	1	\N	0
5107525488	0	nadista.	0	2	0	0	0	0	\N	0
2095890156	0	Michaell. 🔮	0	26	0	0	0	4	\N	0
6003376424	0	zuya	3	319	0	0	627.3600000000008	584	\N	0
5418073435	0	.	0	95	0	0	0	35	\N	0
5441505077	0	F	0	3	0	0	0	11	\N	0
5954423995	0	Ace	0	2	0	0	0	0	\N	0
6657281836	0	Baee	0	71	0	0	0	52	\N	0
6354749356	0	agis౨ৎ	0	17	0	0	0	47	\N	0
1643171898	0	ohyeah	0	0	0	0	0	0	\N	0
5272230795	0	repan always nt	0	3	0	0	0	2	\N	0
1209525588	0	vy	0	0	0	0	0	0	\N	0
5675798135	0	ranum	0	1	0	0	182.02	26	\N	0
7102777662	0	Revol	0	1	0	0	0	1	\N	0
5345229762	0	nau	0	29	0	0	0	0	\N	0
1779188234	0	clArhEa	0	64	0	0	11	45	\N	0
1901055692	0	vi	0	3	0	0	0	0	\N	0
1949195573	0	Mattheo @bdssboy	0	2	0	0	0	0	\N	0
6139235745	0	putra	0	2	0	0	0	4	\N	0
6284973999	0	rày	0	3	0	0	0	6	\N	0
1950900430	0	ren	0	3	0	0	0	31	\N	0
5130774323	0	Sksk	0	1	0	0	0	2	\N	0
5042600057	0	s	0	10	0	0	0	0	\N	0
2135729436	0	Hamka	0	0	0	0	0	16	\N	0
6021049655	0	shakila	0	4	0	0	0	0	\N	0
1482095726	0	Reymond	0	4	0	0	0	2	\N	0
5743896213	0	•͜͡🀋²jāxöc ngēwrʷʳᵇ	0	17	0	0	87.75	4	\N	0
5397127923	0	᪤..୨୧ ashley	0	2	0	0	0	0	\N	0
5414560609	0	Rey	0	1	0	0	0	1	\N	0
1878513939	0	zeaa	0	1	0	0	0	2	\N	0
2066509361	0	doremi	0	2	0	0	0	0	\N	0
1429411489	0	yochito gawwwRrr T0T	0	27	0	0	0	54	\N	0
1561207490	0	ana	0	19	0	0	78	2	\N	0
1832661441	0	rish	7	331	0	0	9.3299999999997	885	\N	0
1687904276	0	Dena	0	1	0	0	0	1	\N	0
5936167671	0	arselle ratu mafia 😈😈😈😈	0	4	0	0	0	0	\N	0
6462008618	0	cikho	0	7	0	0	0	21	\N	0
1795500152	0	marco	0	2	0	0	0	0	\N	0
5461055518	0	𝐙𝐄𝐑𝐎	0	6	0	0	0	9	\N	0
6357217526	0	olip	0	1	0	0	0	0	\N	0
1882836724	0	k	0	2	0	0	0	0	\N	0
5997124685	0	ceri	0	1	0	0	0	0	\N	0
5956300537	0	Ren	0	4	0	0	0	0	\N	0
7194083363	0	cifud	0	1	0	0	206.86	20	\N	0
5516641674	0	pawii	0	1	0	0	0	1	\N	0
6015713006	0	amara, d. ☽	0	4	0	0	0	0	\N	0
1434369140	0	私 anes	0	1	0	0	0	0	\N	0
6077320143	0	yola uda logout	0	36	0	0	0	31	\N	0
1498874040	0	brian	0	62	0	0	0	8	\N	0
2100582242	0	Toji Fangirl, 𝐇erav	0	1	0	0	0	0	\N	0
6253225793	0	bila	0	8	0	0	0	0	\N	0
1964215475	0	Ciaaaa	0	12	0	0	0	4	\N	0
1340530521	0	ayaya	0	20	0	0	0	106	\N	0
5324480190	0	fay	0	9	0	0	0	6	\N	0
5448659334	0	Chyz	0	23	0	0	2403	201	\N	0
5305084776	0	chaery	0	6	0	0	0	10	\N	0
5304819671	0	Patricia	0	1	0	0	0	2	\N	0
6267478090	0	LEA	0	3	0	0	0	6	\N	0
5308181289	0	kanala	0	3	0	0	0	1	\N	0
1674562312	0	raels	0	4	0	0	0	1	\N	0
5768150074	0	fyy	0	1	0	0	0	8	\N	0
5578733265	0	loml	0	0	0	0	0	0	\N	0
2114754275	0	Aditya	0	1	0	0	0	1	\N	0
5397110374	0	d for del	0	1	0	0	0	0	\N	0
6934414792	0	ayà	0	3	0	0	0	0	\N	0
1781249393	0	katherine	0	29	0	0	0	16	\N	0
6232186975	0	cin	0	4	0	0	0	0	\N	0
6393100263	0	Secret	0	3	0	0	0	22	\N	0
5237259261	0	.	0	5	0	0	0	0	\N	0
5325419036	0	..	0	19	0	0	0	3	\N	0
5963103832	0	Roy	0	86	2	0	0	29	\N	0
5122957650	0	dikaa	0	1	0	0	0	0	\N	0
6165136661	0	Sila 🎧	0	3	0	0	0	0	\N	0
1160657092	0	genia.	0	2	0	0	0	26	\N	0
1704490030	0	rashit	0	1	0	0	0	3	\N	0
5068058515	0	tebak nama	0	59	0	0	1282.36	2608	\N	0
6290846610	0	Himy.	0	8	0	0	0	4	\N	0
5437442133	0	mahën.	0	141	0	0	674.46	455	\N	0
6103784977	0	Ꮺㅡ the prèttiest, Shasha. 🧚🏻‍♀	3	28	0	0	1020.22	273	\N	0
5379228049	0	nadya.	0	3	0	0	0	1	\N	0
2042732966	0	j	0	20	0	0	0	12	\N	0
6560643552	0	𝓖adisha — gbs rush	0	23	0	0	0	2	\N	0
6636787426	0	luvy	0	2	0	0	0	0	\N	0
1742473887	0	ㅤ	0	9	0	0	0	60	\N	0
6661718474	0	L	0	44	0	0	6.530000000000001	155	\N	0
5398873690	0	user n	0	33	0	0	150	19	\N	0
1933190137	0	khayee	0	0	0	0	0	0	\N	0
1578043064	0	laper	0	4	0	0	0	18	\N	0
5813540466	0	bebas	0	1	0	0	0	24	\N	0
6251626143	0	cesidior	0	1	0	0	0	0	\N	0
1983090097	0	nrtrrn	0	87	0	0	0	364	\N	0
6623843366	0	ᴋᴇʏ	0	4	0	0	0	2	\N	0
6384165689	0	Devries @tampanjx	0	1	0	0	0	0	\N	0
5075411722	0	c	0	1	0	0	0	0	\N	0
6419775073	0	el	0	1	0	0	0	0	\N	0
1165149470	0	alea	0	382	0	0	3.46	114	\N	0
5823531745	0	.	0	5	0	0	0	2	\N	0
5146328917	0	manusia boboiboy	0	7	0	0	0	5	\N	0
5129635448	0	Jiffara.	0	36	0	0	0	32	\N	0
5052630945	0	kesar	0	4	0	0	0	328	\N	0
953150124	0	Fake Love	0	2	0	0	0	14	\N	0
5207086908	0	lia sobat miksu	0	10	0	0	66.9	51	\N	0
5939649355	0	Deva	0	9	0	0	0	7	\N	0
6311736652	0	snow☃️	0	2	0	0	0	11	\N	0
1766158645	0	💟	0	2	0	0	0	0	\N	0
1982271034	0	qilaaa	0	1	0	0	0	1	\N	0
6680008863	0	Seraphine's personal fuckers, Rafshand Fillsh	0	1	0	0	0	1	\N	0
1749502072	0	saya aslinya 2 orang	0	11	0	0	0	5	\N	0
1948732153	0	nean	0	553	0	0	21.200000000000003	3542	\N	0
1424087771	0	.	0	12	0	0	190.54	30	\N	0
5795034669	0	Ian	0	7	0	0	0	3	\N	0
2143299887	0	Tyasa.	0	3	0	0	0	0	\N	0
5140800138	0	Ryan	0	3	0	0	0	3	\N	0
1916707865	0	Brent	3	172	0	0	6917.899999999999	2588	\N	0
5794718404	0	ar	0	46	0	0	0	2138	\N	0
6179713892	0	reynjun	0	2	0	0	0	7	\N	0
6125322696	0	chess istri jaekyung💋	0	4	0	0	0	0	\N	0
5051773660	0	Ninnie the kitty	0	3	0	0	0	6	\N	0
5558167223	0	cio	0	100	0	0	0	30	\N	0
5853880626	0	k	8	82	0	0	233.36	610	\N	0
1424392377	0	Ocirr	0	30	0	0	0	22	\N	0
7092061163	0	Sabitha M.	0	4	0	0	0	0	\N	0
6175675240	0	only rep cf	0	51	0	0	29.81	1569	\N	0
6068139951	0	Keenan Seth.	0	1	0	0	0	0	\N	0
6029399711	0	cii	0	2	0	0	0	2	\N	0
5789103580	0	niel	0	2	0	0	0	0	\N	0
5774498570	0	khesya	0	4	0	0	0	22	\N	0
5461637389	0	Rayla	0	16	0	0	55.91	129	\N	0
5870274039	0	˖ ࣪ Sachiro T. Yuzuru	0	1	0	0	0	2	\N	0
6430635331	0	J.Yolanda	0	3	0	0	0	14	\N	0
5489742581	0	caca	0	1	0	0	0	2	\N	0
5027815048	0	aleee ֶָ ᮫	0	661	0	0	33.30000000000001	276	\N	0
5072705843	0	mouri	0	1	0	0	0	0	\N	0
1959664342	0	Elle. #BRITCHIESOPMEMB	0	30	0	0	45.79	39	\N	0
5258797076	0	Prinses	0	1	0	0	10.5	5	\N	0
6114758605	0	umbrella	14	113	0	0	1261.3599999999997	242	\N	0
1055936806	0	͏	0	6	0	0	0	1	\N	0
898163614	0	roqi	0	2	0	0	0	0	\N	0
6386686507	0	awa	0	68	0	0	768.0700000000002	193	\N	0
1851502321	0	Kayerine. ♡	0	2	0	0	0	0	\N	0
5210585895	0	Straké	0	182	1	0	0	7	\N	0
5423974732	0	Jeje	0	8	0	0	28.919999999999987	13	\N	0
1733822838	0	n	9	51	0	0	36.350000000000264	37	\N	0
5773001799	0	diego	0	17	0	0	0	185	\N	0
1755871583	0	ale	0	4	0	0	0	6	\N	0
1778857530	0	Wakhidd	0	2	0	0	0	2	\N	0
5241387017	0	K	0	4	0	0	0	2	\N	0
1692443480	0	bb	0	10	0	0	0	34	\N	0
2075166901	0	najen.	0	18	0	0	11.620000000000005	5	\N	0
5207188868	0	k	0	76	0	0	0	10	\N	0
5864413579	0	J	0	4	0	0	0	0	\N	0
5118433412	0	Ardhan	0	2	0	0	0	0	\N	0
5959868086	0	AYA.	9	911	0	0	410.6999999999998	4632	\N	0
1341633865	0	Al	0	16	0	0	0	50	\N	0
1180488033	0	entah ok	0	1	0	0	0	2	\N	0
1768526113	0	c	0	80	0	0	1230.04	813	\N	0
1470740009	0	Flankkin	0	24	0	0	0	8	\N	0
1816050834	0	Meta	0	5	0	0	0	9	\N	0
1875561693	0	M	0	2	0	0	0	0	\N	0
1826596093	0	Toko Nokos Tele	0	2	0	0	0	3	\N	0
1410570179	0	Vinn	0	21	0	0	1228.44	149	\N	0
1895396866	0	D ~	0	0	0	0	0	1	\N	0
772339942	0	Ozuce	0	12	0	0	0	248	\N	0
5149599736	0	Freelance	0	7	0	0	0	3	\N	0
6070047257	0	ca.	0	4	0	0	0	20	\N	0
1605101700	0	ryu	0	0	0	0	0	0	\N	0
5918217418	0	natt	0	2	0	0	0	0	\N	0
6912896188	0	A	0	2	0	0	0	0	\N	0
5847284772	0	pulupulu	0	6	0	0	100	26	\N	0
1838444445	0	libbie	0	1	0	0	1500	100	\N	0
5099268654	0	dean	0	13	0	0	0	32	\N	0
1980431345	0	claObie . . 🌷	0	2	0	0	0	2	\N	0
2038374564	0	mediena otw jadi capres	0	13	0	0	0	4	\N	0
1398217529	0	zila	0	3	0	0	90.22	303	\N	0
1927049119	0	anin, return @Gispelle	0	0	0	0	0	3	\N	0
5304398331	0	Jane lagi galau	0	8	0	0	0	5	\N	0
1863298075	0	Elysian Taxia	0	3	0	0	0	0	\N	0
1307440824	0	🐥	0	9	0	0	0	1	\N	0
1637025078	0	ian	0	27	0	0	0	62	\N	0
5189359528	0	gracie, m.	0	515	0	0	9.12999999999995	12862	\N	0
1820230788	0	nola	0	91	0	0	0	1	\N	0
5998662530	0	ETHAN, L.	0	1	0	0	0	0	\N	0
6790796415	0	someoneee	0	1	0	0	0	2	\N	0
5296287865	0	oca	0	13	0	0	0	123	\N	0
5788612033	0	D. amoraa	0	27	0	0	0	70	\N	0
5567044422	0	ebiii	0	3	0	0	0	1	\N	0
5049351538	0	.	0	1	0	0	0	0	\N	0
6756691006	0	na🍍	0	0	0	0	0	96	\N	0
6648778847	0	zhiii	0	8	0	0	0	0	\N	0
1724294154	0	cece	0	1	0	0	0	0	\N	0
5469968764	0	𐂂. pajo, sama sama dut	12	301	0	0	197.84000000000003	156	\N	0
6702690402	0	ja	0	6	0	0	0	0	\N	0
6049693587	0	gwen	0	1	0	0	0	0	\N	0
6929561013	0	gatra	0	2	0	0	0	0	\N	0
1608684112	0	ap yh	0	3	0	0	0	73	\N	0
1615746932	0	dasha loanjing	0	2	0	0	0	42	\N	0
1955066882	0	αñne	0	10	0	0	0	91	\N	0
7121520839	0	><	0	13	0	0	0	4	\N	0
2001293737	0	.	0	2	0	0	0	0	\N	0
6462422972	0	Gaby.	0	8	0	0	0	0	\N	0
5848904510	0	el	0	3	0	0	0	0	\N	0
5065291336	0	jjoxav	0	24	0	0	40	351	\N	0
5240145673	0	𝖃𝖊𝖑	0	2	0	0	0	1	\N	0
1875563934	0	gndtzz	0	7	0	0	0	1	\N	0
1244750119	0	tra	0	205	0	0	0	0	\N	0
1661305238	0	adelia	0	277	0	0	36	53	\N	0
1868019304	0	💐	0	2	0	0	0	5	\N	0
2134664123	0	ãrscyllaä	0	2	0	0	0	2	\N	0
1880604060	0	Annalyn	0	425	0	0	65.2899999999994	608	\N	0
6354116070	0	kio	0	3	0	0	0	11	\N	0
5889985031	0	?	0	0	0	0	0	0	\N	0
6944619746	0	✧⃝⛧𝐛𝐲𝐫𝐢	0	2	0	0	0	2	\N	0
5107673125	0	nata	0	1	0	0	0	0	\N	0
1462572346	0	fuck	0	2	0	0	0	0	\N	0
6021338687	0	Thalassa Feyya	4	40	0	0	2288.3700000000003	654	\N	0
1421959667	0	syifAaa💤💤	0	328	0	0	964.17	68	\N	0
6449485745	0	Gifari	0	1	0	0	0	0	\N	0
5586256259	0	var.	0	15	0	0	0	0	\N	0
6720854995	0	D	0	1	0	0	0	0	\N	0
1724215426	0	• isabella	0	2	0	0	0	3	\N	0
5147729120	0	𝐉𝐞𝐣𝐞 #suka garto	0	2	0	0	0	3	\N	0
6291707993	0	𝒛𝒆𝒍𝒊𝒏𝒆'𝒔	0	1	0	0	33.79	0	\N	0
1292416356	0	a	0	5	0	0	0	4	\N	0
1745533640	0	dess	0	329	0	0	0	4	\N	0
5374238021	0	susah	0	2	0	0	0	13	\N	0
6257642267	0	kiyo	0	1	0	0	0	1	\N	0
5678367461	0	💎 sain	0	18	0	0	0	30	\N	0
5469263787	0	y	0	12	0	0	0	0	\N	0
1831959651	0	xᴄʟᴏᴜ	0	1	0	0	0	10	\N	0
5212783305	0	a	0	126	0	0	415.7700000000001	225	\N	0
1489805687	0	izra	0	16	0	0	0	77	\N	0
6237322816	0	RmdhanForYou	0	1	0	0	0	7	\N	0
1603164220	0	k	0	167	0	0	5220.37	47	\N	0
1606903769	0	alvaryan	0	4	0	0	0	0	\N	0
2028586896	0	imel	0	2	0	0	0	1	\N	0
814549823	0	saint	0	17	0	0	0	2	\N	0
1832760443	0	Achyesa. ꦲꦼꦩ꧀ꦥꦸₑₛᵩ	0	2	0	0	0	4	\N	0
5241260654	0	Yunna	0	11	0	0	0	4	\N	0
2011381918	0	shellea	0	114	0	0	71.7	224	\N	0
6779475150	0	raja iblis	0	52	0	0	6.45	9	\N	0
1385034655	0	pieeeᯅ🧌	0	411	0	0	441.16999999999985	17336	\N	0
1814034944	0	biell	8	965	0	0	12392.300000000003	1162	\N	0
1657342277	0	Rama	0	136	0	0	0	93	\N	0
1827178573	0	som ay	0	28	0	0	0	18	\N	0
1941488541	0	asya💤	2	20	0	0	567.8199999999996	1640	\N	0
6845703977	0	vaultboy	0	12	0	0	0	11	\N	0
1899310636	0	Catherine, A.	10	1058	0	0	4460.249999999999	437	\N	0
6493742291	0	seno	0	1	0	0	136.46	1	\N	0
6868005235	0	￭ ⾕ ฺ næra 🧣 ‌ ⨳	0	3	0	0	0	0	\N	0
6925821207	0	°. Mentari Elysia.	0	4	0	0	0	2	\N	0
5181531315	0	L a	0	13	0	0	0	0	\N	0
422825241	0	♡ . 𐙚	5	131	0	0	1297.9500000000003	28	\N	0
6139621964	0	delsa' ʀʀᴡ ᴛᴢᴄᶜʳⁱ	0	3	0	0	0	3	\N	0
6964929862	0	ᴶ李,珍妮	0	0	0	0	0	1	\N	0
6635401233	0	ʀʀᴡ sha	0	1	0	0	0	0	\N	0
5230853920	0	netnot	0	104	0	0	8.800000000000011	941	\N	0
5793993209	0	sera	0	8	0	0	0	8	\N	0
1740914222	0	kenn	0	28	0	0	397.54	180	\N	0
1831923969	0	Bey	0	1	0	0	0	0	\N	0
2127323130	0	Jazz is a little fairy' 🦋💭	0	7	0	0	0	100	\N	0
6050346747	0	Chester A.	0	3	0	0	0	0	\N	0
5393054633	0	Aryasa.	0	8	0	0	0	3	\N	0
5304226386	0	𓆝 𓆟 pitaa 𓆝 𓆟	0	5	0	0	0	95	\N	0
6037003659	0	🦕	0	49	0	0	0	32	\N	0
6151527067	0	d	0	42	0	0	0	3	\N	0
5294391488	0	Haechan	0	1	0	0	0	0	\N	0
1346763941	0	a	0	0	0	0	0	4	\N	0
1394672940	0	Airynè logout	0	2	0	0	0	7	\N	0
6205432598	0	⸸	0	25	0	0	0	10	\N	0
1451420887	0	salvatore	0	1	0	0	0	0	\N	0
1909230281	0	yfi	0	1	0	0	0	1	\N	0
6528981636	0	Maddie R. slowrespon	0	3	0	0	0	0	\N	0
5942432086	0	nisy	0	17	0	0	200.88	189	\N	0
1854082295	0	ion	0	17	0	0	0	29	\N	0
6373617356	0	härˈmōnēəs	0	1	0	0	0	0	\N	0
5802876075	0	ëran	0	59	0	0	1.3599999999999994	44	\N	0
6271291360	0	Jeya	0	2	1	0	0	2	\N	0
6947730452	0	Zack	0	30	2	0	5	72	\N	0
5593081178	0	bebell	0	1	0	0	0	2	\N	0
6054411926	0	ly	0	1	0	0	0	0	\N	0
1849731193	0	karen //	0	12	0	0	0	63	\N	0
5906661464	0	Prayyy	0	1	0	0	0	0	\N	0
5405942558	0	⋅˚₊‧ ୨ s.lillianné, ᬦ.	0	4	0	0	0	0	\N	0
5051520881	0	Xiangling	0	573	0	0	779.69	1480	\N	0
5026235036	0	Samael	0	3	0	0	0	0	\N	0
5388203556	0	johes	0	36	0	0	0	106	\N	0
1902765765	0	◦♡°Mιℓкѕнαкє°♡◦	0	25	0	0	0	6	\N	0
6130209409	0	.	0	20	0	0	0	1	\N	0
6107987407	0	ayyara	0	2	0	0	0	1	\N	0
5985355175	0	cici ҽlsa ❄️	0	4	0	0	460	3	\N	0
5224788726	0	carissa	0	6	0	0	0	11	\N	0
5645495100	0	Arvhie egl	5	12	0	0	2231.4399999999996	19	\N	0
6924121832	0	KAJEHA	0	74	0	0	0	10	\N	0
2022641936	0	Devin	0	1	1	0	0	0	\N	0
1949412890	0	malv emosi	0	1	0	0	0	0	\N	0
1952707601	0	Mil	0	33	0	0	2487.620000000001	73	\N	0
6477141706	0	Gabby 244crewvk 𝟷𝙱𝙻𝙽𝚅𝙺 𝗢𝗣𝗟𝗜𝗡𝗞𝗢𝗩𝗞	0	1	0	0	0	0	\N	0
6332163988	0	Nayesha Arshella🫧	0	6	0	0	0	3	\N	0
6333234850	0	Keyara	0	2	0	0	0	0	\N	0
5444035677	0	ust. Anesh	0	4	0	0	0	1	\N	0
5546715639	0	ndyy	0	1	0	0	0	0	\N	0
1995267490	0	Gtw gbt.	0	46	0	0	0	15	\N	0
6258108439	0	ramaeyl	0	2	0	0	0	0	\N	0
1772238764	0	Ajay	0	1	0	0	0	0	\N	0
5469492585	0	Reo	0	6	1	0	0	41	\N	0
1844699553	0	harry's gf	0	458	0	0	0	85	\N	0
1908858529	0	zZzzZidane :0	0	5	0	0	163.4	11	\N	0
5074355586	0	🤍	0	320	0	0	5.23	820	\N	0
1238431364	0	arga	0	27	0	0	1650.1899999999816	177	\N	1
1317129199	0	aya blubup	0	1	0	0	0	0	\N	0
5904941802	0	gecko. Fsr donkkl	0	1	0	0	0	0	\N	0
6618910499	0	al	0	2	0	0	0	0	\N	0
5418589106	0	whis	0	280	0	0	151.94000000000005	685	\N	0
6172758776	0	M	0	2	0	0	0	0	\N	0
1826058504	0	Marcello.	0	1	0	0	57.35	3	\N	0
1340987655	0	booys	0	1	0	0	0	0	\N	0
7109307169	0	Malesub	0	7	0	0	0	1	\N	0
5547775372	0	letnan	0	1	0	0	0	2	\N	0
6422048183	0	aldo sama gege dni ew perek 🤏🏻	4	231	0	0	763.7400000000001	224	\N	0
5728933383	0	poll	0	72	0	0	982.34	175	\N	0
1827971304	0	elelelelelel	0	79	0	0	0	338	\N	0
5297237759	0	AN_Deva.	0	16	0	0	0	1	\N	0
5973138065	0	eva	0	2	0	0	0	30	\N	0
6211889622	0	shereenn	0	18	0	0	0	37	\N	0
2062592505	0	Mikaella Joe	0	1	0	0	0	0	\N	0
1778922583	0	A. kalAshley	0	3	0	0	0	0	\N	0
6796232860	0	carl	0	14	0	0	0	0	\N	0
5029673025	0	zaa	0	4	0	0	0	0	\N	0
5359417358	0	Tipan 🥨	0	0	0	0	0	2	\N	0
1906087293	0	Cgaëlle. mmm	0	1	0	0	0	6	\N	0
5141026010	0	delbert	0	2	0	0	0	0	\N	0
1447211263	0	Abaaang	0	1	0	0	0	1	\N	0
1886467021	0	gedsel	0	41	0	0	0	1	\N	0
5602191914	0	c	0	102	0	0	0	153	\N	0
1614030545	0	pacar ku(soon)	0	1	0	0	0	1	\N	0
5141600937	0	Jisa	0	11	0	0	0	4	\N	0
6255292529	0	jejey	0	7	0	0	0	0	\N	0
1829054156	0	rian	0	1	0	0	0	0	\N	0
1601792175	0	⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣	0	28	0	0	0	1	\N	0
6586922471	0	K'Evertine.	0	1	0	0	0	0	\N	0
6557615406	0	𝐂harlotte	0	3	0	0	0	0	\N	0
6885041516	0	Corn	0	2	0	0	0	1	\N	0
5882336151	0	Yas	0	1	0	0	6.79	8	\N	0
5145484504	0	Lionél J.	0	24	0	0	448.98000000000013	89	\N	0
1716240606	0	Sha💥	0	1	0	0	0	1	\N	0
7100825329	0	vinchie	0	1	0	0	0	1	\N	0
7063380270	0	el | jksel pride	0	6	0	0	0	0	\N	0
6131545934	0	Zahra	0	8	0	0	0	1	\N	0
7058994839	0	Tiwastak	0	0	0	0	0	0	\N	0
5617792502	0	Ghyna	9	68	0	0	39276.749999999985	11519	\N	0
5630740847	0	Omg	0	5	0	0	0	3	\N	0
1998433122	0	lvaa	0	4	0	0	0	1	\N	0
5876390215	0	yiel	0	9	0	0	0	5	\N	0
5120691673	0	yOuRrA	0	146	0	0	944.73	524	\N	0
6097432644	0	.	0	0	0	0	0	0	\N	0
5624948058	0	🍒	0	21	0	0	317.95	1210	\N	0
1367552180	0	-	0	2	0	0	0	0	\N	0
6729459381	0	Pukis Matcha Latte	0	7	0	0	0	4	\N	0
1617455090	0	Adelaïde E.	0	2	0	0	0	14	\N	0
6084855655	0	naraya	0	100	0	0	0	99	\N	0
6756496408	0	pai	0	2	0	0	0	5	\N	0
6440815990	0	lopyu	0	28	0	0	0	5	\N	0
1519128884	0	Gwen	12	123	0	0	3147.1300000000006	1099	\N	1
5289985578	0	ja	0	2	0	0	0	29	\N	0
2063756829	0	joji fushiguro	0	11	0	0	0	0	\N	0
1420267684	0	captain mile👩🏻‍✈ @etheralkiss	0	11	0	0	0	75	\N	0
5936123232	0	Veronica.	0	24	0	0	0	105	\N	0
6155480102	0	38	0	1	0	0	0	0	\N	0
1864156225	0	luna 𝔞𝅦🇬🇩	0	9	0	0	17.22	13	\N	0
2048373226	0	Charlie mau jd Kristoff demi Anna	0	32	0	0	230.51	2665	\N	0
2006032258	0	luna	0	7	0	0	0	0	\N	0
6595511318	0	keep ch	0	2	0	0	0	1	\N	0
5192169991	0	ja	0	14	0	0	0	25	\N	0
1282505101	0	tiger	0	32	0	0	0	1	\N	0
1798272117	0	mirielle	0	13	0	0	0	3	\N	0
1288555228	0	🏌️	0	1	0	0	0	0	\N	0
5013955937	0	⁣⁣⁣⁣⁣⁣⁣⁣⁣margot K.	0	13	0	0	0	0	\N	0
1872584810	0	a	0	0	0	0	0	0	\N	0
6131232107	0	t12	0	9	0	0	0	8	\N	0
1895157417	0	GERALD	0	6	0	0	0	4	\N	0
5553348804	0	Kitt. mau jadi nemo 🫧	0	63	0	0	0	71	\N	0
6395279523	0	<Isabelle3! ...♥️	0	10	0	0	0	64	\N	0
5680766478	0	Leuz (inactv)	0	1	0	0	0	0	\N	0
6024360967	0	zëy	0	1	0	0	0	0	\N	0
1621382812	0	shenetta.	0	4	0	0	0	0	\N	0
6587797556	0	temenin gue, gue lagi gaa baik-baik aja	0	215	0	0	2.579999999999984	3707	\N	0
6772296193	0	ayu	0	15	0	0	0	50	\N	0
1693676296	0	Meera	0	262	1	0	0	417	\N	0
6719037068	0	🪐	0	56	0	0	0	1	\N	0
1379459752	0	nebulaAaaAaaAA🐈	0	1	0	0	0	0	\N	0
1291620281	0	ׅintan	0	30	0	0	10.799999999999997	7	\N	0
6819571385	0	ransha	0	18	0	0	435	1	\N	0
5251913147	0	caaxsy dystōpia.	0	23	0	0	0	2	\N	0
6377587233	0	Nayesha	0	68	0	0	0.8299999999999841	214	\N	0
1902326683	0	kiya	0	246	0	0	5	1963	\N	0
5132021946	0	Kaeel	0	1	0	0	0	0	\N	0
1331676871	0	Lan	0	8	0	0	0	17	\N	0
1594313003	0	Julian prajaswara.	0	82	0	0	0	91	\N	0
5423745386	0	aku teh cewe cok	0	12	0	0	0	3	\N	0
1694612195	0	sasira	0	4	0	0	0	0	\N	0
5103656121	0	𝙘𝙝𝙧𝙞𝙨𝙨𝙮	0	1	0	0	0	4	\N	0
6881863784	0	M	0	39	0	0	0	51	\N	0
5448323991	0	Nay	0	54	0	0	0	10	\N	0
5726983126	0	arin	0	1	0	0	0	0	\N	0
5065580774	0	Lily	0	1	0	0	0	0	\N	0
5006741173	0	vil	0	81	0	0	0	23	\N	0
5384134884	0	Shaena.	0	0	0	0	0	7	\N	0
1486354691	0	sasha	0	2	0	0	0	0	\N	0
6856526677	0	El'juragan purel	0	35	0	0	0	75	\N	0
1786237417	0	al	0	1	0	0	0	0	\N	0
6185534219	0	хуй	0	8	0	0	0	8	\N	0
6049566783	0	ㅤㅤ	0	1	0	0	0	0	\N	0
5400897464	0	esther	0	1	0	0	0	3	\N	0
1201723511	0	Jjeocha Mashezara	0	1	0	0	0	15	\N	0
5076032467	0	raz	1	122	0	0	5942.74	10281	\N	1
1430418035	0	Zzz	0	75	0	0	0	0	\N	0
5408655887	0	nurull	0	10	0	0	0	4	\N	0
6504401040	0	ata	0	17	0	0	0	31	\N	0
2104257687	0	Cella	0	5	0	0	0	9	\N	0
5390184633	0	￴v	0	101	0	0	7	76	\N	0
6191529177	0	Yuna	0	2	0	0	0	0	\N	0
1692294663	0	aca	0	50	0	0	125.80000000000001	165	\N	0
6469192138	0	ai	0	19	0	0	0	0	\N	0
5100575397	0	mi amor.	0	9	0	0	0	35	\N	0
6682070178	0	d	0	29	0	0	0	89	\N	0
5786923310	0	Kyo 🦭	0	18	0	0	0	9	\N	0
1671403881	0	El	0	33	0	0	0	10	\N	0
6141224766	0	acaaa 𐙚	0	2	0	0	0	7	\N	0
5379097292	0	kaykayii	0	0	0	0	0	0	\N	0
6609425733	0	Em	0	21	0	0	0	6	\N	0
6233712563	0	Sei	0	1	0	0	0	14	\N	0
5552990015	0	✿❀❀✿	0	125	0	0	0	16	\N	0
1082650264	0	Kaisar	0	228	0	0	753.5699999999999	6184	\N	0
6825890246	0	Arundayu F	0	5	0	0	0	8	\N	0
6018238068	0	Ruth, rest	0	104	0	0	301.39	14	\N	0
5521010890	0	Gaharu || ANAK UB CHAT GW DH	0	2	0	0	0	0	\N	0
2028731346	0	akiko.	0	3	0	0	0	0	\N	0
5986303921	0	naraa	0	1	0	0	0	0	\N	0
6200814204	0	m	0	3	0	0	0	0	\N	0
5720642450	0	dy	5	229	0	0	4429.039999999999	430	\N	0
1748755039	0	.	0	1	0	0	0	0	\N	0
1700196566	0	Cè dawei	0	4	0	0	0	0	\N	0
1665052398	0	niss :p	0	256	0	0	224	141	\N	0
6092166878	0	reo	0	5	0	0	0	0	\N	0
1425013049	0	eve	0	219	0	0	638.73	143	\N	0
7168864607	0	i	0	1	0	0	0	1	\N	0
5537392726	0	..	0	19	0	0	0	51	\N	0
5563989599	0	athur	0	6	0	0	0	0	\N	0
1508675203	0	ㅤㅤㅤ	0	542	1	0	5	6	\N	0
5774809175	0	૮Ꮚ ´͈ awkaye `͈꒱ა 𔘓	0	6	0	0	0	3	\N	0
1738301013	0	marcelino gio	0	2	0	0	0	1	\N	0
6524915010	0	2	0	7	0	0	0	1	\N	0
1358513769	0	Ta	0	12	0	0	0	2	\N	0
5644422712	0	jane #antifaker	0	0	0	0	0	0	\N	0
1392561536	0	.	0	103	0	0	0	2	\N	0
1666104103	0	Kate, inactive for a while.	0	0	0	0	0	1	\N	0
2133318927	0	Jennifer	0	3	0	0	0	0	\N	0
6377062145	0	Angelyn.	0	2	0	0	0	1	\N	0
2016285091	0	miwa	0	6	0	0	0	5	\N	0
6089601727	0	™	0	8	0	0	0	3	\N	0
6526667087	0	aime	0	0	0	0	0	0	\N	0
5504204993	0	r	0	6	0	0	0	6	\N	0
1176003518	0	Monroe, S.	0	4	0	0	0	2	\N	0
1959543029	0	??	0	240	0	0	545.01	277	\N	0
1677925749	0	dipxt	0	8	0	0	0	5	\N	0
1458579888	0	Secilla	0	0	0	0	250	1747	\N	0
5538525454	0	D	0	42	0	0	0	244	\N	0
6921325382	0	(+♡) 🫧゙ ֢ ⸝⸝ ᴘʜɪʟᴀᴅᴇʟᴇᴜsᴛᴀᴄᴇ ! *귀엽게* 🪷 ⟅ ׄ ±	0	1	0	0	0	1	\N	0
1747133554	0	V	0	13	0	0	0	3	\N	0
865515816	0	Random	0	2	0	0	0	3	\N	0
6061945163	0	ᴅƧʀ DHIKA	0	1	0	0	0	0	\N	0
1672983778	0	willy	0	9	0	0	0	1	\N	0
5335161329	0	m	0	42	0	0	0	12	\N	0
1417463115	0	anjani	0	35	0	0	0	14	\N	0
5823864153	0	yarel mabuk jeno	0	1	0	0	57.38000000000005	0	\N	0
5293900413	0	Tuscany	0	37	0	0	0	20	\N	0
5329580512	0	C L A	9	412	0	0	47.41000000000005	1168	\N	0
5247957722	0	Panggil chen	0	7	0	0	0	10	\N	0
2023806268	0	Saka Emiliano	0	3	0	0	0	114	\N	0
6179245266	0	chai loverra	0	3	0	0	65.15000000000022	13	\N	0
1229952524	0	A	0	76	0	0	0	1	\N	0
6613634086	0	Aca	0	251	0	0	9.769999999999982	14	\N	0
6854634394	0	miu 😍😍😍😍	0	27	0	0	0	712	\N	0
5257011313	0	52	0	451	1	0	5.300000000000182	32	\N	0
5513695611	0	.	0	4	0	0	0	0	\N	0
6016984233	0	V.	0	2	0	0	0	0	\N	0
5173444045	0	sachi	0	0	0	0	0	0	\N	0
5651909462	0	jjeye	0	4	0	0	0	0	\N	0
6333638280	0	Nevan.	0	3	0	0	0	10	\N	0
783548956	0	Ridwan	0	3	0	0	264.05	35	\N	0
5006398760	0	k/sia. Ichii	0	3	0	0	0	0	\N	0
6022394549	0	xeoshi	0	16	0	0	12	22	\N	0
5541507524	0	mirabel	0	2	0	0	0	20	\N	0
7104227408	0	jerpor	0	2	0	0	0	0	\N	0
6534473269	0	Bang riv.	0	3	0	0	0	0	\N	0
7080112626	0	ⱺω𐓣𝗂𝖾🌷.	0	3	0	0	0	0	\N	0
5355424536	0	Promise	0	2	0	0	0	2	\N	0
1818623241	0	micimoii	0	329	0	0	1449.9399999999998	3161	\N	0
6127069047	0	s	14	8	0	0	0	2	\N	0
6493257398	0	na	0	23	0	0	0	37	\N	0
6591480849	0	꒰୨୧◞ ...청아 — Shemima	0	3	0	0	0	1	\N	0
5068400399	0	t⍺ ⑅	0	1	0	0	0	0	\N	0
6545052133	0	ucii	0	7	0	0	0	2	\N	0
5864789757	0	killa	0	1	0	0	0	25	\N	0
6958047807	0	x	0	70	0	0	3.0100000000000016	74	\N	0
5290346807	0	lala	0	10	0	0	0	13	\N	0
7040276922	0	Lena	0	3	0	0	0	6	\N	0
1666473902	0	leaving	0	26	0	0	0	1	\N	0
1638126838	0	ca	0	4	0	0	0	4	\N	0
5358020988	0	Valeeaa	0	8	0	0	0	4	\N	0
6158421483	0	.	0	4	0	0	74.85	1	\N	0
1830791592	0	i, liz.	0	2	0	0	0	0	\N	0
1742156211	0	Raven	0	0	0	0	0	1	\N	0
5399090340	0	hima mood rn 📈📈	0	42	0	0	0	9	\N	0
5591899655	0	Rev	0	165	0	0	0	16	\N	0
6123164560	0	ֶָ🎀𓂃 ֶָ֢࣪	0	17	0	0	0	1	\N	0
6087986619	0	,	0	101	1	0	5	11	\N	0
6785501380	0	mayo	0	2	0	0	0	1	\N	0
5416656716	0	🧸🛌 𖦹 ࣪˖ ◂	0	65	0	0	0	66	\N	0
5758350775	0	ʀᴇɴɴ	0	1	0	0	0	1	\N	0
6026052531	0	2.32 pm	0	16	0	0	0	13	\N	0
6649789026	0	jihAn	0	3	0	0	0	0	\N	0
5291292369	0	A	0	39	0	0	0	19	\N	0
5238397203	0	paja	0	1	0	0	0	13	\N	0
6959171650	0	csw⁰⁴. arga	0	6	0	0	0	0	\N	0
1831735984	0	Pell	0	6	0	0	0	2	\N	0
1684905339	0	ayyin	0	0	0	0	0	0	\N	0
2089592432	0	faharu	0	2	0	0	0	1	\N	0
6246711064	0	Pieya S. 🪸 FSR	0	1	0	0	0	0	\N	0
1840173380	0	Sawawa Leovania.	0	18	0	0	0	233	\N	0
5387150406	0	ajiz	0	13	0	0	0	0	\N	0
2137990368	0	al	0	2	0	0	0	0	\N	0
5422011078	0	Bima	0	14	0	0	0	8	\N	0
969195088	0	GreenTea	0	3	0	0	0	136	\N	0
1786256217	0	Vɪɴ	0	9	0	0	0	92	\N	0
5653050969	0	A	12	1	0	0	1503.2800000000004	12	\N	0
1697497993	0	Anda	0	1	0	0	0	1	\N	0
6665746886	0	Aura	0	5	0	0	0	4	\N	0
5163756457	0	&	0	8	0	0	0	40	\N	0
5897753885	0	Yanwar	0	6	0	0	0	7	\N	0
1614496847	0	aca.	0	5	0	0	0	10	\N	0
5362449133	0	美しい水	0	10	0	0	0	62	\N	0
1919212074	0	azasa	0	39	0	0	1207.5	26	\N	0
1774852005	0	meysa	0	51	0	0	142	0	\N	0
1967523360	0	.	0	28	0	0	0	0	\N	0
5505132881	0	Sunshine	0	6	0	0	0	81	\N	0
5018389582	0	Vinna	0	5	0	0	0	164	\N	0
1727557391	0	moraaaaa	0	6	0	0	0	2	\N	0
1760950469	0	azov	0	1	0	0	0	0	\N	0
2087955705	0	Al	0	1	0	0	0	47	\N	0
5515125961	0	bielll loving mrklee	0	11	0	0	0	0	\N	0
6206462253	0	Michiko.	0	1	0	0	0	0	\N	0
1977804502	0	ayaw	0	2	0	0	0	0	\N	0
5184793926	0	Cathrine Reilley.	0	1	0	0	0	0	\N	0
1719399090	0	Stessie	0	22	0	0	0	10	\N	0
5153825648	0	ayass salima	0	1	0	0	0	0	\N	0
1788968374	0	AngellPranasya 🎀🎀🎀🎀	0	1	0	0	0	0	\N	0
5102695114	0	K.	0	4	0	0	0	98	\N	0
1350568881	0	Leaving	0	4	0	0	0	5	\N	0
1725132101	0	haura	0	36	0	0	0	0	\N	0
6228158232	0	reva	0	2	0	0	0	16	\N	0
2039201707	0	kavi	0	10	0	0	0	0	\N	0
5284104696	0	Jamias	0	0	0	0	0	0	\N	0
5311262324	0	Juhlan Qaid.	0	1	0	0	0	12	\N	0
1649037978	0	s	0	118	0	0	548.2699999999999	284	\N	0
6558900633	0	Odyyy	0	35	0	0	180.84	18	\N	0
1641492066	0	nana	0	119	0	0	237.07999999999998	1	\N	0
1298200277	0	chaesa	0	79	0	0	0	9	\N	0
5321234454	0	kinot pcr momin	0	1	0	0	0	0	\N	0
5384321205	0	Danian	0	14	0	0	76.42000000000013	8	\N	0
6612065411	0	chie	0	208	0	0	98.32999999999998	69	\N	0
6446470554	0	L RAWR🦖	0	5	0	0	0	32	\N	0
6302319610	0	Badut	0	0	0	0	0	1	\N	0
5024071415	0	Rael	0	1	0	0	0	4	\N	0
5060121495	0	M	0	114	0	0	0	15	\N	0
5724865076	0	.	0	31	0	0	0	3	\N	0
1856592498	0	zephyr	0	13	0	0	0	15	\N	0
6521425237	0	keziaa	0	4	0	0	0	0	\N	0
5202483680	0	bira T___T	0	11	0	0	0	39	\N	0
6435160634	0	s, khaivy.	0	28	0	0	0	0	\N	0
6275854961	0	memeii	0	7	0	0	1889	2	\N	0
6832071362	0	ana	0	0	0	0	0	0	\N	0
1775599866	0	liaa pengen nyepong	0	1	0	0	0	0	\N	0
6459526595	0	୨୧ . . valencia	0	23	0	0	0	14	\N	0
5552613762	0	Jemiueu	0	1	0	0	0	1	\N	0
2055289023	0	acc sfs	0	10	0	0	0	0	\N	0
6271592262	0	m	0	7	0	0	0	0	\N	0
6255094021	0	karin	0	13	0	0	0	35	\N	0
5634711795	0	cae	4	466	0	0	1163.7799999999988	667	\N	0
5472710211	0	daboy 🎧	0	26	0	0	50.28	85	\N	0
1808967261	0	Raidan	0	1	0	0	0	3	\N	0
5074910124	0	shaista	0	22	0	0	0	1	\N	0
6539281014	0	Justin	0	4	0	0	0	1	\N	0
5174397880	0	mrmyadose.	0	83	0	0	13.459999999999923	88	\N	0
1685988344	0	Br	0	3	0	0	0	8	\N	0
1267523027	0	Eulb	0	4	0	0	0	0	\N	0
5580837294	0	Escapism	0	4	0	0	0	3	\N	0
5926963885	0	naevaaa	0	1	0	0	0	2	\N	0
1170307241	0	G?	0	6	2	0	0	2	\N	0
5910214101	0	⋆ Est 2000, Seruni A. ⋆	0	3	0	0	0	4	\N	0
6899389334	0	cause	0	7	0	0	0	11	\N	0
5279917157	0	𖤝... Edrice [return @dHaerinKang to me]	0	148	0	0	0	62	\N	0
1446805387	0	Jo the kid	0	144	0	0	160.5	218	\N	0
5458061648	0	rayhan	0	16	0	0	0	0	\N	0
5865546853	0	Zephyr	0	0	0	0	0	0	\N	0
1259021727	0	Javie	0	94	0	0	0	149	\N	0
1698867662	0	yera	0	38	0	0	0	12	\N	0
5181879699	0	El's	1	148	0	0	7150.339999999998	280	\N	0
5952673599	0	ECA ʜᴀᴛᴀᴋᴇ ꭙ 𝙀𝙎𝙇𝙊𝙏	0	7	0	0	0	2	\N	0
6266529734	0	a	0	3	0	0	0	0	\N	0
6043190141	0	ᅠ	0	1	0	0	0	0	\N	0
6827045076	0	Alaitaa Azyuna	0	8	0	0	0	4	\N	0
1708134629	0	pii	10	2173	0	0	8341.45	2338	\N	0
5853326240	0	Abila S	0	2	0	0	0	0	\N	0
6737245217	0	CXD	0	17	0	0	0	5	\N	0
5901295166	0	Jo	0	9	0	0	0	4	\N	0
5426446688	0	serren	11	139	0	0	75.56999999999996	85	\N	0
6475946328	0	gwenn, A.	0	4	0	0	0	3	\N	0
1587919971	0	ㅤ	0	2	0	0	0	0	\N	0
1786760327	0	missie	0	453	0	0	337.21	174	\N	0
6915046179	0	J. Athar 𝑪𝒂𝒍𝒎𝒊𝒏𝑹𝒓	0	6	0	0	0	33	\N	0
1332312834	0	naravy	12	391	0	0	1135.9	963	\N	0
5550633643	0	b,	0	5	0	0	28.81	10	\N	0
6370378797	0	sound of scoups gf	0	22	0	0	0	2	\N	0
632766134	0	๑ cerr	0	0	0	0	0	0	\N	0
6236841367	0	OwL	5	398	1	0	18.899999999999295	975	\N	0
5483553279	0	.	0	10	0	0	1387.4799999999996	36	\N	0
1825124009	0	aje	0	2	0	0	0	1	\N	0
6187904651	0	sasa	0	8	0	0	0	0	\N	0
5202042314	0	Zeelysheé	0	13	0	0	15	0	\N	0
5804251387	0	katiya	0	5	0	0	0	1	\N	0
5492445767	0	victory	0	76	0	0	14.829999999999998	38	\N	0
2108438416	0	Atlànna	0	0	0	0	0	0	\N	0
1791740066	0	z99. naherA	0	1	0	0	0	0	\N	0
7129357630	0	V	0	1	0	0	0	0	\N	0
6348872313	0	cell	0	1	0	0	0	0	\N	0
5399456617	0	Laa	0	9	0	0	0	4	\N	0
6922094163	0	bi	0	2	0	0	0	0	\N	0
2107679234	0	Neneng	0	1	0	0	0	7	\N	0
5480750721	0	keyin	0	5	0	0	0	19	\N	0
6000284750	1	Morga Sipembalap.	2	189	0	0	3240.469999999999	208	\N	0
1676994594	0	Euntae. @EuntaeHwaang	0	14	0	0	0	18	\N	0
6109151534	0	🚩.zie' 𝐃Λ. 𝑺𝑵	0	17	0	0	0	186	\N	0
5242050567	0	dHizZieEe.	14	819	0	0	4303.349999999993	9735	\N	1
1299800179	0	el	0	31	0	0	0	16	\N	0
5700433196	0	agas	0	4	0	0	0	11	\N	0
1829541435	0	cinta cita ta	4	1249	0	0	401.0500000000002	505	\N	0
7066168726	0	satriaaaa	0	9	0	0	0	21	\N	0
5736851368	0	ʚɞ rijel de-noir.	0	7	0	0	0	11	\N	0
1436804645	0	nasywa #cnitcha	0	3	0	0	0	0	\N	0
5022783802	0	Raka	0	2	0	0	0	0	\N	0
6695943765	0	roraaa	0	0	0	0	0	0	\N	0
1908537062	0	𝐉 #prajabf	0	2	0	0	0	0	\N	0
5126269040	0	keira	0	59	0	0	641.15	112	\N	0
5653113877	0	Bee	0	9	0	0	0	63	\N	0
5371870997	0	Bracio	0	1	0	0	0	1	\N	0
5455863455	0	Callidora S.	0	0	0	0	0	20	\N	0
6961927177	0	Moniel. ✞	0	3	0	0	8.33	67	\N	0
1615735467	0	.za	0	77	0	0	0	22	\N	0
1982743580	0	Z.	0	5	0	0	0	4	\N	0
902249361	0	Reinald SmoothAzf	0	9	0	0	0	28	\N	0
5674300517	0	Vinn.	0	2	1	0	0	1	\N	0
5632545531	0	ez	0	219	0	0	6	1	\N	0
1229705870	0	Kiyotaka's student	0	10	0	0	0	7	\N	0
937763425	0	Haqi.	0	19	0	0	0	4	\N	0
6237241249	0	slsya	0	2	0	0	0	1	\N	0
6076600898	0	z	0	5	0	0	102	5	\N	0
1599283610	0	Abel Weshit	0	23	0	0	0	11	\N	0
1915936592	0	byashiena caveela.	0	1	0	0	0	2	\N	0
1679243568	0	gestara	0	15	0	0	0	0	\N	0
6897207429	0	jaegar 𝐑ᵈᵐ°	0	11	0	0	87.73	22	\N	0
5914727085	0	Dēva	0	31	0	0	1.6600000000000001	4	\N	0
6794287205	0	yesa	0	1	0	0	0	0	\N	0
6793525066	0	jo	0	16	0	0	0	92	\N	0
5954099264	0	arka	0	45	0	0	7	37	\N	0
6265670804	0	s‌ᴄ‌ғ ᴢ͢ᴇᴇ̷ᴍɪʟᴏᴜ pending	0	99	0	0	329.52	70	\N	0
5922916656	0	🐾	0	1	0	0	0	0	\N	0
6783783488	0	auraa	0	2	0	0	0	0	\N	0
5654075102	0	ayyaa	0	0	0	0	0	0	\N	0
6773162716	0	aelaa.	0	3	0	0	0	0	\N	0
1528809073	0	jessyana	3	8	0	0	2343.9399999999996	324	\N	0
6069340658	0	Isabelle	0	6	0	0	0	8	\N	0
6359622351	0	jiy	0	7	0	0	0	7	\N	0
2107473909	0	gyummybear	0	1	0	0	0	1	\N	0
6781824386	0	shaa	0	1	0	0	0	0	\N	0
1398185661	0	cya	0	229	0	0	718.6300000000001	480	\N	0
1248467054	0	Cia	0	25	0	0	0	22	\N	0
5578878506	0	rasya	0	4	0	0	0	1	\N	0
6680696587	0	dei	0	50	0	0	478	26	\N	0
6442150986	0	paii	0	1	0	0	0	0	\N	0
6081336889	0	j,connecting pler	0	2	0	0	0	0	\N	0
5666392122	0	yaaaa	0	0	0	0	0	2	\N	0
6154158499	0	𝐓𝐑≛𝐏𝐒 nazula	0	43	0	0	0	9	\N	0
6158209911	0	Musca	0	2	0	0	306.65	6	\N	0
5531589393	0	bukan naya	0	238	0	0	168.72999999999956	529	\N	0
1874941881	0	wy	0	18	0	0	0	0	\N	0
6448938404	0	shofiaaaaaa	0	1	0	0	0	0	\N	0
1842532905	0	ray	0	28	0	0	0	29	\N	0
5406228284	0	ran	0	8	0	0	0	7	\N	0
905086801	0	chuu ˃ᆺ ˂ 	0	32	0	0	0	179	\N	0
1816207494	0	who?!	0	5	0	0	0	1	\N	0
2127915558	0	yayaa	0	749	0	0	1402.88	339	\N	0
1930314690	0	αsα	0	83	0	0	0	8	\N	0
1798818025	0	kate	0	2	0	0	0	3	\N	0
6115370063	0	yoosi	0	2	0	0	0	19	\N	0
6755394562	0	Kim Taehyung	0	1	0	0	0	0	\N	0
6144094114	0	who's rea	0	22	0	0	154.08	1	\N	0
6744610908	0	abey	0	1	0	0	0	12	\N	0
5515224140	0	Æ. Lavencie Röséilaroe	0	145	0	0	0	13	\N	0
6322261028	0	Delva Adiò	0	3	0	0	0	3	\N	0
6477249057	0	d	0	6	0	0	0	8	\N	0
6338038603	0	Kaito.	0	2	0	0	0	0	\N	0
6191523188	0	HARU SACHIKO.	12	461	0	0	24060.34999999999	8654	\N	1
5132384646	0	Fad	0	1	0	0	0	5	\N	0
6203211552	0	🙊	0	0	0	0	0	85	\N	0
1445378502	0	El	0	11	0	0	0	7	\N	0
5212390215	0	Jeanna	0	8	0	0	0	0	\N	0
6351795423	0	rivalxet	0	0	0	0	0	0	\N	0
6461150516	1	rei	0	35	0	0	0	0	\N	0
1610769375	0	𝐎rléanna	0	5	0	0	0	1	\N	0
1060076380	0	Y	0	44	0	0	0	90	\N	0
6560328680	0	frdoni	0	17	0	0	0	12	\N	0
1710861688	0	re	10	489	0	0	2498.140000000002	14027	\N	1
5682798268	0	arel @arelialionel	0	55	0	0	5	36	\N	0
7042715221	0	Shyeren.	0	26	0	0	0	13	\N	0
6003960465	0	Asya	0	53	0	0	1579.47	1128	\N	0
1334955345	0	airin > rest	0	3	0	0	0	0	\N	0
5345747966	0	Atp	0	11	0	0	0	18	\N	0
5784559767	0	Ezra.	0	88	0	0	0	531	\N	0
1816305075	0	s ִֶָ˚.	1	241	0	0	2787.9199999999996	1230	\N	0
2082750243	0	Ms. Na LOVESSS DAY6 KYAH ❣️	0	27	0	0	50.05	474	\N	0
5739184266	0	jenandra	9	372	0	0	4.199999999999989	9	\N	0
1739280138	0	ojap	0	11	0	0	0	6	\N	0
6902124741	0	acey	0	2	0	0	0	0	\N	0
5013292532	0	agas	0	3	0	0	0	6	\N	0
1908392135	0	m	0	2	0	0	0	0	\N	0
1687621916	0	R.grenna💐	0	4	0	0	0	0	\N	0
1108841828	0	anna	0	2	0	0	0	2	\N	0
5930790201	0	hema	0	1	0	0	0	0	\N	0
5955680829	0	J	10	181	0	0	541.1400000000001	190	\N	0
6783564186	0	𝕺ktaviō Ãlgarvē	0	1	0	0	0	0	\N	0
5680554147	0	jou	5	65	1	0	1571.89	133	\N	0
2065763157	0	cipa, as your girlfriend	0	0	0	0	0	1	\N	0
1252711695	0	cy	0	66	0	0	0	0	\N	0
6000254406	0	vwxyz	0	31	0	0	0	2	\N	0
5142202677	0	ea	0	2	0	0	0	2	\N	0
5380062357	0	meyi currently busy loving errol	0	22	1	0	185.78000000000003	117	\N	0
6395953348	0	𝑜𝒻 .. gypsyy	0	1	0	0	0	0	\N	0
1755466225	0	zia♧	0	3	0	0	0	0	\N	0
6421182530	0	avs. Ek 🅰️ L 🚮 🆒️ drpw	0	4	0	0	0	0	\N	0
5552950573	0	Sari	0	0	0	0	0	0	\N	0
5395138536	0	Anie! seneng banget cuyy	5	57	0	0	0	619	\N	0
6802885997	0	C	0	13	0	0	0	0	\N	0
6478845722	0	m	0	0	0	0	0	0	\N	0
5739359648	0	pabe nxr	0	6	0	0	0	2	\N	0
6408078501	0	aca sakit katanya	0	2	0	0	0	0	\N	0
5647477782	0	Flauwe.	0	3	0	0	0	1	\N	0
1484566963	0	Kajova Anneth	0	116	0	0	5	1848	\N	0
5472576042	0	Atlas ‡	0	6	0	0	0	17	\N	0
1843663696	0	arbiel	0	78	0	0	1325.6000000000001	175	\N	0
1926229295	0	🗯️	0	24	0	0	0	14	\N	0
1804383021	0	Faldana	0	1	0	0	0	0	\N	0
1621324644	0	4u	0	6	0	0	0	3	\N	0
1420061743	0	notfear	0	1	0	0	0	2	\N	0
5077121641	0	Mell	0	0	0	0	0	0	\N	0
5650266034	0	saa	0	1	0	0	0	0	\N	0
6443122235	0	tweetiny	0	2	0	0	0	1	\N	0
1834156814	0	apa ya	0	15	0	0	0	95	\N	0
6905704857	0	𝐓𝐑≛𝐏𝐒 ` vey	0	4	0	0	0	0	\N	0
1915697030	0	nana not nana	0	463	0	0	9.400000000000006	2720	\N	0
853391167	0	ajet	0	2	0	0	0	1	\N	0
5577053852	0	910. Resha	0	1	0	0	0	0	\N	0
5779705492	0	chéri.	0	0	0	0	0	0	\N	0
5213997133	0	theo (taylor's version)	0	24	0	0	0	0	\N	0
6314267211	0	an	0	55	0	0	265	30	\N	0
6873142965	0	Ayii	0	6	0	0	500	32	\N	0
1863280069	0	ale	0	132	0	0	0	3	\N	0
1888240296	0	Sadrine	0	11	0	0	0	0	\N	0
6015404530	0	Lavina	12	178	0	0	46.509999999999934	197	\N	1
6660221846	0	Tita	0	163	0	0	0	58	\N	0
6288236534	0	ega minaj	0	1	0	0	0	0	\N	0
5189083858	0	Nadline	0	1	0	0	0	11	\N	0
6287034117	0	meyy	0	5	0	0	0	1	\N	0
1427096418	0	L	0	9	0	0	0	1	\N	0
5770973118	0	.	0	13	0	0	0	0	\N	0
1757326558	0	y	0	1	0	0	0	0	\N	0
1801968811	0	dara	0	221	0	0	1258.05	0	\N	0
818122592	0	jeka	2	216	0	0	919.3699999999998	356	\N	0
1975448144	0	.	0	5	0	0	0	2	\N	0
6950383545	0	Yaya	0	2	0	0	0	1	\N	0
6712573754	0	Nadhira	0	16	1	0	456.90999999999997	189	\N	0
5250683676	0	Gal	0	1	0	0	0	0	\N	0
5896167666	0	shadin	0	5	0	0	0	1	\N	0
1319797301	0	nayayaya	0	182	0	0	0	14	\N	0
1764293121	0	Malio	0	15	0	0	100	31	\N	0
6032399069	0	j	11	2180	0	0	5.4999999999972715	1322	\N	0
5955244027	0	a	0	7	0	0	3211.14	2254	\N	0
6071109926	0	ria, Sabar Muter.	0	43	0	0	0	187	\N	0
5080088590	0	Carolline pt.2	6	95	0	0	147.11	119	\N	0
1780771201	0	mill	0	10	0	0	0	0	\N	0
6931729263	0	bal	0	3	0	0	0	0	\N	0
2038176253	0	￴ ￴nnm	0	12	0	0	0	0	\N	0
6363868649	0	katchan	0	10	0	0	345.63	31	\N	0
6531456705	0	mClfrey	0	0	0	0	0	19	\N	0
1811778347	0	a	0	5	0	0	0	27	\N	0
2057574567	0	pie	0	3	0	0	0	2	\N	0
1398963492	0	ᴅᴀɴᴢ	0	0	0	0	0	2	\N	0
5442192547	0	K	0	25	0	0	9.440000000000001	1	\N	0
5630920564	0	ayaa	0	1	0	0	0	0	\N	0
5295661207	0	pramasta z.veust	0	71	1	0	665.2299999999999	153	\N	0
1840394893	0	cici	0	5	0	0	0	0	\N	0
6032780266	0	rei	0	3	0	0	0	19	\N	0
5386631327	0	railey gomen	0	418	0	0	10.940000000000001	130	\N	0
6283743154	0	Al	0	16	0	0	0	13	\N	0
6305292935	0	zian	0	6	0	0	0	12	\N	0
5030870999	0	Almonate	0	5	0	0	200	22	\N	0
6348359145	0	zac	0	14	0	0	0	1	\N	0
1913615452	0	𝐊𝐚𝐭𝐡	0	5	0	0	156	1	\N	0
1868299228	0	rest j5z sencaz 🇯🇪	0	401	1	0	0.35000000000002274	57	\N	0
6173562669	0	adhina	0	6	0	0	0	24	\N	0
6118471926	0	0%	0	0	0	0	0	0	\N	0
6990646290	0	𝐓𝕺𝐑𝐒 || aènaa	0	1	0	0	0	0	\N	0
6876786862	0	helena	0	1	0	0	0	0	\N	0
6371173208	0	fᵴr. Killian	0	2	0	0	0	0	\N	0
1838540072	0	oca.	14	3	0	0	1273.13	20	\N	0
1842334756	0	N a k a m o t o	0	37	0	0	0	113	\N	0
1882545968	0	acayyy	0	1	0	0	0	1	\N	0
6118653550	0	kàsh.	0	29	0	0	0	321	\N	0
873475950	0	Ev van	0	1	0	0	0	0	\N	0
5540246832	0	ryxa	0	52	0	0	0	5	\N	0
5646690690	0	karalace soju	0	5	0	0	0	3	\N	0
1957999206	0	Athalla	0	0	0	0	0	0	\N	0
5097831542	0	sasa	11	198	0	0	35653.854999999996	22796	\N	1
5360241972	0	المنوره	0	0	0	0	0	4	\N	0
6138179438	0	kyl	0	17	0	0	358.2899999999996	66	\N	0
1613241026	0	Winnie	0	2	0	0	0	0	\N	0
1830641847	0	Saintly 🐰	0	107	0	0	0	14	\N	0
6433566251	0	.	0	1	0	0	0	0	\N	0
1237286278	0	𝐓he 𝐉ade	0	3	0	0	0	4	\N	0
6231987617	0	jorsie	0	0	0	0	0	0	\N	0
1977295270	0	Ayomi	0	3	0	0	0	42	\N	0
1782307420	0	chelle. @ryuyjin on offer!	0	3	0	0	0	0	\N	0
1650869616	0	pyca hyawyeowieiw	0	8	0	0	0	1	\N	0
1828709904	0	alen	0	21	0	0	0	75	\N	0
6739666754	0	yukii	0	3	0	0	0	3	\N	0
6650377374	0	n	0	13	0	0	26.87	10	\N	0
1723498632	0	bianca	0	56	0	0	0	76	\N	0
6079961391	0	n. Yoel	0	4	0	0	0	1	\N	0
6414862832	0	green obsessed!	0	3	0	0	0	4	\N	0
6805323061	0	i	0	0	0	0	0	0	\N	0
6040878519	0	M	0	5	0	0	0	11	\N	0
5180668155	0	˚ʚ haechan's love taker, hesa. dni	0	0	0	0	0	3	\N	0
5189950561	0	v	0	3	0	0	0	0	\N	0
5154325075	0	Varel 822bogs🇰🇳🇩🇴	0	3	0	0	0	0	\N	0
1789546313	0	mpiii	0	21	0	0	2118	4	\N	0
5303907805	0	pian suka cilor	0	2	0	0	0	1	\N	0
7004899972	0	arnavian S.	0	1	0	0	0	1	\N	0
5026960739	0	ei	0	1	0	0	0	0	\N	0
5981024645	0	Bastian	0	3	0	0	0	0	\N	0
5971644596	0	ѕµѕτ Hazel Dafier 𝑖𝑛𝒉𝑜𝑠 || drxt³	0	5	0	0	0	30	\N	0
5398469904	0	Elzoave	0	1	0	0	0	0	\N	0
5341730868	0	Rinn. limit	0	4	0	0	0	187	\N	0
2020540314	0	kaleya	0	7	0	0	0	24	\N	0
1707918581	0	Reree	0	2	0	0	0	1	\N	0
5657577051	0	LA	0	2	0	0	174.77	27	\N	0
5459196285	0	Dayne	0	3	0	0	0	36	\N	0
5225676772	0	kia	0	12	0	0	0	1	\N	0
6145285792	0	kall	10	194	2	0	5886.000000000001	220	\N	0
5540980360	0	Aevy	7	16	1	0	41.8	111	\N	0
5008309910	0	.	0	2	0	0	0	0	\N	0
1572780566	0	eyaa	0	25	0	0	170	71	\N	0
6683682226	0	ayaa	0	4	0	0	0	9	\N	0
5712246045	0	1975	0	7	0	0	0	122	\N	0
6932864309	0	g	0	42	0	0	0	0	\N	0
5456519235	0	Elios.	0	6	0	0	0	1	\N	0
1742736006	0	quintessa	0	97	0	0	0	111	\N	0
6152558369	0	a	0	7	0	0	0	7	\N	0
6152765951	0	jénara	0	29	0	0	23.58	24	\N	0
6529207369	0	casey	0	2	0	0	0	4	\N	0
1074193448	0	r	0	4	0	0	0	7	\N	0
6074783542	0	die	0	2	0	0	0	4	\N	0
2130335272	0	ꕮ𝅄 NayESSHAA (♡)	0	19	0	0	0	1	\N	0
5701630606	0	Noyaaa	0	25	0	0	0	61	\N	0
1939670042	0	Agaresh V.	0	0	0	0	0	0	\N	0
6305985996	0	s	0	12	0	0	0	3	\N	0
6898151339	0	elle ratu iblis	0	7	0	0	0	3	\N	0
5188626485	0	Abina.	0	10	0	0	0	4	\N	0
5788747163	0	ra	0	131	0	0	9.719999999999999	0	\N	0
5953120754	0	허윤진, belva🍂	0	1	0	0	0	0	\N	0
1749317412	0	𝑴𝒆𝒙	0	4	0	0	0	13	\N	0
5220779502	0	Mauda	0	11	0	0	0	5	\N	0
5158356498	0	fiya	14	143	0	0	2591.729999999997	320	\N	1
954703410	0	shaniuniuu	0	28	0	0	0	4	\N	0
6800726082	0	shouxue on twit @yoshefaala	0	3	0	0	0	0	\N	0
5453874781	0	yel	0	13	0	0	0	18	\N	0
6201861635	0	feby	0	1	0	0	0	2	\N	0
5835426332	0	.	0	3	0	0	0	0	\N	0
1889633636	0	Jake's Love Machine, Dara.	0	2	0	0	0	0	\N	0
5283697923	0	khiel	0	2	0	0	0	0	\N	0
5585821532	0	Kys	0	1	0	0	0	0	\N	0
5383539864	0	Riri	0	152	0	0	0	167	\N	0
5129779483	0	︎︎︎	0	72	0	0	0	45	\N	0
5944030418	0	....	0	29	0	0	0	52	\N	0
1970942530	0	azaalea	12	183	0	0	83	14	\N	0
1076185277	0	amaa	0	3	0	0	99.86	200	\N	0
740853585	0	fia	0	5	0	0	0	0	\N	0
6702442718	0	Luffiaa's.	0	6	0	0	0	2	\N	0
6283646788	0	Clarissa	0	43	0	0	0	223	\N	0
5444000531	0	jevanne.	0	2	0	0	0	0	\N	0
6417058415	0	naya	0	7	0	0	63	9	\N	0
2096980704	0	𐙚 αvαα 😛😛	0	2	0	0	0	0	\N	0
5917760361	0	buuuuuLan	0	8	0	0	0	16	\N	0
1313598142	0	jn	0	67	0	0	176.59	88	\N	0
1733785604	0	nara	0	2	0	0	0	3	\N	0
1897719960	0	je	0	2	0	0	0	16	\N	0
5958958944	0	leanna	0	36	0	0	13.129999999999995	274	\N	0
5562674087	0	dirtiest angel, keenan 👱🏻‍♀️🪄	0	8	0	0	0	0	\N	0
5858332293	0	Suji	0	558	0	0	20.390000000000327	100	\N	0
5716336105	0	ressa	0	20	0	0	0	25	\N	0
5922989221	0	raka	8	32	0	0	56.91	26	\N	0
5845944709	0	westcoast choppa	0	3	0	0	0	3	\N	0
6259223377	0	:v	0	2	0	0	0	0	\N	0
6961326205	0	yow	0	44	0	0	0	0	\N	0
5581498179	0	419. sasa.	0	2	0	0	0	5	\N	0
1954171262	0	Esel	0	13	0	0	490.25	303	\N	0
6997421259	0	Mauve 🤎	0	1	0	0	0	0	\N	0
1651741973	0	Jeje	0	619	0	0	217.08999999999983	3044	\N	0
6712218630	0	avell	0	54	0	0	162.39000000000001	514	\N	0
5030345227	0	dinnn	0	62	0	0	0	258	\N	0
1862737132	0	abe🩰🎧	0	11	0	0	0	3	\N	0
1883177676	0	ㅤRubby.	0	34	0	0	3620	161	\N	0
5068356017	0	nanad	0	1	0	0	0	3	\N	0
5206072636	0	lvr ʀʀᴡ	0	4	0	0	0	21	\N	0
6930993360	0	Grayone	0	2	0	0	0	6	\N	0
5301560634	0	Maribēth K.	0	0	0	0	0	0	\N	0
1911289667	0	sharmine	7	2295	0	0	2312.57	3083	\N	1
2071052581	0	phi yorichi	8	148	0	0	-0.5600000000000023	393	\N	0
1539654753	0	ㅤ	0	535	0	0	0	101	\N	0
1677793755	0	.	0	44	0	0	0	3	\N	0
5610701413	0	~	0	1	0	0	209.64	9	\N	0
6620809145	0	Nozz	0	4	0	0	0	4	\N	0
6949534889	0	anaa	0	2	0	0	0	0	\N	0
1842762879	0	ㅤㅤ	0	1	0	0	0	0	\N	0
1781723236	0	roki	0	1	0	0	0	0	\N	0
5777904047	0	Mahiro Baskara	0	11	0	0	0	3	\N	0
1944475234	0	Arunika.	0	1	0	0	0	0	\N	0
1834731642	0	chesa	0	1	0	0	0	1	\N	0
5615112174	0	roronoa	0	2	0	0	0	6	\N	0
1549526640	0	Han	0	1	0	0	0	10	\N	0
5928960800	0	Abiezer Ethan.	0	138	0	0	7.139999999999986	0	\N	0
5920419861	0	bitey	0	0	0	0	0	0	\N	0
6666985810	0	Marshall.	0	0	0	0	0	24	\N	0
1114794499	0	Lovä Badut	0	1	0	0	0	0	\N	0
5394136611	0	narraAa ᶻ 𝗓 𐰁	0	19	0	0	0	0	\N	0
5688594544	0	Vackim	0	4	0	0	0	24	\N	0
6300931335	0	ᴢᴏᴇʏʏ⛧	0	8	0	0	0	15	\N	0
5550177151	0	byze	0	5	0	0	0	0	\N	0
5119331472	0	ini fayee	0	0	0	0	68.01	5	\N	0
5777636344	0	Mirham	0	42	0	0	215.48000000000002	365	\N	0
6627449885	0	.	0	64	0	0	1.0100000000000193	21	\N	0
6069398235	0	Cilus skibidi sigma	0	11	0	0	0	2	\N	0
1991246849	0	ra	0	3	0	0	0	1	\N	0
1990928075	0	kingbella	0	24	0	0	0	12	\N	0
5326677875	0	ㅤㅤㅤ ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ ㅤㅤㅤㅤ	0	28	0	0	0	89	\N	0
6327561544	0	chimi	0	2	0	0	0	0	\N	0
6865650038	0	ell?	0	9	0	0	0	5	\N	0
5918517724	0	ri	0	213	0	0	5.7299999999977445	217	\N	0
6802791599	0	irene.	8	127	0	0	240.48000000000002	286	\N	0
5364174562	0	Dann	0	3	0	0	0	3	\N	0
815108367	0	Naufal I	0	35	0	0	0	34	\N	0
6125288620	0	Kayla E	0	4	0	0	0	0	\N	0
1918342352	0	- さ Ashaa	0	16	0	0	0	5	\N	0
5950499012	0	ShaiLLe #Telekubis14th	0	1	0	0	0	0	\N	0
6297346240	0	𝙖𝙙𝙚𝙡𝙞𝙣𝙚	0	3	0	0	0	3	\N	0
6695757709	0	gebiaan	0	0	0	0	0	2	\N	0
6469765318	0	sean.	0	1	0	0	0	0	\N	0
5758843136	0	....	0	12	0	0	0	0	\N	0
2122897032	0	?¿	0	320	0	0	15.550000000000182	143	\N	0
5592861277	0	Kainanananana	0	1	0	0	0	0	\N	0
5151507050	0	Renjun #NCT127_Ay_Yo	0	17	0	0	0	5	\N	0
5006878957	0	hambokben lha ngopo	0	1	0	0	0	0	\N	0
1688383284	0	sherina mileasya.	0	0	0	0	0	0	\N	0
2031391904	0	m	0	2	0	0	0	27	\N	0
6280708577	0	Ardianta	0	2	0	0	0	8	\N	0
1790573190	0	anya	0	12	0	0	0	0	\N	0
6076893696	0	ifaa	0	0	0	0	0	0	\N	0
5465135822	0	Kaiden	0	1	0	0	28.36	1	\N	0
5105965361	0	hm	0	5	0	0	0	0	\N	0
6714512144	0	𖤝 difcytheels gotta chum	0	8	0	0	0	0	\N	0
6282792598	0	Dave	0	3	0	0	0	4	\N	0
5650662810	0	Rahajeng.	0	2	0	0	0	0	\N	0
6059933921	0	idih sebel	0	52	0	0	0	251	\N	0
1669766350	0	Akun kerja,sfs,lpm	0	198	0	0	35	0	\N	0
1856908390	0	.	0	108	0	0	0	205	\N	0
5047578591	0	127 embul	0	4	0	0	0	5	\N	0
1328443310	0	bebek	0	21	0	0	0	69	\N	0
7007030166	0	zizii	0	0	0	0	0	0	\N	0
6088597027	0	acaa	0	3	0	0	0	1	\N	0
5123867479	0	.	0	223	0	0	13.86	239	\N	0
5616521091	0	Jo.	0	0	0	0	0	3	\N	0
5109819532	0	Valerie Aecia, pacar mingyu.	0	20	0	0	0	0	\N	0
5294969184	0	J.bridge	0	268	0	0	1642.8300000000033	1914	\N	0
5316904141	0	Azra_Pontianak	0	6	0	0	0	0	\N	0
5084641951	0	SheaAa :3	5	4	0	0	442.8499999999999	46	\N	0
5003306766	0	gendis	0	1	0	0	0	0	\N	0
6199316916	0	jenay rbio	0	1	0	0	0	0	\N	0
5996320623	0	uwi	0	12	0	0	0	9	\N	0
6730479312	0	jevan	0	1	0	0	0	0	\N	0
2032664494	0	arkan	0	27	0	0	0	1	\N	0
5027971152	0	Jules	0	4	0	0	0	1	\N	0
5601399407	0	naveen ᜊ( ᵕᴗᵕ )	0	1	0	0	0	1	\N	0
5909178161	0	𝕸adelyn.	0	1	0	0	0	0	\N	0
5684803732	0	Aka.	0	1	0	0	0	1	\N	0
1810391014	0	Cathy.	0	22	0	0	0	175	\N	0
6098835866	0	Nanda	0	2	0	0	0	1	\N	0
1861011605	0	cecil on duty	0	3	0	0	0	47	\N	0
6576267133	0	giska	0	11	0	0	0	44	\N	0
6799381334	0	fish	0	3	0	0	0	0	\N	0
5712591108	0	Winolien.	0	10	0	0	0	15	\N	0
5836921132	0	Ras	0	1	0	0	0	0	\N	0
6815847202	0	febrii	0	2	0	0	0	1	\N	0
1499392627	0	hiyahuyahuya	0	1	0	0	0	0	\N	0
1858773905	0	Aden	0	2	0	0	0	0	\N	0
1811891782	0	Trav	0	24	0	0	112.31	24	\N	0
6224857137	0	c	0	51	0	0	0	72	\N	0
5598710006	0	Pras	0	1	0	0	70.23	18	\N	0
2124209256	0	dap!	0	26	0	0	5.640000000000001	0	\N	0
6069850338	0	Liam	0	1	0	0	0	6	\N	0
5147139256	0	aeraa🚩	0	0	0	0	0	0	\N	0
6716337452	0	Yor nem	0	1	0	0	0	1	\N	0
6122451729	0	ail drxt¹[𝐒𝐕𝐇𝟑𝟏]ᴰ⁵	0	4	0	0	0	50	\N	0
1815409950	0	Angga	0	34	0	0	0	0	\N	0
5079455204	0	ičhikaa	0	20	0	0	0	9	\N	0
6412430740	0	z	0	5	0	0	25.71	22	\N	0
1540768535	0	di§	0	2	0	0	0	0	\N	0
6690784651	0	Adzana Shäyna :p	0	5	0	0	0	0	\N	0
2129066121	0	St. Eusebia.	0	5	0	0	0	9	\N	0
5511469901	0	Siapa	0	2	0	0	0	0	\N	0
7008446134	0	𝐁𝐒 wa	0	2	0	0	0	0	\N	0
5083528955	0	zii	0	1	0	0	0	0	\N	0
1964300622	0	ㅤAltair Mahatma Dikta.	8	333	0	0	4.319999999999993	286	\N	0
1814262981	0	H	0	6	0	0	0	3	\N	0
6552146539	0	J	3	52	0	0	432.63999999999993	624	\N	0
1952100199	0	gupi. close	0	16	0	0	0	13	\N	0
1847607436	0	alsarra	0	3	0	0	0	1	\N	0
6753816879	0	Alee	0	24	0	0	0	1	\N	0
6568895111	0	Ew	0	0	0	0	0	0	\N	0
5469927684	0	YA	0	4	0	0	0	84	\N	0
1296832440	0	LU	0	275	0	0	1783.2800000000002	700	\N	0
1462586686	0	shabiee	0	2	0	0	0	0	\N	0
2081724684	0	indri ୧⍤⃝🔥	0	0	0	0	0	0	\N	0
1575371818	0	k	0	48	0	0	0	40	\N	0
1765965416	0	likaa.	0	44	0	0	0	19	\N	0
5578477890	0	.	0	72	0	0	0	0	\N	0
6554476340	0	caa	10	219	1	0	4.7099999999999795	146	\N	0
5871684913	0	Jingga	0	16	0	0	71.61	45	\N	0
6893397835	0	riii	0	0	0	0	0	0	\N	0
6785536320	0	shakil	0	0	0	0	0	0	\N	0
2011056857	0	rest sikamala mala kudin	0	169	0	0	404.2	156	\N	0
1385509501	0	Daniel	0	10	0	0	0	5	\N	0
6002998667	0	Oby	0	1	0	0	0	1	\N	0
5606107768	0	ceel	0	1	0	0	0	0	\N	0
5582797348	0	cariiis betmut	0	105	0	0	11.72	171	\N	0
5397171100	0	shel	0	1	0	0	0	5	\N	0
5680598061	0	jela	0	3	0	0	0	0	\N	0
5920571584	0	239. Laurenth `cvk¹ovkārctiͼ	0	6	0	0	0	7	\N	0
6209330469	0	Brielle	0	7	0	0	15.07	1	\N	0
1645800896	0	nata	0	2	0	0	0	0	\N	0
5898019227	0	racyy	3	891	0	0	1350.8200000000006	431	\N	0
1986360747	0	Nanaa	0	7	0	0	0	6	\N	0
5053157124	0	awa	0	17	0	0	24	11	\N	0
5317534185	0	a	0	7	0	0	368	2	\N	0
5753238229	0	Mahesa	0	7	0	0	2600	16	\N	0
2118687461	0	α	0	1	0	0	0	8	\N	0
898211390	0	ㅡ ayyá	0	2	0	0	0	0	\N	0
5316877656	0	cyaan.	0	1	0	0	0	6	\N	0
1930709534	0	jevan.	0	19	0	0	0	5	\N	0
6501935170	0	cacaaaaa	0	1	0	0	0	1	\N	0
6969063299	0	k	0	2	0	0	0	1	\N	0
5932395276	0	Juan𝑲𝑹ʀʀᴡ	0	92	0	0	39.87	19	\N	0
2074489341	0	ra	0	32	0	0	30	11	\N	0
2099363208	0	Saguel	0	15	0	0	94	15	\N	0
6920006571	0	Jaydan	0	8	0	0	0	0	\N	0
6169612942	0	emil	0	1	0	0	0	0	\N	0
1833792192	0	ayya lustify	0	8	0	0	0	0	\N	0
6154023316	0	a	0	122	0	0	9.389999999999986	28	\N	0
1044194809	0	.	0	1	0	0	0	0	\N	0
828964620	0	bubblemipop	0	116	0	0	54.26000000000011	157	\N	0
1761747435	0	ama	1	51	0	0	2304.4300000000003	176	\N	0
5328704062	0	mon	0	1	0	0	0	0	\N	0
1184377877	0	urmaster	0	2	0	0	0	1	\N	0
1769990386	0	Marka	0	2	0	0	0	1	\N	0
1066638949	0	kaley	0	1	0	0	0	0	\N	0
1676211289	0	loe wen	0	4	0	0	0	2	\N	0
5610374571	0	kayyin pending	0	1	0	0	0	0	\N	0
6087773145	0	jaeheyun	0	423	0	0	2.789999999999935	117	\N	0
5580631631	0	fa	0	20	0	0	0	23	\N	0
1269417365	0	Al	0	2	0	0	0	0	\N	0
5650767146	0	levina	0	4	0	0	0	38	\N	0
6433906995	0	.	7	164	0	0	52.95	449	\N	0
1331021417	0	.	0	1	0	0	0	0	\N	0
1301722809	0	hell	0	9	0	0	0	6	\N	0
1823569656	0	Frequency’t	9	34	0	0	563.16	342	\N	0
5621880396	0	Kaiby	0	29	0	0	840.3000000000002	568	\N	0
6622510593	0	Ell in love w/L	0	16	0	0	0	19	\N	0
1262474199	0	Chibul	0	86	0	0	3022.2700000000004	3108	\N	0
5467175505	0	Gista	0	2	0	0	0	2	\N	0
5291431447	0	GASTALEO, still alive.	0	4	0	0	0	10	\N	0
1617791800	0	ce	0	6	0	0	0	24	\N	0
6238578668	0	lea	0	1	0	0	0	0	\N	0
1779252892	0	n.v	0	5	0	0	400	0	\N	0
6198809679	0	laaa	0	54	0	0	0	0	\N	0
7036334865	1	who's	0	10	0	0	0	0	\N	0
6946048810	0	Nakayamuraa	0	2	0	0	0	0	\N	0
2116244540	0	karel	0	1	0	0	0	0	\N	0
1268011863	0	James	0	1	0	0	0	0	\N	0
1346153622	0	ell	0	2	0	0	0	10	\N	0
6520169644	0	Ꮶ	0	7	0	0	0	5	\N	0
2128125928	0	keyra	0	106	0	0	609.5	339	\N	0
5685223154	0	wooja	0	352	0	0	21.5	12	\N	0
2027340355	0	$&#%.🎸axe!¡—	0	72	0	0	0	3	\N	0
6571462289	0	a	0	2	0	0	0	0	\N	0
2076183203	0	unknown	0	4	0	0	0	0	\N	0
6907186350	0	ka	0	1	0	0	0	7	\N	0
5925541724	0	Dzaula.	0	10	0	0	987.17	89	\N	0
6920808248	0	Ezaa	0	3	0	0	0	4	\N	0
1871092497	0	aku	0	7	1	0	0	48	\N	0
2115208872	0	kelly	0	14	0	0	0	43	\N	0
1772902169	0	k	0	271	0	0	0	3	\N	0
6054456209	0	Harley	0	1	0	0	0	0	\N	0
1611119347	0	dapka	1	162	0	0	487.24000000000046	2488	\N	0
1957384152	0	Adzana Shaliha.	0	37	0	0	0	9	\N	0
1861245124	0	𖧧 ָ࣪ 🩰˖ ࣪αbꫀƖ˖𓂅:♞	0	0	0	0	0	3	\N	0
5538377491	0	Yek	0	3	0	0	0	14	\N	0
1299328135	0	sanpiuuu	0	15	0	0	0	43	\N	0
5094596394	0	ini adhet	10	140	0	0	4153.1	586	\N	0
1049834734	0	Shanee	0	9	0	0	0	3	\N	0
5943340849	0	anna	0	1	0	0	0	0	\N	0
6693421833	0	fix(u)elᴴᴸ	0	13	0	0	0	257	\N	0
6996953019	0	n	0	17	0	0	0	0	\N	0
1741496896	0	Eren.	0	2	0	0	0	10	\N	0
1779030938	0	f ^__^	0	44	0	0	0	12	\N	0
1838008511	0	Sephia ‼️‼️	0	5	0	0	0	25	\N	0
997789074	0	Cutie, Sasaaa 😶‍🌫️	0	9	0	0	846	0	\N	0
7090820530	0	.	0	2	0	0	0	1	\N	0
7068919131	0	althea	0	1	0	0	0	1	\N	0
5852719948	0	mai	0	38	0	0	78.14	31	\N	0
6256446451	0	L	0	9	0	0	0	0	\N	0
5727116188	0	sha jd mba mba karen	0	2	0	0	0	8	\N	0
1737214724	0	araa	0	0	0	0	0	0	\N	0
5325909838	0	cheyy	0	260	0	0	6	419	\N	0
1905070943	0	nizell suka onitnelaV	0	78	0	0	4.3300000000000125	712	\N	0
1655965828	0	Louis G	0	8	0	0	0	2	\N	0
6149318560	0	lang	5	1	0	0	230.11999999999998	25	\N	0
6018679047	0	Lian	0	12	0	0	36.20000000000017	22	\N	0
5988649877	0	Malio	0	4	0	0	0	0	\N	0
6256727097	0	r	0	11	0	0	0	0	\N	0
1251136442	0	m	0	7	0	0	0	6	\N	0
6157649085	0	𝐈𝐆𝐋¹ alnon. 𝐍𝐄𝐎𝐙⁰¹	0	0	0	0	33.07	54	\N	0
5067788756	0	Yaya	0	7	0	0	0	4	\N	0
1278075478	0	a	7	402	0	0	4752.419999999998	231	\N	0
6907837110	0	nan	0	3	0	0	0	7	\N	0
7144513555	0	amar	0	2	0	0	0	1	\N	0
2104324759	0	anaa	0	14	0	0	0	1	\N	0
5026272337	0	aii	0	20	0	0	87.1	21	\N	0
6604173656	0	Austin	0	10	0	0	241.94	90	\N	0
1138006842	0	ganarcho	0	21	0	0	0	2	\N	0
6865945889	0	r	0	31	0	0	0	0	\N	0
6203194215	0	faya	0	8	0	0	0	166	\N	0
5462239749	0	flòo	0	11	0	0	0	5	\N	0
6648498461	0	.	0	1	0	0	0	0	\N	0
1841157193	0	A	0	3	0	0	0	0	\N	0
6680991489	0	v	0	8	0	0	0	5	\N	0
5001453144	0	Calva.	0	12	0	0	0	0	\N	0
5924714607	0	Harum	6	215	0	0	149.54000000000042	309	\N	0
6735087111	0	ge	0	2	0	0	0	0	\N	0
1726120030	0	Nzz	0	1	0	0	0	1	\N	0
6133820684	0	Naomi M.	0	0	0	0	0	0	\N	0
2006436111	0	ㅤㅤㅤㅤㅤ	0	2	0	0	0	0	\N	0
6471182397	0	key	0	55	0	0	20.99000000000001	1009	\N	0
5611134157	0	.	0	87	0	0	0	9	\N	0
5955801866	0	agam	0	9	0	0	0	17	\N	0
5031733529	0	A	0	55	0	0	90.49000000000001	45	\N	0
1797799614	0	j	0	6	0	0	0	21	\N	0
814856127	0	delisa	8	375	0	0	15224.089999999998	14180	\N	0
2045497553	0	iney	0	122	0	0	34	35	\N	0
6052204781	0	mave	0	4	0	0	0	27	\N	0
1258824496	0	dew	0	579	0	0	0	32	\N	0
1427364536	0	Athena.	0	2	0	0	0	0	\N	0
1772122902	0	ִ𓊔˖ ۫ ݂ 💭 ა ⬞ 𝚋abꪱ͟ᧉ࡛͠᥉ּ۪ȶ ֹ[ kiyow ]𓂃݊ ׅᘏᘏ ᮫ ⑅ׅ	0	14	0	0	1475.48	2	\N	0
5680574257	0	abiel	0	50	0	0	0	162	\N	0
5881154817	0	jo	14	38	0	0	555.99	227	\N	0
6382760295	0	kiki	0	1	0	0	300	0	\N	0
1280669924	0	jumanji	0	4	0	0	0	23	\N	0
6839506274	0	Haechan	0	2	0	0	0	0	\N	0
5249609411	0	m	0	4	0	0	0	1	\N	0
5677987260	0	bela	0	41	0	0	97.71000000000004	705	\N	0
5249408551	0	M	0	17	0	0	0	3	\N	0
6772750960	0	412	0	5	0	0	0	28	\N	0
6005935496	0	gf sungun	0	33	0	0	0	0	\N	0
6062315951	0	Ayunda	0	5	0	0	0	0	\N	0
5826507329	0	aveinyé	0	127	0	0	6.079999999999998	89	\N	0
5941075160	0	ads	10	615	0	0	2663.38	1727	\N	0
5029447587	0	Sese	0	256	0	0	6.890000000000001	193	\N	0
6615015773	0	𝅄 ֹ 𝒻beauté; maddén hésia. ۫ છ 𝅼	0	17	0	0	152.44	6	\N	0
1571498063	0	e pusing parah	0	1	0	0	0	0	\N	0
5589946601	0	Kajeyya A.	4	78	0	0	2561.0299999999997	467	\N	0
1632286745	0	ᝯ nantta’s	0	2	0	0	0	8	\N	0
5881103588	0	ㅤ☁️	0	46	0	0	0	2	\N	0
5316148100	0	-Cheyon🫥	0	50	0	0	78.38999999999999	173	\N	0
6952625038	0	ciwaw smartfren	0	9	0	0	0	0	\N	0
1314938734	0	maya.	0	3	0	0	0	1	\N	0
2086912377	0	Yh	0	1	0	0	0	0	\N	0
5418270189	0	Shafa	0	1	0	0	0	0	\N	0
6244764002	0	Ar	0	4	0	0	0	0	\N	0
1842731416	0	sey	0	4	0	0	0	0	\N	0
5666550286	0	508 xabiru	0	271	0	0	815.7900000000001	66	\N	0
1521218999	0	rest egan	14	368	0	0	2197.0899999999997	646	\N	1
5031658889	0	nolala	0	1	0	0	0	0	\N	0
6181906913	0	xontol	0	4	0	0	0	0	\N	0
5897787799	0	anne	0	1	0	0	0	6	\N	0
1653703313	0	kiyaa! 𝑸𝑬¹	4	77	0	0	4960.939999999999	543	\N	1
5465268394	0	Nayanika Pijar.	0	140	0	0	558.8500000000003	636	\N	0
6539305027	0	Abbi P	0	50	0	0	148.57	56	\N	0
1836189063	0	madel	0	133	0	0	3.8299999999999983	92	\N	0
6165028999	0	Soka	0	11	0	0	0	11	\N	0
5965666219	0	wino	0	1	0	0	0	1	\N	0
5267971808	0	ze	0	3	0	0	784.44	0	\N	0
5677359250	0	zii	0	60	0	0	1074.59	440	\N	0
1511938258	0	G.	0	51	0	0	0	27	\N	0
5078983513	0	d	0	1	0	0	0	0	\N	0
5403497806	0	angelinaa	0	8	0	0	0	7	\N	0
1761505209	0	u	0	0	0	0	0	0	\N	0
5086920243	0	raa	0	63	0	0	20.310000000000002	35	\N	0
1969535103	0	Vodka	0	346	0	0	0	30	\N	0
1976981743	0	vian	0	0	0	0	0	0	\N	0
6300649140	0	doy	0	0	0	0	0	0	\N	0
5100090941	0	Blythe	0	13	0	0	0	62	\N	0
7106077401	0	veēna ᴴᴸ.	0	12	0	0	0	62	\N	0
5721448891	0	naishaa.	1	1208	0	0	10.800000000001447	1639	\N	0
2063505560	0	 ૮₍´˶• . • ⑅ ₎ა	0	4	0	0	0	83	\N	0
5213416627	0	d	0	429	0	0	-8.63999999999993	472	\N	1
5097511975	0	a	0	167	0	0	57.24000000000001	9	\N	0
5000803726	0	tsh.	0	473	0	0	3661.0299999999997	710	\N	0
5848911456	0	kaiii ft càthez ("okay")	0	2	0	0	0	0	\N	0
1146366096	0	Lagea	0	3	0	0	0	6	\N	0
1943097288	0	𝐀ɾυᥒᥲ	0	69	0	0	4.83	39	\N	0
1439774353	0	Jeha 💢	0	5	0	0	0	5	\N	0
5748119293	0	abey	0	0	0	0	0	0	\N	0
5737165363	0	nad	0	7	0	0	0	5	\N	0
1987143947	0	Jargas	0	1	0	0	0	0	\N	0
5084614249	0	Mark	0	1	0	0	0	7	\N	0
6264216630	0	pablo 99$.	0	1	0	0	0	0	\N	0
6283069595	0	에밀리에— 𝖧𝖾𝖺𝗋𝗂𝗇𝗇𝖾	0	2	0	0	0	0	\N	0
5616642701	0	☫ cera 𝕍𝕚𝕝𝕝𝕚𝕒𝕟's Ace!	0	3	0	0	0	3	\N	0
5409174824	0	unlucky	0	0	0	0	0	1	\N	0
6892735416	0	k for kyaa	0	0	0	0	0	3	\N	0
5099378240	0	nier	0	4	0	0	0	6	\N	0
1491073663	0	Blax	0	128	2	0	0	7	\N	0
1592935509	0	Mallisa, return @ParkJongqSeong to me.	0	125	0	0	0	93	\N	0
2102452335	0	allen	0	3	0	0	0	0	\N	0
1652617891	0	𝐌r. 𝐙évan فانلوفيز	0	1	0	0	0	0	\N	0
5994297647	0	lala	0	9	0	0	0	15	\N	0
2056819836	0	ZA	0	1	0	0	0	2	\N	0
6583575133	0	jè 🦢	0	42	0	0	535.37	481	\N	0
1870599168	0	Ice	0	2	0	0	0	2	\N	0
5422432128	0	Arrietty	0	14	0	0	0	18	\N	0
1870182934	0	Faèyz	0	10	0	0	0	4	\N	0
7170365439	0	olly	0	3	0	0	0	0	\N	0
6795850851	1	pinqeu	0	66	0	0	0	347	\N	0
1931756621	0	XiaoNanaa	0	20	0	0	0	32	\N	0
1875026737	0	ℬ4₲🇦🇱 jeyya victoryking	0	1	0	0	0	0	\N	0
1935698260	0	𝐓𝐑≛𝐏𝐒 `jejee' タ𝔯𝕥𝐒	0	33	0	0	0	52	\N	0
5136966793	0	Kael. Inactive	0	3	0	0	0	0	\N	0
5846857247	0	N	0	3	0	0	0	0	\N	0
1504083290	0	myesha	0	5	0	0	0	9	\N	0
5168989273	0	marion	0	7	0	0	0	18	\N	0
1628359734	0	jizzanneeEe	0	1	0	0	0	0	\N	0
6052568520	0	Beo	0	1	0	0	0	0	\N	0
1239093999	0	Nug Nanami	0	0	0	0	0	1	\N	0
1450668079	0	Jevangga. R	0	22	0	0	0	0	\N	0
1514071153	0	Seraphine.	0	0	0	0	0	0	\N	0
5379863682	0	on resting.	0	513	0	0	75.39999999999978	1032	\N	0
6929320938	0	kιmbbᥱrly ֢	0	46	0	0	0	40	\N	0
5598440040	0	jelaa	0	3	0	0	0	21	\N	0
5291540973	0	diva	8	166	0	0	1448.5900000000001	5903	\N	0
5360768735	0	alva ext⁴`	0	3	0	0	0	0	\N	0
6742635937	0	🎀🌀˚₊ aira - open freelance!333	0	42	0	0	0	11	\N	0
5098471670	0	slctv. oceanna	0	0	0	0	0	0	\N	0
1975352141	0	guanta #monstergoyek	0	7	0	0	0	89	\N	0
6172906630	0	nadine.	0	1	0	0	0	0	\N	0
6189524855	0	eren	0	66	1	0	13	6	\N	0
2015546383	0	zizi	0	10	0	0	0	52	\N	0
5318385059	0	Haan	0	15	0	0	0	0	\N	0
6329866633	0	Raa	0	2	0	0	0	0	\N	0
6260994481	0	abel	0	19	0	0	0	0	\N	0
5842326162	0	Miska	0	1	0	0	0	0	\N	0
1890759529	0	ડ᭙ꫀꫀtเꫀ ᖯ𖦹𖦹 ！！	0	2	0	0	0	2	\N	0
5170252843	0	zoe raya	0	3	0	0	0	18	\N	0
1924453079	0	anne estèria 🥨	0	2	0	0	0	0	\N	0
7191726784	0	Slipknot	0	8	0	0	0	29	\N	0
6282834200	0	babe	0	12	0	0	0	199	\N	0
1111619248	0	kia	0	5	0	0	0	3	\N	0
5752885977	0	a	0	6	0	0	0	0	\N	0
2067731026	0	nAnAaa??!!	0	84	0	0	0	135	\N	0
1373116795	0	ηє̷σ •ꭰøиᥲιժ•〠	0	18	0	0	0	36	\N	0
5318536737	0	Ael.	0	6	0	0	0	4	\N	0
1369507030	0	Carmilla.	0	2	0	0	0	0	\N	0
5874360674	0	kreyy	0	1	0	0	0	0	\N	0
5293316270	0	chacha	0	4	0	0	0	0	\N	0
5227968332	0	.	0	2	0	0	0	0	\N	0
5353138725	0	Margo, always open.	0	0	0	0	0	0	\N	0
6133403430	0	abel	0	3	0	0	0	0	\N	0
1834248643	0	asel	0	24	0	0	0	323	\N	0
1270589203	0	Joyy	0	44	0	0	0	93	\N	0
5560017324	0	bubub haruto	0	137	0	0	224.8	344	\N	0
2120209792	0	waa	0	10	0	0	0	1	\N	0
6216370835	0	vyel	0	6	0	0	0	0	\N	0
6037866612	0	Kirann 🧌🧌	0	1	0	0	0	0	\N	0
6206120638	0	airi peme sejati	0	0	0	0	0	0	\N	0
6685610990	0	xen	0	5	0	0	0	8	\N	0
5319400483	0	Cakra	0	2	1	0	0	0	\N	0
1657548427	0	kell	0	15	0	0	0	2	\N	0
6338216761	0	Eca	0	2	0	0	0	4	\N	0
6821443561	0	Mian	0	1	0	0	0	1	\N	0
5195769839	0	sasä	0	89	0	0	2163	597	\N	0
5432887838	0	jénar	0	24	0	0	0	38	\N	0
1712071315	0	Amstel	0	5	0	0	0	0	\N	0
2145075696	0	jade	0	9	0	0	504.04999999999995	11	\N	0
6277849422	0	Scorpionboy	0	6	0	0	0	11	\N	0
5004102267	0	Ay.	0	3	0	0	0	18	\N	0
5914476595	0	Kyra	0	1	0	0	0	1	\N	0
1510788617	0	azkha	0	28	0	0	0	23	\N	0
1667912518	0	ra	0	0	0	0	0	0	\N	0
5487202173	0	jéanne 🦋	0	8	0	0	0	25	\N	0
6037172781	0	youtha	0	45	0	0	8	55	\N	0
766140123	0	Lova	0	1	0	0	0	1	\N	0
5620555331	0	🐬	0	4	0	0	0	4	\N	0
5079364557	0	Naomii slow respon	0	43	0	0	257.2	3	\N	0
6858349594	0	Mabila	0	1	0	0	0	1	\N	0
6625224425	0	Fida	0	5	0	0	0	1	\N	0
6570753103	0	v	0	3	0	0	0	8	\N	0
1392805975	0	.	0	5	0	0	0	0	\N	0
6663046044	0	piaa	0	6	0	0	0	6	\N	0
1696464200	0	Jeandra	0	4	0	0	0	0	\N	0
6895040975	0	io	0	1	0	0	0	0	\N	0
1182246311	0	anje	0	1	0	0	0	1	\N	0
5852775347	0	awikawik	0	15	0	0	77.12	33	\N	0
1647235765	0	naomiii	0	10	0	0	0	12	\N	0
6124206053	0	Jeff	0	1	0	0	0	3	\N	0
1323785648	0	arvind	0	31	1	0	23.950000000000003	104	\N	0
5376368609	0	Reyfka ultramine	0	3	0	0	0	39	\N	0
2069524397	0	gathan	0	9	0	0	0	49	\N	0
6040951798	0	aysele	0	75	0	0	8.899999999999977	20	\N	0
6933560897	0	Eja	0	1	0	0	0	17	\N	0
6315342680	0	R	0	7	0	0	0	48	\N	0
5544397385	0	nesha k42〻	0	1	0	0	0	4	\N	0
1835430093	0	Xanderr	0	11	0	0	196.47	25	\N	0
5075832223	0	Gura.	0	5	0	0	0	4	\N	0
5028970745	0	Mala	0	0	0	0	0	0	\N	0
1349497324	0	mbayung.	0	2	0	0	0	1	\N	0
1426481416	0	.	0	38	0	0	0	0	\N	0
6034195826	0	sakel	0	2	0	0	0	0	\N	0
2045201987	0	Daniel	0	51	0	0	0	12	\N	0
7136918076	0	kinara	0	1	0	0	0	0	\N	0
6899069793	0	len	0	3	0	0	0	0	\N	0
1399957577	0	vae	0	4	0	0	0	6	\N	0
5317787988	0	Michie, open fastresp! ♥️	0	49	0	0	0	71	\N	0
6636823109	0	🌷🌷	0	45	0	0	11.189999999999998	36	\N	0
1636824085	0	lena	0	4	0	0	0	13	\N	0
1612019425	0	sheila	0	7	0	0	66.77	290	\N	0
1331017526	0	Dean	0	7	2	0	0	28	\N	0
1447651872	0	rendu	14	585	0	0	12.149999999999324	1762	\N	0
5038692566	0	... ❨🐇❩ 토끼, zaziel.	5	25	0	0	944.27	109	\N	0
6480271780	0	nayya	0	4	0	0	0	0	\N	0
5677730128	0	abiell	0	0	0	0	0	1	\N	0
6250365145	0	105. Viera	0	1	0	0	0	3	\N	0
6281761528	0	rafa	11	216	0	0	82.65000000000009	318	\N	0
6978532174	0	A	0	106	0	0	0	121	\N	0
1948347727	0	chihiro mrh	0	29	0	0	310	51	\N	0
1525556239	0	izzah	0	11	0	0	0	23	\N	0
6408697486	0	cfluffy	0	1	0	0	0	1	\N	0
5976479041	0	Serrana Yvonne.	0	1	0	0	0	2	\N	0
2066740359	0	cici	0	54	0	0	15.620000000000005	69	\N	0
1979237919	0	Zeta	0	402	0	0	25.460000000000008	77	\N	0
1473100718	0	ian	0	16	0	0	0	0	\N	0
5844187771	0	Tunas	0	2	0	0	0	0	\N	0
1540866060	0	Nia	0	34	0	0	0	8	\N	0
1167157080	0	Ma'ruf Aulia	0	30	0	0	1002.08	137	\N	0
5428449610	0	˓˓ ʬ ˓🐾 ഒ ࣪˖ 𝐒iren(a) 𖥔 ˖ׁ	0	5	0	0	0	0	\N	0
5221197643	0	ᴢᴏʏ	11	57	0	0	838.0099999999999	187	\N	0
2005678322	0	cølla	0	366	0	0	0	137	\N	0
6020425131	0	alishaa	0	16	0	0	0	20	\N	0
6713806712	0	𝟗𝟏𝟗. Draxellion #EndruBinal	0	1	0	0	0	0	\N	0
1198599216	0	🅰️	0	330	0	0	0	268	\N	0
1936908113	0	sxyvsxyisxya	0	5	0	0	0	6	\N	0
1349087201	0	nikzon	9	165	0	0	2493.06	3349	\N	0
5374861316	0	D	9	4	0	0	71.25	110	\N	0
1527069124	0	Rara	0	1	0	0	0	0	\N	0
5308051439	0	an	0	1	0	0	0	0	\N	0
2063324857	0	R	0	1	0	0	0	7	\N	0
1804585285	0	k!	0	14	0	0	0	7	\N	0
6115464074	0	Oza	13	371	0	0	154.3800000000004	630	\N	0
5407190652	0	nctr	0	244	0	0	594.0699999999997	5249	\N	0
1381882418	0	atheina	0	1	0	0	0	5	\N	0
5515714805	0	caca	0	2	0	0	0	3	\N	0
5517887887	0	haura	0	1	0	0	0	0	\N	0
1696851490	0	regita	0	5	0	0	0	1	\N	0
6027169753	0	K. Rbio #K	0	1	0	0	0	0	\N	0
5773002060	0	Janu.	0	1	0	0	0	0	\N	0
5926035771	0	alenn	0	32	0	0	0	37	\N	0
6656877728	0	el	0	0	0	0	0	0	\N	0
5830575517	0	Rui Kawamori.	0	22	0	0	0	0	\N	0
6209287604	0	Yura.	0	1	0	0	0	1	\N	0
1478091903	0	ysf	0	1	0	0	0	0	\N	0
6534296424	0	z	0	16	0	0	0	2	\N	0
1961138891	0	Key	0	32	0	0	4.079999999999998	14	\N	0
7013545939	0	Indomie	0	5	0	0	0	0	\N	0
5150318158	0	máura	0	14	0	0	0	29	\N	0
6452147413	0	lintang	0	2	0	0	0	0	\N	0
1968903446	0	🤡	0	8	0	0	0	40	\N	0
2034853800	0	reksaa!	0	32	0	0	0	0	\N	0
6731526431	0	Jojow	0	40	0	0	14.45	617	\N	0
6184324591	0	ell	0	3	0	0	0	0	\N	0
6149788947	0	galen sodara kandung lisa	0	42	0	0	20.10999999999993	66	\N	0
6531667029	0	ya.	2	22	0	0	449.94000000000005	662	\N	0
5383905765	0	Eden.	0	0	0	0	0	0	\N	0
6567155300	0	Jake Cameron	0	7	0	0	0	0	\N	0
5262323387	0	dison	0	3	0	0	0	0	\N	0
5856890419	0	piaannn	0	3	0	0	0	3	\N	0
5200986904	0	kgn bgt	0	19	0	0	0	0	\N	0
2098652970	0	Disaa	0	1	0	0	0	32	\N	0
7060195084	0	Zee	0	4	0	0	0	0	\N	0
5368028093	0	ㅤㅤㅤㅤ	3	17	0	0	316.77	201	\N	0
6727225225	0	sneaky link	0	0	0	0	0	1	\N	0
6883105680	0	aan	0	9	0	0	0	2	\N	0
6212680865	0	f	0	24	0	0	0	1	\N	0
7149750035	0	𝐓𝐑≛𝐏𝐒 `gamy	0	46	0	0	0	56	\N	0
1831867112	0	Ngeluh mulu	0	12	0	0	0	39	\N	0
1912166839	0	J	0	48	0	0	0	1	\N	0
1776596189	0	ayayaya	0	4	0	0	0	6	\N	0
2098558595	0	jinné	0	16	0	0	0	0	\N	0
5700567167	0	jenaaa	0	133	0	0	0	69	\N	0
1639727646	0	azalea	0	536	0	0	27.16999999999996	1431	\N	0
1807849914	0	edyaa	0	17	0	0	0	268	\N	0
5759046307	0	parsa	0	1	0	0	0	0	\N	0
7186178853	0	Henriette.	0	4	0	0	0	5	\N	0
1924894424	0	Rachine alexa	0	0	0	0	0	0	\N	0
6455641806	0	ᴸᶜᴬᴮ. Arutala Thirta	0	7	0	0	0	4	\N	0
6324957020	0	 ⁠益ALZEA	0	0	0	0	0	2	\N	0
6197304226	0	nina ga bobo 🧌	0	1	0	0	0	108	\N	0
1758926208	0	cc	0	78	0	0	357	30	\N	0
5152906773	0	bai	0	344	0	0	0	223	\N	0
6465301346	0	Ayel	0	4	0	0	78	56	\N	0
1717500224	0	kj	0	10	0	0	0	33	\N	0
685748031	0	H	0	2	0	0	0	1	\N	0
6687683299	0	ᴍᴠɴ. geelárs	0	5	0	0	0	3	\N	0
1566542369	0	Athalia.	0	7	0	0	0	1	\N	0
1318841016	0	Caeyy.	0	86	0	0	115	6	\N	0
1744596525	0	A	0	219	0	0	13.030000000000427	69	\N	1
1865269821	0	anything u want	0	197	0	0	14.25	131	\N	0
1890195355	0	Jere capek diejek	0	5	0	0	0	50	\N	0
1761583612	0	dokter jorra 👩🏻‍⚕🇵🇸	0	0	0	0	0	7	\N	0
6133968583	0	cesya	0	13	0	0	0	16	\N	0
7099828002	0	Sandrya (on rest)	0	13	0	0	0	22	\N	0
1990187107	0	Kuman	0	3	0	0	0	6	\N	0
2054556043	0	zahra	0	49	0	0	0	3	\N	0
5211054827	0	.	0	218	0	0	10	268	\N	0
6612678745	0	yef	0	11	0	0	434	991	\N	0
5126507891	0	Putra	0	205	0	0	13.650000000000773	1276	\N	0
5005367851	0	t	0	12	0	0	0	0	\N	0
5698531827	0	rosieee	2	206	0	0	72.7299999999999	65	\N	0
5791370223	0	Cadee R20 Noktel	0	156	2	0	0.20000000000010232	7	\N	0
6609723297	0	K	0	1	0	0	0	3	\N	0
5576575732	0	aku rara	0	16	0	0	0	3	\N	0
5702267041	0	ailéna	0	11	0	0	0	61	\N	0
5078616285	0	#phs bukan pacar gua tapi suami	0	187	0	0	4.440000000000055	1159	\N	0
6095579712	0	naye 𝑺𝑵	0	2	0	0	0	1	\N	0
1981169520	0	Chiy	0	30	0	0	0	3	\N	0
1682567044	0	Aed	0	3	0	0	0	30	\N	0
1951724007	0	zora	0	102	0	0	5	4	\N	0
1263706664	0	尺ㄩᗰI𝗡𝗢𝙎𝙃𝙄	0	309	0	0	49.620000000000005	193	\N	0
1564746339	0	Arkan	0	1	0	0	0	0	\N	0
1876349434	0	𝐃𝐏𝐑—𝗔. 𖧧 ֺ ᥲrуᥒძᥙᥙ 𐀔 R39	0	6	0	0	0	1	\N	0
6893728806	0	je	0	5	0	0	0	9	\N	0
6104019295	0	Rahmat	0	9	0	0	0	5	\N	0
2084547382	0	ijey	0	2	0	0	0	10	\N	0
5624259736	0	alenA	0	4	0	0	0	15	\N	0
5389582500	0	Ari Wilyaa	0	16	0	0	0	9	\N	0
5069411543	0	queue	0	20	0	0	19.669999999999902	14	\N	0
1739604075	0	nad	0	36	0	0	0	11	\N	0
1825535979	0	sara	0	23	0	0	0	6	\N	0
5244665695	0	hnun	0	19	0	0	0	26	\N	0
1571731525	0	a	0	8	0	0	0	2	\N	0
1485004550	0	Noera	0	4	0	0	0	13	\N	0
1315140161	0	Yippiyaee	0	4	0	0	0	26	\N	0
1943726768	0	dell	0	78	0	0	0	2	\N	0
1874103712	0	marko	0	18	0	0	0	165	\N	0
1715898224	0	saaya.	0	2	0	0	0	0	\N	0
1817181479	0	piwa	0	1	0	0	0	2	\N	0
1734462804	0	soul	0	3	0	0	0	2	\N	0
1754930987	0	naesyaa	0	4	0	0	0	2	\N	0
5085067565	0	gad	5	8	0	0	0	172	\N	0
5493113202	0	୨🎀୧ Mi- cHie>___<	0	3	0	0	0	4	\N	0
1088324244	0	Neia	0	85	0	0	75	3061	\N	0
6139881776	0	vitt	0	17	0	0	965.45	20	\N	0
5993047925	0	💋💋	0	1	0	0	0	0	\N	0
5417312273	0	shera	0	1	0	0	0	0	\N	0
1859494344	0	𝗝unnie.	0	3	0	0	0	0	\N	0
5132968101	0	kala	0	13	0	0	0	7	\N	0
5138615126	0	Amel	0	620	0	0	3	659	\N	0
5502107467	0	Kai	8	22	0	0	1073.21	1785	\N	0
1602217353	0	unknown	0	4	0	0	0	0	\N	0
5409741703	0	Kyros	0	1	0	0	0	13	\N	0
6696426387	0	erdan	0	0	0	0	0	0	\N	0
5207235759	0	keza	0	1	0	0	0	3	\N	0
1564250421	0	ㅤㅤㅤㅤ	0	9	0	0	0	0	\N	0
6724069394	0	Jaymore	0	1	0	0	0	3	\N	0
2039749293	0	bee	0	10	0	0	0	37	\N	0
1982865682	0	pers. naomiiii @bae4rene	0	10	0	0	0	3	\N	0
1344088063	0	Jàyy	0	85	0	0	0	145	\N	0
5607711037	0	Rieece's	0	18	0	0	0	9	\N	0
1257947140	0	paulsuu	0	15	0	0	1881	25	\N	0
5093633366	0	abel	0	2	0	0	0	3	\N	0
1031673832	0	el	0	4	0	0	0	0	\N	0
5641147921	0	ael	0	78	0	0	866.96	117	\N	0
5280899263	0	j𝔞	0	21	1	0	0	22	\N	0
5045992569	0	𓊆𓆸𓆏۫𝓖𝒶𝓊𝓇𝓮𝓷๋𓊇	0	2	0	0	0	1	\N	0
1986478053	0	🥁🥁🥁🥁	0	9	0	0	0	0	\N	0
1936481268	0	pgn jd projen	0	31	0	0	0	94	\N	0
1834424730	0	shy shy meong	6	601	0	0	10294.09	931	\N	0
6732772945	0	Keysha	0	3	0	0	0	17	\N	0
5079822179	0	d	12	639	0	0	23200.929999999997	1809	\N	1
6947789453	0	mhesa	0	2	0	0	0	0	\N	0
5506853821	0	Gilang Saputra	0	3	0	0	0	2	\N	0
5914992170	0	Rayra salima	0	9	0	0	0	0	\N	0
6203587193	0	by	0	56	0	0	15.849999999999994	2	\N	0
5745301060	0	Shealine Aubreeca.	7	185	0	0	1649.880000000001	162	\N	0
7145151308	0	pin	0	46	0	0	0	102	\N	0
1689515548	0	mshtkt_tm	0	5	0	0	0	1	\N	0
5864318556	0	jella	0	0	0	0	0	0	\N	0
1758301588	0	biFey🍰🍰🍰	0	1	0	0	0	132	\N	0
5125801809	0	奥, shelaaaa	0	264	0	0	319.63999999999965	40	\N	0
1895456602	0	chessa	0	50	0	0	9.809999999999999	79	\N	0
6036573649	0	Jj	6	203	0	0	1421.79	6	\N	0
5876326433	0	kiki	0	7	0	0	0	1	\N	0
6991197826	0	ᨘ໑▸ 𖥻 յׁׅꪱׁׁׁׅׅׅɑ݊ꪀ ˑ 𖦹	0	3	0	0	0	0	\N	0
6119498094	0	lily	0	51	0	0	297.87	103	\N	0
2015801303	0	alien	14	170	0	0	5.31999999999789	49	\N	1
6179375741	0	aaron	0	18	0	0	0	3	\N	0
1715368902	0	k	0	21	0	0	74.36	139	\N	0
5767383531	0	kalanaaaa	0	7	0	0	0	5	\N	0
5278255863	0	edgar	0	35	0	0	10.649999999999999	129	\N	0
5545767728	0	Livia	0	7	0	0	0	0	\N	0
5805515490	0	rumm	0	1	0	0	0	4	\N	0
2138749476	0	leo	0	3	0	0	0	5	\N	0
5218041553	0	Joule	0	13	0	0	0	67	\N	0
5613018682	0	N.	0	2	0	0	0	13	\N	0
1714483121	0	jejen supremacy	14	327	0	0	941.88	1885	\N	0
6918983017	0	.	0	42	0	0	2.240000000000002	18	\N	0
1954266038	0	Clayfic	0	1	0	0	0	0	\N	0
1729018396	0	Xakiell	0	5	0	0	0	0	\N	0
5858357035	0	....	0	33	0	0	456	4	\N	0
1959524345	0	𝓝oelle	0	9	0	0	0	25	\N	0
6720834977	0	Ashaa	0	1	0	0	0	0	\N	0
1415026047	0	ೀ °.	0	5	0	0	0	1	\N	0
5410116159	0	loi	0	7	0	0	0	1	\N	0
5008988796	0	aya	0	1	0	0	0	0	\N	0
6890927096	0	aley lg jadi seken cois	0	2	0	0	0	2	\N	0
5251962765	0	jayden	0	27	0	0	0	34	\N	0
1212753510	0	mora	0	2	0	0	0	1	\N	0
5028911858	0	C	0	4	0	0	0	0	\N	0
1684471333	0	Ann	0	25	0	0	0	1	\N	0
1667157629	0	abi	0	0	0	0	0	0	\N	0
1262634186	0	ji	0	1	0	0	0	2	\N	0
5582490232	0	jaemin's lovetaker, Maddië.	0	3	0	0	0	0	\N	0
6590059968	0	Juan	0	1	0	0	0	1	\N	0
1554728975	0	el	0	39	0	0	31	59	\N	0
5874629795	0	n	0	105	0	0	9.18	16	\N	0
2012485561	0	rima.	0	3	0	0	0	0	\N	0
6154396336	0	555	0	33	0	0	37.64999999999998	1	\N	0
5303927922	0	w	3	2383	0	0	2955.600000000004	4544	\N	0
1814921746	0	E	0	7	0	0	0	1	\N	0
6727977385	0	Fellysya	0	8	0	0	80.81999999999994	9	\N	0
6666989254	0	c	0	1	0	0	0	0	\N	0
1337628693	0	Z	0	3	0	0	0	1	\N	0
1477474086	0	Lingga	0	1	0	0	0	0	\N	0
5710582903	0	floo	0	84	0	0	0	0	\N	0
1721647354	0	.	0	0	0	0	0	0	\N	0
1258271635	0	nai	8	369	0	0	18.899999999999977	421	\N	0
5096875151	0	Naresya pacar Adelard Zevanaa	0	0	0	0	0	67	\N	0
1194199988	0	bayu	0	2	0	0	0	0	\N	0
1879637466	0	j. mork	8	78	0	0	0	424	\N	0
1776348046	0	v.	0	8	0	0	0	0	\N	0
5744703153	0	.	0	257	0	0	0.9000000000000004	116	\N	0
7182439629	0	𖹭..Nathea myrthle. I,	0	2	0	0	23.92	18	\N	0
6205210916	0	alan	0	3	0	0	0	1	\N	0
1967919141	0	ur sa	0	6	0	0	0	236	\N	0
1941169927	0	iycha	0	3	0	0	0	146	\N	0
5029887131	0	gievsishdsisnn	0	4	0	0	0	5	\N	0
5898560630	0	Clyden Jaile Ramirez.	0	1	0	0	0	0	\N	0
6935696120	0	__🚕_____🚗______🚙_____🚐_____🚚_____🚜______	0	26	0	0	1000	73	\N	0
5554422813	0	gavii @arcticgavi	0	0	0	0	0	0	\N	0
2121050122	0	C	0	0	0	0	0	0	\N	0
5558894820	0	a	0	117	0	0	0	104	\N	0
953540514	0	relieff	0	2	0	0	128.02	0	\N	0
1534855288	0	jes	0	1	0	0	0	6	\N	0
1690118397	0	abil	0	14	0	0	0	146	\N	0
1698266083	0	pipip	0	21	0	0	6	46	\N	0
2123972286	0	Vai	0	440	0	0	18.050000000000182	3715	\N	0
6806805285	0	7 @bungaz	0	3	0	0	0	0	\N	0
2025600754	0	ash	0	13	0	0	0	6	\N	0
2100870168	0	Damar, M.	0	278	0	0	2377.2999999999997	433	\N	1
1929916764	0	lea	0	2	0	0	0	9	\N	0
5822954118	0	Adhisty Madeline.	0	81	0	0	0	13	\N	0
5011545179	0	Amoraa J. 🪷	0	1	0	0	0	3	\N	0
6700860029	0	Ryn	0	11	0	0	0	15	\N	0
6467277966	0	Azhar Godwis	0	17	0	0	0	7	\N	0
6056466773	0	Arv Malfoy.	3	47	0	0	746.5599999999998	384	\N	0
5986841623	0	Adischa L.	0	64	0	0	319.97	270	\N	0
1832122977	0	gládyes	0	2	0	0	0	0	\N	0
5079236727	0	03	0	53	0	0	0	16	\N	0
1420764210	0	jeeppypypypy	0	2	0	0	0	7	\N	0
5521235177	0	ִֶ ࣪ ، Ayaa ヤ !	0	66	0	0	40.59999999999991	109	\N	0
6787812516	0	Bel	0	0	0	0	0	2	\N	0
5163464155	0	deyy	0	240	0	0	0	160	\N	0
5350079072	0	pauja	0	1	0	0	0	1	\N	0
1840451312	0	M Dani Setiawan	0	3	0	0	0	0	\N	0
5837652295	0	bell	0	1	0	0	0	0	\N	0
6840037057	0	aaaa	0	10	0	0	0	4	\N	0
2095773444	0	d	0	3	0	0	0	24	\N	0
5239209244	0	ody	0	89	0	0	121.13000000000008	28	\N	0
5191056286	0	irene	0	6	0	0	0	0	\N	0
5908814623	0	yiraa	0	21	0	0	0	4	\N	0
5582003591	0	ileyy - 𝑺𝑵 ` sᴇᴊᴀɢᴀᴛ ` #pds	0	1	0	0	0	0	\N	0
1971597153	0	r	0	11	0	0	20.58	1	\N	0
5169735743	0	... ꕤ pret:ty! 𝗝𝗼𝘆𝘆𝗮𝗻𝗮 ⊰ 🐇	0	6	0	0	0	5	\N	0
1756872553	0	jordan	0	7	0	0	0	25	\N	0
6629415416	0	26	0	44	0	0	10	176	\N	0
5843065972	0	.	0	8	0	0	0	6	\N	0
2077210293	0	naa	0	8	0	0	0	16	\N	0
6242333881	0	zæ	11	18	0	0	2.0499999999883585	93	\N	1
1669880769	0	Nàvier	0	11	0	0	178	93	\N	0
1624590911	0	tata	5	225	0	0	1393.62	212	\N	0
1688620113	0	Cele	0	104	0	0	2216.02	705	\N	0
2070274895	0	d1n44444	0	4	0	0	0	3	\N	0
6243776322	0	nz	0	1	0	0	0	0	\N	0
2068389484	0	saisasa	0	1	0	0	0	7	\N	0
5008672625	0	Elza	0	1	0	0	0	0	\N	0
1755787633	0	who	0	186	0	0	0	287	\N	0
6274052585	0	bima	0	1	0	0	0	0	\N	0
1422484698	0	davin, yang ngajak moots dibales nanti	0	0	0	0	0	519	\N	0
5441135987	0	sania	0	0	0	0	0	0	\N	0
5548089180	0	j	0	32	0	0	3678.8	143	\N	0
5452597886	0	xal	0	146	0	0	0	247	\N	0
6647245989	0	📎cya🦢🌷	0	2	0	0	0	2	\N	0
2042506657	0	jo	0	1	0	0	0	0	\N	0
5410189108	0	juju🚂	0	2	0	0	0	32	\N	0
7120832068	0	.	0	6	0	0	0	55	\N	0
5337481731	0	deventh	0	8	0	0	0	0	\N	0
1550092600	0	abby	0	4	0	0	0	9	\N	0
2130662732	0	ca	0	222	0	0	0	9	\N	0
1464687530	0	Kaká	0	7	0	0	0	33	\N	0
5721133650	0	f.	0	1	0	0	0	6	\N	0
5139967601	0	kila bbw	0	4	0	0	0	0	\N	0
6413948779	0	actually888	0	1	0	0	0	0	\N	0
5793537533	0	Daniel	0	8	0	0	0	7	\N	0
6125731207	0	Nasyanav.	0	4	0	0	0	0	\N	0
5975595361	0	ajay jagoan mama	0	2	0	0	39.19999999999999	3	\N	0
1911956466	0	lenjaa	0	11	0	0	0	14	\N	0
5182413748	0	rouwa zeill	12	174	0	0	85.89999999999782	452	\N	0
1439566714	0	ice cekek	0	2	0	0	0	2	\N	0
5099688319	0	C/BA, Renada	0	14	0	0	0	0	\N	0
6281219883	0	elsa N. JIGGER EMPIRE DNI	0	0	0	0	0	0	\N	0
1214547905	0	adi	0	18	5	0	0	4	\N	0
6861795466	0	emotionality takes control of me	0	47	0	0	0	430	\N	0
5171744654	0	tama	0	1	0	0	0	1	\N	0
1218493844	0	sabiya’s	0	7	0	0	0	275	\N	0
6630438280	0	star	0	3	0	0	0	0	\N	0
5611489505	0	Kai	0	37	0	0	0	174	\N	0
1232316560	0	👀	0	202	0	0	5	7	\N	0
6901033366	0	CW. rrw	0	2	0	0	0	1	\N	0
1192221669	0	ㅤㅤalexturner	0	1	1	0	0	2	\N	0
5452514992	0	yasa bukan manusia	0	1	0	0	0	4	\N	0
6596148039	0	Agian	0	0	0	0	0	2	\N	0
1884798812	0	r	0	7	0	0	0	44	\N	0
5363758541	0	c	0	38	0	0	165.12	3	\N	0
943724919	0	denis	0	3	0	0	0	5	\N	0
1741328387	0	ay	8	47	0	0	170	250	\N	0
1952079910	0	Lau	0	20	0	0	243	129	\N	0
1218531500	0	dJason	0	0	0	0	0	0	\N	0
1309521254	0	.Toniii	0	3	0	0	0	5	\N	0
6285283050	0	Camilla	0	1	0	0	0	0	\N	0
6141013993	0	美しい Wina	0	8	0	0	0	27	\N	0
5807378021	0	nam	0	91	0	0	0	28	\N	0
5827674600	0	alifa	0	6	0	0	0	2	\N	0
2132806079	0	vensa	0	15	0	0	0	7	\N	0
6178314996	0	Keyshaa	0	6	0	0	0	7	\N	0
6633031164	0	rearea	0	1	0	0	0	0	\N	0
6195011429	0	ⓘ 馅饼 — SAI .. ” OFF SICK	0	3	0	0	0	29	\N	0
1908498192	0	N	11	41	0	0	2321.6000000000004	30	\N	0
1856733755	0	Khalid	0	4	0	0	0	1	\N	0
1814493597	0	sza	0	1	0	0	0	1	\N	0
5002850886	0	kaivaa	0	2	0	0	0	2	\N	0
5084855798	0	salva, account wtb 🌷	0	2	0	0	0	0	\N	0
1568131856	0	stfu	0	209	0	0	0	9	\N	0
6410728326	0	Aaron	0	0	0	0	0	0	\N	0
1865573599	0	Fahrez	0	37	0	0	0	18	\N	0
5994050485	0	︎ uwin princes blububb	0	25	0	0	0	2	\N	0
2100843134	0	revan	0	1	0	0	0	0	\N	0
5897972437	0	kai suka jj	0	14	0	0	0	11	\N	0
6094398674	0	ta	0	62	0	0	0	0	\N	0
6418654321	0	Mas mas	0	0	0	0	0	0	\N	0
6438833660	0	syaa🪼	8	170	0	0	202.94999999999996	147	\N	0
5895264300	0	Raes, winter's lovetaker @uRaped	0	0	0	0	0	0	\N	0
6327507210	0	jerr	0	2	0	0	0	2	\N	0
5388748484	0	ᴧʟᴅɪ	0	1	0	0	0	0	\N	0
1736883991	0	yäyä	0	144	0	0	17.5	219	\N	0
2123481873	0	Ruhiee	0	1	0	0	0	139	\N	0
5958371356	0	Sherly	0	3	0	0	0	1	\N	0
5000705946	0	.	0	174	0	0	0	29	\N	0
6152703385	0	Jasmine k/ia	0	3	0	0	0	63	\N	0
1865232663	0	Fz	0	738	1	0	291.80999999999995	103	\N	0
5557366965	0	Sa	0	30	0	0	108.40999999999997	264	\N	0
5490679763	0	Lauriestine	0	8	0	0	0	14	\N	0
6970417063	0	jpaa	0	32	0	0	0	5	\N	0
6211763715	0	iyoo nt trs	0	1	0	0	0	3	\N	0
5705326508	0	Armada L.	0	2	0	0	0	0	\N	0
6670341957	0	aa rey.	0	3	1	0	0	8	\N	0
856462861	0	Zielvanya, UAS.	0	1	0	0	0	1	\N	0
2125907570	0	𝓡𝓮𝓷	0	22	2	0	0	0	\N	0
5191992660	0	𖤝. — ֹ {} madame - eera.	0	6	0	0	0	12	\N	0
5302653819	0	𝖘𝖆𝖆	0	2	0	0	0	4	\N	0
1837505681	0	Genta	0	176	0	0	1702.5	290	\N	0
1831685324	0	cavita	7	490	0	0	648.4599999999997	910	\N	0
1137196480	0	Apsa SamueI	0	74	0	0	0	31	\N	0
5595238862	0	naizaa spidey.	0	2	0	0	0	7	\N	0
1161950955	0	kenny	0	0	0	0	0	0	\N	0
5519297356	0	💐	0	1	0	0	0	3	\N	0
2019705637	0	strawberry shortcake	0	1	0	0	0	0	\N	0
2027319687	0	aubrey mæydoith	0	2	0	0	0	0	\N	0
1888804309	0	Drianzxz	0	6	0	0	956	7	\N	0
1616262096	0	Mina	0	1	0	0	0	1	\N	0
1400450182	0	cylaa	0	78	0	0	3.66	369	\N	0
5782091629	0	calaa	0	40	0	0	0	154	\N	0
5165907776	0	433	0	6	1	0	0	30	\N	0
1444192020	0	Cha.	0	0	0	0	0	0	\N	0
5108235044	0	kalila	0	4	0	0	0	2	\N	0
6594148157	0	m	0	1	0	0	0	1	\N	0
6366772961	0	Rinn	0	86	0	0	5.859999999999999	115	\N	0
6669464128	0	edgar	0	18	0	0	0	9	\N	0
820313913	0	.	0	28	0	0	16.24000000000015	0	\N	0
5798794221	0	Nat | Fsr 😁	0	4	0	0	0	3	\N	0
1534871633	0	jev	0	21	0	0	15	6	\N	0
2026935925	0	eve’s that girl	0	22	0	0	0	0	\N	0
5503109412	0	ibobz	0	41	0	0	0	2	\N	0
5879182576	0	celestia	0	6	0	0	0	1	\N	0
5395710021	0	aca	0	0	0	0	0	0	\N	0
5858663205	0	han jil bt cuy WTB AKUN ROBLOX BT	0	30	0	0	7.840000000000003	8	\N	0
6914312376	0	prettygurlfr	0	7	0	0	0	0	\N	0
6776858293	0	cey	0	12	0	0	0	79	\N	0
2016213491	0	Akiell	0	5	0	0	0	52	\N	0
5459235433	0	jaAaa	0	507	0	0	2.4599999999996953	329	\N	0
6555515462	0	Loraaa ror	0	10	0	0	0	20	\N	0
5763467446	0	kasa	0	116	0	0	0	57	\N	0
5702621719	0	Varsen	0	2	0	0	0	0	\N	0
5347829832	0	mithaa	0	0	0	0	0	0	\N	0
5107625702	0	.	0	127	0	0	0	5	\N	0
5496228506	0	Rest	0	3	0	0	0	0	\N	0
1922754310	0	🎐	0	7	0	0	0	16	\N	0
5976491152	0	Blasteran Spain	0	3	0	0	0	3	\N	0
7090596845	0	acac	0	1	0	0	0	0	\N	0
6225368935	0	amellll	0	6	0	0	0	0	\N	0
6291083714	0	nalala:o	0	0	0	0	0	0	\N	0
6146337996	0	.	0	12	0	0	3.32	6	\N	0
7027301712	0	fuckeveryone	0	6	0	0	2441	48	\N	0
2060989372	0	Angelyna	0	4	0	0	0	3	\N	0
1842682256	0	kay	0	45	0	0	0	1028	\N	0
6878530346	0	key	0	4	0	0	13	0	\N	0
7066534239	0	beiby	0	26	0	0	22.350000000000023	20	\N	0
1404039123	0	Akuma	0	3	0	0	0	5	\N	0
5760387014	0	v	0	2	0	0	0	0	\N	0
5057144547	0	Adit	0	6	0	0	0	3	\N	0
5176918727	0	?	0	552	0	0	-2.5	542	\N	0
5060122952	0	nakey	0	3	0	0	0	10	\N	0
6417108027	0	K	0	14	0	0	0	1	\N	0
5688808801	0	.	0	4	0	0	0	3	\N	0
1962217888	0	Jasver	0	48	0	0	1601.76	715	\N	0
5966403409	0	acila rarely active	0	3	0	0	0	0	\N	0
6568138510	0	Ruby chellsy athala Zamora Husen	0	4	0	0	0	12	\N	0
5818073905	0	Ai	0	7	0	0	32.239999999999995	20	\N	0
7163060406	0	methavia	0	12	0	0	0	31	\N	0
1879169478	0	Zaraa.	0	4	0	0	0	5	\N	0
1904372289	0	caa	0	12	0	0	0	0	\N	0
6712659472	0	Kaivan R.	0	2	0	0	0	0	\N	0
5866286481	0	.	0	1	0	0	0	13	\N	0
910319647	0	Risaaa	0	190	2	0	13	33	\N	0
2001066906	0	kylie	0	1	0	0	0	0	\N	0
6879776359	0	prabroro	0	2	0	0	0	0	\N	0
5386965813	0	Kinan Nan	3	6	0	0	90.95	11	\N	0
5216874621	0	Tian Suherman	4	39	0	0	8925.29	3349	\N	0
5618725585	0	nathalie	0	17	0	0	0	0	\N	0
5942679732	0	Liam F	0	0	0	0	72.98000000000002	0	\N	0
5739405899	0	𝓐ricia May. 𝓖eneviene	0	243	0	0	1577.8400000000001	99	\N	0
5290049058	0	joraaa	0	28	0	0	0	49	\N	0
1454491726	0	shap	0	0	0	0	0	0	\N	0
1981244897	0	Pers/Ba—Alin Daffwang	0	34	0	0	0	28	\N	0
6318779402	0	miwa	0	2	0	0	0	5	\N	0
2121990687	0	K.	0	81	0	0	3449.8599999999997	348	\N	0
5933581334	0	al	0	71	0	0	133.13000000000005	44	\N	0
1708688673	0	ㅤ	5	121	0	0	1053.8999999999999	744	\N	0
1950315356	0	Adinda	0	17	0	0	17.78	395	\N	0
1862647604	0	Oakley ᵕ̈	0	24	0	0	26.349999999999994	219	\N	0
5862447567	0	Radikta	0	7	0	0	0	1	\N	0
1718807526	0	Duchess Kaia	0	17	0	0	0	0	\N	0
5886328719	0	𝒍𝒂𝒔𝒌𝒂𝒓 𝒄𝒖𝒊𝒓𝒂𝒔𝒔	0	71	0	0	0	49	\N	0
6291560167	0	chitato	0	1	0	0	0	6	\N	0
1759522283	0	.	0	300	0	0	144.5100000000001	619	\N	0
6878456613	0	Vinci	0	146	0	0	0	17	\N	0
1844546467	0	dev	0	32	0	0	767.96	177	\N	0
5551097193	0	Jorth Ael.	0	2	0	0	0	7	\N	0
5488232212	0	daniélle.	0	3	0	0	0	66	\N	0
1710795460	1	dip.	0	24	0	0	0	0	\N	0
2131391964	0	mdm_𝓓ndstya	0	59	0	0	0	374	\N	0
1645272629	0	j	0	3	0	0	0	0	\N	0
5042799367	0	a	0	11	0	0	350.9	28	\N	0
6359734789	0	Kansa mumet	0	3	0	0	0	0	\N	0
6313613067	0	a	0	3	0	0	0	34	\N	0
1783520833	0	؜	0	15	1	0	0	8	\N	0
2039444692	0	kei pecinta botita @jienny	0	2	0	0	0	3	\N	0
5349763500	0	d	0	6	0	0	0	3	\N	0
1952658611	0	cin's	0	3	0	0	0	1	\N	0
6777054004	0	gatha	0	52	0	0	0	19	\N	0
5905110503	0	araa	0	3	0	0	0	15	\N	0
1608117661	0	Sven¹⁶⁴	0	250	0	0	2187.63	1301	\N	0
1718649550	0	Prislee.	7	232	0	0	1598.2299999999998	1623	\N	1
5174858261	0	#V1 isSsaa 4twenty	0	1002	0	0	1.6550000000000011	497	\N	0
6622851342	0	flora çytherea. @charyc	0	3	0	0	0	3	\N	0
5814025979	0	ellyna queensha	0	253	0	0	6	70	\N	0
5172062605	0	max	14	610	0	0	127.00000000000011	1112	\N	0
5142555533	0	jeje	0	169	1	0	422.7800000000002	33	\N	0
5663178326	0	biy	0	52	0	0	0	16	\N	0
6778204656	0	sid	0	80	0	0	0	750	\N	0
1193225744	0	sajepta	0	1	0	0	0	0	\N	0
6881204291	0	Vanè.	0	5	0	0	0	17	\N	0
6477429987	0	Flora	0	2	0	0	0	1	\N	0
1802010447	0	amarakei🧚‍♂	0	43	0	0	0	5	\N	0
2073501657	0	R3	0	4	0	0	0	6	\N	0
1428935889	0	Lionlymf	4	687	1	0	4138.2100000000055	238	\N	1
5735083286	0	Rahma	0	0	0	0	0	4	\N	0
1276072424	0	lee ho yeon	0	24	0	0	0	48	\N	0
6247031655	0	who?	0	141	0	0	0.8299999999999272	206	\N	0
6227134892	0	Malory Del Rey	13	511	0	0	340.80999999999995	3195	\N	1
6495263061	0	Matteo	0	1	0	0	0	0	\N	0
5438787015	0	hoggy	0	4	0	0	0	3	\N	0
1760172289	0	d	0	39	0	0	8.719999999999999	57	\N	0
1564787259	0	Zhak	0	17	0	0	0	13	\N	0
1671670640	0	.	0	17	0	0	540.1600000000001	78	\N	0
6867399379	0	˖ ࣪ ִֶָ ୨ Angie ! ୧ ˖ ࣪ ִֶָ ﹆	0	42	0	0	0	34	\N	0
1802318647	0	isha victorykingmarko	0	81	0	0	13.89	1	\N	0
5775511156	0	eyya	0	77	0	0	10.75	24	\N	0
5935875659	0	឵	0	5	0	0	213.48000000000002	7	\N	0
5511964297	0	apil	0	3	0	0	0	0	\N	0
5601123200	0	deychie.	0	1	0	0	0	3	\N	0
6455931500	0	. .ciLo ´♡	0	12	0	0	0	81	\N	0
5261379295	0	eming	6	678	1	0	1590.81	1614	\N	0
6355034696	0	cegilmarklee	0	0	0	0	0	0	\N	0
6226843471	0	.	0	9	0	0	0	29	\N	0
1590418069	0	Lucia Asyanalla	0	4	0	0	0	8	\N	0
1590330536	0	k	0	5	0	0	0	0	\N	0
2005120185	0	Adira	0	26	0	0	0	3	\N	0
5726779196	0	Tha	0	24	0	0	0	19	\N	0
1647609635	0	Стальяна	0	6	0	0	0	0	\N	0
6596056028	0	aangelll	0	61	0	0	0	20	\N	0
1823565127	0	roseee	0	13	0	0	0	1	\N	0
1443826384	0	aqil doler	0	185	0	0	1651.11	582	\N	0
6325727942	0	tier	0	10	0	0	1238.9700000000007	5	\N	0
5459981107	0	khyle	0	3	0	0	0	0	\N	0
5726721431	0	peter	0	14	0	0	0	3	\N	0
5431500441	0	Rendra	0	3	1	0	0	0	\N	0
6026289973	0	𝐊alea	0	4	0	0	0	0	\N	0
1506197006	0	fasya	0	1	0	0	0	2	\N	0
6730043667	0	Laurent K.	0	3	0	0	0	7	\N	0
1398352492	0	hei!	0	3	0	0	63.26999999999992	16	\N	0
6103096466	0	jennifer	0	3	0	0	46.04	6	\N	0
5911570407	0	Vist	0	2	0	0	0	32	\N	0
6379045713	0	raraa	0	1	0	0	0	0	\N	0
2131005762	0	Vikri	0	1	0	0	0	0	\N	0
1821958802	0	𓈒♡̷̷̷ ◟ ࣪🪸 вχzєт³ nala ! #OPLINKBOSS #CANDMVK #OPLINKPTR	0	9	0	0	0	15	\N	0
7149361077	0	A	0	2	0	0	0	0	\N	0
1942337165	0	Helia Wyrthaleen.	0	0	0	0	0	0	\N	0
5239386266	0	Jiwa	0	48	0	0	100	122	\N	0
1505298914	0	matt	0	33	0	0	0	149	\N	0
5670779624	0	Aury	0	18	0	0	0	2	\N	0
5691678841	0	.	0	1	0	0	0	5	\N	0
1944961417	0	ndi	0	1	0	0	0	0	\N	0
1762268316	0	Will	0	0	0	0	0	12	\N	0
5992721702	0	hekal	5	56	0	0	1949.5999999999995	429	\N	1
1723074434	0	Jayden, doler	0	1	0	0	0	1	\N	0
6793852929	0	asisst ajiw	0	3	0	0	0	1	\N	0
1674336384	0	queenshaa	0	20	0	0	0	9	\N	0
1931076456	0	366jagat sbøz🇬🇺	0	2	0	0	0	0	\N	0
5025250062	0	jenar	0	4	0	0	1438.06	32	\N	0
1715464547	0	na	0	3	0	0	0	0	\N	0
5584940988	0	ôniii 🇮🇹	0	23	0	0	0	46	\N	0
1944167237	0	Shaciel.	0	1	0	0	0	3	\N	0
1782546598	0	Kyy	0	20	0	0	0	1	\N	0
5143018324	0	aceyy	0	2	0	0	0	3	\N	0
1458352400	0	cening	0	3	0	0	0	7	\N	0
5219545978	0	ur fckin lil slut, seeya.	0	51	0	0	0	6	\N	0
5117260520	0	renzi	0	1	0	0	0	0	\N	0
5995943543	0	Nia	0	0	0	0	0	3	\N	0
6527475461	0	JEJE	0	11	0	0	0	95	\N	0
6086312327	0	kalea	0	12	0	0	0	12	\N	0
5969321908	0	Este	0	42	0	0	465.02	0	\N	0
1879716467	0	padil	0	0	0	0	0	0	\N	0
1897267769	0	rex 323	0	157	0	0	376	307	\N	0
6542130038	0	Cyaa	0	6	0	0	0	1	\N	0
1824717722	0	Divera	0	8	0	0	0	12	\N	0
5195305846	0	Emmanuelle, on duty.	0	2	0	0	0	0	\N	0
5193997685	0	esteve.	0	145	0	0	0	2	\N	0
1760124986	0	Abel，831<3.	0	2	0	0	0	0	\N	0
6745268651	0	Zaii	0	1	0	0	0	0	\N	0
1806053400	0	cisi	0	25	0	0	0	2	\N	0
6006602024	0	carina	0	3	0	0	0	0	\N	0
1837463101	0	n aya	0	2	0	0	0	0	\N	0
6519517984	0	L	0	12	0	0	0	55	\N	0
1569962075	0	🥛	0	0	0	0	0	0	\N	0
5466547735	0	nao	9	137	0	0	2545.2899999999995	532	\N	0
6394165660	0	z¡a	0	102	0	0	5.940000000000055	78	\N	0
6963469782	0	kath	0	62	0	0	0	40	\N	0
6104672218	0	an suka bio	0	5	0	0	0	19	\N	0
6505825657	0	nuvel	0	5	0	0	0	5	\N	0
1771250643	0	keii	0	3	0	0	0	0	\N	0
1428605200	0	harvey	0	1	0	0	0	0	\N	0
1378823321	0	X	0	75	0	0	958.72	4	\N	0
6462765022	0	chessiee	0	3	0	0	0	0	\N	0
5083999072	0	dede bayi	0	160	0	0	284.20000000000005	627	\N	0
5352219509	0	reinachandesu	9	95	0	0	9.8	300	\N	0
6154015149	0	Vederick Hegalouise.	0	2	0	0	0	11	\N	0
5972047996	0	Zia	0	4	0	0	0	0	\N	0
2114505725	0	GUN-PARK.	0	58	0	0	0	19	\N	0
1751140368	0	jemi suka bebek	0	99	0	0	0	17	\N	0
5732265840	0	Petrick	0	191	0	0	44.09000000000019	4	\N	0
5156427446	0	𝐴𝑙𝐹𝑖	0	15	0	0	0	27	\N	0
1722270928	0	Aneet	0	19	0	0	203.4	207	\N	0
5573519994	0	Mayra DNFI	0	1	0	0	0	0	\N	0
1436151186	0	ㅤ	0	119	0	0	0	113	\N	0
1833935712	0	naomi	12	966	0	0	36.36999999999949	5637	\N	1
1979230030	0	lula	0	126	0	0	0	131	\N	0
5206943457	0	Jafar.	0	1	0	0	0	0	\N	0
1961116499	0	v	0	10	0	0	0	4	\N	0
1689770414	0	Hugo	0	1	0	0	5.95	109	\N	0
5349025295	0	Sipaa 🫰🏻.	9	773	0	0	1508.9800000000014	643	\N	0
1962923578	0	dipdipdip	0	503	0	0	0	515	\N	0
6896260702	0	del	0	5	0	0	0	0	\N	0
5826426488	0	ell's. </3	0	4	0	0	0	0	\N	0
1775696443	0	J	0	4	0	0	0	0	\N	0
1710836842	0	ayaa	0	4	0	0	0	0	\N	0
6042964126	0	arash.	0	1	0	0	0	1	\N	0
1934794762	0	caren scn	0	2	0	0	0	5	\N	0
6302909630	0	No	0	6	0	0	0	5	\N	0
5346075194	0	Raphael.	0	8	0	0	0	0	\N	0
1312933119	0	Denka	0	22	0	0	11.36	179	\N	0
2129287730	0	xuyu	0	10	0	0	0	0	\N	0
6754744951	0	kania	0	5	0	0	215.08	7	\N	0
6015334505	0	Jisaa	0	8	0	0	0	2	\N	0
5418761360	0	¯⁠\\⁠_⁠༼⁠ ⁠•́⁠ ͜⁠ʖ⁠ ⁠•̀⁠ ⁠༽⁠_⁠/⁠¯	0	21	0	0	0	14	\N	0
5370699007	0	kela	0	19	0	0	0	92	\N	0
1919557927	0	alicia	0	86	0	0	0	110	\N	0
6161619230	0	LouiSe 🌺	0	27	0	0	0	28	\N	0
2013029633	0	Zazaa	0	3	0	0	0	2	\N	0
5878931777	0	ica	0	1	0	0	0	0	\N	0
6794000612	0	Libby	0	26	0	0	0	5	\N	0
5880875050	0	araa	0	2	0	0	0	0	\N	0
6878743699	0	ㅤ	0	1	0	0	0	0	\N	0
548114859	0	Neela	0	2	0	0	0	0	\N	0
5575281164	0	kerta	0	15	0	0	0	3	\N	0
5045659331	0	Doyaemong	0	1	0	0	0	0	\N	0
1441349120	0	el	0	3	0	0	0	1	\N	0
5214787706	0	𝓡aini	0	1	0	0	0	0	\N	0
6757216125	0	.	0	3	0	0	0	1	\N	0
5994009692	0	gohan	0	1	0	0	0	0	\N	0
5942509598	0	Sagufta Kiansa.	0	74	0	0	0	2	\N	0
2005367107	0	cca	0	37	0	0	2.35	144	\N	0
2111122976	0	ayy #CALMEMWIKKY	0	341	0	0	5150.270000000001	961	\N	0
1947400632	0	derby! sencãzmojanawp 🇧🇩	0	15	0	0	0	2	\N	0
1713663216	0	ra	0	2	0	0	77.75	0	\N	0
6502659009	0	arsena, rechat	0	3	0	0	0	0	\N	0
1965859088	0	あ . kαjeα ¡! 🎸	0	5	0	0	0	1	\N	0
2125928818	0	🦁	0	9	0	0	0	5	\N	0
969502235	0	papazola	0	12	0	0	0	18	\N	0
1344898734	0	bey.	0	0	0	0	1230	0	\N	0
5183382424	0	leaa, sabarr lagi limitt	0	1	0	0	0	0	\N	0
5645955715	0	𝙎𝙞𝙧 𝙈	0	0	0	0	0	17	\N	0
5960876435	0	cipeyyy - 🧙🏼‍♂️ Batak!	0	6	0	0	0	7	\N	0
1594052519	0	vann	12	206	0	0	87.34	1734	\N	0
1480319701	0	¡!zeaa!¡ʰᵒᵍʷᵃʳᵗˢ'ʰᵒᵐⁱᵉ	0	12	0	0	0	3	\N	0
6235021368	0	achaaa	0	1	0	0	0	0	\N	0
6867869592	0	nami	10	15	0	0	3.39	68	\N	0
1832703014	0	lynx	0	21	0	0	0	41	\N	0
1894819355	0	sashi	0	1	0	0	0	0	\N	0
2103556753	0	alcy !!	0	22	0	0	0	57	\N	0
6162721771	0	ayya	0	1	0	0	0	0	\N	0
6629119549	0	chan?	0	3	0	0	0	3	\N	0
1943596527	0	jeA	0	1268	0	0	1354.8925	2584	\N	0
1189615089	0	El	0	1	0	0	0	1	\N	0
6639012824	0	syifaaa🍭	0	0	0	0	0	1	\N	0
1159239645	0	Gaa	0	8	0	0	0	7	\N	0
5956674932	0	縮簸絵化	0	3	0	0	0	14	\N	0
6687054726	0	gweth	0	3	0	0	1000	0	\N	0
5125204282	0	mangosteen	0	8	0	0	19.51	22	\N	0
5264240835	0	keyshi	10	183	0	0	413.07000000000005	489	\N	0
6856944485	0	ciwa	0	1	0	0	0	0	\N	0
5609369546	0	faye	0	16	0	0	0	99	\N	0
5947807755	0	acel	0	3	0	0	0	7	\N	0
5685952815	0	Keba	0	5	0	0	0	15	\N	0
6295843472	0	KEVASHA.	0	6	0	0	0	1	\N	0
6313371654	0	wifia	0	1	0	0	0	0	\N	0
5635759727	0	biann	0	65	0	0	84.45999999999998	37	\N	0
5952744523	0	Ashery.	0	8	0	0	0	0	\N	0
1807553417	0	morgan	0	37	0	0	1975.2500000000007	647	\N	0
1763066115	0	4	0	7	0	0	0	0	\N	0
6129262108	0	ninin	0	0	0	0	0	0	\N	0
5818470619	0	pasyaa	1	708	0	0	278.43	2795	\N	0
5060977248	0	⤫ 𝐃𝐨𝐧 𝐆𝐢𝐨𝐫𝐠𝐢𝐧𝐨 .𝐉 𓃬 ♔	0	2	0	0	0	1	\N	0
6984981649	0	Flynn R. Asenath	0	2	0	0	49.57	3	\N	0
6093132124	0	matteoo`𝔰𝔦𝔞	0	14	0	0	0	0	\N	0
6553478727	0	𝘼𝙧𝙠𝙝𝙖𝙫𝙖 𝙖𝙠𝙝𝙩𝙖𝙧	0	31	0	0	0.6600000000000001	31	\N	0
6746062556	0	.	0	28	0	0	0	5	\N	0
6267819842	0	az	0	221	0	0	16.03	36	\N	0
1962811529	0	Sndraa	0	9	0	0	0	22	\N	0
6618466318	0	C	0	2	0	0	0	0	\N	0
1635134868	0	𝐊irey	0	1	0	0	0	0	\N	0
5043023621	0	piya itu ncaa	0	7	0	0	0	65	\N	0
7104939043	0	dom	0	0	0	0	0	0	\N	0
2054885011	0	Nayia Lubby, anak²	0	24	0	0	0	25	\N	0
5862412268	0	Naru	0	13	0	0	0	3	\N	0
5346506831	0	ala	0	3	0	0	0	1	\N	0
6769818155	0	leA	0	4	0	0	0	0	\N	0
1950101476	0	Rayy	0	4	0	0	0	2	\N	0
1843545366	0	zero	0	18	0	0	0	0	\N	0
5849912097	0	Michael E.	0	105	0	0	15.210000000000008	569	\N	0
2082105711	0	joèry cloud	0	0	0	0	0	0	\N	0
7124753986	0	arutala	0	1	0	0	0	0	\N	0
1923222372	0	a	0	4	0	0	0	25	\N	0
1750472851	0	sasha	0	17	0	0	0	60	\N	0
5328865846	0	rinaaaww	0	1	0	0	0	0	\N	0
5083939872	0	aya	0	520	0	0	0	104	\N	0
6889147937	0	zvnyyy	0	3	0	0	0	0	\N	0
1681778646	0	alma	0	10	0	0	0	22	\N	0
1568415626	0	dngs	0	9	0	0	0	1	\N	0
1332048216	0	r	0	59	0	0	0	4	\N	0
6173714810	0	𝖑𝖞𝖆𝖆	0	36	0	0	0	83	\N	0
1170737847	0	0.9	0	5	0	0	0	5	\N	0
6557748899	0	Dimas	0	7	0	0	0	24	\N	0
1530773779	0	w	0	81	0	0	0	136	\N	0
1942452111	0	W	0	10	0	0	16.2	1	\N	0
5183836206	0	auffa rocita rahmadani	0	1	0	0	0	4	\N	0
1918999364	0	⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣	5	87	0	0	564.96	115	\N	0
6351172894	0	Sabiru.	0	5	0	0	0	15	\N	0
5978624361	0	lizzy	0	9	0	0	0	78	\N	0
1706755407	0	Naell.	0	1	0	0	0	1	\N	0
5647474559	0	Jorgan'ez Vient.	0	3	0	0	0	0	\N	0
5608863747	0	Son	0	2	0	0	0	4	\N	0
6254863355	0	Genzy	0	1	0	0	0	0	\N	0
6925401809	0	KEILA 🧚🏻‍♀️	0	14	0	0	0	62	\N	0
1904835784	0	do	0	7	0	0	7.089999999999918	5	\N	0
6808695353	0	What do u think?	0	0	0	0	0	29	\N	0
1879557405	0	queen	0	18	0	0	0	65	\N	0
5091047723	0	Mita.	0	188	1	0	105.45999999999998	899	\N	1
5318550296	0	fel, selective y	0	261	0	0	20.389999999999844	27	\N	0
2127368755	0	haileey	0	9	0	0	0	0	\N	0
6291335694	0	Keeva.	0	230	0	0	6.87000000000015	217	\N	0
1796994319	0	Lasika	0	0	0	0	0	0	\N	0
2142610094	0	Na	0	64	0	0	478	49	\N	0
5554439545	0	ᴠɪʀɢᴏ	0	1	0	0	0	2	\N	0
6524826849	0	Biu	0	1	0	0	0	0	\N	0
2075793757	0	Kale.	9	554	0	0	3.9999999999995453	5526	\N	0
5635761388	0	Katherine	0	3	0	0	0	4	\N	0
1707975258	0	pinci	0	1	0	0	0	0	\N	0
5155584786	0	Milea, 🩰	0	44	0	0	0	4	\N	0
5082346430	0	rizta bocil esempe	0	1	0	0	0	3	\N	0
5599212124	0	𔘓. Cillãyshie >__< !	0	5	0	0	0	0	\N	0
5862235407	0	cy ping 🎀🎀	0	3	0	0	0	0	\N	0
1982920163	0	L	0	36	0	0	0	51	\N	0
1801248505	0	Gentara	0	1	0	0	0	0	\N	0
5130656251	0	morroll	0	16	0	0	134	67	\N	0
5375104426	0	jaerico	0	65	0	0	0	248	\N	0
5758109698	0	bila	0	3	0	0	0	8	\N	0
1759264333	0	?	0	40	0	0	0	63	\N	0
5806242340	0	Ara:3	0	19	0	0	3.3500000000000014	0	\N	0
1221540827	0	Lin :3	0	2	0	0	0	1	\N	0
6913752096	0	ℌ. @YMlRRSAMA	0	0	0	0	0	0	\N	0
1611822241	0	Dey	0	92	0	0	2754	1	\N	0
5940695953	0	argi	0	84	0	0	-3.1400000000000006	115	\N	0
1451732015	0	Farhan	0	2	0	0	0	12	\N	0
1028796625	0	Vini Jr	0	9	0	0	0	2	\N	0
5892894577	0	chanèlia	0	58	0	0	241	108	\N	0
6869338052	0	Jelly 4twenty 💭	0	2	0	0	0	5	\N	0
2083056467	0	Calistaaa! ஐ	0	1	0	0	0	0	\N	0
6920935880	0	zaki	0	4	0	0	0	2	\N	0
1607650433	0	𝕺ktaviō Ãlgarvē	0	9	0	0	0	15	\N	0
5130580681	0	F	0	1	0	0	0	3	\N	0
6001284867	0	reyaa	0	4	0	0	0	8	\N	0
7028256961	0	bonyok	0	8	0	0	0	0	\N	0
6104700428	0	ais	0	6	0	0	0	1	\N	0
5969949111	0	thea	0	1	0	0	0	3	\N	0
1420187861	0	Junhui	0	21	0	0	0	9	\N	0
5200300946	0	wle wle wle	0	1266	0	0	216.34999999999997	1786	\N	0
1198351499	0	Lasa-nonelse	0	23	0	0	229.69000000000005	680	\N	0
5299189330	0	anka	0	5	0	0	0	1	\N	0
5748185778	0	candala	0	4	0	0	0	18	\N	0
6478982279	0	vimcel skay	0	2	0	0	0	4	\N	0
5337005149	0	Denada.	0	1	0	0	0	0	\N	0
6163028362	0	Josie miaw - miaw🐈💭	0	0	0	0	0	11	\N	0
1731175024	0	Ada Wong	0	1	0	0	0	22	\N	0
1824159752	0	riv	0	1	0	0	0	0	\N	0
2117713016	0	Work yeon	0	1	0	0	0	0	\N	0
1892324177	0	c	0	7	0	0	0	1	\N	0
5124059309	0	navis .r	0	1	0	0	0	0	\N	0
1744523758	0	yelenaivy	0	1	0	0	0	0	\N	0
5516429867	0	rysh	0	89	0	0	7	77	\N	0
5018779235	0	Cainfon	0	4	0	0	0	34	\N	0
5498902682	0	davin	0	192	0	0	4.060000000000002	67	\N	0
5431700724	0	ly	0	128	0	0	0	37	\N	0
6947474847	0	jey	10	30	0	0	2196.73	1186	\N	0
6485542351	0	florence	1	167	0	0	1896.42	2275	\N	0
5126102929	0	g	0	12	0	0	0	13	\N	0
1673388267	0	Clevy	0	3	0	0	0	1	\N	0
1858195876	0	AJie	0	9	0	0	0	3	\N	0
2028343014	0	rest) vgu². Arièsha	0	2	0	0	0	0	\N	0
6588994093	0	el	0	17	0	0	11	0	\N	0
1702205413	0	Cansie on resting	0	3	0	0	0	0	\N	0
5823852076	0	Atlanna—S.	0	1	0	0	0	11	\N	0
5024321916	0	r	0	1	0	0	0	0	\N	0
1771997099	0	129. bira	0	1	0	0	0	1	\N	0
6000729832	0	ra	0	1	0	0	0	1	\N	0
6595260753	0	dika 𝐀𝟗𝟕	0	0	0	0	0	18	\N	0
6946190463	0	발레 Livae	0	1	0	0	0	0	\N	0
1221106612	0	Matthew Setiaji	0	1	0	0	0	6	\N	0
5662145836	0	Arsen Eprhaine.	0	8	0	0	0	5	\N	0
5074627528	0	cc	0	12	0	0	0	14	\N	0
5915027985	0	isaa	0	5	0	0	0	2	\N	0
1950830232	0	ale	0	13	0	0	0	2	\N	0
5921232545	0	Fira	0	1	0	0	0	1	\N	0
6987030087	0	oni	0	1	0	0	0	0	\N	0
1813423751	0	suipad	0	7	0	0	0	21	\N	0
5331028184	0	𓂋⁺˳ 🐈📦⟆ ddeAa!!＿<	13	418	0	0	1192.0499999999997	1127	\N	0
6194801397	0	.LULAA	0	0	0	0	0	0	\N	0
1903523285	0	riel :p	0	1	0	0	0	0	\N	0
5608165733	0	md	0	35	0	0	4.760000000000105	116	\N	0
6063228785	0	Aruna M Rachelle	0	1	0	0	0	1	\N	0
1705780185	0	na'ilah andira syaputri	0	2	0	0	0	0	\N	0
6733937489	0	ziea	0	1	0	0	0	0	\N	0
6295201746	0	nazala, kinda selective chat.	0	3	0	0	0	3	\N	0
1710510825	0	nar benzema	0	11	0	0	0	47	\N	0
5733747755	0	sorai	0	71	0	0	0	189	\N	0
5272238363	0	L	0	196	0	0	78.89	266	\N	0
2005686351	0	Nazel 🕷 slv	0	1	0	0	0	2	\N	0
5001325491	0	jepa	0	119	0	0	31.5	38	\N	0
6243232596	0	🙌🏻	0	1	0	0	0	1	\N	0
1964006499	0	abel	0	467	0	0	0	0	\N	0
5702025257	0	na	0	5	1	0	0	0	\N	0
1774661659	0	pi tu de yo	12	616	0	0	32566.43999999996	43345	\N	1
5249771176	0	mtw𝐃nz. Matreo's	0	7	0	0	0	8	\N	0
2068568068	0	olaaa	0	34	0	0	0	61	\N	0
1603011394	0	Mathius	0	2	0	0	0	0	\N	0
5599424837	0	ler	0	2	0	0	0	49	\N	0
6947405875	0	alle	0	2	0	0	0	0	\N	0
1741302680	0	Milosky 🔞	0	1	0	0	0	0	\N	0
1647920635	0	Yue	0	1	0	0	0	1	\N	0
1452461914	0	loh	0	26	0	0	0	35	\N	0
6958384664	0	rachel	0	10	0	0	0	35	\N	0
6750074208	0	Marianoooooo	0	1	0	0	0	1	\N	0
1738468581	0	Alea	0	0	0	0	0	0	\N	0
5630684335	0	Magyn	0	22	0	0	0	0	\N	0
1010608754	0	asha	0	218	0	0	0	0	\N	0
5351472113	0	kaykaykay	0	11	0	0	0	11	\N	0
1771882576	0	nebulaa	0	1	0	0	0	0	\N	0
5276079558	0	eung	0	23	0	0	0	0	\N	0
5710097514	0	Meong	0	8	0	0	0	10	\N	0
5214526339	0	ikiii	0	4	0	0	0	1	\N	0
1798573318	0	.	0	2	0	0	0	2	\N	0
6767669047	0	yayaa	0	2	0	0	0	1	\N	0
5566231969	0	ca.	0	9	0	0	18.3	138	\N	0
6939537116	0	Baras	0	3	0	0	0	2	\N	0
1444964208	0	𝐍escha	0	5	0	0	0	0	\N	0
6243750339	0	noah	0	7	0	0	0	29	\N	0
6569254843	0	MISYA—⁠	0	3	0	0	0	37	\N	0
2032711745	0	raya	0	2	0	0	0	4	\N	0
1945239604	0	ㅤnadyaa,	0	1	0	0	0	12	\N	0
6951189104	0	jevrine	0	17	0	0	0	81	\N	0
6592571895	0	fn	0	1	0	0	0	0	\N	0
2083490050	0	kei	0	3	0	0	0	0	\N	0
2024997382	0	Arfa J.	0	73	0	0	433.42999999999995	57	\N	0
6100842340	0	J	0	4	0	0	0	0	\N	0
5787673910	0	Stupid Cumdump, Aira	0	2	0	0	0	0	\N	0
2143100075	0	k o s o n g	0	17	0	0	0	6	\N	0
6828450488	0	Jex	0	3	0	0	0	2	\N	0
5479523110	0	Rajendra	0	1	0	0	0	1	\N	0
2079363553	0	kaizar	0	0	0	0	0	0	\N	0
5622557160	0	io	0	0	0	0	0	0	\N	0
6137077054	0	Anna	0	1	0	0	0	0	\N	0
1965911223	0	clove	0	10	0	0	941.9399999999999	95	\N	0
1758053633	0	faisal	0	9	0	0	0	0	\N	0
5960468050	0	Revandra	0	3	0	0	0	1	\N	0
1331932526	0	.	0	1	0	0	0	7	\N	0
5850315554	0	jiaaaa	0	33	0	0	0	106	\N	0
5374525177	0	jidan	0	3	0	0	0	0	\N	0
6859266449	0	rest	0	64	0	0	0	150	\N	0
6685297485	0	rrAaalaa	0	1	0	0	0	0	\N	0
5932326178	0	Jiyya	0	2	0	0	2.05	239	\N	0
6419222460	0	Malik	0	1	0	0	0	0	\N	0
5996978925	0	Matthew	0	55	0	0	31.259999999999998	7	\N	0
5095929148	0	e.	0	418	0	0	12.919999999999987	18	\N	0
1712776328	0	ataaaaa	0	126	1	0	0	2	\N	0
927065588	0	rexa, dni	0	202	0	0	990.7700000000001	12	\N	0
6982885102	0	na	0	7	0	0	0	0	\N	0
5630648081	0	fuckih	0	16	0	0	166.77999999999997	245	\N	0
5796734131	0	Joleo's lovetaker, Teyashe.	0	74	0	0	456	162	\N	0
1721621007	0	Mella.	0	9	0	0	0	3	\N	0
5220213676	0	kajidul_____________<< *wuff* *wuff* 🤖👅🦔🍄☝️	0	7	0	0	0	2	\N	0
6304073128	0	Re	0	2	0	0	0	0	\N	0
6587766482	0	ri	0	16	0	0	0	5	\N	0
5252042482	0	adeline	0	2	0	0	0	13	\N	0
1724297922	0	jacqueline	0	25	0	0	0	61	\N	0
2012353313	0	.	0	144	0	0	0	14	\N	0
1289945605	0	niel	0	1	0	0	0	0	\N	0
5428736579	0	proses garansi jam 18.00-21.00	0	4	0	0	0	0	\N	0
7016630125	0	Nfann	0	1	0	0	0	0	\N	0
1705400679	0	nonee	0	6	0	0	0	25	\N	0
6161883762	0	🦋	0	0	0	0	0	1	\N	0
2102273989	0	ᴊᴀɴᴇ	0	4	0	0	0	1	\N	0
5115581966	0	rafa	0	4	0	0	0	19	\N	0
5062211825	0	ghefira	0	1	0	0	0	0	\N	0
1306790468	0	bayy	5	21	0	0	69.05	1	\N	0
5184246090	0	Aulia XII (17)	0	1	0	0	0	0	\N	0
5405972319	0	Pramuditya.	0	38	0	0	-2	294	\N	0
5101178700	0	𐙚˙ " yasminë .. "	0	0	0	0	0	0	\N	0
5414058548	0	Jiechaira	0	58	0	0	371.38	2	\N	0
6801782246	0	mai	0	14	0	0	0	6	\N	0
2104627676	0	Adirans	0	2	0	0	0	3	\N	0
5482043956	0	dna	0	2	0	0	0	1	\N	0
6669325350	0	ciaa	0	0	0	0	0	4	\N	0
5057797357	0	Jo	0	1	0	0	0	2	\N	0
5972329905	0	Melody.	0	356	0	0	814.6899999999998	851	\N	0
5800388040	0	.	0	5	0	0	0	1	\N	0
5795706301	0	ale	0	0	0	0	0	0	\N	0
6486155238	0	Keigo Macnare.	0	1	0	0	0	0	\N	0
6548807527	0	@.	0	2	0	0	0	7	\N	0
6259596907	0	2nd gloS	6	88	0	0	23.110000000000582	543	\N	0
1479631584	0	Dikta Candradinata	0	53	0	0	0	358	\N	0
5395767037	0	azlan	0	6	0	0	0	4	\N	0
1705351343	0	aca	0	2	0	0	0	1	\N	0
5345016478	0	siroo	13	62	0	0	13.129999999999999	16	\N	0
5445311320	0	Ado	0	124	0	0	0	565	\N	0
5895702809	0	nop	0	14	0	0	0	62	\N	0
5538911088	0	shneen 𝘣𝘳𝘸	0	2	0	0	0	3	\N	0
6476753118	0	key	0	1	0	0	0	1	\N	0
1042740339	0	asya	0	22	0	0	0	8	\N	0
6427360402	0	séna marquez 93 #UdahTobat	0	31	1	0	0	124	\N	0
5176192635	0	Ragaz Vion Wylliam	0	1	0	0	0	8	\N	0
1482717643	0	cheya, t	0	64	0	0	42.28999999999978	31	\N	0
7185575132	0	naw (centil era)	0	8	0	0	0	7	\N	0
2063313010	0	︎︎︎ ︎︎︎ ︎︎︎ fLíí.	0	11	0	0	0	5	\N	0
1221469736	0	baron intisirkth	0	224	1	0	205.07000000000002	86	\N	0
6561721735	0	ray	0	2	0	0	0	0	\N	0
1767986247	0	Jove	0	15	0	0	0	25	\N	0
1830675731	0	Zeyranaa $̷ㅤㅤㅤㅤ	0	3	0	0	32.12	0	\N	0
1762582623	0	jeno pacarku	0	8	0	0	0	0	\N	0
1093054698	0	M	0	1	0	0	0	0	\N	0
1789676877	0	panda	0	3	0	0	0	0	\N	0
2016441973	0	Abe	0	1	0	0	0	0	\N	0
6813523685	0	🌷💞🩰💭🎀	0	2	0	0	0	0	\N	0
5222299928	0	Rindou @haitnai	0	24	0	0	0	3	\N	0
5922217042	0	anzah	11	15	0	0	627.17	9	\N	0
5745634376	0	ʀɪsʜ	0	63	0	0	10.61	60	\N	0
5228026843	0	lilioioi	0	162	0	0	316.5	41	\N	0
6686366401	0	??	0	1	0	0	0	0	\N	0
5938162024	0	Aiman	0	4	0	0	0	18	\N	0
2002157109	0	raa anjai	0	9	0	0	61.32999999999969	27	\N	0
7176501964	0	elya	0	3	0	0	0	0	\N	0
5842172855	0	sya	0	37	0	0	297.59000000000003	184	\N	0
1978115302	0	ㅤBar	0	1	0	0	0	0	\N	0
1663109291	0	Dhitoo	0	54	0	0	0	0	\N	0
5992457877	0	Jyeesha's sec.	0	1	0	0	0	0	\N	0
6139889992	0	sa	0	2	0	0	0	1	\N	0
2054704293	0	j	0	3	0	0	0	0	\N	0
5447988253	0	cii	0	32	0	0	0	24	\N	0
5478996825	0	l	0	10	0	0	0	17	\N	0
1805663889	0	K.	0	0	0	0	0	0	\N	0
5527892561	0	kyle	9	0	0	0	307.82000000000005	1	\N	0
5366204489	0	Aysel Maverick J.	0	27	0	0	64.4000000000002	54	\N	0
1900274464	0	?	0	1	0	0	0	1	\N	0
6723682794	0	lennn	0	3	0	0	0	11	\N	0
6568584169	1	Keenan G.	0	44	0	0	0	2	\N	0
2036505844	0	127. adisa	0	6	0	0	0	2	\N	0
6836004782	0	chloé <3	0	11	0	0	0	38	\N	0
1523933854	0	Gal	0	1	0	0	0	7	\N	0
7068272096	0	k	0	4	0	0	0	8	\N	0
5992749123	0	Leora Betmen [𝐒𝐕𝐇𝟑𝟏]ᴰ⁸	0	0	0	0	0	0	\N	0
1284953666	0	OWL ₒᵣₜₓ	0	2	0	0	0	3	\N	0
1752962740	0	ruby.	0	0	0	0	0	0	\N	0
5648782525	0	船⁵ haegii rrw . rest	0	13	0	0	0	0	\N	0
5839933715	0	dey	0	3	0	0	0	2	\N	0
6100094634	0	layla henle	0	15	0	0	68.4	704	\N	0
5631017640	0	jijiiiii	0	23	0	0	626	2	\N	0
5620243553	0	zzzz	0	18	0	0	0	4	\N	0
5952131215	0	Eleanor	11	510	0	0	103.95999999999975	17	\N	0
5032476201	0	J	0	6	0	0	0	4	\N	0
6552655789	0	A N D O	0	35	0	0	268.81	673	\N	0
5220286823	0	Sanjiii	0	5	0	0	0	13	\N	0
1767546428	0	A	0	2	0	0	0	7	\N	0
1390775176	0	gege	0	1	0	0	0	0	\N	0
5440541087	0	shindi	0	155	0	0	0	86	\N	0
1883047204	0	im tired.	0	1093	0	0	28.200000000000045	271	\N	0
6257707727	0	val	0	9	0	0	0	30	\N	0
1323438722	0	long rest.	0	199	0	0	0	96	\N	0
1306138162	0	yr	0	1	0	0	0	1	\N	0
1878065806	0	cyrarara	13	842	0	0	1212.0400000000002	1137	\N	1
5292461530	0	ㅤal	0	170	0	0	0	2	\N	0
1492590247	0	adammmmmm	0	1	0	0	0	0	\N	0
6462016162	0	Sa	0	3	0	0	0	1	\N	0
1711291984	0	zaiden	0	2	0	0	0	2	\N	0
5531329194	0	Kakaa	0	1	0	0	0	0	\N	0
5319414250	0	𝐉𝐞𝐨𝐧𝐧𝐚 ✧. ┊ ⁭ ⁭ KOK FURINA PULANG	0	3	0	0	0	12	\N	0
5194509752	0	Jaguar	0	18	0	0	0	26	\N	0
1832130233	0	chelsea	0	15	0	0	0	2	\N	0
1998061702	0	n	0	2	0	0	0	0	\N	0
1926337082	0	aji	0	9	0	0	0	2	\N	0
6944182888	0	y	0	27	0	0	0	38	\N	0
6723334299	0	araaaa	0	2	0	0	0	3	\N	0
1391846011	0	yosfe	0	8	0	0	0	14	\N	0
1959693035	0	ecel	13	98	0	0	2836.869999999997	2147	\N	1
6013279980	0	35	11	70	0	0	49.25999999999931	13	\N	0
6493154393	0	bianca	0	3	0	0	0	1	\N	0
2099894236	0	Bavi	0	2	0	0	0	0	\N	0
5790965864	0	clara :p	0	3	0	0	0	5	\N	0
6693324786	0	bria	0	2	0	0	0	4	\N	0
6743613376	0	nnswa	0	1	0	0	0	2	\N	0
1179801563	0	Bara	0	7	0	0	0	58	\N	0
7058639877	0	🇵🇸🇵🇸🇵🇸	0	6	0	0	0	86	\N	0
1694266520	0	𝐀yden	0	1	0	0	0	0	\N	0
5504614079	0	𝗼𝗹𝘇 . 🎧	0	5	0	0	0	27	\N	0
1209996969	0	Azle	0	15	0	0	0	18	\N	0
1763349803	0	twyllaphia, b.	10	93	0	0	2825.160000000001	1051	\N	1
1559936872	0	mérindaanne	0	0	0	0	0	1	\N	0
5334130859	0	🧚🏻‍♀️🧚🏻‍♀️. peri sedih	0	147	0	0	-14.517499999999991	0	\N	0
1896046839	0	a.	0	66	0	0	0	114	\N	0
5710881874	0	Rafael	0	3	0	0	0	19	\N	0
5024689287	0	hanee meow	0	219	0	0	1197.5	17749	\N	0
6444161823	0	Rey?	0	4	0	0	0	1	\N	0
5267984690	0	miawey-ie! :P	0	5	0	0	0	25	\N	0
6538270016	0	Vew	0	1	0	0	0	11	\N	0
6933129426	0	🙍🏻‍♀️	0	1	0	0	0	2	\N	0
1410802797	0	atara	0	12	0	0	0	25	\N	0
6803597615	0	.	0	1	0	0	0	0	\N	0
1650734648	0	.	0	2	0	0	0	0	\N	0
1926066734	0	jew	0	2	0	0	0	0	\N	0
5990476888	0	abi	0	3	0	0	0	2	\N	0
6850777723	0	sasa	0	3	0	0	0	0	\N	0
6926373696	0	🎸 . . 유진, Alkà > hottest mami	0	2	0	0	0	4	\N	0
6175786447	0	Nayma	0	18	0	0	8.2	5	\N	0
6256632823	0	hinata	0	4	0	0	0	3	\N	0
6017397161	0	claura	0	12	0	0	0	39	\N	0
1707259232	0	Cey	0	316	0	0	59.269999999999996	634	\N	0
2125810956	0	andra	8	271	0	0	2834.2800000000166	1376	\N	1
6266436168	0	bian	0	159	0	0	8.310000000000088	421	\N	0
6431269992	0	your little kitten ,rachel.	0	3	0	0	0	0	\N	0
2007806686	0	Mario's gf, Kanina A.	0	12	0	0	0	267	\N	0
6725494531	0	Eileithya Lily.	0	1	0	0	0	0	\N	0
6795954884	0	Rai	0	6	0	0	0	17	\N	0
6314934588	0	Bibble	0	0	0	0	0	0	\N	0
2084359471	0	nay	0	0	0	0	0	0	\N	0
1667485084	0	J	5	154	0	0	8403.41	803	\N	0
1950960525	0	memeiii	0	182	0	0	0	715	\N	0
5708656816	0	Gernand Djave.	0	7	0	0	0	4	\N	0
1506508284	0	dafychi	0	3	0	0	0	0	\N	0
6113595616	0	k	0	4	0	0	0	0	\N	0
1941182265	0	somay	0	57	0	0	13.270000000000003	96	\N	0
6858233025	0	cera	0	6	0	0	0	87	\N	0
2129168402	0	Nayla	0	4	0	0	0	1	\N	0
1561804341	0	zaff	0	6	0	0	0	9	\N	0
1744576587	0	Kherén D	0	6	0	0	0	0	\N	0
6622670670	0	asaa	0	4	0	0	0	1	\N	0
6085016904	0	bubub	0	15	0	0	0	31	\N	0
7099642006	0	japar	0	2	0	0	0	1	\N	0
6165143529	0	shaquella eveith!	0	15	0	0	0	0	\N	0
6666667122	0	shybubu, #CALMINRO	0	3	0	0	0	3	\N	0
5320782565	0	cece #nga open bo	0	1	1	0	0	0	\N	0
5588082581	0	a	0	40	0	0	0	23	\N	0
1846243458	0	lunana	0	16	0	0	0	61	\N	0
6283330045	0	Nale	0	6	0	0	0	1	\N	0
6944516988	0	VINNY	0	4	0	0	0	0	\N	0
5553780855	0	zean	0	4	0	0	0	1	\N	0
6031162888	0	orel	0	49	0	0	0	9	\N	0
6874619329	0	cindyuy	0	4	0	0	0	0	\N	0
5987212823	0	penaxz	0	1	0	0	0	6	\N	0
2064637508	0	Shafir	0	3	0	0	0	0	\N	0
1446895785	0	Gaada Nama	0	2	0	0	0	1	\N	0
6021714425	0	na	0	14	0	0	0	21	\N	0
5882169176	0	abel	0	1	0	0	0	0	\N	0
1306025909	0	ray	0	117	0	0	0	136	\N	0
1808751275	0	athan	0	19	0	0	60.20000000000025	49	\N	0
6391162458	0	emily	0	17	0	0	0	27	\N	0
5157496636	0	2222	8	394	0	0	3960.4400000000014	1062	\N	1
5086294505	0	Rction	0	1	0	0	0	2	\N	0
1645857385	0	Gomini^^	0	6	0	0	50.38	24	\N	0
986629635	0	Daffa	0	3	0	0	0	3	\N	0
1642491174	0	Oliver Sykes	0	3	0	0	0	11	\N	0
1216795608	0	sugar	0	2	0	0	0	4	\N	0
6156783995	0	federico dethan	0	5	0	0	269.7	12	\N	0
6972113221	0	𝐓𝐑≛𝐏𝐒 sya	0	1	0	0	0	2	\N	0
1778951147	0	Aji	0	2	0	0	0	11	\N	0
6914316416	0	blue ravodka	0	1	0	0	0	0	\N	0
5554091391	0	ganja	0	2	0	0	0	3	\N	0
6439949947	0	rarely active	0	1	0	0	0	1	\N	0
6151647776	0	‌	0	16	0	0	715.8700000000001	17	\N	0
5357038672	0	Rbio) syasyaaa	0	59	0	0	0	4	\N	0
1727579893	0	wawalala... ?	0	2	0	0	30.82	9	\N	0
6248801339	0	Rukia.	0	39	0	0	13.26	12	\N	0
882111441	0	zach-arry	0	20	0	0	0	11	\N	0
6843614046	0	VA, Kaizuri	0	1	0	0	0	0	\N	0
6835952174	0	Notyour0	0	34	0	0	19	43	\N	0
5124103198	0	n	0	15	0	0	0	17	\N	0
6255493940	0	Jedayu Lamtiar	0	5	0	0	0	8	\N	0
1454941399	0	nanaa	0	15	0	0	0	2	\N	0
1765722266	0	naomi	0	11	0	0	0	7	\N	0
5796473838	0	naevanya	0	15	0	0	0	8	\N	0
5084053336	0	odette	0	1	0	0	0	0	\N	0
1702164753	0	acel	0	0	0	0	0	1	\N	0
2011002961	0	belbella	0	64	0	0	480	22	\N	0
1425682114	0	jo	0	1	0	0	0	7	\N	0
5201299800	0	rest for a while	0	155	0	0	1.2200000000000273	87	\N	0
6929969324	0	Kei	0	1	0	0	0	20	\N	0
2069504473	0	.	0	14	0	0	0	0	\N	0
1732811304	0	🐰 . ヾuni』Lupii <3	0	5	0	0	0	4	\N	0
6471974652	0	Neal	0	2	0	0	0	18	\N	0
5315805564	0	nayaa🌱	0	43	0	0	1009.2299999999999	63	\N	0
6082772767	0	jegar	0	1	0	0	0	5	\N	0
6893917144	0	nisa.	0	2	0	0	0	0	\N	0
5491248131	0	carti	0	16	0	0	0	16	\N	0
5071100406	0	ji nonaktif.	7	489	0	0	14.189999999999998	60	\N	0
6433482559	0	nawaaaaaaaa	0	3	0	0	0	1	\N	0
1966009309	0	zeta ( baca au + wp )	0	4	0	0	0	0	\N	0
1815975960	0	Mikel	0	1	0	0	0	0	\N	0
6222631457	0	je	0	5	0	0	0	37	\N	0
5562729636	0	nalaa	0	0	0	0	0	1	\N	0
5287480536	0	Tya	0	0	0	0	0	0	\N	0
6116750799	0	lorenzy	0	3	0	0	54.36	0	\N	0
5810647408	0	khansazia	0	65	0	0	530	8	\N	0
5436202653	0	ˑ ִ ֗ ꒰ 🎀 Nɑrɑ！𝅄˚˳	0	5	0	0	0	47	\N	0
5881727843	0	jerashka kedua	0	6	0	0	500	466	\N	0
5504395256	0	luccia	0	4	0	0	0	2	\N	0
5432185681	0	aur	0	1	0	0	0	0	\N	0
1646643805	0	.	0	516	0	0	290.14	172	\N	0
5561191041	0	j	0	1	1	0	0	0	\N	0
1425378369	0	daniel	0	12	0	0	0	7	\N	0
6803093650	0	Agastya A	0	1	0	0	0	0	\N	0
931924701	0	Nekopie	0	0	0	0	0	5	\N	0
5836440378	0	.	0	119	0	0	0	59	\N	0
6703177843	0	namikazey	0	0	0	0	0	0	\N	0
2076136917	0	abel	0	144	0	0	38.65	74	\N	0
5913917064	0	aile	0	5	0	0	0	61	\N	0
6702957934	0	nadd	0	37	0	0	0	178	\N	0
1185259466	0	Lada	0	2	0	0	0	121	\N	0
2069506785	0	winkk	0	2	0	0	167.8	203	\N	0
6020660095	0	isabella.	0	2	0	0	0	0	\N	0
2078871615	0	seshaaa	0	6	0	0	0	9	\N	0
6308034524	0	nnd	0	3	0	0	0	1	\N	0
1801718624	0	金 ─ ❝ 𝐆𝐨𝐥𝐝𝐞𝐧𝐞𝐢𝐫𝐧 ❞ ꕑ 𓈒	0	157	0	0	8.999999999999972	392	\N	0
5081843393	0	.	0	2	0	0	0	0	\N	0
5305009499	0	raa	0	1	0	0	0	0	\N	0
6572542085	0	ishaay! 3	0	15	0	0	0	0	\N	0
5060186350	0	Cindy	0	189	0	0	-2.5	113	\N	0
6410393944	0	byebye <3	0	0	0	0	0	0	\N	0
5952465790	0	Naom	0	1	0	0	0	3	\N	0
6666126473	0	Liaa	0	8	0	0	0	40	\N	0
1712241485	0	nissinwafer	0	7	0	0	0	0	\N	0
1549898036	0	bita	0	1	0	0	0	0	\N	0
5947853326	0	Fellyn	0	6	0	0	0	5	\N	0
5525422236	0	Rifqi	0	1	0	0	0	5	\N	0
6523039161	0	evan	0	31	0	0	0	153	\N	0
5889451488	0	jasMINe	4	1533	1	0	14.459999999999127	1787	\N	0
6117203955	0	ema	0	1	0	0	0	0	\N	0
7020179603	0	dd imoed	0	3	0	0	0	3	\N	0
7006846068	0	Adelion	0	2	0	0	0	0	\N	0
5468639342	0	dann	0	5	0	0	0	2	\N	0
2140730181	0	neir	0	254	0	0	0	0	\N	0
1801480795	0	marsyAa sdg pushenk	0	37	0	0	292.5	247	\N	0
5444271671	0	cä - @CaListazxh	0	1	0	0	0	0	\N	0
5517958651	0	Majee	0	6	0	0	0	7	\N	0
2087092199	0	chris	0	9	0	0	0	0	\N	0
7144206178	0	Elvania	0	1	0	0	0	0	\N	0
6181159999	0	org cepu dni	0	38	0	0	185.38	6	\N	0
5545179712	0	Jevarenata.	0	19	0	0	0	241	\N	0
5396665002	0	Jeannette Madge, Naje	0	1	0	0	0	76	\N	0
5974181703	0	Jhonatan	0	3	0	0	0	11	\N	0
1803678754	0	Atta	0	2	0	0	0	1	\N	0
5864971543	0	♡💬+ ׁ ⸼ ꒰ 🌷malaa! ꒱	0	34	0	0	0	65	\N	0
1655681799	0	keira	0	0	0	0	0	0	\N	0
5679030793	0	kila	0	25	0	0	0	6	\N	0
5323720979	0	ᥒᥲkᥡһᥙm	0	17	0	0	0	0	\N	0
1665448636	0	Jouth	0	6	0	0	0	8	\N	0
6546496809	0	n	0	6	0	0	0	29	\N	0
6978904859	0	귀여운 — Miela S. Kalielsha	0	5	0	0	0	2	\N	0
6435215750	0	nadya	0	1	0	0	0	0	\N	0
1855996753	0	binda whales	0	4	0	0	0	2	\N	0
6406935222	0	dd ijel 1st	0	5	0	0	0	7	\N	0
1651141216	0	papermint	0	54	0	0	500	2	\N	0
5457631368	0	N	0	2	0	0	0	1	\N	0
1932747323	0	Gery	0	2	0	0	0	4	\N	0
1796898503	0	hailey	0	28	0	0	0	15	\N	0
854260994	0	xisie	0	2	0	0	0	0	\N	0
6224721783	0	gabell	0	263	0	0	11.840000000000146	3222	\N	0
5842351075	0	Nia	0	3	0	0	0	35	\N	0
1849148931	0	Yya	3	181	0	0	3376.5299999999997	2887	\N	0
6403877449	0	𝐀gnez	0	0	0	0	0	0	\N	0
1769264138	0	naila	0	6	0	0	0	7	\N	0
5479494637	0	ayaa :p	0	1	0	0	0	0	\N	0
6946200616	0	key	0	1	0	0	0	0	\N	0
1738572343	0	kibo fairy	0	1	0	0	0	0	\N	0
1402996129	0	cantika	0	145	0	0	6.960000000000008	57	\N	0
5382823938	0	🇵🇸 𝐂ᧉꪀ̸ִַׂ֪𝐳ꪱ๋ɑ メ	9	745	0	0	1711.4500000000005	4897	\N	0
1354136999	0	.	0	223	0	0	3.5	47	\N	0
6475326014	0	re	0	10	1	0	0	3	\N	0
5075621147	0	「 #Fahri⸙彡」⁩•	0	3	0	0	0	0	\N	0
1943645240	0	tikaaa	0	5	0	0	0	0	\N	0
6155166990	0	véda	0	1	0	0	0	0	\N	0
5771432388	0	Gena 🔥	0	3	0	0	1000	10	\N	0
6851466681	0	cece	0	4	0	0	0	52	\N	0
6443140904	0	dey	0	3	0	0	0	0	\N	0
1900736625	0	Ardika.	0	138	0	0	98	45	\N	0
6591632243	0	keiz	2	585	1	0	1472.9099999999999	353	\N	0
1271268162	0	bang yon	0	11	0	0	0	10	\N	0
5430528450	0	only	14	137	0	0	119.03	557	\N	0
1273365102	0	djavar	0	50	0	0	860	31	\N	0
6324864682	0	Praya	0	1	0	0	0	119	\N	0
6680406691	0	𝓓eby	0	4	0	0	0	41	\N	0
1859177820	0	za	0	11	0	0	0	20	\N	0
6271254397	0	Nebula	0	6	0	0	0	7	\N	0
5667258138	0	아벤트라 C.	0	14	0	0	6.8	11	\N	0
6219917684	0	asha	0	7	0	0	0	45	\N	0
1864999679	0	Naeva	0	1	0	0	231.41	77	\N	0
2043049429	0	bilaa	0	5	0	0	0	1	\N	0
5759917659	0	a	0	1	0	0	0	1	\N	0
2131432474	0	aBEYUEWWUWE	0	253	0	0	747.55	271	\N	0
5996184415	0	jiji	0	1	0	0	93.32	0	\N	0
6516400104	0	DISSSS!!!	0	6	0	0	0	15	\N	0
6495807862	0	Cikaa	0	3	0	0	0	0	\N	0
5500594860	0	୨୧ : bɐaúty's ㅤ݂ㅤ z y ( æ) ʼʼ	0	53	0	0	0	19	\N	0
1656303080	0	paul	0	41	0	0	0	21	\N	0
5505514263	0	Abel	9	559	0	0	15203.65	11375	\N	0
1802935313	0	jossie	0	0	0	0	0	1	\N	0
5732316633	0	jenniee	0	2	0	0	0	0	\N	0
1486683114	0	ㅤmëi	0	3	0	0	0	0	\N	0
5544968044	0	prince lawrence	0	39	0	0	0	69	\N	0
5140147131	0	K	0	4	0	0	0	1	\N	0
6713898190	0	"OKSA, C.."	0	7	0	0	0	2	\N	0
1801226890	0	ca	0	2	0	0	0	0	\N	0
5482078970	0	Deo.	14	27	0	0	59.280000000000044	126	\N	0
6162145076	0	Shaki	0	18	0	0	0	5	\N	0
1496622942	0	घर.	0	7	0	0	0	0	\N	0
6156474357	0	Josephine A.	0	14	0	0	0	0	\N	0
5484426008	0	🎀princess feya♡🎀💗	0	0	0	0	0	7	\N	0
6922184731	0	Asha.	0	41	0	0	0	26	\N	0
6916227731	0	ayuta	0	17	0	0	28.58	40	\N	0
6210464556	0	cadis eltara diraizel	0	17	0	0	0	38	\N	0
6188910139	0	Cataluna closeupsubs	0	1	0	0	18.74	4	\N	0
6793271982	0	Hugo, W.	0	1	0	0	0	0	\N	0
5228800627	0	mashala	0	0	0	0	0	2	\N	0
1882381933	0	¹⁷⁺	0	1	0	0	0	0	\N	0
1548062362	0	sl	0	0	0	0	0	33	\N	0
1848533814	0	G. victoryking @jaeminurbff	0	1	0	0	0	0	\N	0
1873660999	0	matahari	0	8	0	0	0	8	\N	0
7158640740	0	r	0	3	0	0	0	0	\N	0
2112735759	0	ᑲᥕᥲᑲᑲу ᥲᑲᥲh vercixus. #᥆⍴mᥱm᥎k	0	2	0	0	27.95	12	\N	0
5361442202	0	azzam	0	22	0	0	4170	20	\N	0
6489256480	0	Rahna.	0	5	0	0	0	0	\N	0
2113637682	0	Izekiel Alpheus	0	91	0	0	0	0	\N	0
1756203599	0	Maddie	0	1	0	0	0	3	\N	0
6546511069	0	20times.	0	19	0	0	0	26	\N	0
1891522675	0	𝐄𝐥𝐢𝐳𝐚𝐛𝐞𝐭𝐡	0	1	0	0	0	0	\N	0
5655945072	0	Madonna Amartha.	0	5	0	0	1185.2400000000002	92	\N	0
2087500367	0	raēl	0	3	0	0	0	0	\N	0
1713667086	0	Abel	0	15	0	0	0	3	\N	0
6739190351	0	luna🌊	0	4	0	0	0	5	\N	0
1741046112	0	ay	0	0	0	0	0	0	\N	0
6829395495	0	nayy🐳	0	6	0	0	0	2	\N	0
6575391161	0	Ayl, business acc	0	4	0	0	0	1	\N	0
6636688484	0	Abid	0	10	0	0	1031.12	134	\N	0
1464944672	0	𝐂asey Épaulière	0	11	0	0	17.12	10	\N	0
1936288290	0	alora	0	151	0	0	5.949999999999989	11	\N	0
5470302320	0	re	0	1	0	0	0	2	\N	0
1793748276	0	T,	0	0	0	0	0	8	\N	0
6122509981	0	ky.	0	7	0	0	0	2	\N	0
6401571968	0	.	0	8	0	0	0	0	\N	0
1683486104	0	Liv, EMYU open seabad lagi. #cintanganggur	0	35	0	0	100	15	\N	0
1879149149	0	ㅤ	0	499	0	0	450.8699999999998	1505	\N	0
2005096294	0	rest	0	3	0	0	0	0	\N	0
1740638451	0	Kael.	0	316	0	0	2302.4	236	\N	0
5539082185	0	naca.	0	3	0	0	0	8	\N	0
5804547712	0	silv!	0	1	0	0	0	2	\N	0
2096422086	0	SHEra	0	1	0	0	0	1	\N	0
1795973129	0	wrg.trd¹ aa jave	0	14	0	0	0	37	\N	0
5461851466	0	Khabiz Ad.	0	6	0	0	0	7	\N	0
5142000401	0	angela	0	4	0	0	0	0	\N	0
1761047001	0	jiun's lovetaker, yorie	0	1	0	0	27.47	13	\N	0
5405214050	0	Gabriella	0	3	0	0	0	3	\N	0
5532297951	0	jaxen all in✌🏻	0	1	0	0	0	1	\N	0
5831233048	0	al	0	1	0	0	0	0	\N	0
1230263357	0	r	0	10	0	0	0	0	\N	0
5945585938	0	Dimas	0	11	0	0	0	1	\N	0
5434680929	0	Joe	0	30	0	0	385.13	5541	\N	0
5476480120	0	aboye	0	1	0	0	0	3	\N	0
1730623893	0	monicaa	0	10	0	0	0	14	\N	0
1715139190	0	farel	0	15	0	0	0	9	\N	0
5023517372	0	Veerza.	0	44	0	0	0	30	\N	0
1314350405	0	natasya牛悦亮	0	0	0	0	0	41	\N	0
5246709742	0	Zivana || Katanya Fsr?	0	3	0	0	0	1	\N	0
1960108266	0	Sha~	0	1	0	0	0	0	\N	0
6311382112	0	awa >3	0	23	0	0	225.12	257	\N	0
5470574711	0	kalilla	0	3	0	0	0	1	\N	0
5606980235	0	Tabyna.	0	15	0	0	24.85999999999993	14	\N	0
6053685346	0	Verenita	0	2	0	0	0	27	\N	0
5518670226	0	✧⁠*⁠。.⁠Fayee•⁠ᴗ◍.⁠｡⁠*⁠♡🐻🐻	0	89	0	0	0	32	\N	0
6962624177	0	Dangers	0	1	0	0	0	0	\N	0
1700634842	0	Kama	0	49	0	0	0	65	\N	0
1877074111	0	je	0	19	2	0	0	35	\N	0
6384598606	0	J	0	1	0	0	0	0	\N	0
6225474722	0	BAEEE	0	5	0	0	0	3	\N	0
6269432252	0	anoya.	0	3	0	0	0	0	\N	0
5166388825	0	maharatu, sacha	0	2	0	0	0	0	\N	0
5423317307	0	nephthys asthrophel..𐚈	0	1	0	0	0	0	\N	0
5822921718	0	ㅤㅤㅤㅤㅤㅤ	0	7	0	0	0	37	\N	0
5914271805	0	Aeri's	0	1	0	0	0	0	\N	0
6028698347	0	ys	0	1	0	0	0	0	\N	0
5809971702	0	R	0	241	0	0	-5.739999999999924	352	\N	0
6572657627	0	Mario	0	0	0	0	0	1	\N	0
1917645737	0	secret	0	1	0	0	0	0	\N	0
1697654069	0	eve	0	40	0	0	0	0	\N	0
1759531374	0	chi	0	8	0	0	0	4	\N	0
1853366162	0	jejey	0	4	0	0	0	2	\N	0
6187309218	0	bilaa	0	9	0	0	0	5	\N	0
1311853558	0	Ampun	0	35	2	0	0	91	\N	0
6019295924	0	l	0	9	0	0	0	0	\N	0
1927826833	0	collas	0	842	0	0	4.679999999999836	91	\N	0
1959317837	0	Nada✝️	0	1192	0	0	783.4400000000005	4544	\N	0
1746389319	0	lil caspys	13	154	0	0	4787.610000000001	2337	\N	1
5848089505	0	Praxyira	0	0	0	0	0	5	\N	0
5846646767	0	noi	0	10	0	0	118.34	22	\N	0
1724428672	0	sangga	0	0	0	0	0	41	\N	0
2050162807	0	Anlanta	0	4	0	0	0	5	\N	0
6486539855	0	Bastian	0	23	0	0	36	3	\N	0
1893625193	0	R	0	31	0	0	0	22	\N	0
5241974429	0	naomi	0	62	0	0	695	4	\N	0
5075923756	0	🐾–𝔓utee	0	7	0	0	0	2	\N	0
5300515700	0	Erick.	0	2	0	0	0	0	\N	0
5355195068	0	rest	0	43	0	0	0	0	\N	0
1854088713	0	aku bebiboy	0	2	0	0	0	0	\N	0
1721791856	0	with love, ilo ₍ᐢ..ᐢ₎	0	4	0	0	34	20	\N	0
6758597686	0	saaa	0	2	0	0	0	2	\N	0
1909158650	0	Rafles Jerónimo †	0	2	0	0	0	1	\N	0
6021661223	0	Chalista	0	5	0	0	0	4	\N	0
6272369588	0	Jaem	0	90	0	0	0	94	\N	0
2037232513	0	ana	0	17	0	0	486.68	555	\N	0
1748492658	0	L	0	1	0	0	0	0	\N	0
6062784893	0	jaejaaa	0	18	0	0	0	100	\N	0
5533110747	0	gerpin	0	2	0	0	0	6	\N	0
6501116567	0	Puppy, Melvin ʚ♡ɞ	0	4	0	0	0	0	\N	0
5494536414	0	rey	0	2	0	0	0	0	\N	0
2112866683	0	Awan	0	7	0	0	0	9	\N	0
6551956974	0	Micaa.	0	36	0	0	0	11	\N	0
5458991588	0	Christie	10	159	0	0	117.53999999999999	174	\N	0
6246429587	0	Julian River.	0	12	0	0	0	5	\N	0
7145039753	0	azl	0	56	0	0	20.83	249	\N	0
5347237950	0	reilAa.	3	679	0	0	5447.63	1112	\N	0
5066171591	0	seana	0	190	0	0	0	517	\N	0
5713051618	0	𝐅r 【﻿ＨＬ】	0	1	0	0	0	0	\N	0
1537626286	0	DNIF.	0	138	0	0	20	71	\N	0
5174904359	0	kavin	0	84	0	0	7	48	\N	0
1604775884	0	Noelle.	0	103	0	0	0	290	\N	0
5803193423	0	ᴊᴇɴᴅʀᴀʟ. 𝐑𝐞𝐥𝐥𝐞𝐧 ōtsuryu	4	83	0	0	1.3000000000000007	36	\N	0
1805653508	0	salmaa	0	25	0	0	3	218	\N	0
1962785365	3	laneya	0	653	0	0	0	60	\N	0
5850408081	1	vinananana	11	428	0	0	1345.9500000000003	1422	\N	1
6753915222	0	claire	0	1	0	0	0	5	\N	0
6212827647	0	aji.	0	17	0	0	0	13	\N	0
6546354553	0	el	0	19	0	0	0	77	\N	0
6197207296	0	ea	0	17	0	0	0	55	\N	0
6410708903	0	.	0	19	0	0	113	4	\N	0
6642473426	0	oktaa	0	7	0	0	0	8	\N	0
5850197033	0	Memey	0	5	0	0	287.37	4	\N	0
1939955290	0	dara	0	3	0	0	0	1	\N	0
5193882668	0	pit	0	11	0	0	0	0	\N	0
1971903904	0	𝕯︪︩𝐳𝐬🇫🇷. Banyu biru matwous	0	4	0	0	0	0	\N	0
5794653305	0	𝐓𝐚𝐧𝐭𝐞 𝐙𝐡𝐮	0	11	0	0	70.44	199	\N	0
1894557839	0	kiyoko.	0	7	0	0	0	0	\N	0
1460501684	0	shasha	0	50	0	0	0	11	\N	0
5479928848	0	dabin	0	3	0	0	0	28	\N	0
6624556928	0	ailyssa moore	0	4	0	0	0	1	\N	0
5298927146	0	denn	0	21	0	0	0	0	\N	0
1364772180	0	αmoyαα.	0	0	0	0	0	44	\N	0
6067725982	0	Runaa	0	1	0	0	50	58	\N	0
5959767503	0	ayara	10	346	0	0	2646.29999999997	9214	\N	1
5394828110	0	cantika	0	0	0	0	0	1	\N	0
6474576442	0	linK	0	0	0	0	0	0	\N	0
1954398808	0	.	0	309	0	0	2228.51	313	\N	0
5710600566	0	diandra.	0	3	0	0	0	7	\N	0
6168851680	0	ell	0	16	0	0	0	0	\N	0
1508221591	0	Kedelai	0	5	0	0	0	1	\N	0
5495759071	0	vito	5	686	0	0	121.05000000000001	79	\N	0
6711309927	0	ddy	0	13	0	0	985	5	\N	0
5651130071	0	a	0	3	0	0	0	2	\N	0
5147041035	0	seline	0	67	0	0	0	9	\N	0
1735497372	0	alia. ♡	13	346	0	0	819.8	312	\N	0
7156146983	0	Jenna Pratesa K.	0	12	0	0	128.35	6	\N	0
5832028449	0	lolo, duluan.	0	1	0	0	0	8	\N	0
1406689762	0	xvaf𝖅༉	0	4	0	0	0	14	\N	0
1305177221	0	Chris`	0	2	0	0	0	0	\N	0
5544287273	0	anne :p	1	678	0	0	4924.5099999999975	10812	\N	0
1827578319	0	H	0	178	0	0	969.5	79	\N	0
5020306007	0	Dev	7	111	0	0	284.6199999999998	237	\N	0
5497193520	0	Ersa	0	1	0	0	0	12	\N	0
6390658909	0	aya	0	42	0	0	835.76	2	\N	0
5864331734	0	Reyy	0	354	0	0	-9	159	\N	0
1790700553	0	teressa	0	1	0	0	0	6	\N	0
6938749414	0	ㅤ	0	2	0	0	0	8	\N	0
6704115999	0	179	0	3	0	0	0	0	\N	0
1863447306	0	auriel	0	17	0	0	0	107	\N	0
1978549429	0	˹㊮˼el	0	2	0	0	0	7	\N	0
1779282750	0	ian	0	5	0	0	0	0	\N	0
5964921600	0	Mikexy	0	1	0	0	0	0	\N	0
1796947672	0	Naomi	0	7	0	0	0	11	\N	0
6138216264	0	?	0	136	0	0	401.8799999999999	359	\N	0
1828094287	0	Priscilla Sinabang	0	9	0	0	0	6	\N	0
5355641106	0	Mami Ikichan	0	4	0	0	0	0	\N	0
1932063147	0	𝐑enjana	0	3	0	0	0	8	\N	0
6064309207	0	Mabelva.	0	1	0	0	0	0	\N	0
6856751402	0	dinda	0	3	0	0	0	5	\N	0
5729356727	0	rev	0	11	0	0	0	35	\N	0
6241259139	0	Elgarth.	0	6	0	0	0	4	\N	0
6944524954	0	Landon G.	0	3	0	0	0	6	\N	0
5578672529	0	warda	0	5	0	0	0	2	\N	0
6370639963	0	your b	0	1	0	0	0	6	\N	0
1921397442	0	Yasmine	0	57	0	0	0	0	\N	0
1860536708	0	D	0	284	0	0	26.380000000000116	111	\N	0
1956779685	0	95 𝐍aNda AkiLa Changcuters @kutomu	0	28	0	0	0	4	\N	0
6693670893	0	keiko	13	28	0	0	0	108	\N	0
909748722	0	A	0	13	0	0	121.50999999999999	60	\N	0
1225426762	0	senjarie	0	316	0	0	0	0	\N	0
1477237016	0	Lara	0	48	0	0	0	4	\N	0
5231689190	0	Herlangga.	0	300	0	0	4	577	\N	0
1640510168	0	kala	0	40	0	0	0	136	\N	0
5963760013	0	𝐖𝐢𝐥𝐥𝐢𝐚𝐦 ɢ𖦼	0	91	0	0	51	111	\N	0
5461219230	0	nonik	0	14	0	0	360.53	143	\N	0
5896799242	0	suráá	10	41	0	0	7.939999999999998	37	\N	0
5360286123	0	dni.	0	32	0	0	3.9300000000000637	28	\N	0
1893321756	0	deyy	0	77	0	0	207.99	438	\N	0
6797217464	0	ciaAaa	0	0	0	0	0	0	\N	0
6453320827	0	hellen	0	10	0	0	0	10	\N	0
6261347782	0	Prvt.	0	5	0	0	19.51	76	\N	0
1731451297	0	v	0	2	0	0	0	0	\N	0
6266174049	0	ann	0	29	0	0	0	0	\N	0
5134187265	0	ㅤㅤㅤ	0	1	0	0	0	1	\N	0
6423217359	0	ah gatau	0	9	0	0	0	9	\N	0
1307591259	0	Na	0	8	0	0	0	39	\N	0
1363012665	0	.	0	2	0	0	0	0	\N	0
6230403536	0	juli	0	398	0	0	489.05000000000007	965	\N	0
5027870938	0	nael	0	2	0	0	0	0	\N	0
5009891215	0	rey	0	28	0	0	0	2	\N	0
6611831623	0	D, Maggie 	0	28	0	0	0	48	\N	0
6184409293	0	petra	8	446	0	0	3078.48	4301	\N	1
5516703594	0	Refa.	12	448	0	0	30008.97	3510	\N	1
5358466305	0	aska	0	49	0	0	16.3	22	\N	0
7141652039	0	aruu	0	4	0	0	0	0	\N	0
6765514360	0	neyyaa	0	50	0	0	0	72	\N	0
1774651239	0	fawn⋆	2	613	0	0	5598.850000000001	14047	\N	0
6874388371	0	ayya (hiat)	0	3	0	0	0	3	\N	0
1591223644	0	Hirotaka.	0	55	0	0	0	1	\N	0
6108625527	0	Kafka.	0	17	0	0	0	11	\N	0
6872299916	0	D. Jarcobs, Varboss.	0	7	0	0	0	1	\N	0
1866317200	0	🕸	0	7	0	0	0	0	\N	0
6742486186	0	strowberry	0	0	0	0	0	9	\N	0
6142448090	0	eca LIMIT GC only +6285217515697	0	1	0	0	0	27	\N	0
1845977832	0	kerta	0	4	0	0	0	0	\N	0
5298165548	0	Adhinata.	0	112	0	0	237.65999999999985	69	\N	0
1804023845	0	⁻ ˢ	0	64	0	0	5	46	\N	0
1626784788	0	mody	0	158	0	0	20.130000000000003	33	\N	0
5722152635	0	na	0	13	0	0	0	0	\N	0
7163586605	0	-	0	5	0	0	0	3	\N	0
5196155842	0	azka	0	8	0	0	0	0	\N	0
6330813989	0	ndra.	0	3	0	0	0	0	\N	0
923972793	0	patin	0	1	0	0	13.53	25	\N	0
5080255231	0	.	0	13	0	0	0	6	\N	0
5066915732	0	jjax	0	79	0	0	0	76	\N	0
1691597383	0	kassie 𝖙𝖊𝖆𝖒ʷˡᵛˣ	0	4	0	0	100	65	\N	0
7026196961	0	sky hiatdrpw	0	7	0	0	0	0	\N	0
6938242840	0	Alice.	0	3	0	0	0	25	\N	0
5317636142	0	Jordan // rechat	0	11	0	0	0	164	\N	0
5816626505	0	iel	0	18	0	0	296.49	107	\N	0
1868168201	0	seyshu	0	217	0	0	0	8	\N	0
6115707117	0	aca	0	30	0	0	0	47	\N	0
6036893786	0	s	0	150	0	0	3	6	\N	0
1406860826	0	vat	0	72	0	0	213.42000000000002	1036	\N	0
1274784167	0	je	0	208	0	0	12.25	99	\N	0
1937982234	0	sh	0	17	0	0	0	28	\N	0
1630720134	0	kajel	0	0	0	0	0	3	\N	0
1936864182	0	royan	0	72	0	0	0	0	\N	0
5253591635	0	j	0	1	0	0	0	0	\N	0
5980224592	0	Ayabellee.	0	35	1	0	597.86	52	\N	0
1600491664	0	verli	0	16	0	0	0	4	\N	0
5978378507	0	Bila.	0	126	0	0	0	75	\N	0
6260903668	0	Ana.	0	3	0	0	0	32	\N	0
1784432645	0	subuwu	0	1	0	0	0	0	\N	0
6693069864	0	Din.	0	1	0	0	0	0	\N	0
1833996558	0	Fa	0	24	0	0	0	3	\N	0
5214065444	0	javas LITERASI	0	2	0	0	0	0	\N	0
6219185564	0	ciao	0	27	0	0	0	0	\N	0
5091778720	0	anisaac	0	2	0	0	0	1	\N	0
5370612807	0	.	0	3	0	0	0	0	\N	0
5022371252	0	𝐓essa.	0	10	0	0	0	40	\N	0
1741258571	0	bungaa	0	0	0	0	0	2	\N	0
5168814622	0	n	0	2	0	0	0	8	\N	0
6750308158	0	Kiraichi Oukā	0	17	0	0	0	11	\N	0
5371630563	0	Yasmin	0	29	0	0	0	0	\N	0
1220564037	0	zam	0	14	0	0	0	7	\N	0
5457846628	0	er	0	28	0	0	0	12	\N	0
6587462814	0	naswa	0	186	0	0	3.8599999999999994	15	\N	0
6358933387	0	ecay🐋	0	56	0	0	226.76	51	\N	0
6234010776	0	xac	0	2	0	0	0	18	\N	0
5970058454	0	olip nasi kuning	9	49	0	0	254.42	200	\N	0
2030364852	0	ㅤㅤㅤㅤㅤ	0	6	0	0	35	16	\N	0
6950053954	0	hunter	0	20	0	0	368	223	\N	0
5735004458	0	ay	0	45	0	0	0	15	\N	0
5441657482	0	kyoisa, r. HECTIC ERA :]	0	16	0	0	0	44	\N	0
6734277003	0	mami ponne	0	11	0	0	0	14	\N	0
5942529723	0	cc	0	11	0	0	0	0	\N	0
5469175495	0	:c	0	1	0	0	0	0	\N	0
1772771584	0	nai	0	229	0	0	0	978	\N	0
6650810549	0	.	0	20	0	0	0	4	\N	0
1840932576	0	Katherina Arunika.	0	3	0	0	0	0	\N	0
6068802699	0	᥎іᥱ` 🫧	0	19	0	0	0	1	\N	0
6421370424	0	ㅤ	0	3	0	0	0	0	\N	0
5948361197	0	raraa. 艾儿诶艾儿诶	0	1	0	0	0	0	\N	0
5964730474	0	𝐓𝐑≛𝐏𝐒 ` ayra	0	44	0	0	1890	0	\N	0
1598846749	0	K/ia	0	26	0	0	0	154	\N	0
6531127868	0	abll	0	1	0	0	0	0	\N	0
7060081143	0	Avril Lavigne.	0	2	0	0	0	3	\N	0
1836777632	0	amei's. pending	0	5	0	0	0	0	\N	0
6950993392	0	tarán	0	2	0	0	0	1	\N	0
5336846154	0	seora	11	2479	1	0	17149.770000000026	48123	\N	1
6761163432	0	wιrα 🃏ʲˢ²	0	3	0	0	0	5	\N	0
6033746076	0	celine sk mingyu	0	106	0	0	0	0	\N	0
2125678645	0	dch.	0	1	0	0	0	0	\N	0
6366864034	0	JaeV	0	8	0	0	0	3	\N	0
6416819413	0	♑	0	32	0	0	0	3	\N	0
5751295830	0	Sheanne.	0	6	0	0	0	3	\N	0
6758186699	0	L. Kaérine 💋	0	3	0	0	0	0	\N	0
1893779619	0	jiera cezzzzzzzzzz	0	12	0	0	0	116	\N	0
6176713842	0	ashforshaa	0	10	0	0	4.21	20	\N	0
5679899054	0	evee.	0	6	0	0	0	635	\N	0
1889239254	0	aidan	0	5	0	0	25.019999999999996	4	\N	0
1695951064	0	KamiLa	0	4	0	0	0	11	\N	0
2043241545	0	slr, on exam	0	1	0	0	0	16	\N	0
5931314923	0	luux	0	1	0	0	0	0	\N	0
6692362110	0	cici	0	1	0	0	0	0	\N	0
1390848074	0	acaa	0	26	0	0	0	110	\N	0
1472287028	0	Dino	0	27	0	0	0	271	\N	0
7191937522	0	K.	0	18	0	0	6.52000000000001	36	\N	0
1655251245	0	Mattheo.	0	3	0	0	0	0	\N	0
6044470576	0	ael	0	6	0	0	0	5	\N	0
6633310821	0	reyy🚬	0	26	0	0	0	3	\N	0
5511236502	0	Isabela	0	31	0	0	0	5	\N	0
5080619179	0	nora	0	55	0	0	0	66	\N	0
5463781905	0	kALULAA IPS DUA	0	47	1	0	0	567	\N	0
1784899874	0	.	0	1	0	0	0	3	\N	0
1566675760	0	Iky	0	2	0	0	0	1	\N	0
1908910448	0	kajesa	0	19	0	0	0	25	\N	0
1793431359	0	abian	0	45	0	0	0	33	\N	0
6715066884	0	yaya fans aldi taher	0	1	0	0	0	0	\N	0
7127290915	0	hangheng	0	29	0	0	0	0	\N	0
5181475474	0	dibaaa	0	9	0	0	0	7	\N	0
6464421596	0	Dena	0	13	0	0	0	2	\N	0
6314027172	0	asha	0	4	0	0	0	3	\N	0
1903844229	0	rtz	0	15	0	0	0	0	\N	0
2068111056	0	Frisca	0	1	1	0	0	0	\N	0
1914398939	0	Jea.	0	12	0	0	871.0699999999997	2204	\N	0
1961678962	0	Vengela	0	37	0	0	0	1	\N	0
1821630406	0	zeanne.	0	23	0	0	0	11	\N	0
6065726834	0	kala	0	220	0	0	1544.19	533	\N	0
1702383240	0	ଘ 🍎 ɑ𝗉𝗉𝗅ᧉ 𝗉ꪱᧉ ♡︭ ۫ ⸝⸝	0	10	0	0	0	1	\N	0
6171783640	0	kathiaa	0	18	0	0	0	1	\N	0
6647635624	0	Lien's paramour, HAN	0	28	0	0	9.02	144	\N	0
1793922630	0	cicuy	0	52	0	0	0	0	\N	0
2080779925	0	udh ga tipsy	0	21	0	0	0	21	\N	0
1812430282	0	Zahra	2	777	0	0	861.1599999999997	390	\N	0
1674862238	0	theo	0	11	0	0	1540	1	\N	0
1797968628	0	akasa	0	1	0	0	0	1	\N	0
1836270903	0	Nonton	0	9	0	0	0	0	\N	0
5214329055	0	wimala vs everybody	0	70	0	0	2326.83	1876	\N	0
6761272427	0	a	0	14	0	0	0	39	\N	0
2147118384	0	Kean¹²³	0	1	0	0	0	0	\N	0
6515106759	0	abēllionee	0	2	0	0	0	0	\N	0
6248608813	0	.	0	37	0	0	1	3	\N	0
5780974875	0	cala	0	2	0	0	0	0	\N	0
2056759838	0	Aurel.	0	12	0	0	0	0	\N	0
2117386484	0	𝐚lice	0	57	0	0	0	0	\N	0
6812630483	0	Syasya	0	21	0	0	0	10	\N	0
5223780027	0	𓆞	0	5	0	0	0	25	\N	0
5398231173	0	ai	0	61	0	0	0	109	\N	0
1864496040	0	bening.	1	166	0	0	2256.1300000000006	4	\N	0
1913856404	0	jade	2	319	0	0	18.269999999999982	215	\N	0
5022895534	0	cc	0	347	0	0	760.57	102	\N	0
2016685998	0	Daging ayam	0	1	0	0	66.95	140	\N	0
1888595521	0	isa	0	0	0	0	0	0	\N	0
5289047692	0	Ricky lovers ||Sempak Promote 🐶	0	3	0	0	0	15	\N	0
6870513561	0	🕸	0	37	0	0	0	9	\N	0
5336024770	0	j	0	0	0	0	0	0	\N	0
5161432906	0	🐰> shabiyyaA!	0	19	0	0	0	0	\N	0
5357223186	0	re	0	2	0	0	0	1	\N	0
6885236910	0	Willero.	0	38	0	0	178	26	\N	0
1865009840	0	Yoi	4	365	0	0	5535.509999999999	284	\N	0
1285761179	1	nasy	5	425	0	0	5083.259999999999	139	\N	0
1930961868	1	iwaa	0	3	0	0	0	0	\N	0
5323313515	0	Cagi, stressed teenager..	12	302	0	0	29494.850000000002	2230	\N	0
1575716847	0	.	0	3	0	0	0	0	\N	0
5042696273	0	dewangga	0	1	0	0	0	0	\N	0
1825428429	0	랜	0	2	0	0	0	0	\N	0
1439956626	0	dovE	0	13	0	0	0	156	\N	0
2114440586	0	fnh	0	201	0	0	0.6599999999999966	155	\N	0
1563134007	0	Yoshida.	0	1	0	0	0	0	\N	0
2144431033	0	Arthur	0	6	0	0	0	55	\N	0
6910759951	0	𝑹𝒂𝒇𝒇𝒂𝒆𝒍	0	6	0	0	0	2	\N	0
1841660949	0	lala	0	71	0	0	0	358	\N	0
6500299399	0	sal	0	30	0	0	0	6	\N	0
5603804216	0	.	0	8	0	0	0	211	\N	0
1437342281	0	Byesilla	0	2	0	0	0	0	\N	0
6508092771	0	caca	0	117	0	0	94.19999999999999	222	\N	0
5144257559	0	Lz	0	9	0	0	0	72	\N	0
5507712285	0	a	0	88	0	0	0	4	\N	0
5660778150	0	stuff	0	1	0	0	0	0	\N	0
5807470429	0	el	0	101	0	0	1307.3400000000001	208	\N	0
7042832764	0	feyya2nd	0	16	0	0	0	3	\N	0
7183250394	0	acy	0	25	0	0	0	0	\N	0
6788140562	0	Nata.	0	1	0	0	0	0	\N	0
6223492969	0	simon	0	5	0	0	0	0	\N	0
6055982706	0	y	0	37	1	0	0	5	\N	0
5510398053	0	Kanagara.	14	3	0	0	2137.38	46	\N	0
2006780465	0	aurel	0	1	0	0	0	0	\N	0
5621920123	0	esha	0	9	0	0	0	27	\N	0
1593379821	0	Jemara Wheeler.	0	6	0	0	0	1	\N	0
5446475448	0	Cryy	0	1	0	0	0	0	\N	0
1356728956	0	p	0	4	0	0	0	1	\N	0
2038437669	0	rrnita	0	13	0	0	0	0	\N	0
1689742669	0	arjune	0	1	0	0	0	0	\N	0
7066659950	0	lino	0	5	0	0	0	2	\N	0
5917930819	0	ghesa🎖	0	31	0	0	0	8	\N	0
6655480342	0	key	0	1	0	0	0	0	\N	0
5307727580	0	jeskay holex	0	1	0	0	0	1	\N	0
5260743255	0	Punow T.	0	145	0	0	22	532	\N	0
1751404844	0	a s k a	0	9	0	0	0	3	\N	0
6134744073	0	caca	0	4	1	0	0	1	\N	0
1300496533	0	Co	0	1	0	0	0	0	\N	0
5649639099	0	bima	0	22	0	0	0	17	\N	0
1471219612	0	Jeje	0	3	0	0	0	0	\N	0
2095456879	0	Ar.	0	1	0	0	0	4	\N	0
6469539817	0	DNFI.	0	1	0	0	0	0	\N	0
1818293639	0	💎 deluxin	0	11	0	0	0	6	\N	0
6511431984	0	The Cinderella, Ryuuka.	0	12	0	0	0	14	\N	0
1492381385	0	Dresanala Arimbi A	0	2	0	0	0	0	\N	0
755847741	0	annie	0	8	0	0	0	0	\N	0
938809628	0	A	0	10	0	0	0	0	\N	0
1372592910	0	Sekᥲlᥲ	0	1	0	0	0	0	\N	0
1763960489	0	𝟑𝟏𝟑.	0	3	0	0	0	0	\N	0
5813539342	0	Bryce	0	156	0	0	13.8900000000001	42	\N	0
800307449	0	lycá intivds *miAw MiAw*	0	1	0	0	0	0	\N	0
6599673131	0	𝐓𝐑≛𝐏𝐒	0	22	0	0	0	563	\N	0
5872712824	0	Moon (Taylor's version)	0	2	0	0	0	0	\N	0
6013918238	0	alif	0	1	0	0	0	0	\N	0
5218540035	0	Bumblebee	0	10	0	0	0	19	\N	0
1683910778	0	abby	0	5	0	0	11.07	21	\N	0
6184828283	0	gea msi esempe	0	101	0	0	5.969999999999999	9	\N	0
6137416182	0	saci	0	34	0	0	134.3300000000001	205	\N	0
6717269596	0	ki	0	10	0	0	0	131	\N	0
6305158407	0	neeya	0	0	0	0	0	0	\N	0
6616021967	0	Karlyn	0	1	0	0	0	19	\N	0
2127222728	0	Key	0	10	0	0	0	1	\N	0
5016706571	0	kailo	0	98	0	0	0	36	\N	0
5370409511	0	A d i	0	0	0	0	0	140	\N	0
6745934425	0	Sophia ִōtsukitzu	0	58	0	0	0	1	\N	0
1479984056	0	Rin.	0	3	0	0	0	1	\N	0
6208971363	0	dy ngejam sbr yaa	0	1	0	0	0	0	\N	0
875328629	0	lemon	0	23	0	0	148.51	31	\N	0
5935271349	0	.	0	1	0	0	0	0	\N	0
1330399537	0	lenore amyreth..	0	0	0	0	0	3	\N	0
7024009836	0	melodía	0	4	0	0	0	85	\N	0
1375600225	0	Nomel	0	1	0	0	0	0	\N	0
2101076683	0	nad.	3	77	0	0	3924.1800000000007	188	\N	0
5764429094	0	Vin 🎀🐰	5	9	0	0	1682.9899999999996	512	\N	0
6327929561	0	aven	0	2	0	0	0	0	\N	0
6402434505	0	Shss.	0	34	0	0	0	2	\N	0
1989426962	0	Aicel, de Luze	0	0	0	0	0	10	\N	0
1937619716	0	jipaa pasipagaa	12	172	0	0	1696.3699999999997	823	\N	0
6772822366	0	kamila	14	715	0	0	400.41999999999996	284	\N	0
6177463410	0	Bunny	12	1	0	0	371.0999999999999	11	\N	1
6495593133	0	ell	0	28	0	0	33	0	\N	0
1881866438	0	mounel	0	9	0	0	0	24	\N	0
2132899554	0	qc	0	1	0	0	0	0	\N	0
5819140526	0	🪬	0	113	0	0	0	63	\N	0
5737982762	0	2.2	0	1	0	0	0	1	\N	0
7144446848	0	j, slctv	0	0	0	0	0	0	\N	0
1426258823	0	🦕	12	164	0	0	289.80999999999494	702	\N	1
6636570914	0	sefa	0	1	0	0	0	3	\N	0
5145473548	0	ibu peri anindiya •᷄‎ࡇ •᷅	0	23	0	0	0	8	\N	0
1897301677	0	oussië miaw ^~~^	0	54	0	0	3.079999999999984	144	\N	0
6794874990	0	𝜗𝜚 ࣪ ִִֶ Chévarine A.	0	1	0	0	0	0	\N	0
5804830920	0	Hanna gk percaya ini 2024	0	22	0	0	101.78	66	\N	0
5055773548	0	its ilaa	0	1	0	0	0	0	\N	0
5348219457	0	Jo.	0	63	0	0	0	20	\N	0
2025557204	0	b	0	221	0	0	1740.54	368	\N	0
1842951056	0	asta	0	3	0	0	0	3	\N	0
5321304504	0	kaye	5	194	0	0	10.010000000000005	725	\N	0
5064496098	0	gaskar	0	15	0	0	0	4	\N	0
6036891885	0	yumée	0	3	0	0	634.9999999999998	21	\N	0
5826550728	0	🎀❕	0	2	0	0	0	2	\N	0
1698229398	0	Nicholas.	0	5	0	0	0	0	\N	0
5434886245	0	line	0	12	0	0	0	4	\N	0
1413509422	0	:\\	0	11	0	0	500	28	\N	0
5600757617	0	J	0	3	0	0	0	5	\N	0
1845314117	0	Alena	0	2	0	0	0	0	\N	0
1771711679	0	radja	0	50	0	0	0	131	\N	0
5555426835	0	lili	11	51	0	0	261.77	51	\N	0
5629390198	0	Starla.	11	1191	0	0	282.58000000000106	911	\N	0
1654844322	0	rowena	0	1	0	0	0	0	\N	0
5890375038	0	d'	0	9	0	0	0	4	\N	0
6124568829	0	Alenia #BARBIEWDS	0	39	0	0	15.48	7	\N	0
5332718520	0	shin	0	8	1	0	0	10	\N	0
6051840264	0	Rocky	0	2	0	0	0	5	\N	0
1996779390	0	Revana Tamanni Azkia	0	2	0	0	0	1	\N	0
1968874862	0	perkedel enak	0	91	0	0	-2.6900000000000546	323	\N	0
6438171326	0	eric	0	0	0	0	0	0	\N	0
1893373751	0	alv	0	90	0	0	0.4499999999999993	52	\N	0
6240117679	0	abell L nya dua	0	1	0	0	0	0	\N	0
1648208895	0	アリーファ	0	49	0	0	0	28	\N	0
6978830804	0	sier	0	28	0	0	0	23	\N	0
6529508295	0	Kapi	0	5	0	0	0	1	\N	0
5761376140	0	naufal	0	1	0	0	0	0	\N	0
6955264935	0	888	0	26	0	0	14.660000000000053	20	\N	0
1181318328	0	Arkan	0	795	0	0	18.5	292	\N	0
5872820009	0	mel @kimryu7	0	2	0	0	0	3	\N	0
5457566391	0	Shavena	0	22	0	0	0	11	\N	0
1952075125	0	bagas	0	9	0	0	0	19	\N	0
1737187639	0	ama	0	3	0	0	0	0	\N	0
1840791111	0	nanananana	0	10	0	0	0	17	\N	0
1352487992	0	biyaf	0	2	0	0	0	0	\N	0
1510093927	0	Prana mipa 7	0	13	0	0	0	11	\N	0
5872745620	0	yiyaㅤ	13	7	0	0	221.12000000000003	1334	\N	1
5182200354	0	Jen	0	1	0	0	0	1	\N	0
7080673500	0	gebiw	0	11	0	0	39.97	43	\N	0
2083159975	0	kay icikiwir	0	3	0	0	0	1	\N	0
1567826515	0	seveth nadine🇨🇭	0	41	0	0	352.34	0	\N	0
6235600546	0	.	0	24	0	0	0	2	\N	0
6808151351	0	eran	0	77	0	0	0	20	\N	0
5747323802	0	Tralala	0	3	0	0	0	0	\N	0
6960792937	0	𝕳𝕶𝕽. #prinses tata 🎀	0	7	0	0	0	11	\N	0
5945562440	0	ogies 吉斯	10	570	0	0	509.3800000000008	1340	\N	0
5064690270	0	sasa	0	25	0	0	0	0	\N	0
6619021057	0	keyna	0	96	0	0	3	23	\N	0
7171021537	0	.	0	12	0	0	0	2	\N	0
6281106674	0	read bio	0	9	0	0	149.88	58	\N	0
5920439020	0	𝐝𝐨𝐮𝐤𝐢𝐜𝐡𝐚𝐧	0	5	0	0	0	1	\N	0
1682094745	0	Avena udah bobo	0	2	0	0	0	2	\N	0
6122015581	0	j	0	14	0	0	90.75	6	\N	0
2014688129	0	Travis	0	524	0	0	4	1001	\N	0
6160633519	0	Faye Vrazella.	0	1	0	0	478	0	\N	0
6096618228	0	namiww	0	11	0	0	0	3	\N	0
1882762377	0	Irvan	0	0	0	0	0	0	\N	0
6108046539	0	jocelyn	0	1	0	0	0	0	\N	0
1896346012	0	angel, off	0	115	0	0	0	41	\N	0
1825402966	2	giel	0	12	0	0	0	1	\N	0
1692602207	0	d	0	3	0	0	0	0	\N	0
5866913109	0	ini asa	0	2	0	0	0	0	\N	0
6421004127	0	Anaheim.	0	0	0	0	0	0	\N	0
1820776797	0	mark's gf	0	0	0	0	0	1	\N	0
5916710268	0	ella	0	1	0	0	0	2	\N	0
7058949210	0	G.	0	2	0	0	700	0	\N	0
5515786207	0	gяα¢ια ˡᵒᵛᵉᵗᵃᵏᵉʳ η🎞️🤍	0	27	0	0	135	718	\N	0
5630071712	0	cici🥀💟	0	1	0	0	0	0	\N	0
1896070088	0	noel	0	61	0	0	0	2	\N	0
6885863809	0	nanaa	0	0	0	0	0	0	\N	0
6066538203	0	miley	0	5	0	0	0	1	\N	0
6496744860	0	𝅄˚. kinan	0	2	0	0	0	1	\N	0
5660246062	0	📔	0	6	0	0	0	0	\N	0
6091689584	0	Asher Chryseis	0	136	0	0	5.719999999999956	70	\N	0
1501457766	0	aza	0	3	0	0	0	0	\N	0
6122613045	0	cell.	0	4	0	0	0	18	\N	0
5784945776	0	dindaa	0	7	0	0	0	8	\N	0
2016364256	0	dean	0	2	0	0	0	21	\N	0
1175514482	0	Annette Walthrone.	0	13	0	0	0	0	\N	0
1799011215	0	戦士.revira#galaw 𝕬𝖙ѕυι¢¹	0	13	0	0	0	22	\N	0
2029149371	0	Geova	0	2	0	0	0	0	\N	0
1887169674	0	vanilla	0	3	0	0	0	2	\N	0
1790093642	0	jane	0	5	0	0	0	3	\N	0
7061252067	0	Nayy🦋	0	1	0	0	0	5	\N	0
2075981521	0	na	0	52	0	0	412.98	165	\N	0
5314607849	0	oOody	0	4	0	0	104.54	10	\N	0
1718210877	0	-	0	40	0	0	15.05	26	\N	0
5095754654	0	meysaa	0	0	0	0	0	0	\N	0
1239396215	0	fey	0	481	0	0	1.1999999999999886	3017	\N	0
2036221314	0	Bisma	0	1	0	0	0	0	\N	0
6270001279	0	biyee	0	25	0	0	0	81	\N	0
6297543985	0	assa	0	1	0	0	0	0	\N	0
2137377282	0	M	0	49	0	0	0	5	\N	0
6092998649	0	Avarka J.	0	1	0	0	0	3	\N	0
1864738397	0	richard	0	7	0	0	20.040000000000003	20	\N	0
2098570717	0	rai very slowrespon.	0	2	0	0	0	0	\N	0
5009984617	0	ReiiiiIL	0	9	0	0	0	75	\N	0
5125681228	0	ash	0	1	0	0	0	0	\N	0
5932452650	0	diki	0	1	0	0	0	0	\N	0
2128589472	0	nako	0	1	0	0	0	0	\N	0
6530672984	0	jcob	0	6	0	0	0	1	\N	0
5488830015	0	xaz	0	10	0	0	0	2	\N	0
5201971130	0	.	0	643	0	0	2607.1799999999994	153	\N	0
1848893596	0	ⱱgx cakra³	0	1	0	0	0	1	\N	0
6057998170	0	Jeje	0	1	0	0	0	0	\N	0
6172094267	0	abelanay	0	174	0	0	2617.0199999999995	1082	\N	0
5534353728	0	H	0	3	0	0	0	27	\N	0
6689374793	0	valent	0	7	0	0	0	27	\N	0
6374865395	0	gleen	0	2	0	0	0	2	\N	0
5026599676	0	dipa	0	1	0	0	0	0	\N	0
1131069333	0	A	4	13	0	0	1097.6100000000001	5	\N	0
1462704267	0	Snowiee	0	3	0	0	0	0	\N	0
1858318751	0	🫀	0	4	0	0	0	0	\N	0
6113181091	0	diego	0	9	0	0	0	1	\N	0
2001413090	0	09 njip	0	3	0	0	0	0	\N	0
5825350819	0	lele	0	1	0	0	0	1	\N	0
1824284659	0	67. isa	0	18	0	0	0	5	\N	0
1814620714	0	jamal	0	555	0	0	5.299999999999997	515	\N	0
6673243477	0	kaila	0	1	0	0	0	0	\N	0
7159486442	0	lailee	0	22	0	0	15	7	\N	0
2008514446	0	mimaa	0	1	0	0	0	0	\N	0
6434011973	0	B	0	3	0	0	0	2	\N	0
2142545956	0	call me jii	0	171	0	0	225.17000000000002	185	\N	0
2067077968	0	liy's	0	70	0	0	179.2	0	\N	0
5366974263	0	chocolate	0	3	0	0	0	0	\N	0
1059181263	0	aya.	8	544	0	0	529.4200000000001	2680	\N	0
6151163158	0	kesaa 🪼	0	37	0	0	0	8	\N	0
6494030858	0	Xnz	0	9	0	0	0	14	\N	0
5902712147	0	sava	0	1	0	0	0	0	\N	0
5310972449	0	nadine.	0	32	0	0	0	79	\N	0
7185887516	0	L	0	27	0	0	0	0	\N	0
6943956449	0	Who's?	0	1	0	0	0	2	\N	0
5979784005	0	bulbull	0	11	0	0	0	0	\N	0
5753812685	0	Ceii.	0	6	0	0	0	2	\N	0
5607672338	0	Dije L.	0	1	0	0	0	0	\N	0
2137410507	0	diwa	0	4	0	0	0	16	\N	0
5166514970	0	jeje	0	3	0	0	0	0	\N	0
1405607872	0	ayaa	0	9	0	0	0	3	\N	0
7077851643	0	Renata A.	0	1	0	0	0	0	\N	0
5155367666	0	Acc Trade	0	2	0	0	0	0	\N	0
5570425781	0	ody	0	0	0	0	0	0	\N	0
2078042526	0	a	0	1	0	0	0	0	\N	0
5545947407	0	aji	0	11	0	0	0	0	\N	0
1282110587	0	Rarely active	0	17	0	0	2637.75	7811	\N	0
6036690624	0	ㅤㅤ 𝗆𝗈𝗐𝗐𝖽𝗂𝖾	0	0	0	0	0	76	\N	0
6604095775	0	j	0	23	0	0	0	1	\N	0
1678107118	0	s.	0	54	0	0	0	9	\N	0
7009232002	0	qolbee._	0	4	0	0	0	3	\N	0
1700175075	0	Reena khalista.♡	3	138	0	0	42.5499999999999	139	\N	0
6675512508	0	dipidabibi ₊˚⊹⋆	0	53	0	0	4	72	\N	0
1777842026	0	𓍼 ، ࣪ ࣪𖡎 ּ ִ zeey ִ ࣪𔘓 ۫. ࣪𖦹︎ ᳝ 〞	0	1	0	0	0	0	\N	0
5675735456	0	ren	0	1	0	0	0	0	\N	0
1855901446	0	drian	0	5	0	0	0	1	\N	0
5157368554	0	Miseya @#$!	0	1	0	0	0	15	\N	0
5523775371	0	ozie	0	5	0	0	0	5	\N	0
1664195270	0	c gi bbo	0	15	0	0	0	20	\N	0
1831771304	0	k --	0	19	0	0	0	63	\N	0
6086881977	0	M. Adipta	0	25	0	0	0	1	\N	0
5861060283	0	riasha sabreena	0	13	0	0	370.98	56	\N	0
5313064170	0	hani	0	71	0	0	0	58	\N	0
5634410203	0	milo	0	111	1	0	295.47	141	\N	0
1361248765	0	ケンマ	0	1	0	0	0	0	\N	0
5828436643	0	ესტა	0	2	0	0	0	0	\N	0
1706003967	0	︎︎ ︎︎ ︎︎ ︎︎ ︎︎ ︎︎︎ ︎︎ ︎︎ ︎︎	0	311	0	0	147.61999999999983	4	\N	0
1954771520	0	amy	0	3	0	0	0	1	\N	0
6855741016	0	Fransisca	0	3	0	0	478	6	\N	0
5249555409	0	Y	0	8	0	0	0	0	\N	0
7111252677	0	ִֶָ 𓏲 shirley 𖣠 ༨	0	9	0	0	0	1	\N	0
1602875194	0	keènan.	0	376	0	0	285.06	1584	\N	0
1707254679	0	peony danella ♡👺	0	7	0	0	0	1	\N	0
2126663502	0	Ayanaa	0	9	0	0	0	1	\N	0
1903941149	0	jani	0	112	0	0	0	2	\N	0
5164523341	0	Pand.	0	15	0	0	0	1	\N	0
6693839108	0	Who?!	0	1	0	0	0	0	\N	0
1817674855	0	#SADULANOPMEMB jiyel	0	3	0	0	0	93	\N	0
1850010225	0	darvex	0	14	0	0	0	1	\N	0
1331079811	0	pacar vasko	8	1336	0	0	2772.552	29479	\N	0
6402336694	0	ishaa	0	64	0	0	206	53	\N	0
6073971332	0	neese	0	23	0	0	0	28	\N	0
1619218422	0	.	0	332	0	0	0	26	\N	0
1827340739	0	muyaaa	5	164	0	0	1006.7400000000006	12312	\N	0
5897411842	0	Mimi	0	23	0	0	0	148	\N	0
6040903611	0	nan	0	4	0	0	0	0	\N	0
2031745553	0	ameey.	2	224	0	0	18811.790000000005	866	\N	0
6155909898	0	ileyy rarely active	0	2	0	0	0	335	\N	0
6267511788	0	r	0	2	0	0	0	0	\N	0
5685715773	0	.	0	11	0	0	0	0	\N	0
1050985360	0	Russel	0	26	0	0	0	156	\N	0
6491491848	0	BELUM DI SB? RC AJA.	0	5	0	0	0	0	\N	0
5274803838	0	sel	0	7	0	0	0	8	\N	0
2018271720	0	al	0	57	0	0	0	66	\N	0
1860743994	0	odette	0	5	0	0	0	45	\N	0
5335282887	0	misca	0	3	0	0	0	0	\N	0
6754983442	0	abby	0	6	0	0	0	6	\N	0
2039823088	0	jen	7	331	0	0	536.8000000000001	416	\N	0
1898062083	0	sha	0	29	0	0	0	0	\N	0
5203624692	0	abian	0	4	0	0	0	0	\N	0
6419299402	0	vannn	0	2	0	0	0	2	\N	0
7067722927	0	Niarramadhani	0	2	0	0	0	6	\N	0
1995358872	0	Jaegara	0	4	0	0	0	0	\N	0
6103698903	0	Shaju	0	254	0	0	16.230000000000132	218	\N	0
5631072466	0	ayaa`	0	20	0	0	0	4	\N	0
1841906771	0	私 egar	0	43	0	0	0	0	\N	0
5774580056	0	Tama&Nidya. 🩰 on!	0	1	0	0	0	0	\N	0
6791168521	0	ryn🕷	0	14	0	0	0	75	\N	0
1782527806	0	ayuma	0	8	0	0	0	96	\N	0
5808666829	0	ayakk	0	4	0	0	0	0	\N	0
6190164719	0	tralala tara	0	72	0	0	5.8599999999998715	237	\N	0
927019133	0	urra	0	1	0	0	0	11	\N	0
5210588912	0	nora	0	176	0	0	44.37000000000013	15	\N	0
5481107398	0	rest for a while.	12	511	0	0	1400.1400000000012	2105	\N	0
1757577093	0	Perozpeko	0	1	0	0	0	0	\N	0
7093899797	0	raysha	0	4	0	0	0	5	\N	0
1791549339	0	Kkura	0	7	0	0	0	1	\N	0
1784297804	0	Bellingham	11	110	0	0	7670.72	12058	\N	0
1956213515	0	dii	0	13	0	0	0	7	\N	0
5846422045	0	yas	0	2	0	0	0	0	\N	0
1760776703	0	Hanelle.	0	1	0	0	0	0	\N	0
7115601976	0	b	0	4	0	0	0	0	\N	0
1918906760	0	veysel	0	83	0	0	18686.83	11229	\N	0
5523590729	0	143 rué	0	66	0	0	5080.4	355	\N	0
1992172541	0	Lilyy🪿	0	2	0	0	0	19	\N	0
5226500705	0	mark's gf	2	299	0	0	3003.2200000000003	10676	\N	0
5411364970	0	bri	0	1	0	0	0	0	\N	0
1650396208	0	pêjoy	0	0	0	0	0	0	\N	0
1979955898	0	je	0	1	0	0	0	2	\N	0
6338280406	0	c'est la vie	0	0	0	0	0	3	\N	0
6302310316	0	jorgas	0	6	0	0	0	0	\N	0
5298819899	0	denux	0	314	0	0	112.45000000000005	1903	\N	0
1850594310	0	7D_30_Ersya Lunetta Roffi	0	4	0	0	0	0	\N	0
6481779142	0	B one	0	2	0	0	0	15	\N	0
5094003996	0	アルセニオ	0	8	0	0	0	0	\N	0
5846692320	0	Kaizen.	0	119	0	0	4.67	4	\N	0
1115483936	0	Aurelia	0	4	0	0	0	2	\N	0
6088432833	0	yuna 🫧	0	3	0	0	0	3	\N	0
1894912501	0	J	0	0	0	0	0	0	\N	0
1399663028	0	iim	0	3	0	0	0	11	\N	0
5641515312	0	zı	0	8	0	0	0	6	\N	0
1873563086	0	Nazwa	0	9	0	0	0	1	\N	0
6123661521	0	XyiePhoenix⁶⁹Dior.	0	1	0	0	0	0	\N	0
5196831263	0	Keisha :p	0	0	0	0	0	8	\N	0
5127457838	0	🐳	0	1	0	0	0	1	\N	0
6108460128	0	yesi	0	1	0	0	0	1	\N	0
6123997035	0	erica	0	6	0	0	0	7	\N	0
5099064193	0	Arga.	0	1	0	0	0	0	\N	0
1825009742	0	⚝⦮ ⦯|ɴʀᴇ⋆ᖭ༏ᖫ⋆🍘💎🐚 🐙🐮🐥 #LORDRUBBY 〠𖦺 𖠌㊣🎸🤺	0	28	0	0	0	0	\N	0
1156762651	0	Kael J	0	1	0	0	0	7	\N	0
6139908412	0	James temenan.	0	3	0	0	0	2	\N	0
1295758779	0	maela	0	2	0	0	0	1	\N	0
5997421150	0	s	0	3	0	0	0	0	\N	0
1387789349	0	kayl	0	27	0	0	0	3	\N	0
1865793816	0	jane	0	11	0	0	0	0	\N	0
6345738515	0	.	0	95	0	0	0	29	\N	0
1611743124	0	lilie	0	65	0	0	135.61	44	\N	0
6567957115	0	kaylaaa	0	3	0	0	0	30	\N	0
1911847402	0	b	0	1	0	0	0	0	\N	0
1146292828	0	lee	0	101	0	0	217.42000000000002	165	\N	0
5118332265	0	ca	0	238	0	0	0	52	\N	0
2073919006	0	kal	0	6	0	0	0	17	\N	0
5465815637	0	—	0	11	0	0	0	0	\N	0
6542709849	0	kiranaaaa	0	1	0	0	0	0	\N	0
1955473061	0	𝙉𝙖𝙩𝙝𝙖𝙣.	0	6	0	0	0	5	\N	0
6553638165	0	El	0	3	0	0	0	2	\N	0
5155101539	0	amorza	0	1	0	0	0	0	\N	0
5331735562	0	hunter slctv, dni	8	845	0	0	5650.57	9607	\N	0
6208737247	0	Rayenn :D	0	38	0	0	0	72	\N	0
5025938910	0	Kiiwi	0	9	0	0	0	21	\N	0
1480144075	0	devandra	0	1	0	0	0	2	\N	0
1709757473	0	ship	0	20	0	0	1980	0	\N	0
1970969927	0	nel	0	5	0	0	0	48	\N	0
1723868544	0	lealeale	0	0	0	0	0	0	\N	0
1406657385	0	Dhiya	0	1	0	0	0	0	\N	0
6308606524	0	cipa 18+	0	97	1	0	12.870000000000005	787	\N	0
1887537282	0	bebel	0	7	0	0	0	0	\N	0
6729579763	0	ciyara	0	2	0	0	0	1	\N	0
6076788292	0	v. olaay's	0	1	0	0	0	38	\N	0
6376291333	0	aisy°	0	10	0	0	0	8	\N	0
6218116280	0	Lemon	13	48	0	0	3547.33	183	\N	0
6094160531	0	gee!	0	1	0	0	0	14	\N	0
5963070790	0	Fidoo	0	26	0	0	0	11	\N	0
1759020175	0	nzia. apk prem. freelance	0	21	0	0	0	17	\N	0
2037338854	0	Mark gf||alle	0	1	0	0	0	10	\N	0
5854460999	0	K	0	1	0	0	0	0	\N	0
1973942649	0	Vai	0	65	0	0	0	242	\N	0
5933647911	0	タ𝔯𝕥𝐒	0	2	0	0	0	7	\N	0
1702461483	0	hmu kalo @ nya ufs.	0	4	0	0	0	0	\N	0
5788547933	0	utara	0	24	0	0	0	10	\N	0
5991864598	0	baronn.A	0	6	2	0	0	10	\N	0
1128956656	0	annaya, late rep	0	0	0	0	33.6	69	\N	0
1524643546	0	Off.	0	69	0	0	0	6	\N	0
1920389357	0	Alsa	5	600	0	0	826.4199999999989	4263	\N	1
6425891578	0	velyn ⁴You	0	4	0	0	0	2	\N	0
5513589960	0	Hakim. @pendtekar	0	8	0	0	0	1	\N	0
7130630980	0	ᴢɪᴀʜ	0	4	0	0	0	2	\N	0
1725583792	0	nayla.	0	1	0	0	0	0	\N	0
7161921889	0	Not yours	0	2	0	0	0	4	\N	0
5779292010	0	d	0	53	1	0	12.569999999999993	3	\N	0
6591063102	0	+𖣁 kit-deliza. ᶻ 𝗓 𐰁	0	1	0	0	0	0	\N	0
6167419272	0	Naaa	0	2	0	0	0	1	\N	0
6451744703	0	.	0	1	0	0	0	0	\N	0
5942900438	0	Thomas	0	1	0	0	0	3	\N	0
6415252224	0	carissa	0	2	0	0	0	0	\N	0
5631744460	0	megA	0	1	0	0	0	0	\N	0
1447589749	0	valeen, slowresp.	0	45	0	0	2996.3999999999996	0	\N	0
5031696448	0	TEO	0	1	0	0	0	0	\N	0
1751190492	0	farley.	0	145	1	0	0	70	\N	0
1820550841	0	..	0	194	0	0	481.55999999999995	552	\N	0
6179546451	0	ᴅᴇᴠɪʟ. kurir sabu	3	93	0	0	2293.15	162	\N	0
1857614732	0	ボタン	0	3	0	0	0	1	\N	0
2102844637	0	$ . kanjackerman	0	179	0	0	7.259999999999998	184	\N	0
1393885442	0	Elleia Malore's	0	31	0	0	0	22	\N	0
1753130627	0	dik the kid	10	19	0	0	2772.8499999999995	46	\N	0
5365598485	0	Mons, Joseph Scheinwhelt.	9	15	0	0	71.92	32	\N	0
5509304343	0	medi	0	4	0	0	0	1	\N	0
5221715029	0	rryu.	0	1	0	0	0	2	\N	0
6892401107	0	bianca	0	6	0	0	0	1	\N	0
5164006836	0	.	14	282	0	0	46.290000000000646	43	\N	0
5354184687	0	el	0	1	0	0	0	0	\N	0
1993029375	0	لويس	0	214	0	0	0	812	\N	0
6830942518	0	dni	0	6	0	0	0	0	\N	0
7189873261	0	eleee💤	0	20	0	0	0	5	\N	0
5308168604	0	𝟐𝟒𝟖	0	1	0	0	0	0	\N	0
6356626096	0	Nanaaa	0	60	0	0	0	40	\N	0
5933754060	0	Fa	0	305	0	0	20.210000000000036	250	\N	0
2047280176	0	Geraldo	0	2	0	0	0	0	\N	0
6727501417	0	raezylea	0	3	0	0	0	0	\N	0
5278382304	0	.	0	33	0	0	0	1	\N	0
7106937240	0	Reiiiiiiiiii	0	6	0	0	0	0	\N	0
5736840302	0	Jèvarsa Kavarèsta	0	6	0	0	0	2	\N	0
1729162190	0	adis	0	2	0	0	0	5	\N	0
5062956595	0	Athan ℭ𝔞𝔭𝔱.	0	8	0	0	0	3	\N	0
5060751792	0	.	0	14	0	0	0	5	\N	0
6252228911	0	blm tau	0	1	0	0	0	0	\N	0
5438316676	0	Paldo	0	2	0	0	0	1	\N	0
5994773224	0	Woman	0	241	0	0	0	26	\N	0
5257868030	0	Gun	0	1	0	0	0	0	\N	0
5572425249	0	adel	0	1	0	0	0	1	\N	0
6128773003	0	jeasther	0	7	0	0	0	27	\N	0
6347488856	0	shäney n. أحبك	0	1	0	0	0	0	\N	0
6591850253	0	shala	0	1	0	0	0	0	\N	0
6407264403	0	der	0	3	0	0	0	0	\N	0
5638009502	0	jeord	0	32	0	0	973.0699999999999	3295	\N	0
1690202069	0	<=3	0	1	0	0	0	0	\N	0
6084967649	0	bijer barakallah	0	133	0	0	408.03999999999996	244	\N	0
1849697248	0	.	0	2	0	0	0	0	\N	0
1374927997	0	𝙰	0	1676	0	0	29626.199999999997	1798	\N	0
6142554016	0	sophia	0	4	0	0	0	0	\N	0
1887121444	0	Khaleela.	0	38	0	0	201.39999999999998	339	\N	0
1601860390	0	iban	0	9	0	0	0	12	\N	0
5543937387	0	chielly	0	62	0	0	0	88	\N	0
5324411364	0	laurence	0	68	0	0	0	224	\N	0
1635727595	0	Demian Langston.	0	17	0	0	10	12	\N	0
2019573709	0	af	0	57	0	0	0	0	\N	0
6513427874	0	en	0	4	1	0	0	5	\N	0
2111810565	0	sharbin	0	1	0	0	0	0	\N	0
1840851739	0	zipa ハッピー	0	104	0	0	238	136	\N	0
1263853435	0	🥏	0	404	0	0	593.1	254	\N	0
5229666788	0	Maggie.	3	571	0	0	3436.1400000000003	1005	\N	0
1894492887	0	R	0	4	0	0	0	0	\N	0
1912895297	0	akarashikaa.	0	39	0	0	489.5	48	\N	0
5766995953	0	Nath.	0	4	0	0	0	2	\N	0
972670385	0	C	0	1	0	0	0	2	\N	0
5406412330	0	nyanya	0	30	0	0	0	0	\N	0
1278215074	0	mrkus	0	16	0	0	38.27	3	\N	0
1716988164	0	syee	0	43	0	0	0	103	\N	0
6188802170	0	Hankao cinta epep dan pabji	0	6	0	0	0	36	\N	0
2083769882	0	manuel	6	208	0	0	0	308	\N	0
5361732290	0	ameena victoryking	0	5	0	0	0	6	\N	0
6731447625	0	𝕯𝕬¹🇹🇹	0	1	0	0	0	1	\N	0
6956995788	0	j	0	7	0	0	0	0	\N	0
5259686958	0	Laparrrrrrrrrr..........	0	143	0	0	3	68	\N	0
1966406370	0	davin — fastrespon	1	1679	0	0	718.0999999999996	10980	\N	0
1398232839	0	beeze	0	2	0	0	0	1	\N	0
1063720977	0	Alan capek di kitchen 😰😰	0	55	0	0	0	11	\N	0
5950031839	0	🥝	0	8	0	0	0	3	\N	0
1760469570	0	joe	0	1	0	0	0	0	\N	0
2071704759	0	nathan	0	33	0	0	0	65	\N	0
6641375452	0	nayasa	0	1	0	0	0	0	\N	0
5757954671	0	K.	0	307	1	0	163.29999999999936	1241	\N	0
6236553214	0	Nathan.	0	10	0	0	193.42	39	\N	0
5977157547	0	raziel	0	1	0	0	0	0	\N	0
5503532600	0	🐻	0	1	0	0	0	3	\N	0
1932087393	0	Rence, Sugyeom's mine.	0	40	0	0	0	197	\N	0
1320831060	0	J	0	65	0	0	10	1	\N	0
1972023729	0	Yuuji Kennedy	9	20	0	0	2408.01	23	\N	0
2002058496	0	pindah akun	0	14	0	0	0	2	\N	0
6205673883	0	nda.	0	2	0	0	0	0	\N	0
1580684360	0	Ayana	0	7	0	0	0	1	\N	0
1856023717	0	rozil	0	2	0	0	0	0	\N	0
1620506481	0	𝕬𝖈𝖆	0	3	0	0	0	0	\N	0
5977435142	0	aeri	0	6	0	0	62.2	17	\N	0
5109033857	0	fela ngidam usn @.	0	8	0	0	0	68	\N	0
5433857807	0	hazel	0	0	0	0	0	0	\N	0
1843630858	0	¹²⁺𝐒𝐃𝐒 dd nana	0	60	0	0	550	0	\N	0
5026416810	0	ve	0	8	0	0	0	0	\N	0
6180201833	0	kala	0	95	0	0	659.2399999999993	850	\N	0
1426926401	0	Akilla.	0	2	0	0	0	0	\N	0
6987640942	0	cello	0	1	0	0	0	0	\N	0
5982230775	0	.	0	10	0	0	0	2	\N	0
6441199247	0	A for adel	0	3	0	0	0	5	\N	0
6350799258	0	laut	0	2	0	0	0	0	\N	0
1943145471	0	Jereno.	0	3	0	0	0	17	\N	0
6966900199	0	drax	0	2	0	0	0	0	\N	0
6509550160	0	Natxzzz	0	2	0	0	0	2	\N	0
5763286367	0	a fahrezi	0	6	0	0	0	1	\N	0
1589105019	0	faya	0	25	0	0	0	101	\N	0
7094804821	0	hang heng	0	36	0	0	0	0	\N	0
5179872525	0	el	0	18	0	0	0	18	\N	0
1596801241	0	kitten dust	0	1	0	0	0	0	\N	0
1782764146	0	M.	0	26	0	0	0	8	\N	0
6537575041	0	Wlekkwlek	0	5	0	0	0	3	\N	0
5576271963	0	mouine	0	1	0	0	0	0	\N	0
1902982302	0	nami	0	0	0	0	0	0	\N	0
5341414273	0	Najendra	0	0	0	0	0	0	\N	0
954326379	0	Rayn	0	1	1	0	0	0	\N	0
1939950562	0	Jefferson.	0	3	0	0	0	0	\N	0
7050878424	0	antikahh	0	0	0	0	0	1	\N	0
6829370901	0	filbert	0	34	0	0	0	4	\N	0
1751331915	0	asa berpita	0	4	0	0	0	0	\N	0
6569305198	0	jastin ōtsukiryu	0	1	0	0	0	0	\N	0
5356628954	0	Rif	0	4	0	0	0	4	\N	0
6112478071	0	f	0	11	0	0	0	0	\N	0
1728957272	0	cheevaㅤㅤ	0	4	0	0	0	14	\N	0
1892151251	0	jenaissante.	0	1	0	0	0	7	\N	0
5607132604	0	zeraa	0	52	0	0	3.67	84	\N	0
5448385111	0	j	12	51	0	0	185.28999999999985	274	\N	0
5205144064	0	delion	0	35	0	0	0	0	\N	0
6550484373	0	chssy	0	1	0	0	0	0	\N	0
5961309594	0	ell	0	1	0	0	0	6	\N	0
6377603891	0	midnight rain	9	3	0	0	239.75000000000003	220	\N	0
1286129862	0	taehyung	0	6	0	0	0	11	\N	0
6673679073	0	lea	0	4	0	0	0	2	\N	0
1313415777	0	yuniii	0	1	0	0	0	1	\N	0
6431729851	0	tanayaa	0	1	0	0	0	8	\N	0
5580115376	0	b suicy	0	1	0	0	0	0	\N	0
6808962177	0	waverly, 🍤	0	2	0	0	0	4	\N	0
5359356811	0	L	0	12	0	0	0	1	\N	0
6732318796	0	azj	0	1	0	0	0	0	\N	0
1891984966	0	jay?	0	57	0	0	141.93	64	\N	0
5730004765	0	Syaaa	0	0	0	0	0	0	\N	0
6532238403	0	𝐶𝐿 n	0	2	0	0	0	0	\N	0
5179988490	0	rann @robdn!	0	43	0	0	55.06	34	\N	0
6872680099	0	alisha.	0	1	0	0	0	0	\N	0
5885044799	0	Away	0	4	0	0	0	6	\N	0
1714056999	0	vy.	0	0	0	0	0	0	\N	0
5294570782	0	whif	0	3	0	0	0	0	\N	0
6569043697	0	flowiee	0	6	0	0	0	13	\N	0
2025856639	0	verox	0	36	0	0	0	69	\N	0
2020508071	0	indy	0	1	0	0	0	0	\N	0
5147959815	0	aktif kl mood aj.	0	65	0	0	0	149	\N	0
7124296384	0	bikina	0	1	0	0	0	4	\N	0
6711203382	0	ay	0	13	0	0	0	4	\N	0
1696289136	0	nana	0	120	0	0	1397.24	106	\N	0
5004749393	1	꣑୧..”사랑 Shenina, J.”	11	486	0	0	348.1	1451	\N	1
259509203	0	gincu	0	263	0	0	4079	0	\N	0
6398681927	0	Nnnnn	0	158	0	0	7.790000000000006	302	\N	0
2026989926	0	kailla	0	6	0	0	0	1	\N	0
924137391	0	A	0	1	0	0	0	2	\N	0
5686588745	0	Ar	0	14	0	0	0	14	\N	0
6105995520	0	meyraa	0	14	0	0	690.6899999999999	7	\N	0
1086219672	0	farawww	0	0	0	0	0	3	\N	0
6604204122	0	Abina	0	61	0	0	9	7	\N	0
6294011237	0	Mikel.	0	1	0	0	0	0	\N	0
5108611133	0	raya matwous #OPLINKEGL	0	1	0	0	0	3	\N	0
1817036132	0	Renja Naa	0	2	0	0	0	2	\N	0
5106762623	0	magute	0	3	0	0	0	2	\N	0
1720847846	0	riri	0	1	0	0	0	5	\N	0
1989150104	0	jara	0	2	0	0	0	1	\N	0
6215474758	0	May	0	2	0	0	0	0	\N	0
1487010535	0	y	0	1	0	0	0	2	\N	0
1920406922	0	Zerasha Radine	0	124	0	0	0	253	\N	0
6184311291	0	love	0	13	0	0	0	5	\N	0
5073177219	0	Nanaaa	0	53	0	0	5.83	12	\N	0
6399274605	0	alinn	0	3	0	0	0	22	\N	0
6947058565	0	del	0	2	0	0	0	0	\N	0
6072020932	0	sya	0	3	0	0	0	1	\N	0
6272197827	0	rachel	0	2	0	0	0	1	\N	0
5214452766	0	qinqin	0	1	0	0	0	2	\N	0
1641845666	0	Edel	0	2	0	0	0	2	\N	0
1788557226	0	:p	0	11	0	0	0	10	\N	0
5564729822	0	Nina	0	0	0	0	0	19	\N	0
5537083590	0	asyaa.	0	869	0	0	2.1000000000008185	211	\N	0
5272723606	0	el	0	2	0	0	0	0	\N	0
1731869295	0	Juna, IA.	0	1	0	0	0	5	\N	0
5801099369	0	ʚ almeira ɞ	0	1	0	0	0	0	\N	0
7092422412	0	rean	0	1	0	0	0	0	\N	0
1748828706	0	juwaaa	0	1	0	0	0	0	\N	0
6173054004	0	— àyy	0	58	0	0	0	24	\N	0
5321510758	0	nacya	0	1	0	0	0	0	\N	0
5018472775	0	risyad	0	1	0	0	0	0	\N	0
6246386382	0	Azamm	7	5	0	0	794.6299999999999	282	\N	0
5543049402	0	sachii	0	6	0	0	0	55	\N	0
5604720820	0	tasherrew	0	4	0	0	0	1	\N	0
1204469121	0	Lala	0	8	0	0	0	0	\N	0
6936489129	0	fy	13	26	0	0	110.18000000000002	398	\N	0
6828186078	0	ysmn (move)	0	1	0	0	0	0	\N	0
6286356473	0	. Angkasa hehe	0	19	0	0	0	10	\N	0
6537678268	0	ᥲdrιᥲᥒ 𝖈𝖗𝖆𝖘𝖍'⁶² 𝐀𝟗𝟕	0	0	0	0	0	0	\N	0
5097341583	0	Hisa	0	23	0	0	50	232	\N	0
6198826572	0	evelyn!	0	71	0	0	3379.8599999999997	109	\N	0
1913621184	0	aa heza	0	3	0	0	0	6	\N	0
5502238041	0	Rie	0	1	0	0	0	9	\N	0
5566995342	0	bebek	0	4	0	0	0	0	\N	0
6456184928	0	-	0	1	0	0	0	15	\N	0
2003495589	0	shey vogos	0	31	0	0	0	34	\N	0
1795940095	0	⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣	0	3	0	0	0	31	\N	0
1820396248	0	ussy	0	0	0	0	0	0	\N	0
5108827253	0	Jame	0	1	0	0	0	3	\N	0
5461629123	0	uzma	0	2	0	0	0	0	\N	0
2049755979	0	Imelda	0	14	0	0	103.13	0	\N	0
1916142257	0	Adip	0	1	0	0	0	0	\N	0
5615880537	0	🍑	0	82	0	0	71.95000000000002	79	\N	0
5206018067	0	Niscala Valentino	0	340	0	0	0	3	\N	0
1869549506	0	— 𝑨leia rdl	1	283	0	0	188.69999999999982	47	\N	0
5020556401	0	kind celestine	0	2	0	0	0	0	\N	0
5279610270	0	c	0	0	0	0	0	0	\N	0
6954407067	0	Binar	0	1	0	0	0	3	\N	0
5438403395	0	Dlarrr	0	2	0	0	0	0	\N	0
6604057201	0	ry	0	1	0	0	0	0	\N	0
5230800032	0	Ryensha	0	5	0	0	0	1	\N	0
6359593267	0	👽 glarettaa	0	4	0	0	0	0	\N	0
5328246585	0	kembaran wonyy ♡゙	0	28	0	0	0	113	\N	0
5405862445	0	davisya	0	1	0	0	0	0	\N	0
5888696969	0	syahlw	0	4	0	0	0	1	\N	0
1434631318	0	natheo	0	1	0	0	0	3	\N	0
5881734310	0	૮₍ ⸼ᐢᐢ 𝕥𝘁𝕒𝗹𝗴𝕚 🍓💬 hasley ♡	0	1	0	0	58.15	6	\N	0
1571526524	0	pio	0	12	0	0	0	18	\N	0
6170199328	0	orca	0	24	0	0	17.859999999999957	19	\N	0
1739706993	0	aye salima	0	108	0	0	2853.61	1293	\N	0
1772912415	0	sha	0	4	0	0	0	0	\N	0
1771071216	0	l	13	210	0	0	4051.5499999999993	33	\N	0
6023447828	0	galendra.	0	42	0	0	155	176	\N	0
1849061900	0	aby	0	35	0	0	0	30	\N	0
1746242044	0	bluëy.	0	4	0	0	0	2	\N	0
1768417757	0	Renjun's Admirer, Kamala	0	4	0	0	0	1	\N	0
5294720419	0	daraAa miaw miaw	0	10	0	0	0	1	\N	0
5589070037	0	🦸🏻‍♀️💋	0	16	0	0	61.64	31	\N	0
1232420314	0	ichiko no sauyu tkh	0	2	0	0	0	0	\N	0
1722503047	0	nail	0	5	0	0	0	0	\N	0
1909595338	0	Nanaaa🐰	0	8	0	0	0	7	\N	0
1206217026	0	nn	12	1049	0	0	46.94999999999953	2235	\N	1
5429212324	0	Jenaya	0	1	0	0	0	0	\N	0
6092359311	0	Chelvath—L.	0	0	0	0	0	6	\N	0
687989151	0	R	0	2	0	0	0	142	\N	0
5358552511	0	phany twins jihyoo ok	7	71	0	0	0	415	\N	0
5175996421	0	ar	0	3	0	0	0	0	\N	0
6263075108	0	Hirayem	0	23	1	0	0	11	\N	0
1959156825	0	aime?	0	109	0	0	151.5	81	\N	0
6426370720	0	kiára	0	49	0	0	14.83000000000007	15	\N	0
5101970593	0	Jawir	0	12	0	0	484.61999999999983	601	\N	0
6173991837	0	elara	0	10	0	0	0	17	\N	0
5645562773	0	kafka	0	1	0	0	0	7	\N	0
952435101	0	ซี¹ marguerite.	0	4	0	0	0	57	\N	0
7057989258	0	Keyrä A.	0	4	0	0	0	7	\N	0
5471780074	0	Siti	0	1	0	0	0	1	\N	0
1932818297	0	nnaaaooommiii (# >o<)	0	1	0	0	0	2	\N	0
5268534980	0	ajka	0	4	0	0	0	0	\N	0
6877757397	0	z'x	0	0	0	0	0	0	\N	0
5289683023	0	k, autumn girlie	0	11	0	0	115.76000000000028	931	\N	0
6558930385	0	lucie	0	36	0	0	0	617	\N	0
6658623301	0	nirkabel	0	18	0	0	0	6	\N	0
1428141043	0	nay	0	127	0	0	0	525	\N	0
5500948359	0	Nina	0	10	0	0	0	4	\N	0
5865718700	0	kinarr	3	85	0	0	375.959999999998	48	\N	1
6801406323	0	queel no style	0	26	0	0	1450	97	\N	0
1809729389	0	Jeno's Angel, Abigail R.	0	16	0	0	0	0	\N	0
6638270253	0	нѕт≛¹ Jarvis. #BJNWORLD	0	6	0	0	0	0	\N	0
5949002821	0	Marrvez	0	1	0	0	0	0	\N	0
6737623525	0	key	0	1	0	0	0	0	\N	0
1906630543	0	Jed	0	25	0	0	355.36	680	\N	0
6907620149	0	rchell_	0	16	0	0	0	0	\N	0
5570540537	0	s	0	21	0	0	0	39	\N	0
5571374757	0	Yera	0	2	0	0	0	3	\N	0
1906038110	0	mila	0	22	0	0	46	7	\N	0
6145974103	0	Alvian	0	9	0	0	0	0	\N	0
5085255842	0	Mowy𝖅༉	0	28	0	0	0	38	\N	0
5305048659	0	reen	0	6	0	0	0	37	\N	0
1852959893	0	wawa	0	3	0	0	0	0	\N	0
2134563858	0	ㅤㅤㅤㅤㅤㅤㅤㅤㅤ	0	3	0	0	0	0	\N	0
2146624282	0	arsa	0	2	0	0	0	3	\N	0
1592651649	0	cacaA ˶ᵔ ᵕ ᵔ˶	0	3	0	0	0	1	\N	0
5436917549	0	japas s/ia	0	28	0	0	0	178	\N	0
1618479427	0	Youri	0	1	0	0	0	2	\N	0
5401076187	0	Rabu	0	17	0	0	10	0	\N	0
2146689445	0	iyel not in da mood 💢	2	214	0	0	2811.4300000000003	14969	\N	0
1829127242	0	joel	0	11	0	0	0	4	\N	0
7082433134	0	.	0	15	0	0	0	23	\N	0
5343159226	0	D R A G O N	0	5	0	0	0	3	\N	0
5748083183	0	miyuu stobelii 🍓🐇	0	20	0	0	0	80	\N	0
5548065994	0	oke baiklah	0	1	0	0	0	1	\N	0
1764843887	0	joshua	0	2	0	0	0	0	\N	0
6784312072	0	Khailula! :3	0	83	0	0	0	0	\N	0
6622199313	0	Nay	0	7	0	0	0	13	\N	0
1586485362	0	merc	0	2	0	0	0	27	\N	0
1896111392	0	rindu	0	26	0	0	0	12	\N	0
5343489586	0	man	0	78	0	0	2.5	13	\N	0
5970925637	0	a	0	85	0	0	1257.5700000000002	74	\N	0
1659294007	0	deadpool	6	173	0	0	3.179999999998472	3758	\N	0
6216485722	0	karin	0	111	0	0	0	6	\N	0
6791445016	0	N	0	3	0	0	0	0	\N	0
6172168897	0	Seina	0	48	0	0	3.819999999999993	51	\N	0
1764173347	0	lily	0	9	0	0	0	0	\N	0
6179414325	0	Jia	0	11	0	0	0	0	\N	0
6681677286	0	Catherine.	0	3	0	0	0	0	\N	0
6717962679	0	chattyfall	0	1	0	0	0	3	\N	0
6929743506	0	🐈 🐈 🐈 🐈 🐈 🐈 🐈 🐈	0	3	0	0	0	13	\N	0
1500666231	0	Anne	0	7	0	0	0	26	\N	0
1609193170	0	pipit	0	10	0	0	0	1	\N	0
6713394607	0	mabell	0	4	0	0	0	7	\N	0
1991271656	0	aza	0	6	0	0	0	5	\N	0
6981077706	0	P	0	2	0	0	0	1	\N	0
5512706553	0	pie 😾	0	4	0	0	0	1	\N	0
5072174517	0	rafax	0	13	0	0	100	20	\N	0
1795386939	0	423. Gavintara,	0	3	0	0	0	11	\N	0
6834404099	0	e	0	58	0	0	0	140	\N	0
6203194718	0	Dewi	0	1	0	0	0	0	\N	0
5336731969	0	a	0	0	0	0	0	0	\N	0
1601779596	0	samosir	0	1	0	0	0	0	\N	0
2052472655	0	Aricia luella	0	81	0	0	10	3	\N	0
1847291435	0	skyyy	0	1	0	0	0	0	\N	0
1459349972	0	Lin	0	53	0	0	34.97	108	\N	0
5470848702	0	sa	0	32	0	0	0	0	\N	0
2114381041	0	Raily Geosfy.	0	251	0	0	0	1382	\N	0
1165484120	0	ˢᵘⁿPelixx	0	3	0	0	0	1	\N	0
6315481856	0	Iko	0	1	0	0	0	11	\N	0
1623760621	0	Khair,	0	5	0	0	0	19	\N	0
1506673892	0	yay	0	1	0	0	0	0	\N	0
5217452408	0	.	0	49	0	0	0	141	\N	0
6282466319	0	mowmou	0	101	0	0	10.349999999999994	117	\N	0
2123494432	0	taaa	0	3	0	0	0	0	\N	0
6274466883	0	bass	0	8	0	0	0	24	\N	0
5601818762	0	Zewa	0	3	0	0	0	11	\N	0
1746713637	0	gabriel	0	167	0	0	0	2	\N	0
1703917708	0	L	0	1	0	0	0	10	\N	0
5408993478	0	.	0	45	0	0	1079.26	46	\N	0
6726674337	0	aaa	0	13	0	0	0	21	\N	0
1704854755	0	Nalesha.	0	0	0	0	0	0	\N	0
5009678901	0	ais cantik ^~^	0	221	0	0	12.300000000000047	37	\N	0
2021036791	0	Elraz	0	33	0	0	0	22	\N	0
5558492838	0	A	0	39	0	0	0	8	\N	0
2069880293	0	yunjin ;3	0	2310	0	0	1478.47	5645	\N	0
1899956501	0	sasa	6	1073	0	0	1.2199999999998	2775	\N	0
2005274707	0	just call me lia	12	786	0	0	997.889999999999	498	\N	0
6091505709	0	S	0	20	0	0	11.129999999999995	34	\N	0
1591267649	0	c l a	0	97	0	0	0	70	\N	0
5736201758	0	alza obbra	0	5	0	0	0	0	\N	0
1181957272	0	Jerry	0	2	0	0	0	0	\N	0
1942288756	0	Lizzy	0	3	0	0	0	0	\N	0
5290987749	0	kenn	0	0	0	0	0	4	\N	0
1848148368	0	Dave	0	54	0	0	0	57	\N	0
6071817894	0	jifran.	0	5	0	0	286	0	\N	0
5721957174	0	hanni	0	2	0	0	0	0	\N	0
1851949051	0	Zoey	0	7	0	0	0	0	\N	0
6066710938	0	shan	0	9	0	0	0	0	\N	0
657377581	0	mfaisxl	0	1	0	0	0	2	\N	0
910807970	0	prettiest j	0	61	0	0	0	297	\N	0
5477768078	0	Pierre	0	74	0	0	0	37	\N	0
5410989650	0	C	13	58	0	0	0	46	\N	0
6093056264	0	caya	0	3	0	0	0	3	\N	0
5230287448	0	ghefira	0	2	0	0	0	0	\N	0
1751640096	0	ele	0	31	0	0	0	5	\N	0
5471661681	0	lita mau pelihara paus	0	25	0	0	0	7	\N	0
1176389993	0	bintang	0	46	0	0	0	31	\N	0
5879511466	0	Ruviye.	0	58	0	0	185.19	681	\N	0
5328642896	0	𝐓𝐑≛𝐏𝐒 `Madame Catania	0	3	0	0	0	19	\N	0
7082699583	0	r	0	9	0	0	0	0	\N	0
1328570524	0	angkasa H.	0	10	0	0	0	1	\N	0
1609641787	0	Amore Bahng • 𝓛𝗻𝘦𝖛𝖘	0	200	0	0	1878.8900000000003	811	\N	0
6170826059	0	Kyleah	0	101	0	0	0	52	\N	0
6014599207	0	paula	0	5	0	0	0	3	\N	0
6172395631	0	naya dél rey	13	59	0	0	205.04000000000008	587	\N	0
1640611391	0	% . 𝗠𝗮𝗱𝗮𝗺 𝗝𝗈𝖼𝖾𝗒	0	100	0	0	0	4	\N	0
5431496166	0	ney	0	2	0	0	0	2	\N	0
6172198103	0	brenaa 🇸🇿	0	47	0	0	0	39	\N	0
5232633235	0	DNI. arsen	0	1	0	0	0	6	\N	0
1993300324	0	𝐃iuna🍀	0	282	0	0	451.5	58	\N	0
5196252419	0	n	0	16	0	0	0	23	\N	0
1725142110	0	clar.	0	0	0	0	0	0	\N	0
1556846810	0	𝓐. aya	14	194	0	0	850.4699999999989	600	\N	1
6181427995	0	ken	0	47	0	0	0	1	\N	0
6888295639	0	aheng's	0	7	0	0	0	0	\N	0
5174080406	0	Rayena	0	9	0	0	0	26	\N	0
1420798343	0	c	9	3	0	0	0	11	\N	0
6984506961	0	.	0	54	0	0	132	389	\N	0
1292640387	0	iel	0	73	0	0	0	1	\N	0
7157775524	0	amell	0	1	0	0	0	0	\N	0
5879621746	0	louisa	0	11	0	0	0	1	\N	0
1779308907	0	nemoo k	11	1004	0	0	3928.389999999963	8425	\N	1
1715851624	0	cicAa	0	898	0	0	2.9600000000002638	1089	\N	0
1668871829	0	Gilar ckkep	0	11	0	0	0	685	\N	0
6206717651	0	aileen	0	21	0	0	52	0	\N	0
1834739673	0	Muhamad Rifki	0	0	0	0	0	0	\N	0
2091705351	0	Ratu	0	14	0	0	0	4	\N	0
6837690358	0	kakayy	0	9	0	0	0	0	\N	0
5730084658	0	196 jack	0	3	0	0	0	0	\N	0
6297304988	0	Csya𓄹	0	1	0	0	0	0	\N	0
5641686277	0	sye.	0	3	0	0	0	0	\N	0
1489862891	0	sasa	0	1	0	0	0	1	\N	0
1804242168	0	cipai	0	67	0	0	377.2599999999999	671	\N	0
1359615027	0	jie pacar jeno	0	766	0	0	20.889999999999986	601	\N	0
6496669264	0	Ĺingka suka eisa	0	40	0	0	0	97	\N	0
1998306398	0	wawa	0	277	0	0	0	15	\N	0
6113758242	0	catania	0	1	0	0	0	0	\N	0
2145476074	0	Marcel sayang mami lova	0	115	0	0	0	554	\N	0
2076993354	0	vaa ree	0	1	0	0	12.2	2	\N	0
6465743242	0	kanes	0	5	0	0	0	0	\N	0
7185508013	0	ti🅰️	0	8	0	0	0	16	\N	0
6746555102	0	`⁹⁹¹ kayezz	0	1	0	0	0	0	\N	0
967704064	0	Anne	0	2	0	0	0	2	\N	0
6033852184	0	Jeeru.	0	1	0	0	0	0	\N	0
6285212542	0	Kay	0	1	0	0	0	0	\N	0
5677619882	0	Sokka	0	212	0	0	570.0999999999999	367	\N	0
5804030843	0	Amberliesky	0	1	0	0	0	0	\N	0
6405446525	0	syaa	0	12	0	0	0	3	\N	0
5947964867	0	K	0	59	0	0	0	6	\N	0
1417062762	0	nala	0	113	0	0	0	162	\N	0
5251705264	0	yumna	0	1	0	0	0	0	\N	0
5022383560	0	ataa	0	2	0	0	0	2	\N	0
6150647396	0	♡	0	3	0	0	0	0	\N	0
7132082789	0	nata	0	74	0	0	67.4	123	\N	0
6077841396	0	someone	0	43	0	0	0	15	\N	0
1754387585	0	Velop wiu wiu 🚓	0	24	0	0	615.1899999999999	1673	\N	0
6075847818	0	dan.	0	61	0	0	4058.12	19	\N	1
6360892172	0	🍂⌗ Bαstiαn 𓂃 (Taylor's Version) 𖥔༌ ᰷	0	1	0	0	0	0	\N	0
1901097108	0	kay	0	3	0	0	0	6	\N	0
6812622553	0	Adolf	0	5	0	0	0	21	\N	0
1887570788	0	Syalum	5	950	0	0	496.33999999999924	1258	\N	0
6493351260	0	Shayeva Rayakha.	0	6	0	0	0	9	\N	0
1130499702	0	giyyoo	0	21	0	0	0	5	\N	0
5185945994	0	abin assistant	0	383	0	0	332.0999999999999	566	\N	0
1625212542	0	evelyn	0	25	0	0	0	20	\N	0
6970848678	0	dil	0	95	0	0	0	32	\N	0
5751796285	0	yaya tk 🅰	0	9	0	0	29.950000000000045	14	\N	0
5303582267	0	Hanindya Akshaya	0	0	0	0	0	25	\N	0
6416403367	0	pierre	0	2	0	0	0	16	\N	0
1740779831	0	ian	0	1	0	0	0	0	\N	0
6893462907	0	katya	0	10	0	0	0	18	\N	0
5447137742	0	<3	0	1	0	0	0	0	\N	0
6080828573	0	Javas	0	1	0	0	0	0	\N	0
1735748885	0	Naviér	0	7	0	0	0	0	\N	0
6939544040	0	rr	0	1	0	0	0	2	\N	0
2123027682	0	Jeisel miyong	0	176	0	0	0	218	\N	0
1717193537	0	꒰◍ ´꒳ ◍꒱	0	3015	0	0	6.969999999999914	594	\N	0
1959052651	0	verliee 𝑺𝑵	4	873	0	0	1402.9600000000005	10776	\N	0
6035511804	0	mírkyy #LagiMamamEsKulKul no counter	0	11	0	0	0	29	\N	0
6287883894	0	kinan	0	200	0	0	0	350	\N	0
1970239662	0	Anggie	0	30	0	0	0	26	\N	0
6264227943	0	-	0	2	0	0	0	0	\N	0
5140262954	0	z	0	1	0	0	0	3	\N	0
5870523022	0	Patras. J	0	2	0	0	0	0	\N	0
1710207599	0	rv	0	3	0	0	0	0	\N	0
5424033960	0	jeno gf	2	116	0	0	3830.4499999999994	125	\N	0
1738114062	0	bulan	0	9	0	0	0	0	\N	0
1876449916	0	lazada	0	5	0	0	0	0	\N	0
1625633649	0	ticha	0	23	0	0	0	77	\N	0
6290233190	0	.	0	17	0	0	0.38000000000010914	104	\N	0
1810136580	0	j	0	5	0	0	0	226	\N	0
5640870102	0	N. Ciwaraga	0	3	0	0	0	0	\N	0
2033132886	0	Raychella	3	179	0	0	0	1380	\N	0
5102957276	0	Zevallo	0	4	0	0	0	0	\N	0
6078905467	0	Aruna ●	0	2	0	0	0	2	\N	0
5223478214	0	Piers Nivans.	0	8	0	0	0	5	\N	0
1989088858	0	rall	0	19	0	0	0.625	6	\N	0
6502604764	0	cikaa	0	6	0	0	0	0	\N	0
1938522174	0	sya	0	0	0	0	0	0	\N	0
5360270314	0	reyy	0	6	0	0	0	19	\N	0
6037608286	0	yayaa edannn	0	1	0	0	0	0	\N	0
7037214139	0	Choso main accnya kelogout	0	29	0	0	0	12	\N	0
1852259187	0	khayra	0	34	0	0	60	230	\N	0
5486178881	0	z	0	1	0	0	0	1	\N	0
1622313951	0	Arin	0	1	0	0	0	1	\N	0
6261415385	0	cey	0	71	1	0	13.149999999999977	93	\N	0
6109867809	0	ta	0	5	0	0	0	6	\N	0
5488051295	0	syafa	0	1	0	0	0	0	\N	0
5160717175	0	panggil aja lala	0	0	0	0	521.3199999999999	29	\N	0
5442516837	0	Rahas K	0	416	0	0	18.26	375	\N	0
6142647229	0	saa	0	121	0	0	30.939999999999998	32	\N	0
1896567907	0	pia	8	396	0	0	1477.9300000000003	46	\N	0
6694863811	0	Magnum kenny	0	150	0	0	79.91	255	\N	0
5551555698	0	perse, openn slowresp.	0	18	0	0	0	219	\N	0
5836782473	0	sera	0	1	0	0	0	0	\N	0
1154163958	0	egs anjel x ɪɴᴅᴏʙᴇᴛ	0	3	0	0	0	5	\N	0
1839748187	0	nana	0	2	0	0	0	1	\N	0
5213481573	0	Fumiko	0	10	0	0	0	18	\N	0
1574615588	0	iel	0	59	0	0	0	190	\N	0
2015209629	0	Haffindra	0	16	0	0	0	54	\N	0
6232534650	0	Yakhal🧑🏼‍🔧	0	8	0	0	0	1	\N	0
6183670175	0	vanya	0	3	0	0	0	3	\N	0
1633705262	0	a	0	0	0	0	0	6	\N	0
5706264837	0	a	0	1	0	0	0	0	\N	0
6044575018	0	starfúck.	0	5	0	0	0	12	\N	0
6642833269	0	𝐕.	0	1	0	0	0	0	\N	0
5790039912	0	ayy 🐍🐍	0	5	0	0	0	35	\N	0
6215080422	0	ali	0	68	0	0	8.82	5	\N	0
2031024163	0	sabitha 식	0	6	0	0	0	1	\N	0
1736358977	0	꒰ ა eluwcii ໒ ꒱	0	23	0	0	0	20	\N	0
5875655196	0	.	0	3	0	0	0	0	\N	0
5075833112	0	Sayu	0	1	0	0	0	0	\N	0
5977154550	0	Jeje	0	14	0	0	263.27	479	\N	0
5637117597	0	ecall lostfeel	0	49	0	0	0	35	\N	0
6274743345	0	Shaquille	0	2	0	0	0	0	\N	0
5000028326	0	Nrr	0	400	0	0	1093.9799999999998	584	\N	0
5817949265	0	melvin tau apa	0	1	0	0	0	0	\N	0
5604547001	0	venus	0	2	0	0	0	23	\N	0
6757455821	0	Kai	0	7	0	0	0	0	\N	0
1624536414	0	.	0	271	0	0	38.92000000000007	1	\N	0
7181274325	0	ᅠ	0	12	0	0	0	51	\N	0
5931325883	0	14	0	2	0	0	0	0	\N	0
1709986073	0	Audrey J.	0	468	0	0	702.85	112	\N	0
2038383912	0	jel	0	62	0	0	0	127	\N	0
6429253047	0	Oceanus Chryses.	0	138	0	0	0	24	\N	0
1719766025	0	Abigael	0	20	0	0	0	3	\N	0
5434211883	0	kapkol	0	1	0	0	0	168	\N	0
1862827736	0	Biru Laut	0	5	0	0	2463	377	\N	0
6453636507	0	🦋	0	37	0	0	4734	133	\N	0
5828165550	0	kyzun	0	33	0	0	2.790000000000134	244	\N	0
5935640701	0	Rstwaty	0	7	0	0	0	11	\N	0
1004412924	0	calaa	0	0	0	0	0	0	\N	0
5124633103	0	:3	0	27	0	0	324.09999999999997	380	\N	0
5737122695	0	Lie	0	7	0	0	0	0	\N	0
6443218599	0	dd	0	1	0	0	20.98	1	\N	0
6807247324	0	andra	0	4	0	0	0	0	\N	0
5470819658	0	ika	0	1	0	0	0	0	\N	0
1820132174	0	naw	0	1	0	0	0	0	\N	0
5830176195	0	Jericho, Open.	5	179	1	0	5.460000000000036	110	\N	0
5713814807	0	naily	0	50	0	0	3.09	9	\N	0
1497146118	0	jevan	0	28	0	0	0	232	\N	0
6538706821	0	gesha	0	7	0	0	63.25	2	\N	0
1688606116	0	an𝑺era.	0	1	0	0	0	1	\N	0
6722031997	0	sssaaaa	0	1	0	0	0	0	\N	0
6210408556	0	khael	0	2	0	0	0	0	\N	0
6801917524	0	ahong	0	1	0	0	0	0	\N	0
1238964943	0	swan	0	17	0	0	0	79	\N	0
1639905892	0	ʕ⁠´⁠•⁠ᴥ⁠•⁠`⁠ʔ	14	25	0	0	387.05000000000035	336	\N	0
5405732547	0	awaa	0	1	0	0	0	1	\N	0
1730756198	0	..	0	3	0	0	0	0	\N	0
5858240581	0	36	0	6	0	0	16.42	47	\N	0
5376870298	0	nanay	1	198	0	0	10921.150000000001	3855	\N	0
1639780090	0	Ilean	0	1	0	0	0	0	\N	0
6089922768	0	lala	0	12	0	0	0	2	\N	0
1746047313	0	Ethan.	0	4	0	0	0	0	\N	0
1944779708	0	picii nakela	0	98	0	0	0	7	\N	0
1138666771	0	Pram	0	9	0	0	0	2	\N	0
1927544899	0	𝓙emmα	0	2	0	0	0	0	\N	0
1611667437	0	rafaella wts gc y21 y22, idc 1	0	223	0	0	2784.6799999999994	158	\N	0
2031171869	0	jen selling @TaehyunkgKim	0	3	0	0	0	3	\N	0
6163621190	0	rendra, pansos send subs	0	6	0	0	0	1	\N	0
5416742837	0	jas, close	0	2	0	0	0	4	\N	0
1861414500	0	yasmin	0	415	0	0	6.13	59	\N	0
7102111051	0	vebe	0	1	0	0	0	0	\N	0
5892088844	0	Shanetté VL.	0	1	0	0	0	2	\N	0
5101942046	0	u	0	12	0	0	0	2	\N	0
1399838492	0	may0,	0	23	0	0	0	0	\N	0
1860006431	0	sccnaaa	0	1	0	0	0	0	\N	0
1577118997	0	lysandra	0	270	0	0	13.210000000000003	161	\N	0
1096818721	0	Fezco	0	10	0	0	0	3	\N	0
6933661101	0	Zii	0	4	0	0	0	0	\N	0
5388059731	0	voe . s/ia	0	198	0	0	10.29999999999999	269	\N	0
5322721726	0	rifan	0	2	0	0	0	0	\N	0
5881333770	0	.	0	20	0	0	862.7	0	\N	0
5809123458	0	gio	0	5	0	0	0	10	\N	0
6328823389	0	keyra	0	45	0	0	294	33	\N	0
1194652400	0	q	0	130	0	0	0	0	\N	0
7023676154	0	Cika	0	1	0	0	0	0	\N	0
5040034102	0	Geno clone	0	4	0	0	0	11	\N	0
6731159144	0	D	0	2	0	0	0	0	\N	0
1673368964	0	n	0	800	0	0	805.0400000000013	75	\N	1
1940000300	0	bebe salima	0	1	0	0	0	0	\N	0
5340416122	0	Labyrinth.	0	1	0	0	0	0	\N	0
6615512570	0	who's?	0	0	0	0	0	6	\N	0
6857928709	0	ⓘ. Chaostic Leader.	0	1	0	0	0	0	\N	0
1168833194	0	L	0	14	0	0	0	90	\N	0
1851415447	0	ini kela	0	38	0	0	1000	193	\N	0
5029984199	0	?¿	0	27	0	0	0	5	\N	0
1461361672	0	─ Jhiessa	0	2	0	0	0	0	\N	0
6809244091	0	Bunnyy	0	1	0	0	0	4	\N	0
5619294391	0	ibra	0	12	0	0	0	3	\N	0
1101511120	0	krrnnn	0	327	0	0	328.72	188	\N	0
6563454782	0	gin	0	10	0	0	0	46	\N	0
1615877196	0	nikolas	4	12	0	0	20	19	\N	0
5581108578	0	Kaizo N.	0	6	0	0	0	259	\N	0
5151616737	0	a	0	8	0	0	0	1	\N	0
1109081755	0	Valerié Madelyn. Ꮠ	0	40	0	0	0	46	\N	0
6493601230	0	naeva	0	5	0	0	0	0	\N	0
1353615790	0	branss	0	15	0	0	0	7	\N	0
5996368388	0	Amiety dulcibel.	0	11	0	0	0	14	\N	0
6901880473	0	最古 Saikōo	0	12	0	0	0	32	\N	0
1702412252	0	bang aksa, heree!	0	5	0	0	0	7	\N	0
5959137452	0	Matthew D.	0	1	0	0	0	0	\N	0
5190410552	0	d o r a But ਏਓ	0	1	0	0	0	0	\N	0
5200470126	0	𝐒𝐜𝐚𝐫𝐟𝐚𝐜𝐞	0	0	0	0	500	27	\N	0
2046459770	0	kajohan seleb nya tkh³	0	80	0	0	0	18	\N	0
1645573281	0	Geopatrh.	0	8	0	0	38.61	19	\N	0
5391525595	0	dyanne	0	8	0	0	0	3	\N	0
6130496431	0	MJ's twinnie, Mici.	0	6	0	0	0	67	\N	0
2054354350	0	ciel	0	114	0	0	192	14828	\N	0
6073427217	0	💣 gimo	14	187	0	0	8880.91	763	\N	1
6554265590	0	𝐓𝐑≛𝐏𝐒 ` raa	0	1	0	0	0	0	\N	0
6642621062	0	Rena	0	19	0	0	56	15	\N	0
5819853421	0	el	0	1	0	0	0	0	\N	0
1904790190	0	ㅤㅤ	0	334	0	0	1445.23	1335	\N	0
1880127014	0	vrysta	14	219	0	0	6.370000000000175	509	\N	0
6764755635	0	ka(helikopter)	0	12	0	0	0	6	\N	0
5117245456	0	J	0	13	0	0	0	0	\N	0
6307070354	0	ㅤㅤㅤ	0	2	0	0	0	4	\N	0
5307845696	0	yaaa	0	7	0	0	0	13	\N	0
5564754881	0	Cul's	0	1	0	0	0	2	\N	0
6798035133	0	©	0	0	0	0	0	0	\N	0
5805327888	0	ayinn	0	13	0	0	1228.15	14	\N	0
5357487557	0	lix	5	291	0	0	2.100000000000648	7	\N	0
5982564206	0	💎 Sasa	0	15	0	0	0	0	\N	0
5521272696	0	Kalea ᴸᶜᴬᴮ	0	58	0	0	2008.6299999999999	122	\N	0
1186558644	0	H	0	5	1	0	0	0	\N	0
6194792789	0	Mārco D'Javiero	0	3	0	0	0	0	\N	0
5659713393	0	‎ ‎ ‌‎ emma.	0	54	0	0	0	165	\N	0
5975007583	0	mion	0	8	0	0	0	1	\N	0
6149906190	0	ダーリン ## ᴴᴸ	0	0	0	0	0	0	\N	0
6914082064	0	Jaja	0	1	0	0	0	3	\N	0
5131327230	0	OL	4	694	0	0	1.8899999999996382	412	\N	0
6146181733	0	Mikáel	0	48	0	0	37.94999999999999	28	\N	0
1736588111	0	s	0	27	0	0	0	2	\N	0
5331781471	0	dumb	0	3	0	0	0	3	\N	0
5905314064	0	🩰.. ๋ ֢ 𝓓ollete lorèlei ۪ ⌗ 🎀꒱ׂ ׅ ⸼	0	79	0	0	0	0	\N	0
1958063937	0	Mei. wtb gc tele old	0	3	0	0	0	0	\N	0
6800805683	0	ayla	0	6	0	0	0	0	\N	0
5066832522	0	,	0	596	0	0	1.480000000000004	620	\N	0
5334464576	0	Jean	0	1	0	0	0	0	\N	0
6501853776	0	olive	0	103	0	0	0	17	\N	0
5137105563	0	keira al-zahira	0	5	0	0	0	62	\N	0
6353545460	0	Stella Everth	0	26	0	0	0	91	\N	0
2043075199	0	Alby A.	0	12	0	0	0	9	\N	0
1664825007	0	𓄹 🦈 › al ࣪˖⁩ ♡ ›	0	233	0	0	782.0999999999999	1013	\N	0
5473511824	0	Boss	0	4	0	0	0	4	\N	0
5567410400	0	kaye🤍	0	42	0	0	0	0	\N	0
1895764060	0	anak emak	0	10	0	0	0	3	\N	0
1864721389	0	kᥲᥡrᥲ אָ ⍴rіᥒᥴᥱss	0	2	0	0	0	16	\N	0
6496732974	0	.	0	18	0	0	6	1	\N	0
5609833120	0	Grace.	0	65	0	0	128.07	277	\N	0
6820553229	0	adelyn seraphine.	0	0	0	0	0	7	\N	0
6348095523	0	Capt, Jaziel Merapatih.	0	3	0	0	0	0	\N	0
6558259744	0	tama sementara	0	9	0	0	0	74	\N	0
1942017254	0	dew	0	37	0	0	65.96	71	\N	0
1243472673	0	erarea	0	10	0	0	0	13	\N	0
6500614557	0	Ashera M. hmu if ur @ ufs	0	12	0	0	0	8	\N	0
1961093791	0	Isabelle b.	0	44	0	0	0	18	\N	0
1738401875	0	angelina	3	13	0	0	633.8900000000001	202	\N	0
5410747144	0	-_	0	9	0	0	0	0	\N	0
1868687199	0	Dewa	0	7	0	0	0	0	\N	0
6194773558	0	ayis	0	1	0	0	0	0	\N	0
6157475758	0	dimas	0	0	0	0	0	1	\N	0
6324694769	0	Daffa ank baik	0	18	0	0	0	2	\N	0
6519368112	0	keii	0	1	0	0	0	14	\N	0
6217417129	0	Olivia R.	0	2	0	0	0	0	\N	0
1076043918	0	Garth Seignour.	0	1	0	0	0	2	\N	0
2117015798	0	Gabby R.	0	45	0	0	0	34	\N	0
6333849310	0	lyya	0	1	0	0	0	0	\N	0
5045363825	0	.	0	18	0	0	0	1	\N	0
1103868962	0	àl	0	6	0	0	0	13	\N	0
6387021683	0	Ullll	0	23	0	0	6380	72	\N	0
5764548224	0	yumna	0	167	0	0	0	2	\N	0
1607259534	0	Boong	0	8	0	0	0	4	\N	0
6430392867	0	🍐🅰	0	1	0	0	0	3	\N	0
1269005861	0	Bebek fried chicken	0	562	0	0	4255.75	341	\N	0
5829288315	0	Rara	0	1	0	0	0	0	\N	0
6249803205	0	𝜗𝜚	0	0	0	0	0	0	\N	0
1789238300	0	Manuello Elsworth.	0	1	0	0	0	0	\N	0
5133903100	0	Mày	0	63	0	0	0	363	\N	0
5543823117	0	neng geulis	0	50	0	0	0	147	\N	0
1843735196	0	JAXON	1	212	0	0	1315.58	3489	\N	0
5893976542	0	𝐓𝐑≛𝐏𝐒 ` jey	0	5	0	0	0	35	\N	0
5427250519	0	ash	0	10	0	0	1489	122	\N	0
1344404767	0	Jar	0	5	0	0	0	0	\N	0
5939760198	0	soul.	0	3	0	0	0	12	\N	0
5779422759	0	🌷	13	43	0	0	69.86	56	\N	0
981718741	0	ella	0	6	0	0	0	114	\N	0
2097180313	0	Madeline Senara	0	3	0	0	0	0	\N	0
1335043456	0	Joanna.	0	1	0	0	0	0	\N	0
1967501442	0	érbiaa	0	18	0	0	0	94	\N	0
6003910083	0	Val	0	26	0	0	0	6	\N	0
6203126787	0	who?	0	7	2	0	19.6	26	\N	0
6411545727	0	𝐓𝐑≛𝐏𝐒 mine˙✧🪐	0	2	0	0	0	1	\N	0
6607431801	0	caera, PENDINGG	0	6	0	0	0	1	\N	0
652405964	0	Syah	0	8	0	0	0	1	\N	0
6630550209	0	r	0	43	0	0	0	906	\N	0
6197771987	0	zae	0	10	0	0	0	42	\N	0
5834842091	0	kejora. send link / usn	0	63	0	0	8.059999999999999	33	\N	0
6835529858	0	nanas	0	4	0	0	0	2	\N	0
1411506284	0	senja wanita mahal	0	1	0	0	0	3	\N	0
6905704986	0	cancelo	0	20	0	0	156.07999999999998	113	\N	0
1892649759	0	doumine	8	55	0	0	115.21999999999971	185	\N	0
6694567070	0	Loopy !	0	13	0	0	0	2	\N	0
6902826163	0	han	0	21	0	0	0	0	\N	0
6141478147	0	𝗚	0	1	0	0	0	0	\N	0
6036839617	0	Lina	0	3	0	0	0	0	\N	0
1889909710	0	aruna	0	2	0	0	0	0	\N	0
5110174408	0	disya	0	3	0	0	0	0	\N	0
5198293939	0	rf	0	2	0	0	0	6	\N	0
1950391729	0	Rasalbaj.	0	31	0	0	1000	26	\N	0
1899998440	0	Bridget	0	2	0	0	0	1	\N	0
5023924715	0	Jeraxˡʳᶜsᴋʏ¹	0	1	0	0	0	0	\N	0
5600542712	0	PAPA MAFIA	0	21	0	0	0	43	\N	0
5855242338	0	Stephanie	0	3	0	0	0	14	\N	0
1960749290	0	arley fastrespon	0	1	0	0	0	0	\N	0
1629955244	0	lucy	0	592	0	0	1357.8499999999997	2912	\N	0
2105716733	0	nisaa	0	32	0	0	78.49000000000001	9	\N	0
6608319826	0	a clovis	0	17	0	0	0	40	\N	0
5969295349	0	Dewa.	0	3	0	0	0	0	\N	0
5706992138	0	kyraa >___	0	43	0	0	0	0	\N	0
1710529150	0	abel	0	9	0	0	0	3	\N	0
6251399529	0	Rafa	0	0	0	0	0	0	\N	0
6021874924	0	Fara	0	1	0	0	0	0	\N	0
5631592454	0	ccels	0	4	0	0	0	0	\N	0
1986863318	0	keysa	0	9	0	0	0	13	\N	0
5313685828	0	saka bjn	0	7	0	0	0	10	\N	0
1721833327	0	seranaaa	13	410	0	0	9849.440000000004	673	\N	1
6977129591	0	abeey	0	8	0	0	0	0	\N	0
1665695082	0	Verreona	0	121	0	0	0	4	\N	0
1621586202	0	layla	0	11	0	0	0	23	\N	0
6101084153	0	Farel	0	13	0	0	0	19	\N	0
1553089496	0	fααqυу.	0	4	0	0	0	0	\N	0
1496641860	0	lala	0	1	0	0	0	0	\N	0
5120517850	0	7102. sbtn.	3	266	0	0	4918.32	340	\N	0
5078261607	0	kafka	0	43	0	0	0	27	\N	0
1744510594	0	Zel	0	2	0	0	0	0	\N	0
5654231055	0	Sean	0	2	0	0	0	0	\N	0
6241662958	0	pentyy	0	9	0	0	314.6	120	\N	0
5301961492	0	goji pengen mixue	0	3	0	0	0	4	\N	0
5758637519	0	den	10	53	0	0	867.0900000000001	32	\N	0
1607873155	0	igor.	0	0	0	0	1000	0	\N	0
7098662677	0	gina	0	1	0	0	0	2	\N	0
6413442035	0	iyon	0	1	0	0	0	0	\N	0
1912948054	0	roza cinta 🧜‍♀ 372	0	5	0	0	0	12	\N	0
5947836146	0	agam	0	0	0	0	0	1	\N	0
6050793415	0	ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ	0	15	0	0	14.8599999999999	8	\N	0
5064288108	0	esya	0	2	0	0	0	53	\N	0
1369818250	0	raq	0	0	0	0	0	1	\N	0
1919189201	0	Milo	0	12	0	0	0	9	\N	0
6128317100	0	el	0	2	0	0	0	0	\N	0
6896829526	0	Alcely	0	2	0	0	0	4	\N	0
1753702812	0	jax	0	16	0	0	0	25	\N	0
655342685	0	️	0	1	0	0	0	0	\N	0
5285735738	0	Qunzi.	0	62	0	0	0	16	\N	0
1662811230	0	Kei , ⊹	0	25	0	0	1111	5	\N	0
2051037289	0	ayis camaba fisip	0	2	0	0	0	0	\N	0
1857779162	0	babeh d!ckta	0	10	0	0	0	0	\N	0
1331126634	0	enner	0	1	0	0	0	1	\N	0
1829037766	0	n	0	3	0	0	0	2	\N	0
1425647314	0	au	0	19	0	0	0	3	\N	0
5011273586	0	vin	0	1	0	0	0	14	\N	0
1337984121	0	.	0	574	0	0	6.280000000000001	442	\N	0
798054913	0	R	0	10	0	0	1394.7900000000002	0	\N	0
5495952179	0	El	0	3	0	0	0	0	\N	0
1468008009	0	-	0	3	0	0	0	0	\N	0
5435543401	0	Ryyy	0	8	0	0	0	0	\N	0
6250322708	0	kays	0	10	0	0	0	7	\N	0
5362415343	0	Cloren	0	2	0	0	0	0	\N	0
1853236187	0	advertisement	0	130	0	0	0	12	\N	0
6072554811	0	naki ( slow respon ya)	0	9	0	0	0	0	\N	0
6761790228	0	alok	0	12	0	0	0	0	\N	0
5611624646	0	Manda 🧚🏻‍♀	0	2	0	0	0	0	\N	0
5905437214	0	ki	0	1	0	0	0	7	\N	0
1780791869	0	aurisa	0	144	0	0	985.3499999999999	890	\N	0
2142560997	0	k	0	3	0	0	0	0	\N	0
5460706146	0	¹	0	24	0	0	73.52	46	\N	0
5440257182	0	argenta	0	9	0	0	0	5	\N	0
6180959953	0	cewe jeno	0	7	0	0	124.52	37	\N	0
1385118040	0	el	0	1	0	0	0	9	\N	0
1825811465	0	Darka	0	4	0	0	0	20	\N	0
1907724245	1	moreo	1	265	1	1	2945.6599999999994	304	\N	1
6283966511	0	El—thio Willson.	0	2	0	0	0	0	\N	0
5659903253	0	Raga. rarely active	0	1	0	0	0	8	\N	0
1624773479	0	– aleya 𝔒𝔉ⁱⁿᵗⁱ🏴‍☠️	0	2	0	0	0	1	\N	0
6263255155	0	Milky T.	0	0	0	0	0	0	\N	0
5807177058	0	hvsk	0	0	0	0	0	0	\N	0
6455253310	0	nayyu	0	0	0	0	0	2	\N	0
1632946930	0	dago	5	43	0	0	929.7700000000016	536	\N	1
1181212961	0	Hakim	0	53	0	0	0	9	\N	0
6220921216	0	Sachie C. 𝐜𝐫𝐯𝐳¹𝖆𝖇𝖞𝖐𝖘	0	20	0	0	1546.27	270	\N	0
6404354686	0	ai	0	2	0	0	0	0	\N	0
6916457236	0	Joshka Ardolph.	0	3	0	0	0	0	\N	0
6946277982	0	Mavellias J.	0	19	0	0	0	6	\N	0
6867414798	0	我爱你.8º8	0	6	0	0	0	2	\N	0
6573167201	0	serayu	0	2	0	0	0	3	\N	0
6541310651	0	L	0	2	0	0	0	0	\N	0
2146153586	0	bang ele🎏🇬🇮	0	0	0	0	0	3	\N	0
946034281	0	nau	0	80	0	0	205.19	34	\N	0
6214617325	0	jajang	0	36	0	0	11	13	\N	0
6423660792	0	Acela Katherin	0	2	0	0	0	0	\N	0
6893564672	0	miya sinta	0	2	0	0	0	0	\N	0
5596360443	0	Florence.	0	0	0	0	0	0	\N	0
2100474430	0	G.Charlotte	0	155	0	0	9.629999999999999	167	\N	0
1898083678	0	Enola Holmes ⁺◟໒꒱.∘	0	1	0	0	0	43	\N	0
6850875854	0	dn	0	32	0	0	0	149	\N	0
1527309716	0	Mas rendi	0	1	0	0	0	5	\N	0
6947625798	0	allen suka meng	0	2	0	0	0	53	\N	0
5561508954	0	𝐧𝐠𝐚𝐧𝐠 𝐧𝐠𝐞𝐧𝐠 𝐧𝐠𝐨𝐧𝐠	0	1	0	0	0	0	\N	0
2054462413	0	jev	0	285	0	0	0	19	\N	0
5253955643	0	Tsab.	0	2	0	0	0	0	\N	0
1774794804	0	nay	0	11	0	0	0	61	\N	0
5760861998	0	abell	0	1	0	0	0	0	\N	0
1750499366	0	FewwChuakz	0	3	0	0	0	7	\N	0
1734582660	0	sunflow	0	40	0	0	0	1	\N	0
5661501177	0	࿔	0	23	0	0	0	26	\N	0
5336457867	0	arsa	3	68	0	0	308.72999999999996	1596	\N	0
5574941999	0	kikiiiii	0	0	0	0	0	4	\N	0
5620240856	0	🍒 ʚ˚₊‧ ꒱ nebυlɑ stheρɑnꪱe !	0	49	0	0	3	25	\N	0
2048023274	0	Ruth	0	1	0	0	0	0	\N	0
5821452079	0	𝐊ajèshaʰˢ⁶⁹ ᴰ²	0	1	0	0	0	0	\N	0
5461053734	0	Hahahaha	0	16	1	0	0	15	\N	0
1851527812	0	caca	0	54	0	0	336.77	20	\N	0
5704755553	0	hy	0	1	0	0	0	1	\N	0
6829431594	0	raffy	0	53	0	0	544	417	\N	0
1329405781	0	ajengg	0	6	0	0	0	0	\N	0
1324490414	0	Fal	0	3	0	0	0	2	\N	0
5332921619	0	naura	0	58	0	0	0	28	\N	0
1114578484	0	naysky	0	5	0	0	478	3	\N	0
5991267221	0	kheira	0	2	0	0	0	2	\N	0
1859235363	0	hegan	0	6	0	0	0	0	\N	0
1977240113	0	Sky	0	87	0	0	0	14	\N	0
5041794919	0	💭 ׅ ࣪𓏲ּ ֶָ. dinarraaa ♡⸝⸝ 🐇ぃ!	0	12	0	0	0	15	\N	0
1338352723	0	Kumaa	0	2	0	0	0	4	\N	0
1467270700	0	epan	6	602	0	0	4073.9699999999993	2228	\N	0
2010816546	0	mahen	0	1	0	0	0	0	\N	0
6652917020	0	Sheerlyn	0	1	0	0	0	7	\N	0
1739945382	0	Kal	0	1	0	0	0	0	\N	0
5194718268	0	elmeera g ska cwo basa basi	0	1	0	0	0	1	\N	0
1917397446	0	filexa	0	1	0	0	0	6	\N	0
1962021155	0	ㅤㅤㅤㅤ	0	16	0	0	0	1	\N	0
5480788461	0	Babybbuss	0	5	0	0	0	17	\N	0
1776679474	0	carlhesa	0	5	0	0	0	6	\N	0
6837578841	0	nyyzzh	0	1	0	0	0	0	\N	0
6212413188	0	cisaa	0	1	0	0	0	0	\N	0
1758195783	0	fafaa	0	11	0	0	0	10	\N	0
1920241021	0	baee	0	909	0	0	116.59	0	\N	0
1810935602	0	dyv	0	5	0	0	0	0	\N	0
2144588956	0	Reja not raja	0	3	0	0	0	0	\N	0
5717176364	0	ciel	0	11	0	0	0	18	\N	0
5053350483	0	rhea 🧛‍♀	0	262	0	0	6	9	\N	0
6939646590	0	xaa	0	27	1	0	0	4	\N	0
5978888725	0	Bang	0	3	0	0	0	3	\N	0
6146931894	0	za	0	334	0	0	1225.17	358	\N	0
6155038158	0	L	0	20	0	0	10.760000000000005	35	\N	0
6454112975	0	tizr	0	2	0	0	0	0	\N	0
5948768432	0	ai-ra	0	6	0	0	0	10	\N	0
1746758799	0	🤺	0	5	0	0	0	0	\N	0
7026431561	0	Jēnn.	0	5	0	0	0	101	\N	0
5025374812	0	arvell	0	0	0	0	0	0	\N	0
5060431078	0	mx	0	1	0	0	0	0	\N	0
6464509907	0	cayellll	0	5	0	0	0	24	\N	0
5067716119	0	Narkoboy	0	2	0	0	0	0	\N	0
5438341552	0	nothing	0	1	0	0	0	0	\N	0
5862368761	0	tacya	0	32	0	0	0	13	\N	0
5086931273	0	pk oya elit	0	1	0	0	0	2	\N	0
5200173045	0	el	0	81	0	0	0	2	\N	0
6727119308	0	baras/bg vg	0	66	0	0	1801.3700000000001	1072	\N	0
1861516735	0	ecaa	0	2	0	0	0	0	\N	0
5715195857	0	Nicole.	0	1	0	0	0	19	\N	0
6215572387	0	Violin	0	2	0	0	0	0	\N	0
1842869787	0	kayela abellio! @dAerichan	0	6	0	0	0	9	\N	0
5378645930	0	Mijesha	0	28	0	0	235.07	57	\N	0
1620570810	0	Je	0	11	0	0	0	0	\N	0
5308913699	0	nara	0	7	0	0	0	6	\N	0
5836829464	0	f	0	62	0	0	35.45000000000027	377	\N	0
1763539331	0	chesa	0	113	0	0	360	13	\N	0
5347469463	0	𝐬𝐳𝐚 ?!%♡	0	114	1	0	100	179	\N	0
5575340366	0	alena	0	15	0	0	0	48	\N	0
6774277456	0	zayyiii 🩰	0	3	0	0	0	1	\N	0
1631020167	0	hara	0	85	0	0	16.65999999999991	124	\N	0
5549412988	0	kaze	0	25	0	0	0	21	\N	0
5636614692	0	Talullah Mia-Jane	0	4	0	0	0	43	\N	0
1815951610	0	˚. ࣪Octá🥞 ᜔⑅୬	0	2	0	0	50	4	\N	0
5973900934	0	ren	4	97	0	0	6.2799999999991485	188	\N	0
1969236809	0	Althaf	0	53	0	0	0	44	\N	0
1290904857	0	rest. ntin ！	0	3	0	0	0	0	\N	0
5536626280	0	𝐌αrch 7th📸❗	0	28	0	0	0	119	\N	0
1744613024	0	Gretta	0	1	0	0	0	0	\N	0
5073110230	0	Arka	13	78	0	0	397.51999999999987	38	\N	0
1840838611	0	Jeno's love taker, Arimbi.	0	70	0	0	0	18	\N	0
6119683683	0	pilek sk woyong ᴀʟᴋ² Vesco	0	9	0	0	0	27	\N	0
1644220876	0	alaa	4	54	0	0	56.810000000000855	3408	\N	0
1826158158	0	ssttt	0	4	0	0	0	10	\N	0
5701621988	0	risol	0	9	0	0	0	177	\N	0
6321830035	0	la beauté, Kalea	0	10	0	0	0	8	\N	0
1726132807	0	.	0	0	0	0	0	0	\N	0
6071779123	0	Binta di gebukin tugas	0	1	0	0	0	2	\N	0
6112226278	0	nishimura	0	134	0	0	0	2	\N	0
5935101114	0	Leyya	0	20	0	0	875	6	\N	0
1607786533	0	ƙׁׅ֑ꪱׁׅɑׁׅ֮ɑׁׅ֮	0	4	0	0	0	9	\N	0
6805976979	0	.lauvi	0	11	0	0	0	1	\N	0
1153148809	0	line	9	74	0	0	6405.290000000003	486	\N	0
5750753763	0	rrrrr	0	0	0	0	0	0	\N	0
6525456667	0	Briela	0	0	0	0	0	0	\N	0
5058107503	0	ody	0	2	0	0	0	2	\N	0
6123660381	0	.	0	17	0	0	0	17	\N	0
7105401230	0	delon	0	1	0	0	0	0	\N	0
6169480614	0	d	4	278	0	0	3107.05	310	\N	0
7096604465	0	m, Moulaa	0	7	0	0	0	0	\N	0
5386633366	0	fia	0	1	0	0	0	1	\N	0
6522888911	0	ais	5	99	0	0	116.69	208	\N	0
5267292015	0	maudi	0	402	0	0	14.75	4762	\N	0
2101881802	0	R	0	1	0	0	84.28	0	\N	0
6442540134	0	hiraya.	0	38	0	0	0	28	\N	0
5290497075	0	..	0	1	0	0	0	0	\N	0
5845580253	0	🚮	0	23	0	0	0	208	\N	0
1899548788	0	F	0	15	0	0	0	0	\N	0
7159054136	0	alanaAa! :3	0	4	0	0	0	1	\N	0
6608709433	0	L	0	1	0	0	0	0	\N	0
5304566705	0	drieee	0	11	0	0	0	7	\N	0
1800541697	0	jeyaa 🫧	0	233	0	0	94.34000000000003	357	\N	0
6372815242	0	pwetty	7	126	1	0	21.639999999999816	911	\N	0
5985290176	0	igal	0	3	0	0	0	5	\N	0
5361638380	0	𝐑ivera Pembersihan Gsh Marah	0	26	0	0	0	3	\N	0
1985913747	0	nats	0	7	0	0	0	0	\N	0
1650864445	0	√rp•lily	0	2	0	0	0	1	\N	0
2077489222	0	Laalk	0	1	0	0	0	2	\N	0
891446422	0	yan	0	4	0	0	0	0	\N	0
6093661570	0	Nayyara.	0	97	0	0	6.460000000000008	31	\N	0
5485644926	0	Shaone	0	73	0	0	12.61999999999989	0	\N	0
1727412866	0	Bonii	0	2	0	0	0	0	\N	0
1373893218	0	xello	0	2	0	0	0	0	\N	0
6554332913	0	ricky bukan riski	0	29	0	0	0	154	\N	0
5384582123	0	Pacar	0	99	0	0	0	56	\N	0
5610497436	0	jeje	0	54	0	0	0	22	\N	0
5447036795	0	😕😕	0	188	0	0	12.95	467	\N	0
1602037670	1	el	0	31	0	0	0	0	\N	0
1116902938	0	Nuvia	0	0	0	0	0	0	\N	0
6532418001	0	lintang	0	1	0	0	0	0	\N	0
1758165230	0	L	0	352	0	0	0	103	\N	0
1867917776	0	juwwiiita	0	198	0	0	112.43	1690	\N	0
5378911276	0	Kaleya Näkessha.	0	43	0	0	0	14	\N	0
6742241461	0	manyu	0	18	0	0	0	43	\N	0
6222724760	0	oreo zeynard 'Pixytle	0	40	0	0	0	1	\N	0
6196100036	0	angel	0	1	0	0	0	0	\N	0
5827539158	0	Lava	0	1	0	0	0	0	\N	0
1405421095	0	a.	0	94	0	0	12.05	321	\N	0
6461173858	0	Nemo	0	1	0	0	0	0	\N	0
5859021667	0	kyra no chat	0	7	0	0	0	3	\N	0
5063584120	0	sharen	0	1	0	0	0	4	\N	0
1352242166	0	kierra	0	15	0	0	172.81999999999994	15	\N	0
6014880666	0	Véy	0	2	0	0	0	0	\N	0
6317131587	0	anananana	0	3	0	0	0	1	\N	0
6587534086	0	je.	0	28	0	0	477.9300000000002	587	\N	0
731644259	0	ㅤㅤ	0	1	0	0	0	6	\N	0
5572214200	0	Samuel	0	1	0	0	0	63	\N	0
6098736632	0	Cintaa	0	6	0	0	0	1	\N	0
1862730326	0	miguēl.	0	804	0	0	2.5900000000000034	59	\N	0
5058549807	0	𖥻💭 shakuy srz	0	9	0	0	0	3	\N	0
5475848899	0	org	13	350	0	0	3555.19	312	\N	1
5557468111	0	keeyara	0	1	0	0	0	1	\N	0
5372540992	0	antrksa	0	1	0	0	0	4	\N	0
6284853555	0	ʚɞ ⁺˖ Reisya.. 🐚	0	80	0	0	16	34	\N	0
6777576771	0	arelll	0	2	0	0	0	0	\N	0
6961875829	0	wisesa	0	9	0	0	0	3	\N	0
1565933321	0	.	9	803	0	0	3039.9200000000005	980	\N	0
1243793590	0	fanny	0	2	0	0	0	2	\N	0
6450588870	0	novv	0	3	0	0	0	0	\N	0
1958771874	0	serena	0	1	0	0	0	1	\N	0
2089042641	0	ka	0	4	0	0	0	25	\N	0
1973832797	0	Vice @Xicoting @lDinosaur	0	1	0	0	0	0	\N	0
1479900782	0	riverlein	0	19	0	0	17.560000000000002	214	\N	0
5142033197	0	nanat	0	5	0	0	478	2	\N	0
2009497733	0	javier	0	2	0	0	0	0	\N	0
1882501905	0	🌱 kkei🗯	0	98	0	0	7.5	544	\N	0
2117459874	0	aika	0	28	0	0	0	8	\N	0
6102898260	0	jipeeey ྀི	0	3	0	0	0	1	\N	0
1875263255	0	olip	0	6	0	0	0	15	\N	0
6205504063	0	ㅤ	0	2	0	0	0	0	\N	0
5440520171	0	sn	0	2	0	0	200	9	\N	0
5599494167	0	aaff	0	150	0	0	111.76999999999998	54	\N	0
1264695940	0	elle	0	20	0	0	0	10	\N	0
5139571417	0	ve	0	25	0	0	0	3	\N	0
1823714043	0	Caden R.	0	33	0	0	0	129	\N	0
6923046566	0	Diev	0	1	0	0	0	0	\N	0
6623319058	0	leane	0	3	0	0	0	1	\N	0
2108868171	0	🤵🏻 Khandyaz	0	2	0	0	0	2	\N	0
6189718999	0	anya	0	20	0	0	0	1	\N	0
6261829910	0	Kayes	0	8	0	0	0	4	\N	0
6032482033	0	Humbug	10	80	0	0	0	288	\N	0
6265439531	0	a	0	12	0	0	0	0	\N	0
1754611279	0	764. EL luca	8	121	0	0	138.48999999999722	2311	\N	1
6356163950	0	ayya	0	115	0	0	104	42	\N	0
7032374999	0	januar	0	0	0	0	0	0	\N	0
5177224831	0	𝑺𝑵. Arbie	0	4	0	0	0	28	\N	0
5064824184	0	charlie	0	9	0	0	0	2	\N	0
6319344795	0	adam	0	129	3	0	2.22	50	\N	0
7061794550	0	afifah	0	2	0	0	0	0	\N	0
6983986732	0	J	0	1	0	0	0	0	\N	0
1077896826	0	ilooooo𝖅༉	0	3	0	0	0	6	\N	0
5355345785	0	An.	12	217	0	0	15000.149999999987	5305	\N	1
1546310388	0	el	0	11	0	0	0	0	\N	0
1969948884	0	Lucas's Lover, Cyain	0	18	0	0	0	17	\N	0
1844094720	0	'Ghaura' cewe kak 'B'	0	342	0	0	0	5	\N	0
1679494728	0	gika	0	1	0	0	0	31	\N	0
5479051833	0	acca	9	123	0	0	0	86	\N	0
5807601677	0	diva	0	113	0	0	0	1	\N	0
5441078419	0	Saffana	0	12	0	0	19.119999999999997	2	\N	0
1742806563	0	niy	8	318	0	0	4988.94	2298	\N	0
6377522595	0	Aown	0	1	0	0	0	14	\N	0
1874509619	0	chv.	0	386	0	0	1148.54	65	\N	0
1650547898	0	biyaa	0	156	0	0	0	196	\N	0
6094052090	0	lula	10	240	0	0	781.9300000000006	1713	\N	1
1372435340	0	zana cape mau nangis :(	0	42	0	0	0	96	\N	0
6926747739	0	Caca	0	2	0	0	0	0	\N	0
7146246615	0	Shana	0	2	0	0	0	1	\N	0
5412106088	0	pawaz	0	3	0	0	0	0	\N	0
1575800017	0	caca	0	1	0	0	0	0	\N	0
6374464716	0	yell	0	465	0	0	-14.509999999999764	36	\N	0
5809787229	0	laurels	0	28	0	0	0	21	\N	0
5149926010	0	aby	0	0	0	0	0	0	\N	0
1725530833	0	sall	14	414	0	0	7414.4800000000005	6	\N	0
6404799337	0	gist	0	0	0	0	0	0	\N	0
1503458004	0	Jonathan	0	4	0	0	615.62	421	\N	0
1871876946	0	TEMP. Moran hiatus	0	0	0	0	0	2	\N	0
1118229845	0	no name	0	2	0	0	0	0	\N	0
6368630335	0	Vale	0	29	0	0	0	2	\N	0
6329884084	0	xaxa	0	1	0	0	0	1	\N	0
1825475692	0	Ben	0	1	0	0	0	0	\N	0
5179925806	0	Athar R.	0	443	0	0	3.960000000000001	41	\N	0
5273148141	0	el	0	17	0	0	87.49	0	\N	0
2092353758	0	Maghuel	0	3	0	0	0	246	\N	0
1732850974	0	moura	0	1	0	0	173.48	226	\N	0
6864071642	0	ca	0	11	0	0	310.39	2	\N	0
5782769428	0	◗ Rey✧✧	0	1	0	0	0	1	\N	0
1923887854	0	feli	0	116	0	0	1287.78	333	\N	0
1199741681	0	Harrison	0	7	0	0	575	151	\N	0
5679202436	0	ayass	0	2	0	0	0	31	\N	0
5717673289	0	Austin Sabiru.	0	11	0	0	0	0	\N	0
5101975968	0	kavhiel	0	1	0	0	0	65	\N	0
6144567129	0	?	0	3	0	0	0	0	\N	0
6149637692	0	teresa, D.	5	41	0	0	0	249	\N	0
1972695609	0	rel?	0	36	0	0	0	7	\N	0
1318545799	0	.	0	20	0	0	56	17	\N	0
5108641298	0	h, dréys.	0	80	0	0	1404.33	694	\N	0
1836130502	0	Zenaaa	0	11	0	0	311.39000000000004	3	\N	0
5963351113	0	uni bakwan	0	241	2	0	12.46999999999963	748	\N	0
6981053970	0	∆	0	10	0	0	0	17	\N	0
1693521514	0	Cay	0	64	0	0	1353.01	611	\N	0
6618971071	0	CalonOrangKaya	0	3	0	0	0	1	\N	0
6538746503	0	𝓝𝓲𝓬𝓸𝓵𝓮 𝓮𝓵𝓼𝓽𝓸𝓷	0	1	0	0	0	0	\N	0
6869240403	0	Azril	0	1	0	0	0	7	\N	0
5101485639	0	princ	0	158	0	0	0	8	\N	0
5895259730	0	pacar jaemin	0	1	0	0	0	0	\N	0
5818864530	0	ayesha	0	179	0	0	241.29000000000002	110	\N	0
6723253740	0	sa	0	8	0	0	0	0	\N	0
6120726903	0	urell	0	1	0	0	0	0	\N	0
6667954575	0	ard	0	16	0	0	0	4	\N	0
1643803967	0	clowie oleng mount	0	339	0	0	0	14	\N	0
6406911332	0	-	0	14	0	0	0	1	\N	0
1943878939	0	Celine N.	0	18	0	0	0	2	\N	0
1785306843	0	Jane 🍑	0	0	0	0	0	0	\N	0
5797912714	0	Kanala	0	30	0	0	0	0	\N	0
6476408216	0	n	0	1	0	0	0	0	\N	0
1735438516	0	silvii	0	2	0	0	0	0	\N	0
6890458227	0	Ci	0	21	0	0	0	4	\N	0
1099515108	0	Zenin	0	0	0	0	0	0	\N	0
6845413446	0	Ashleigh Gretchens.	0	0	0	0	0	0	\N	0
2060939580	0	e	0	100	0	0	32.140000000000015	257	\N	0
6688927311	0	betsy	0	4	0	0	818.5699999999999	239	\N	0
1848585774	0	alregav pake p	0	17	0	0	0	11	\N	0
1126864363	0	rangga	0	6	0	0	0	0	\N	0
6944752363	0	abel	0	4	0	0	0	38	\N	0
5505090196	0	Renjana	0	3	0	0	0	8	\N	0
939828949	0	Babydho	0	2	0	0	0	32	\N	0
6031295011	0	bilaa	5	148	0	0	3936.62	166	\N	0
1721420200	0	ㅤtia	0	5	0	0	0	11	\N	0
1978278710	0	Rayyen	0	21	0	0	0	0	\N	0
6504092479	0	Zaidan C.	0	2	0	0	0	0	\N	0
6261420073	0	Kayesha k.	0	1	0	0	0	0	\N	0
5787028277	0	aca asj .𝖈𝐳𝖙𝖊𝖆𝖒	3	186	0	0	430.96000000000015	1732	\N	0
5270616775	0	jaguar	0	7	0	0	0	9	\N	0
5092640194	0	abcd	0	42	0	0	0	66	\N	0
1950590244	0	: A.L.A	0	2	0	0	39.53	29	\N	0
1369984045	0	zha	0	2	0	0	0	0	\N	0
1822315472	0	ou-sellyi =]	0	1	0	0	0	0	\N	0
6154165326	0	n	0	2	0	0	0	0	\N	0
1881410963	0	gesha	0	115	0	0	0	31	\N	0
6777302933	0	narendra	0	0	0	0	0	6	\N	0
1654116118	0	rafanaka	0	8	0	0	0	0	\N	0
6224273831	0	Alreeyan.	0	4	0	0	0	80	\N	0
1660309832	0	L	0	4	0	0	0	12	\N	0
5356929561	0	odie	0	2	0	0	0	0	\N	0
2013817654	0	a	0	13	0	0	0	26	\N	0
1444994025	0	Tessa	0	143	0	0	0	1	\N	0
5621469035	0	Syee	0	2	0	0	16.5	1	\N	0
6064431632	0	. szzy	0	7	0	0	548.3299999999999	7	\N	0
6977438810	0	r	0	3	0	0	0	0	\N	0
5526102169	0	eury beulath.	0	1	0	0	0	0	\N	0
5034532940	0	SCHRÖ, M.	0	9	0	0	714.6799999999995	745	\N	0
6226036256	0	Zaki?	0	4	0	0	176.43	0	\N	0
6659095927	0	Marrie Adelaide.	0	2	0	0	0	3	\N	0
5348109341	0	Demian	0	2	0	0	0	0	\N	0
5756350991	0	cintaa	0	2	0	0	0	0	\N	0
6489640095	0	oceann	0	4	0	0	0	23	\N	0
6538407673	0	mOkyo.	0	2	0	0	0	39	\N	0
5430210923	0	rz	0	5	0	0	0	47	\N	0
6087499392	0	vmor 𝗿𝗱𝘀³⁰¹	14	247	0	0	843.06	526	\N	0
1748721714	0	beyy — backup	0	253	0	0	0	295	\N	0
2034917004	0	Sephora Sievert	0	0	0	0	0	0	\N	0
6316709172	0	Al	0	14	0	0	0	56	\N	0
1390747277	0	a	0	10	0	0	0	72	\N	0
5640277239	0	Keithara E.	0	8	0	0	0	0	\N	0
1707620040	0	d	0	11	0	0	456	6	\N	0
5841303512	0	Cece	0	1	0	0	0	0	\N	0
1945409612	0	dann	0	13	0	0	0	7	\N	0
977553823	0	Panda	0	161	0	0	0	63	\N	0
7006646022	0	almëi	0	14	0	0	0	7	\N	0
1198457833	0	f	0	85	0	0	0	58	\N	0
6830054096	0	abass	0	1	0	0	0	0	\N	0
5098752134	0	abeya	0	2	0	0	0	7	\N	0
1530256967	0	769 joy	0	25	0	0	946.28	1	\N	0
1569856769	0	yem	0	153	0	0	21.6	165	\N	0
998040427	0	zen	0	5	0	0	0	225	\N	0
5808481925	0	jirow	0	2	0	0	500	2	\N	0
1831273932	0	𝐚𝐫𝐞𝐬𝐡𝐚 𝐜	0	2	0	0	0	0	\N	0
5331726050	0	sasa	0	19	0	0	0	11	\N	0
6237634517	0	chia	0	31	0	0	0	14	\N	0
6548343307	0	nanaa	0	2	0	0	0	0	\N	0
5035294103	0	Pwqjoa	7	103	0	0	7339.92	1326	\N	0
1333531551	0	sen	0	6	0	0	0	7	\N	0
5514903495	0	Natashaa	0	2	0	0	0	3	\N	0
5816931863	0	azz	0	4	1	0	0	7	\N	0
6644556565	0	kiya	0	0	0	0	0	8	\N	0
1821400396	0	asa	8	424	0	0	4.060000000000514	98	\N	0
6176307069	0	anne	0	15	0	0	0	0	\N	0
5025910558	0	none	0	340	0	0	0	13	\N	0
6508442335	0	.	0	1	0	0	0	0	\N	0
5126143705	0	sa	0	0	0	0	0	0	\N	0
6081357225	0	k	0	3	0	0	0	6	\N	0
6892420334	0	faycLO #sibukngerjainakt	0	3	0	0	0	4	\N	0
5375156682	0	ur gf. Slctv	0	31	0	0	0	26	\N	0
6050952626	0	Cha	0	2	0	0	0	28	\N	0
6937886851	0	Ari	0	2	0	0	0	0	\N	0
2026783340	0	Gevran Z.	0	26	0	0	0	1	\N	0
5191298512	0	Kaela lathusa	0	243	0	0	0	5	\N	0
1880295889	0	bebe	0	54	0	0	0	4	\N	0
5035869244	0	Jochelyn	0	64	0	0	0	1	\N	0
5919264089	0	R	0	13	0	0	355.90999999999997	152	\N	0
6709731392	0	alaia	0	10	0	0	0	3	\N	0
5683088219	0	Shahnaz.	0	1	0	0	0	1	\N	0
7044427738	0	𝜗𝜚 ecα :3	0	22	0	0	0	15	\N	0
5144055859	0	Ashley	0	3	0	0	0	1	\N	0
6973644833	0	xyvnzzh	0	1	0	0	0	1	\N	0
6243594454	0	ike	0	51	0	0	0	4	\N	0
6432046408	0	F	0	5	0	0	0	1	\N	0
5642758191	0	Resya	0	2	0	0	0	19	\N	0
5977020351	0	slut	0	31	0	0	0	68	\N	0
5871841562	0	𝕭𝙷ន eurielle, arsenio's gf	0	1	0	0	0	0	\N	0
6400514036	0	mathias	0	6	0	0	0	1	\N	0
5912699214	0	Ar	0	41	0	0	0	5	\N	0
1335777167	0	Lukas	0	69	0	0	0	0	\N	0
5929628112	0	.	0	1	0	0	0	3	\N	0
5374240793	0	yaya	0	0	0	0	0	0	\N	0
1103439809	0	𝐙	0	1	0	0	0	1	\N	0
5878493459	0	ken	0	6	0	0	0	8	\N	0
5985372072	0	Jasper, f	0	2	0	0	0	0	\N	0
5336786445	0	c	0	36	0	0	0	83	\N	0
5846984794	0	kim, no ghosting	0	14	0	0	0	135	\N	0
6894037023	0	y	0	5	0	0	0	9	\N	0
1398383681	0	Vin	9	0	0	0	1219.6399999999999	10	\N	0
1899335206	0	ㅤ 𝗮	0	0	0	0	32.57	0	\N	0
1775149183	0	chayaaaa	0	164	0	0	0	50	\N	0
5369609482	0	yan	0	7	0	0	0	11	\N	0
2079094593	0	piaaa	0	5	0	0	0	2	\N	0
5235843009	0	Zeus.	0	3	0	0	0	0	\N	0
6782965949	0	key	0	1	0	0	0	0	\N	0
1501077512	0	dam.	0	2	0	0	0	0	\N	0
6173773334	0	ayeshwa	0	9	0	0	0	14	\N	0
6427362654	0	lix	0	5	0	0	0	25	\N	0
2043094695	0	Fubie Sciera.	0	1	0	0	0	1	\N	0
5673552390	0	andah	0	40	0	0	0	600	\N	0
5194485911	0	shara	0	10	0	0	0	4	\N	0
6399583505	0	pika	0	8	0	0	0	10	\N	0
6468511650	0	lily :3	0	2	0	0	614.85	36	\N	0
1904928983	0	sasha	0	2	0	0	0	3	\N	0
1873111125	0	sa$a	0	1	0	0	0	0	\N	0
6048599540	0	🎧jeje	0	6	0	0	0	1	\N	0
1879951456	0	Valerie .K	0	3	0	0	0	16	\N	0
7079721497	0	daisyyy	0	2	0	0	0	2	\N	0
6339020441	0	𝓚	0	1	0	0	0	1	\N	0
1222993373	0	misel	11	8	0	0	3495.659999999998	5904	\N	0
6335181025	0	bryan.	0	1	0	0	0	0	\N	0
5845149163	0	Kailucien Archilles.	0	15	0	0	0	409	\N	0
6576771142	0	abi butuh kasih sayang	0	21	0	0	0	1	\N	0
5404191198	0	cajes	0	10	0	0	0	7	\N	0
1962700206	0	melody kgn gezzar	0	1	0	0	0	0	\N	0
5897794520	0	Jamie	0	9	0	0	4.63	59	\N	0
2130918601	0	Je cinta shani	0	16	0	0	0	23	\N	0
5194250662	0	sally	0	2	0	0	0	4	\N	0
1410265456	0	lis	2	697	0	0	2769.54	7899	\N	0
1324858971	0	relllnaae	0	24	0	0	0	23	\N	0
1011219028	0	J	0	3	0	0	0	0	\N	0
5864856787	0	d	0	4	0	0	0	0	\N	0
1082503625	0	rryuuu	0	51	0	0	5	6	\N	0
6089453765	0	s	0	8	0	0	0	0	\N	0
5580926554	0	jar . work acc	0	22	0	0	0	80	\N	0
5320925177	0	Will	0	1	1	0	0	0	\N	0
6777935855	0	sabiru	0	19	0	0	0	201	\N	0
1355222715	0	😈	0	0	0	0	0	0	\N	0
6493975092	0	꒰⁠⑅⁠ᵕ⁠༚⁠ᵕ⁠꒱⁠˖ sunny's	0	3	0	0	0	0	\N	0
6195823900	0	kai	0	1	0	0	0	8	\N	0
2086776685	0	tccaa	0	15	0	0	0	47	\N	0
1978523483	0	zami	4	218	0	0	865.01	427	\N	0
6610223033	0	royal canin	0	1	0	0	0	0	\N	0
6697400792	0	jst kelp	0	37	0	0	0	40	\N	0
5125523266	0	Joshce.	0	2	0	0	0	3	\N	0
5148341337	0	lio	0	26	0	0	0	21	\N	0
5851918325	0	Yourmine	0	96	0	0	145.7999999999999	139	\N	0
5134659467	0	$ar0	0	1	0	0	0	4	\N	0
6469743611	0	wawa 8	0	323	0	0	0	2	\N	0
6302474837	0	Chiku's	0	26	0	0	0	15	\N	0
1406912106	0	zergio	5	464	1	0	14.44999999999962	19	\N	0
5657993583	0	eyaaa`	0	1	0	0	0	0	\N	0
1434498708	0	Alster's Lovetaker Naomi	0	8	0	0	4.45	7	\N	0
6324751064	0	maraaa	0	2	0	0	0	1	\N	0
5083073494	0	ter'e	0	9	0	0	0	1	\N	0
6859207106	0	.	0	10	0	0	0	204	\N	0
5365569702	0	set	0	0	0	0	0	715	\N	0
6658832593	0	V	0	1	0	0	0	5	\N	0
1874795525	0	keyyy	0	3	0	0	0	8	\N	0
1615373221	0	a	0	4	0	0	0	7	\N	0
6568231888	0	z	0	1	0	0	0	0	\N	0
5110781915	0	Kaelaýa, A.	0	3	0	0	0	1	\N	0
1675281607	0	ᵛꫀׁׅ	0	5	0	0	0	10	\N	0
6234280847	0	Q	0	1	0	0	0	0	\N	0
5436341973	0	Stephanie	0	4	0	0	0	0	\N	0
5160648949	0	alaa	0	13	0	0	0	0	\N	0
1921524834	0	jey	0	0	0	0	0	0	\N	0
1802534036	0	cece	0	367	0	0	645.77	773	\N	0
1817776079	0	tharra	0	94	0	0	309	130	\N	0
5990377762	0	Jeth Jo	8	129	0	0	4968.26	3860	\N	0
1326653881	0	Denji	0	91	0	0	0	34	\N	0
5754462772	0	Cardyas	0	6	0	0	0	1	\N	0
5132219298	0	ㅤㅤlēnuts.	0	37	0	0	3.79	269	\N	0
6149381185	0	Gina🫧	0	8	0	0	0	11	\N	0
1729419529	0	Via	0	13	0	0	0	4	\N	0
1429866659	0	unknown a ✧ DNFI	0	373	0	0	0	6	\N	0
1570468145	0	lil trvs	0	14	0	0	0	6	\N	0
1860463287	0	Abraham.	0	11	0	0	0	0	\N	0
1917782012	0	Zoëvya	0	810	0	0	22.629999999999846	8310	\N	1
5584588983	0	yaya	0	15	0	0	0	37	\N	0
1572876639	0	Alieno.	0	2	0	0	0	0	\N	0
5346406718	0	Lessa	0	19	0	0	0	34	\N	0
5398309865	0	Jace	0	0	0	0	0	0	\N	0
1549516168	0	ezhar.	0	3	0	0	0	0	\N	0
7095553911	0	L	7	169	0	0	434.33000000000004	25	\N	0
5915566234	0	𝐋𝗶𝗻𝗰𝗵𝗲𝗻 lg	0	37	0	0	177.44	2	\N	0
6714661606	0	꒰Ⳋ “..najuli, mahae's lovetaker” <3	0	33	0	0	0	4	\N	0
6819980910	0	m.	0	0	0	0	0	447	\N	0
2050479921	0	Kaylené	0	8	0	0	0	1	\N	0
1740110900	0	zetā —	0	2	0	0	0	1	\N	0
5877133375	0	reja	0	7	0	0	0	9	\N	0
1835944378	0	sya	0	8	0	0	0	0	\N	0
5808759918	0	hadu	0	1	0	0	0	1	\N	0
6458241728	0	Sèrena 🤺	0	7	0	0	0	1	\N	0
6949457235	0	ènolä, only.	0	45	0	0	3684	165	\N	0
5818584602	0	An	0	0	0	0	0	3	\N	0
5103359190	0	a	0	47	0	0	-8.650000000000006	25	\N	0
1560285455	0	ceisyaa	0	64	0	0	0	73	\N	0
1799999721	0	adipa	0	17	0	0	0	4	\N	0
5170550794	0	𝒷	0	1	0	0	0	0	\N	0
5126814511	0	kiana	0	3	0	0	0	2	\N	0
5643022147	0	ecc	0	0	0	0	0	0	\N	0
5535775987	0	Marcell	0	2	0	0	0	0	\N	0
1600329330	0	tiffany	0	24	0	0	0	13	\N	0
6214222896	0	diNata	3	12	0	0	85.68	501	\N	0
5956641925	0	i u and we	0	4	0	0	0	87	\N	0
6696968476	0	Gebiaan, R	0	35	0	0	0	14	\N	0
6312737028	0	acaazz🍣	0	1	0	0	0	0	\N	0
1184233725	0	Bebecita	0	4	0	0	0	4	\N	0
5768887464	0	NaDivaa	0	3	0	0	0	0	\N	0
6346042367	0	ndra	0	3	0	0	0	2	\N	0
5297769338	0	Rizki	0	3	0	0	0	16	\N	0
6158810505	0	Fau	0	5	0	0	0	0	\N	0
1739489323	0	albian	0	12	0	0	0	0	\N	0
851802568	0	Jovian M.	0	1	0	0	0	0	\N	0
5465062132	0	zl	0	3	0	0	0	1	\N	0
6199032163	0	Slipknot	0	56	0	0	562.87	665	\N	0
6611485091	0	secret	0	6	0	0	0	0	\N	0
1504981060	0	we	0	1	0	0	0	0	\N	0
6416558238	0	hokina	0	25	0	0	2.84	56	\N	0
5491593738	0	dni. Shion on a mission to conquer the world with Matthew.	0	2	0	0	904.5799999999999	2	\N	0
5491739740	0	yb al-sayerz	0	0	0	0	0	0	\N	0
5934612430	0	Zachiel Noer.	0	5	0	0	0	1	\N	0
6689436003	0	Addam Hadson.	0	1	0	0	0	0	\N	0
5861661412	0	♡	0	1	0	0	32.19	0	\N	0
5449946570	0	𝗮𝗶𝗹𝘆	0	90	0	0	2.024999999999636	85	\N	0
5926077384	0	Woo-seok.	0	62	0	0	6.58	0	\N	0
1982885032	0	ra	6	138	0	0	486.41999999999985	99	\N	0
5452451057	0	ash	0	4	0	0	0	14	\N	0
5415814590	0	mib	10	325	0	0	7.199999999999818	1217	\N	0
2006551508	0	calea	0	24	0	0	14.899999999999999	6	\N	0
5235589169	0	ochaa	0	31	0	0	2.3399999999999856	11	\N	0
1508110005	0	jessa	0	3	0	0	0	0	\N	0
1982843511	0	Azma	0	17	0	0	750.96	4	\N	0
1898380338	0	d	0	2	0	0	0	0	\N	0
6593921229	0	v	0	11	0	0	0	0	\N	0
5886473940	0	z what?	0	4	0	0	0	0	\N	0
5581721813	0	Kirika	0	1	0	0	0	0	\N	0
1720437638	0	Minjelline Dineschara	0	0	0	0	0	137	\N	0
5926717178	0	lou	0	2	0	0	0	1	\N	0
1973187762	0	ㅤFay	0	1	0	0	0	4	\N	0
1810662074	0	caka	0	61	0	0	0	1036	\N	0
1480583125	0	kuro	0	2	0	0	0	0	\N	0
6764349506	0	r	0	34	0	0	0	3	\N	0
6264358110	0	Jee	0	12	0	0	0	17	\N	0
1762832186	0	RickoChan	0	1	0	0	0	0	\N	0
6044896372	0	??	0	2	0	0	0	0	\N	0
5491665304	0	allverse	0	19	0	0	0	10	\N	0
5631208907	0	mg	0	2	0	0	0	0	\N	0
5369778944	0	Hugo COTY partner, Belvaa.	0	5	0	0	0	9	\N	0
5957448217	0	cyaa	0	11	0	0	0	98	\N	0
1306609796	0	Jennie	0	2	0	0	0	1	\N	0
1951571348	0	Radista B, mhcityrg¹	0	31	0	0	0	0	\N	0
2002597465	0	Vian	14	2	0	0	11916.590000000002	169	\N	1
1861342404	0	galendra.	0	20	0	0	0	13	\N	0
6449399231	0	kentut gurame	0	38	1	0	0	105	\N	0
6777145542	0	,	3	20	0	0	0	77	\N	0
6208051998	0	ㅤnona	0	1	0	0	0	2	\N	0
2092521306	0	wisee	0	5	0	0	0	1	\N	0
5956202267	0	Detective, jiwan	0	19	0	0	0	0	\N	0
7074107418	0	Jayya •	0	35	0	0	0	4	\N	0
2108580543	0	j	0	175	0	0	3610.070000000003	721	\N	0
6724239196	0	k	0	1	0	0	0	0	\N	0
6239573731	0	eciyyy	0	60	0	0	0	15	\N	0
6307637518	0	.	0	312	0	0	74.23000000000008	518	\N	0
6901456938	0	rey	0	1	0	0	0	0	\N	0
7025600163	0	N	0	1	0	0	0	1	\N	0
5354130431	0	abeng busy	0	11	0	0	781.52	168	\N	0
5304414120	0	rayyandra, 611	0	61	0	0	0	22	\N	0
1954974302	0	Ekaal <3	0	0	0	0	0	0	\N	0
1406059692	0	💤	0	108	0	0	0	65	\N	0
6274326759	0	jesyell	0	2	0	0	0	2	\N	0
6284038690	0	p.	4	76	0	0	45.97999999999975	2593	\N	0
1320534967	0	el	0	21	0	0	0	6	\N	0
5163834641	0	araide	0	191	0	0	2.75	206	\N	0
6249026130	0	462 niela baig hati ♞	0	1	0	0	0	1	\N	0
1387731377	0	grace	0	5	0	0	0	5	\N	0
6353674745	0	𝐍aèl #℘𝒹𝓌 ঔৣ	0	1	0	0	0	0	\N	0
1737862607	0	K	0	26	0	0	0	7	\N	0
1605025368	0	Teddy	0	3	0	0	0	7	\N	0
1479581290	0	sashii	0	3	0	0	0	0	\N	0
1816649764	0	Abhin	0	0	0	0	0	0	\N	0
5912584102	0	B–Arafa.	0	1	0	0	0	2	\N	0
1866184478	0	rega	0	17	0	0	412.6	51	\N	0
5348469124	0	Kay	0	14	0	0	0	6	\N	0
6935416956	0	.	0	32	0	0	0	11	\N	0
5080516871	0	joy	0	344	0	0	9.210000000000036	502	\N	0
1789532439	0	Buyaya	0	2	0	0	0	9	\N	0
1770593160	0	anaya ?! @roseannapatk	0	1	0	0	0	0	\N	0
1872622582	0	ecaaaaaaa	0	84	0	0	5727.85	6	\N	0
1977040538	0	.	0	130	0	0	82.86000000000016	5	\N	0
6491550587	0	floo	0	1	0	0	0	3	\N	0
5041126542	0	alterio	0	13	0	0	0	3	\N	0
1728717400	0	kazuya	0	498	0	0	438.95000000000005	3344	\N	0
5077248745	0	ley r.	0	2	0	0	0	0	\N	0
1703539883	0	adena @wnterblss	0	1000	0	0	1706.1999999999998	504	\N	0
1368197938	0	torao slut.	0	23	0	0	0	10	\N	0
1678874571	0	b	0	1	0	0	0	2	\N	0
5504928605	0	Kyra	13	142	0	0	422.82	409	\N	0
5477176097	0	ℒ	0	11	0	0	0	7	\N	0
2070319466	0	whos	0	32	0	0	0	5	\N	0
6173398088	0	rorrrR	0	18	0	0	0	0	\N	0
1419026046	0	retha	0	11	0	0	0	2	\N	0
1985350543	0	Panya	0	1	0	0	0	1	\N	0
1667196263	0	aeraa	0	107	0	0	0	34	\N	0
6087907922	0	taraaa	0	3	0	0	0	5	\N	0
6089162212	0	Lyhz	0	33	1	0	285	1	\N	0
5652431518	0	darl	0	13	0	0	0	7	\N	0
1438406373	0	Hitokaa.	0	21	0	0	0	80	\N	0
6487941213	0	Natsukii	0	2	0	0	0	2	\N	0
5648105004	0	kiova	0	6	0	0	40	2	\N	0
5927525268	0	Amethyst.	0	24	0	0	0	226	\N	0
5557595748	0	Vann	0	150	0	0	460.75	0	\N	0
5646320046	0	Avi	0	0	0	0	0	0	\N	0
2088713857	0	💤	0	39	0	0	3.34	54	\N	0
1959141084	0	aleee	0	64	0	0	0	112	\N	0
1766645576	0	oca basudara	11	434	0	0	10361.95	2462	\N	1
2121443820	0	greKT	0	4	0	0	0	1	\N	0
5938345098	0	r	0	5	0	0	0	1	\N	0
5784798944	0	Fayi 🧖🏻‍♀	0	19	0	0	21.299999999999997	568	\N	0
5152320168	0	N.	0	3	0	0	0	0	\N	0
1828194840	0	Kaktus	0	230	0	0	1681.2800000000002	149	\N	0
6989242186	0	Veliysa Admj	0	3	0	0	0	38	\N	0
1526549381	0	nay	0	4	0	0	0	0	\N	0
5847814548	0	Eve	0	22	0	0	409.92999999999984	47	\N	0
5004045710	0	ken	0	7	0	0	0	6	\N	0
6777307080	0	jee	0	39	0	0	5	35	\N	0
6226183037	0	asha	0	10	0	0	0	60	\N	0
1265705029	0	“𝅄 ۫ ׅ 𐙚 ─ ۫剽蠻, kisa joki fast: “franz kafka's” 🀦	0	2	0	0	160.25	428	\N	0
5901298904	0	Sändaya joppi	0	4	0	0	0	0	\N	0
5198494185	0	neo	0	62	0	0	108.93	235	\N	0
6624288207	0	Shem.	0	6	0	0	0	0	\N	0
1462383746	0	gew	0	6	0	0	0	0	\N	0
6622357085	0	heyyowzelzel	0	123	0	0	10.66	19	\N	0
2053162522	0	ㅤ αthα l๑vᧉs jαᧉmin	0	2	0	0	0	3	\N	0
1987701246	0	eliza	0	15	0	0	0	32	\N	0
1763192610	0	seraphine	0	10	0	0	0	3	\N	0
1407713469	0	ya	4	112	0	0	7496.089999999999	1771	\N	0
5374486310	0	awa	0	3	0	0	0	0	\N	0
5947421049	0	McQueen	0	2	0	0	0	2	\N	0
1603604334	2	s	0	113	0	0	8.969999999999999	69	\N	0
2105787357	0	adel	0	2	0	0	0	1	\N	0
1731334108	0	— •	8	285	0	0	1690.14	372	\N	0
6265507312	0	Oddètte Quièlley.	0	25	0	0	240.48000000000002	29	\N	0
5064955020	0	karl	0	2	0	0	0	1	\N	0
2099862096	0	abeng	0	12	0	0	0	3	\N	0
1704489779	0	dean	0	2	0	0	49.56	11	\N	0
6231690090	0	Okw	0	2	0	0	0	4	\N	0
5474987842	0	a	0	1	0	0	0	0	\N	0
1518966187	0	ale	0	40	0	0	0	0	\N	0
5364148684	0	jijel	0	4	0	0	0	8	\N	0
6653914667	0	Pinuts	0	126	0	0	859	202	\N	0
5845746100	0	rifky	0	3	0	0	0	0	\N	0
1445803068	0	Lanaaaaa.	0	1	0	0	0	0	\N	0
5198703335	0	sofie	0	1	0	0	0	2	\N	0
1820899251	0	A	0	51	0	0	0	62	\N	0
5048992047	0	cia	6	16	0	0	0	21	\N	0
5414584107	0	yordania.	0	6	0	0	0	2	\N	0
6412960648	0	@.hinaurabot	0	8	0	0	0	0	\N	0
1424043886	0	syfzhr	0	0	0	0	0	1	\N	0
1768595983	0	A	0	7	0	0	0	1	\N	0
6883188092	0	౨ৎ ˖ ࣪ — biel's 🧍‍♀️	0	2	0	0	0	0	\N	0
1869395378	0	ellaa	0	1	0	0	0	0	\N	0
5295865010	0	船¹. Djovan	0	6	0	0	0	5	\N	0
6343111151	0	Lovely	0	2	0	0	0	0	\N	0
5919036242	0	.	0	3	0	0	0	3	\N	0
1781443521	0	Daamara	0	176	0	0	0	0	\N	0
5327444772	0	v	0	5	0	0	0	0	\N	0
2117609897	0	yourbaby	0	3	0	0	0	0	\N	0
5926041227	0	Perez	0	2	0	0	0	0	\N	0
6518268260	0	aya will be ayaya	0	224	0	0	-14	87	\N	0
1530909386	0	Amerta	0	0	0	0	0	0	\N	0
5267798406	0	Pewwpew	0	5	0	0	0	3	\N	0
1690705552	0	nel	0	19	0	0	0	2	\N	0
1717659027	0	hisyam	0	9	0	0	391.1599999999999	0	\N	0
6381295073	0	June	0	6	0	0	0	2	\N	0
2043226226	0	rinda	0	290	0	0	6.8799999999999955	868	\N	0
6301803598	0	MIN ACC MIN🙏🙏😓	12	70	0	0	0	9	\N	0
6752573836	0	lion	0	2	0	0	0	20	\N	0
5461240849	0	sasasasa	0	4	0	0	0	0	\N	0
6516452311	0	ᴴᴸ Laura asli sunda	0	0	0	0	0	7	\N	0
5120079695	0	naeeyss suka frozen	0	7	0	0	0	14	\N	0
1372155871	0	ㅤㅤㅤecute af	0	0	0	0	0	2	\N	0
6273311399	0	yirenaAa drpw	0	169	0	0	4.3899999999999935	983	\N	0
2017172951	0	clb¹. Intiᵈᵍᵗ. lingga alzha	0	2	0	0	0	0	\N	0
6884035785	0	celíne	0	1	0	0	0	0	\N	0
1859862458	0	jo	0	158	0	0	8.659999999999854	20	\N	0
1569683609	0	ACE	0	20	0	0	412	4	\N	0
5758846089	0	aya, acc wtb	13	1	0	0	470.16	22	\N	0
5740065688	0	raa	0	1	0	0	0	0	\N	0
6971400145	0	Rest	0	8	0	0	0	14	\N	0
5996570876	0	🏅	0	1	0	0	0	6	\N	0
6275841509	0	pikachue	0	10	0	0	56.88	278	\N	0
6859279869	0	Angga, F.	0	24	0	0	0	16	\N	0
6012184271	0	aptandra	0	17	0	0	0	13	\N	0
5040249545	0	ayen	0	5	0	0	0	1	\N	0
5885299013	0	biru	0	2	0	0	0	0	\N	0
2009747015	0	dii	0	16	0	0	4.9	33	\N	0
6405213119	0	dni	0	9	0	0	0	114	\N	0
5662892311	0	reja	0	332	0	0	10.11	187	\N	0
5866263634	0	Maverick	0	28	0	0	0	12	\N	0
1713350856	0	KINTAMA	0	1	0	0	0	2	\N	0
5199991078	0	Harlan.	0	1	0	0	0	0	\N	0
5236804373	0	zaeya	0	1	0	0	0	0	\N	0
6812912925	0	♡ PEMBERSIHAN, CHECK BIO	0	4	0	0	0	0	\N	0
6922101901	0	Mecca,	0	7	0	0	0	8	\N	0
1630538750	0	cici	0	13	0	0	0	0	\N	0
6466279243	0	sha	0	1	0	0	0	2	\N	0
1729085066	0	Andhika	0	1	0	0	0	0	\N	0
6402942750	0	Yolaa	0	26	0	0	0	16	\N	0
5208007449	0	j’adore	9	45	0	0	0	108	\N	0
1142936816	0	Jacks	0	0	0	0	0	2	\N	0
2083279359	0	.	0	8	0	0	980	0	\N	0
1646098349	0	leon	0	11	0	0	0	26	\N	0
6851461865	0	Vin	0	0	0	0	0	6	\N	0
5560924002	0	asia	0	34	0	0	0	0	\N	0
5393601001	0	Jollee 4twenty	0	2	0	0	0	0	\N	0
5125700760	0	Jhasper	0	27	0	0	0	0	\N	0
1778899574	0	marvel	0	5	0	0	0	0	\N	0
5434064704	0	yay	14	104	0	0	5708.719999999999	626	\N	0
1808461015	0	Black	0	44	0	0	0	48	\N	0
5897818874	0	Yessur	0	4	0	0	0	1	\N	0
5930747890	0	fer	0	13	0	0	0	2	\N	0
5033728370	0	Eric J.	0	3	0	0	0	14	\N	0
1445765632	0	#?!	0	3	0	0	0	31	\N	0
5294196938	0	ㅤ	5	436	0	0	22801.290000000005	6138	\N	0
1516401468	0	aisy	0	57	0	0	6.15	40	\N	0
1870222541	0	yinn	10	180	0	0	1708.6699999999998	2678	\N	0
6828005357	0	stfu	0	6	0	0	63	0	\N	0
1383021993	0	Ruby	0	15	0	0	0	0	\N	0
5930509205	0	Tara	0	61	0	0	0	12	\N	0
2090896112	0	Mbak yuju, offpc.	0	1	0	0	0	0	\N	0
5202769476	0	mayy	0	6	0	0	81.63	768	\N	0
5308495683	0	Mendra	0	2	0	0	0	0	\N	0
1697838708	0	j	0	4	0	0	0	4	\N	0
1970823581	0	mariyadi	0	3	0	0	0	1	\N	0
5871132806	0	ini abin	0	10	0	0	75.05	183	\N	0
6442162991	0	seleey	0	2	0	0	0	4	\N	0
6199492736	0	M	0	1	0	0	0	0	\N	0
6088966777	0	☃️	0	9	0	0	0	15	\N	0
1320402258	0	sián	0	12	0	0	0	49	\N	0
1878234633	0	viraa 💤💤	0	83	0	0	2500	26	\N	0
5614124131	0	El	0	1	0	0	0	1	\N	0
5929344925	0	serena D. 𐙚	0	45	0	0	0	86	\N	0
2097594731	0	arols	0	3	0	0	0	2	\N	0
1700912218	0	jie ; chaewonism.	0	26	0	0	274	120	\N	0
5544078451	0	< 🗒️♥️🍓🍒	0	1	0	0	0	2	\N	0
1883396923	0	ciaaAaa	0	3	0	0	0	33	\N	0
1751031448	0	neth	0	5	0	0	0	0	\N	0
6936142448	0	𝕿ˢᶜᵠ 𝑳𝒊𝒏 𝑳𝒚𝒐𝒏𝒆𝒓𝒆	0	2	0	0	0	2	\N	0
1685108405	0	chigga	0	3	0	0	0	4	\N	0
5552918435	0	heal	0	2	0	0	0	21	\N	0
1689381645	0	dillah	0	997	0	0	566.8500000000004	668	\N	0
5015573185	0	Vey	0	545	0	0	0	12	\N	0
5490976503	0	.	0	28	0	0	6.060000000000002	1	\N	0
2116814226	0	ㅤchel	13	104	0	0	63.269999999999996	27	\N	0
6823823898	0	Nao ♡ing Carlos S.	0	6	0	0	0	0	\N	0
5090487665	0	244. Élyinnn	0	3	0	0	0	2	\N	0
6878474535	0	g	0	1	0	0	0	0	\N	0
1259674183	0	notkffn	0	1	0	0	0	0	\N	0
1880351126	0	d	0	3	0	0	0	5	\N	0
5132805813	0	sasa	0	46	0	0	0	3	\N	0
6755912554	0	jericho	0	64	0	0	0	0	\N	0
1760025078	0	alth	0	10	0	0	0	0	\N	0
1728842692	0	jero	0	1	0	0	0	0	\N	0
6219551898	0	MATRA.	0	25	0	0	0	23	\N	0
6184068992	0	ryu.	0	7	0	0	13.38	41	\N	0
1782727319	0	sean	0	2	0	0	0	4	\N	0
1361621877	0	astro	0	2	0	0	0	13	\N	0
5693132979	0	Disva Saoirse	0	12	0	0	0	0	\N	0
6472792856	0	Rean	0	4	0	0	0	18	\N	0
6392353101	0	audrey	0	5	0	0	0	3	\N	0
6342393246	0	pers	0	29	0	0	13.04	297	\N	0
5315120142	0	ʚïɞ˚	0	5	0	0	0	0	\N	0
5087893843	0	ammar	0	9	0	0	0	1	\N	0
6360409454	0	Chief	0	3	0	0	0	30	\N	0
5166312921	0	Diana	0	17	0	0	0	27	\N	0
5586243499	0	vey	0	570	0	0	4	22	\N	0
1613673139	0	certified ur loved	0	5	0	0	0	0	\N	0
1923722210	0	eiley	0	8	0	0	0	0	\N	0
6152892775	0	可愛 | K	0	72	0	0	0	59	\N	0
2122624418	0	sindy	0	35	0	0	0	12	\N	0
5231432832	0	rajen	0	4	0	0	0	0	\N	0
5253620626	0	nara	0	1	0	0	0	2	\N	0
5753338309	0	keisa	0	86	0	0	9721.409999999996	1533	\N	0
1801798330	0	r	0	36	0	0	88	73	\N	0
5585214937	0	Jess	0	1	0	0	0	7	\N	0
6912274365	0	natha	0	1	0	0	0	3	\N	0
6919559018	0	naraa rorrrr🦖	0	5	0	0	0	5	\N	0
527472801	0	Nixon	0	1	0	0	0	0	\N	0
6541765372	0	I	5	560	0	0	6.910000000000053	449	\N	0
1737191807	0	J.	0	55	0	0	0	0	\N	0
6668982494	0	jerk	0	3	0	0	0	3	\N	0
5082610186	0	N.	0	5	0	0	0	0	\N	0
5307749437	0	ayll	0	73	0	0	389	19	\N	0
5713013957	0	Nay.	0	1	0	0	0	0	\N	0
5158644642	0	den	0	87	0	0	0	119	\N	0
1674198522	0	sabine b,	0	4	0	0	0	1	\N	0
1850070092	0	nad	0	18	0	0	0	11	\N	0
6469529333	0	❄️	0	3	0	0	0	0	\N	0
6124134092	0	;	0	1	0	0	0	1	\N	0
6471765519	0	cilaa	0	0	0	0	0	2	\N	0
5424958833	0	kai	0	62	0	0	2.5700000000002206	10	\N	0
1798294724	0	Cewe Mark, Grëisy Ainsley.	0	1	0	0	0	0	\N	0
1359778228	0	Cornelyo	0	2	0	0	0	0	\N	0
1224589576	0	sha	0	1	0	0	0	0	\N	0
1919981816	0	vxnora	0	10	0	0	0	1	\N	0
1564448820	0	shovi	0	2	0	0	0	0	\N	0
2043301382	0	Ellaa	0	362	0	0	1.2300000000000004	218	\N	0
1626934367	0	Sabiru	0	13	0	0	0	0	\N	0
6090028528	0	𝐌aha𝒓ani	0	6	0	0	0	34	\N	0
1023734974	0	ㅤ	0	5	0	0	0	43	\N	0
6811604303	0	piw	0	1	0	0	0	1	\N	0
1829134406	0	Leanna.	0	12	0	0	50	156	\N	0
1475490517	0	windy` GALAUUUUUUU	0	5	0	0	0	1	\N	0
1607542985	0	Sycthe	0	3	0	0	0	0	\N	0
1704757890	0	ilo	0	35	0	0	0	111	\N	0
5986875030	0	250.arlo	0	1	0	0	0	0	\N	0
957253308	0	.	0	6	0	0	0	0	\N	0
6889985431	0	Gemino	0	1	0	0	0	0	\N	0
5221789423	0	N	0	12	0	0	0	1	\N	0
5123317562	0	J	0	1	0	0	64.3700000000001	0	\N	0
6380324870	0	𝐂𝔩𝔰-¹⁹ thea🚩	0	4	0	0	0	1	\N	0
5359577570	0	Hoam	0	9	0	0	0	3	\N	0
1851530409	0	user a	0	5	0	0	0	0	\N	0
1877738476	0	nabil.	0	1	0	0	0	0	\N	0
5576977555	0	A	0	1	0	0	0	3	\N	0
6620187070	0	Sastra. GALAU HIGHLIGHT ERORRR	0	2	0	0	0	0	\N	0
1813827834	0	helga	0	56	0	0	0	119	\N	0
1188523927	0	ay	0	30	0	0	0	0	\N	0
6528512925	0	z	0	26	0	0	0	12	\N	0
1707041683	0	mau duit 10 milyar	0	9	0	0	0	262	\N	0
5085664990	0	Agarka	0	2	0	0	0	0	\N	0
6937025333	0	lovely kaii ₍ ᐢ..ᐢ ₎	0	0	0	0	0	8	\N	0
1717299471	0	ravé	0	115	0	0	107.43	4	\N	0
2114409389	0	lije ejil	1	427	0	0	7951.910000000008	1509	\N	0
5973422332	0	salima	0	84	0	0	241.7300000000002	38	\N	0
1649230410	0	Alinna.	0	4	0	0	0	0	\N	0
6325000492	0	ᨦ ʿ chàrlotte ࣶ 𝃛 !	0	23	0	0	0	23	\N	0
6562055726	0	☾ .. Adorein Yeshla.	0	0	0	0	0	3	\N	0
1321914783	0	Bastian	0	2	0	0	0	2	\N	0
7141916142	0	ilaa	0	2	0	0	0	1	\N	0
7067495489	0	Jeniya.	0	1	0	0	0	0	\N	0
1683424586	0	tha	0	252	0	0	310.10000000000014	136	\N	0
5555712831	0	d’est nia	0	11	0	0	169.65	68	\N	0
2058387691	0	cece	0	44	0	0	0	3	\N	0
7087149259	0	veve	0	15	0	0	0	0	\N	0
5328909955	0	sena	0	335	0	0	12.43999999999997	342	\N	0
6033705898	0	la	0	4	0	0	0	4	\N	0
5665801636	0	L	0	1	0	0	0	1	\N	0
5256451365	0	⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣ vete	0	13	0	0	0	148	\N	0
1708795312	0	bopeng, bocah ngempeng	1	466	0	0	12.894999999999982	832	\N	0
2034763023	0	palepale	0	429	0	0	1201.53	3817	\N	0
6735441937	0	Z	0	2	0	0	0	0	\N	0
1690441617	0	bèlbel.	0	651	0	0	78.39000000000003	3574	\N	0
6871509590	0	sh	0	1	0	0	0	0	\N	0
6188530402	0	Y	0	45	0	0	205	11	\N	0
1135862420	0	ayhraa boboo	0	1	0	0	0	5	\N	0
6461457760	0	Kei	0	2	0	0	0	1	\N	0
1824921087	0	khawa	0	43	0	0	10	3	\N	0
6233106429	0	kho	0	1	0	0	0	2	\N	0
5410120886	0	el	0	141	0	0	19	3	\N	0
5946294632	0	na – mai. slctv	0	23	0	0	-9	203	\N	0
5934786420	0	fey spiderman	0	33	0	0	0	5	\N	0
5575253071	0	gracelda	0	7	0	0	0	1	\N	0
1794818459	0	.	0	367	0	0	8.11	6	\N	0
1092206603	0	ミ𝐗𝐲𝐦𝐩𝐡𝐨𝐧𝐲 𝐀𝐪𝐮𝐢𝐧𝐚𝐬	0	0	0	0	0	5	\N	0
5522979775	0	Jeanno Grayson	0	1	0	0	0	0	\N	0
1641720089	0	Lili	0	1	0	0	0	0	\N	0
1745471453	0	𝐄𝐝𝐫𝐢𝐜	12	8	0	0	0	102	\N	0
2107583205	0	Reno	0	53	0	0	0	43	\N	0
5057999089	0	𖤍𝗔𝗥𝗦ᵗᶠ - vegas @s3xmorqd	0	11	0	0	0	5	\N	0
5654936753	0	idk	0	59	0	0	0	57	\N	0
5360374720	0	rest.	0	11	0	0	21.480000000000004	438	\N	0
6450745133	0	Daisybelle Phiceby	0	1	0	0	0	2	\N	0
5012553842	0	elia	0	12	0	0	0	149	\N	0
1633856830	0	kaneth abigail	0	214	0	0	0	130	\N	0
5124972040	0	amandaa.	0	3	0	0	61.490000000000016	1	\N	0
6285549342	0	Me	0	2	0	0	0	0	\N	0
5425024020	0	Jatma Vardhamma.	0	3	0	0	0	0	\N	0
6299637688	0	Alfaz	0	1	0	0	0	0	\N	0
6151060971	0	scitwi	0	33	0	0	0	4	\N	0
5950951959	0	renata	0	10	2	0	45	0	\N	0
6180998122	0	a i i k a	0	38	0	0	0.490000000000002	52	\N	0
6164316707	0	Lacéy Là Vivianné 𐍐𝘇𐰁	0	2	0	0	0	3	\N	0
6500571335	0	+ ˚ 👼🏻o'𝖻𝖺𝖻𝗒﹗nozze ⓘ ׅ ۫ ⊹	0	2	0	0	0	3	\N	0
6402799568	0	yhaha	0	9	0	0	0	0	\N	0
1759213850	0	Res	0	26	0	0	153.49	4	\N	0
5528434583	0	Juliette.	0	3	0	0	0	0	\N	0
6242650324	0	ditho	0	1	0	0	0	0	\N	0
5040950400	0	h	0	57	0	0	7.519999999999982	11	\N	0
1308352224	0	ZHANJ	0	42	0	0	0	3	\N	0
6645537338	0	who's?	0	2	0	0	0	1	\N	0
2092783434	0	Bricce. K	0	5	0	0	0	0	\N	0
6987894747	0	reina	0	34	0	0	688	7	\N	0
7157122332	0	V	0	7	0	0	0	5	\N	0
2099535387	0	Dark~	0	13	0	0	0	9	\N	0
6929160046	0	𐙚 ׅ ֹ iv. poetic melody's ⓘ ..📖	0	1	0	0	0	0	\N	0
1449873129	0	NiZHUAA busy, bukan kaum nolep	0	4	0	0	0	4	\N	0
5059629815	0	nessie salima	0	1	0	0	0	0	\N	0
2145899557	0	Sekala	0	140	0	0	2730.41	85	\N	0
1630204730	0	.	0	42	0	0	27.900000000000006	26	\N	0
5059092190	0	geez	0	10	0	0	0	3	\N	0
5302863497	0	cia morgan	0	1	0	0	0	3	\N	0
5690331902	0	sean	0	1	0	0	0	0	\N	0
604046985	0	Ann~•	0	11	0	0	0	0	\N	0
6876218764	0	raja	0	3	0	0	0	2	\N	0
5816167644	0	Verzz	0	1	0	0	0	0	\N	0
1283342657	0	Al	0	1	0	0	0	1	\N	0
6058858057	0	Gezhar	0	1	0	0	0	0	\N	0
5051538757	0	agas	0	26	0	0	0	1	\N	0
1800058579	0	Ly	0	0	0	0	0	54	\N	0
5524352663	0	Willow	0	9	0	0	0	32	\N	0
5378706539	0	— ayyarà.	0	1	0	0	0	5	\N	0
6411522972	0	Jery	0	1	0	0	0	0	\N	0
1326232114	0	ㅤㅤㅤㅤㅤ	2	387	0	0	2241.44	220	\N	0
1775994166	0	𝓴𝓲𝔂𝔞	0	4	0	0	0	9	\N	0
547532574	0	Anindya	0	1	0	0	0	0	\N	0
5198597154	0	Ashmara zhisya	0	3	0	0	0	9	\N	0
1338313557	0	manda	0	1	0	0	0	0	\N	0
2011210528	0	Lalaaaa. #CatLovers 😻🎀	0	13	0	0	0	62	\N	0
2030123437	0	olla 🧚🏻‍♀️	0	15	0	0	814.9599999999999	8950	\N	1
6587960428	0	Isa	0	36	0	0	25.71	73	\N	0
1712577792	0	eja`lstx	0	1	0	0	0	0	\N	0
6854953096	0	aycila #BARUDAKSALIEZ	0	0	0	0	0	0	\N	0
6342012043	0	b	0	6	0	0	0	96	\N	0
5947787725	0	peju siput	0	42	0	0	0	55	\N	0
5561542926	0	Kariie.	0	0	0	0	0	0	\N	0
5590030151	0	Amoura	0	14	0	0	0	23	\N	0
1785898717	0	Zeinis	0	12	0	0	181.5	200	\N	0
5673632588	0	Vina	0	220	6	0	4724	94	\N	0
1770701449	0	Syasya. @zKyujin on offer	0	37	0	0	5.72	27	\N	0
7109092909	0	Ĵollien	0	11	0	0	0	1	\N	0
1305257988	0	Juwu	11	303	0	0	14.660000000000082	227	\N	0
7002078454	0	Angeline. 🎀	0	30	0	0	831	272	\N	0
6607036996	0	.....	0	2	0	0	0	7	\N	0
5337753078	0	gamm	0	25	0	0	0	0	\N	0
1975783750	0	.𖥔 ݁ ˖ Sean ⋆˙	0	11	0	0	355.5	605	\N	0
1823341972	0	''๋ࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣩࣧࣧࣧࣧࣧࣧࣧࣧࣧࣧࣧ͜͡➣𝖋iqri	14	980	2	0	53682.15999999998	24097	\N	1
1573555861	0	Joelle	2	524	1	0	37.420000000000186	8046	\N	0
5949118319	0	w	0	3	0	0	0	0	\N	0
2034487703	0	Julieth M.	0	33	0	0	1695.2799999999993	2798	\N	0
5924599154	0	frasyaa	0	12	0	0	132.2	26	\N	0
5281670266	0	eLmian	0	6	0	0	252.17	115	\N	0
6552218921	0	naraaa	0	5	0	0	0	98	\N	0
6922041023	0	Nirmala	0	4	0	0	0	0	\N	0
7081228460	0	Zalikha	0	2	0	0	0	0	\N	0
7186983189	0	Heavènly.	0	0	0	0	0	1	\N	0
5277525694	0	ākito. hanaka'𝐜𝐫𝐯𝐳¹	0	1	0	0	0	0	\N	0
5474874401	0	RisKY's	12	99	0	0	943.4099999999994	2343	\N	1
1924218927	0	desta	0	3	0	0	0	18	\N	0
5792205167	0	azza's	0	16	0	0	0	37	\N	0
6946809676	0	Ngab bro	0	249	0	0	-8	215	\N	0
1608713329	0	nifa	12	979	0	0	13.100000000001028	761	\N	0
1097765117	0	faa bukan bocil	0	3	0	0	0	6	\N	0
5040328856	0	angkasa	0	25	0	0	50	8328	\N	0
1379307180	0	langris	0	1	0	0	0	0	\N	0
5899568445	0	Cherylie E.	0	2	0	0	0	0	\N	0
6597371755	0	äsa	0	1	0	0	0	0	\N	0
6544945187	0	ca	0	1	0	0	0	0	\N	0
6504732035	0	atlantic 🇳🇬	0	7	0	0	0	6	\N	0
6287807411	0	miyel	0	12	0	0	0	67	\N	0
6565279519	0	KathyA	0	107	0	0	131.51000000000002	97	\N	0
1426000605	0	se	5	1221	0	0	718.3399999999983	2163	\N	0
5013510241	0	Ashley . @ppcarjaemin	0	75	0	0	0	0	\N	0
5745501821	0	kal	0	2	0	0	0	0	\N	0
5002133195	0	miiwa 🐾	0	376	0	0	10.5	2699	\N	0
2099645559	0	kalle	0	1	0	0	0	0	\N	0
6631314545	0	dzai	0	3	0	0	0	0	\N	0
6804353509	0	busy mal	0	1	0	0	0	0	\N	0
5997276612	0	bila	0	0	0	0	0	3	\N	0
7002440958	0	sip	0	2	0	0	0	0	\N	0
6503469431	0	Bintang	0	88	0	0	0	25	\N	0
1140917473	0	rin	0	22	0	0	0	263	\N	0
5653204603	0	채린	0	29	0	0	0	74	\N	0
6214946459	0	Lin	0	428	0	0	12.310000000000088	639	\N	0
2128776234	0	𝔤𝔯𝔦𝔷𝔢𝔩𝔩𝔢	0	2	0	0	0	4	\N	0
5902832729	0	𝐑aa	0	225	0	0	0	108	\N	0
1813534470	0	dika	0	7	0	0	0	0	\N	0
5573548136	0	ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ	0	3	0	0	0	0	\N	0
5918419630	0	kay	0	4	0	0	0	0	\N	0
1746973304	0	ara	0	10	0	0	0	44	\N	0
6742538230	0	≽^•⩊•^nalala	0	10	0	0	0	71	\N	0
1491437914	0	Ara	0	50	0	0	0	0	\N	0
1686063679	0	sasa	0	32	0	0	0	450	\N	0
1982809392	0	Feby loving yuda	0	2	0	0	0	11	\N	0
5483271890	0	xavier	0	1	0	0	0	3	\N	0
5953003402	0	nyshynà	0	1	0	0	0	0	\N	0
1752322400	0	ㅤㅤㅤ	0	1	0	0	0	2	\N	0
1755064852	0	Jeano Vor.	0	1	0	0	0	0	\N	0
2137277154	0	Arzky	0	15	0	0	42.96000000000001	0	\N	0
2054019525	0	jeff	0	7	0	0	0	2	\N	0
1728503625	0	eylie	0	6	0	0	0	2	\N	0
1922072568	0	Öllavely	0	27	0	0	0	38	\N	0
2079961051	0	a	0	2	0	0	0	1	\N	0
5981378369	0	shèa	0	2	0	0	0	0	\N	0
6254732792	0	n’me	0	11	0	0	0	1	\N	0
1776789768	0	El	0	1	0	0	0	0	\N	0
5322861442	0	a	0	1	0	0	55.68000000000026	0	\N	0
1605976122	0	𝔪𝛾 𝔤𝔦𝔯𝔩	0	9	0	0	0	19	\N	0
5126802191	0	Héavenly.	0	1	0	0	0	0	\N	0
5995041285	0	ᴛessᴀ	0	48	0	0	0	44	\N	0
1813112936	0	Raurele Lousiana ♡	0	156	0	0	380	342	\N	0
5958205080	0	vierra	0	4	0	0	0	0	\N	0
5519262866	0	Taraya.	0	2	0	0	0	0	\N	0
6125114478	0	maiesly, h.	0	2	0	0	0	1	\N	0
6104405973	0	kihti	0	14	0	0	0	39	\N	0
5612769838	0	abyan	0	0	0	0	0	0	\N	0
6386307365	0	van.	0	2	0	0	0	7	\N	0
6530002893	0	ㅤㅤㅤ	0	5	0	0	0	0	\N	0
7190998280	0	kasya	0	6	0	0	0	0	\N	0
1946271833	0	fistaaa	6	253	0	0	0	208	\N	0
5789825660	0	J	0	19	0	0	180	6	\N	0
5653096518	0	Arsena	0	10	0	0	0	15	\N	0
6178443623	0	cioo	0	66	0	0	0	68	\N	0
1763553153	0	s	0	256	0	0	-1	693	\N	0
5450388035	0	TooyyLightyearr	0	3	0	0	0	6	\N	0
6260026439	0	kekeyy	0	6	0	0	0	21	\N	0
6641341707	0	𝐓𝐑≛𝐏𝐒 ` ୧ ֹ⸼⊰ zareá 🐈💭.	0	0	0	0	0	58	\N	0
5488714409	0	nayraa.	0	8	0	0	0	2	\N	0
5494086372	0	psh gf	0	906	0	0	6.34	12	\N	0
1321671887	0	jira	0	319	0	0	144.2800000000001	271	\N	0
6237161997	0	J	0	1	0	0	0	0	\N	0
6470586126	0	vickyy opengg	0	53	0	0	0	33	\N	0
6427967543	0	Eca	0	3	0	0	0	1	\N	0
6036009225	0	𝐊. 𝐉énan 𝐀mbarasthà	0	3	0	0	0	1	\N	0
2018924213	0	Harsha not a guy.	0	4	0	0	171.49000000000012	113	\N	0
5050276931	0	Sya	0	1	0	0	0	1	\N	0
948832426	0	pulang sana!	0	1	0	0	0	111	\N	0
6544588482	0	Kei	0	39	0	0	353	3	\N	0
1868334551	0	challa	3	53	0	0	17583.23999999998	613	\N	0
6194972001	0	vanyaaaa	2	460	0	0	52.24000000000069	843	\N	0
1028009806	0	savilaaa.	0	285	0	0	13	270	\N	0
2106619393	0	adinda, t.	0	11	0	0	0	8	\N	0
1903881406	0	👩🏻‍🍳	8	87	0	0	568.2399999999998	66	\N	0
5239070414	0	Jo	0	12	0	0	0	11	\N	0
5966591640	0	zo	0	0	0	0	0	0	\N	0
6943775545	0	cica fasho🇰🇬	0	1	0	0	0	1	\N	0
6234641567	0	C	0	56	0	0	31.620000000000005	1313	\N	0
1224604904	0	zia	0	2	0	0	0	0	\N	0
2041852862	0	a	0	2	0	0	0	0	\N	0
1984713789	0	nancy	0	186	0	0	-2.5	67	\N	0
5419563653	0	betmut Cece	0	1	0	0	0	0	\N	0
6886064866	0	ayesh	0	5	0	0	7.580000000000041	0	\N	0
6003453595	0	umiy	0	4	0	0	0	0	\N	0
1720304458	0	djiwa	0	472	0	0	175.15500000000003	352	\N	0
1090667227	0	ree	0	33	0	0	0	133	\N	0
5351370310	0	lpm	0	104	0	0	0	0	\N	0
7050667263	0	𝗄𝗂𝗄𝗂 ડ𝗂 𝗂ronⅿ𝖺n ૮ •᷅ࡇ•᷄ ა	0	50	0	0	0	199	\N	0
5108482585	0	𝕭𝖘.	0	121	0	0	0	113	\N	0
1766387663	0	z	0	5	0	0	0	2	\N	0
6966707140	0	sya	0	9	0	0	0	34	\N	0
5040167015	0	Ega.	0	109	0	0	82.1	170	\N	0
1331053007	0	Radoulph	0	18	0	0	0	0	\N	0
6112744138	0	jAy	0	1	0	0	0	0	\N	0
6541435666	0	n	0	5	0	0	0	0	\N	0
5208501957	0	Andalio	0	1	0	0	0	1	\N	0
6502080815	0	Waskita	0	2	0	0	0	0	\N	0
1895767233	0	bebe	0	161	0	0	2.5	9	\N	0
5284725993	0	nis 🤷🏻‍♀️	0	1	0	0	0	2	\N	0
6026616549	0	Ada Wong's	0	10	0	0	0	4	\N	0
1152133232	0	Aril	0	40	0	0	0	73	\N	0
5998111052	0	b for bailey.	0	52	0	0	0	27	\N	0
1880903044	0	mey	0	118	0	0	225.64999999999998	462	\N	0
1401263177	0	asH:Y	0	2	0	0	0	0	\N	0
5571077691	0	ola	0	65	0	0	0	13	\N	0
2048290278	0	citraloka.	0	110	0	0	13	17	\N	0
2011017186	0	ayes	0	4	0	0	0	133	\N	0
1825392849	0	tera	0	0	0	0	0	0	\N	0
5341517915	0	cya	0	12	0	0	0	121	\N	0
5645215006	0	Janaiah Asabe.	0	0	0	0	0	69	\N	0
1903926184	0	Arlan.	0	2	0	0	0	27	\N	0
6631530102	0	Laskar	0	2	0	0	0	0	\N	0
1211596736	0	rifqi	13	213	2	0	525.3	276	\N	0
6797536535	0	𝐓𝐑≛𝐏𝐒 `javinn	0	5	0	0	0	3	\N	0
6702417878	0	à ๋࣭ ⚝	0	12	0	0	0	0	\N	0
6002402368	0	bonbon	0	24	0	0	875	81	\N	0
6126511440	0	Nala	0	2	0	0	0	2	\N	0
1848084606	0	talk2me pls 😞	0	208	0	0	14.9	114	\N	0
1650660899	0	𝘢𝘳𝘦𝘭𝘪𝘦	1	9	0	0	0	438	\N	0
1945291533	0	drey.	0	49	0	0	0	21	\N	0
5637819315	0	barr	0	3	0	0	0	3	\N	0
6003782127	0	erlang 244	0	26	0	0	0	0	\N	0
1545319341	0	sel	0	1	0	0	0	0	\N	0
6102841550	0	asver	0	8	0	0	0	36	\N	0
1722882375	0	f(rae)	0	3	0	0	0	0	\N	0
1307626837	0	Je	0	15	0	0	0	7	\N	0
2109470811	0	saraheyoo	0	38	0	0	0	147	\N	0
6852681584	0	R	0	54	0	0	50	39	\N	0
1811452123	0	yuko awr	0	72	0	0	36.94000000000017	262	\N	0
1669124769	0	dyy	9	363	0	0	9.180000000000064	1096	\N	0
5392759920	0	こんとｌ░⃟🌈 🌱	0	2	0	0	0	0	\N	0
5184052138	0	.	0	1	0	0	0	0	\N	0
1544342277	0	jeyyi the explorer.	0	0	0	0	0	37	\N	0
5041504323	0	aisha bilek bilekan	0	6	0	0	0	1	\N	0
5755799317	0	kaeLl	0	4	0	0	0	12	\N	0
6167656758	0	aulyaayae	11	105	0	0	4111.68	2934	\N	1
1509498780	0	biell	0	331	0	0	4.52	237	\N	0
5030301875	0	chaka	0	1	0	0	0	0	\N	0
5540904809	0	haccio	0	1	0	0	0	0	\N	0
5457338965	0	mell	0	8	0	0	0	11	\N	0
5814072111	0	༉ Laura	0	2	0	0	0	12	\N	0
5627798373	0	Abian.	0	2	0	0	100	23	\N	0
5195638555	0	emily	0	295	0	0	35.09	77	\N	0
6869019900	0	ꭉִׂׂ໋ׅαׂׅׅ݂࣭݂ꪱׅ࣭࣪֗ꬻׂׅ	0	3	0	0	0	1	\N	0
6871490240	0	Ethan.	0	1	0	0	0	0	\N	0
6991352748	0	saa	0	16	0	0	0	0	\N	0
5513674311	0	carth	0	4	0	0	0	0	\N	0
2064781635	0	reva	0	2	0	0	0	0	\N	0
5876844359	0	Althäriq Kalterda	0	5	0	0	0	6	\N	0
2002485289	0	fara	0	1	0	0	0	0	\N	0
1074517553	0	return @jbayi to @lunnas	0	27	0	0	0	4	\N	0
5230308268	0	Lia.	0	584	0	0	56.62000000000111	5033	\N	0
6998327084	0	org	0	2	0	0	0	0	\N	0
5350622066	0	ken	0	0	0	0	0	86	\N	0
5393316737	0	re alex tunner gf	0	20	0	0	0	8	\N	0
5254052997	0	shà	0	0	0	0	0	0	\N	0
2090516252	0	A	0	1	0	0	0	0	\N	0
6076188784	0	d 🧜🏻‍♀️	0	426	0	0	23.13999999999993	668	\N	0
1829659098	0	Abimanyu.	0	7	0	0	0	2	\N	0
6381334612	0	raa	0	6	0	0	0	10	\N	0
1766255584	0	jeranc	0	1	0	0	0	0	\N	0
2015978729	0	Yesi	0	0	0	0	0	0	\N	0
5977743285	0	Jwé.	0	3	0	0	0	3	\N	0
6746631556	0	issa	0	1	0	0	0	0	\N	0
5566955891	0	.	0	452	0	0	512.46	101	\N	0
5492653830	0	Nvd	0	2	0	0	0	1	\N	0
1207272709	0	ze	0	36	0	0	0	69	\N	0
6131706751	0	Kissa dv.	0	6	0	0	0	16	\N	0
6432500073	0	jane	0	18	0	0	467.76	21	\N	0
1612329667	0	sha shaa	0	8	0	0	0	7	\N	0
5204895661	0	Arinne K.	0	10	0	0	0	7	\N	0
1913549014	0	telur	0	8	0	0	0	49	\N	0
845479215	0	Maou Sama~	0	12	0	0	0	3	\N	0
6143801737	0	ᬳᬶᬕᬸᬲ᭄ᬢᬶᬗᬸᬭᬄ. Pradika Bramaskara	0	10	0	0	0	0	\N	0
5337560440	0	ㅤㅤㅤㅤㅤㅤㅤ	13	51	0	0	92.61999999999989	537	\N	0
1346095213	0	sya	8	1030	0	0	6251.200000000001	4342	\N	0
1991811469	0	jie qatrider' 4twenty	0	0	0	0	0	82	\N	0
5189034281	0	dew	0	13	0	0	956	2	\N	0
1861623584	0	kei	0	178	0	0	424	0	\N	0
5860648111	0	askiaw	0	1	0	0	0	3	\N	0
6957973553	0	Jay(?)	0	40	0	0	9.200000000000003	23	\N	0
5688309504	0	maera rosette.	0	51	0	0	0	8	\N	0
6595037062	0	Kajevay ꭙ͢ ᴍᴀᴛᴀʜᴀʀɪ¹⁶⁸	0	7	0	0	0	2	\N	0
6313179400	0	Nana	0	1	0	0	0	0	\N	0
2126341723	0	JETHER — H.	0	8	0	0	0	39	\N	0
6113737351	0	zeana	3	31	0	0	611.099999999991	1391	\N	0
1659921641	0	Khais	0	35	0	0	0	0	\N	0
1706767842	0	Necasha.	0	1	0	0	0	0	\N	0
6572856363	0	esha	0	3	0	0	0	4	\N	0
5305847753	0	ㅤㅤㅤㅤ	10	244	0	0	3301.5800000000004	295	\N	0
1614576614	0	reysha	0	238	1	0	71	36	\N	0
1109941363	0	Karlo	0	3	0	0	0	0	\N	0
1634959520	0	ana	0	297	0	0	0	5	\N	0
1137238580	0	A	0	310	0	0	18.54	772	\N	0
1780099733	0	ar	0	507	0	0	3	52	\N	0
1751039883	0	Arlon ah	0	16	0	0	0	11	\N	0
5048301547	0	Haninnn.	0	9	0	0	0	53	\N	0
6897995479	0	Ｓｙｒｅａａ	14	62	0	0	2929.48	410	\N	0
1358567167	1	kibboy.	13	1054	0	0	30759.545000000056	2323	\N	1
2044501136	0	nothing	0	29	0	0	0	4	\N	0
6439087093	0	isan	0	1	0	0	0	1	\N	0
6984761229	0	seaᴴᴸ	0	3	0	0	0	3	\N	0
1713764472	0	ra	4	291	0	0	3168.2299999999987	18947	\N	0
6847274317	0	kinci	0	2	0	0	0	0	\N	0
6851371855	0	Jevano	0	1	0	0	0	2	\N	0
2006590669	0	Arsenic J	0	32	0	0	0	39	\N	0
5326352881	0	muna	0	0	0	0	0	0	\N	0
7188191936	0	4019	0	3	0	0	0	0	\N	0
1952874311	0	cil	0	7	0	0	0	17	\N	0
1490714765	0	Zaza	0	1	0	0	0	6	\N	0
2057090816	0	cha	0	0	0	0	0	3	\N	0
1598777457	0	Ali	0	17	0	0	3334.0899999999983	206	\N	0
5018409853	0	.	0	80	0	0	44.32999999999993	41	\N	0
5390385859	0	rain ngeBA	0	2	0	0	0	2	\N	0
6017574004	0	ef4iryone?	0	1	0	0	0	0	\N	0
2009534475	0	Sya	0	3	0	0	0	0	\N	0
1556772643	0	Umaya 7 fasyal, Ovksoju244zicar.	0	13	0	0	0	5	\N	0
5991121717	0	azXLeo	0	2	0	0	0	0	\N	0
6735995611	0	ibey. 👩🏻‍🎨	0	33	0	0	0	94	\N	0
1997881516	0	𖢻 💎 🐾 Bey	0	118	0	0	960	40	\N	0
5200614167	0	adelyn	0	20	0	0	0	35	\N	0
7182847108	0	cimaa	0	1	0	0	0	0	\N	0
1991269570	0	rey’s dump	0	1	0	0	0	0	\N	0
5441124983	0	zii	0	1	0	0	0	1	\N	0
6337033205	0	iori	0	27	0	0	88.75000000000001	153	\N	0
5472795516	0	Ken	0	9	0	0	223.43	223	\N	0
5802410201	0	Geska.	0	8	0	0	0	0	\N	0
6761114643	0	A.	0	4	0	0	0	0	\N	0
5281335778	0	SFS Chris 002	0	0	0	0	0	0	\N	0
2039492821	0	kabi	0	1	0	0	0	2	\N	0
1627062867	0	rajey udah vaksin dua kali	0	6	0	0	0	65	\N	0
1997476528	0	Jack.	0	127	0	0	123.63	1720	\N	0
1802848340	0	H	0	0	0	0	0	0	\N	0
5119084943	0	alla	0	55	0	0	0	118	\N	0
5386442491	0	sagara	0	1	0	0	0	0	\N	0
1789458410	0	J••N	0	2	0	0	0	5	\N	0
5971666527	0	risyy	0	12	0	0	271.24	345	\N	0
5753193300	0	.	0	2	0	0	0	4	\N	0
5196505897	0	yaya	0	1	0	0	0	0	\N	0
6484632069	0	AAAAAA	0	132	0	0	6	342	\N	0
6483953891	0	Sell??	0	4	0	0	0	28	\N	0
1405523031	0	alea	0	305	0	0	12.620000000000005	210	\N	0
5736431149	0	meyyra	0	2	0	0	0	0	\N	0
6188447907	0	jać ajayy	0	7	0	0	0	0	\N	0
5854307451	0	Juan.	0	16	0	0	0	12	\N	0
6050785004	0	Maeeey	0	172	0	0	0	0	\N	0
1756593150	0	A.	0	311	0	0	1.110000000000582	206	\N	0
6703421201	0	Who?	0	14	0	0	0	0	\N	0
1843024342	0	CIV	5	627	0	0	69.1499999999998	584	\N	0
6859608361	0	𐙚 Lili Lexya܀ 𓍢ִ໋🩰.	0	462	0	0	9.790000000000077	2280	\N	0
5435335201	0	Laura ᴅʏꜱᴛᴏ̄ᴘɪᴀ	0	1	0	0	0	0	\N	0
6983100659	0	x	0	3	0	0	0	3	\N	0
5008932654	0	Rodhe	0	31	0	0	0	32	\N	0
6080346979	0	ayii	0	1	0	0	91.46	242	\N	0
6392526975	0	karin	0	44	0	0	1501.82	378	\N	0
5461843110	0	Ryuu	0	6	0	0	63.94	9	\N	0
2046202751	0	jek	0	2	0	0	0	1	\N	0
5272212466	0	yup	0	4	0	0	0	0	\N	0
1984737910	0	leaving.	0	1	0	0	0	0	\N	0
1717727095	0	Putra `ⱽᴵᴾ	0	65	0	0	0	141	\N	0
6173714175	0	cylana, a	0	13	0	0	0	0	\N	0
5824922700	0	Lustefood.	0	341	0	0	820.3900000000001	327	\N	0
6478489958	0	.	0	1	0	0	0	0	\N	0
1267460998	0	varez.🏴.	0	140	0	0	0	45	\N	0
6055086427	0	n.abiy	0	8	0	0	0	2	\N	0
1854087636	0	𝐓𝐑≛𝐏𝐒 困 ᴊᴇɴᴅʀᴀʟ.	0	4	0	0	0	1	\N	0
1072886386	0	gelf dope.	0	1	0	0	0	0	\N	0
1634358981	0	Najin D.	0	7	0	0	0	3	\N	0
5696110498	0	galen	0	1	0	0	0	1	\N	0
6790790648	0	Vel	0	4	0	0	0	0	\N	0
1219084834	0	kiki	0	1	0	0	64	2	\N	0
6397288617	0	dikacok	0	3	0	0	0	1	\N	0
5544882777	0	Byyy	0	1	0	0	0	25	\N	0
6421477603	0	aeri berrelovu	4	212	0	0	968.53	5	\N	0
7017902110	0	the naturhe's lala	0	9	0	0	0	1	\N	0
1891400028	0	kei	0	243	0	0	1532.5	614	\N	0
1719272209	2	lastelle	0	692	0	1	112.80999999999995	250	\N	0
5192970836	0	nanatt	4	329	0	0	574.8100000000002	177	\N	0
1413148206	2	irene	0	206	0	0	2.159999999999968	105	\N	0
1315935398	0	zie 🧞‍♀️	0	77	0	0	1702.11	1647	\N	0
5576559165	0	bjr . van nyri fsr	8	28	0	0	393.0200000000001	35	\N	0
5444153428	0	Karlesha	0	11	0	0	0	23	\N	0
1839179704	0	ravin	0	49	0	0	0	62	\N	0
6050850942	0	north	11	826	0	0	37.69000000000315	453	\N	1
1745494184	0	isn't be a 'jacqueline'💐	0	1	0	0	0	1	\N	0
1789163057	0	po'ol	0	20	0	0	0	0	\N	0
6166496086	0	camelzà	0	15	0	0	0	2	\N	0
2044499335	0	Dika#bjr#bonge	0	4	0	0	0	248	\N	0
5971529121	0	Awaa.	0	0	0	0	0	1	\N	0
1881907229	0	soki	0	36	0	0	0	27	\N	0
5349293556	0	Ajie	0	11	0	0	0	73	\N	0
5921604916	0	vanandya, acz¹	0	2	0	0	0	9	\N	0
1408889148	0	Revan	0	0	0	0	0	5	\N	0
5661723753	0	Nay	0	1	0	0	0	0	\N	0
1953201765	0	gali	0	6	0	0	0	11	\N	0
5023163864	0	iciieyskie	0	236	0	0	0	2856	\N	0
6425372063	0	aleshaaA	0	2	0	0	0	1	\N	0
6754853338	0	alena	0	229	0	0	250	105	\N	0
6216337044	0	Dylan	0	5	0	0	0	1	\N	0
6570664537	0	Pia	0	9	0	0	0	3	\N	0
6724767967	0	𝐀ra-sta	0	1	0	0	0	3	\N	0
6507435752	0	kiyaa	0	13	0	0	0	10	\N	0
6086818535	0	lavanya anasera	0	21	0	0	0	0	\N	0
5672642185	0	ᴋᴀᴡᴀᴋɪ	0	3	1	0	0	0	\N	0
7025246396	0	Messi Noliana	0	13	0	0	0	388	\N	0
1938855525	0	Yesika ~	0	39	0	0	0	143	\N	0
5625544455	0	Marvin S.	0	18	0	0	0	1	\N	0
5898917607	0	Derrraa	6	62	0	0	1847.23	107	\N	0
6769687649	0	Calypso Ayana	0	2	0	0	0	0	\N	0
6285533823	0	Kinan Sorehari	0	0	0	0	0	0	\N	0
622075159	0	B	0	26	0	0	0	14	\N	0
5514140175	0	evelyn	0	13	0	0	0	0	\N	0
1806298353	0	piaa	0	0	0	0	0	3	\N	0
6513670311	0	A	0	3	0	0	0	0	\N	0
5178593146	0	E	0	40	0	0	0	1	\N	0
1573688805	0	k	0	2	0	0	95.11	2	\N	0
6314503186	0	daniel	0	13	0	0	0	0	\N	0
5446385204	0	langa el-korsa	0	3	0	0	0	7	\N	0
6204432989	0	Lavanya	0	2	0	0	0	0	\N	0
5718229876	0	on rest	0	8	0	0	0	1	\N	0
6309353129	0	N	0	5	0	0	0	6	\N	0
7006347173	0	Saputra	0	0	0	0	0	28	\N	0
1054529459	0	Aska	0	3	0	0	0	3	\N	0
2007252405	0	cunai🛼	0	706	0	0	595.5199999999998	260	\N	0
5639451997	0	ur	0	1	0	0	0	0	\N	0
6189370018	0	.	0	1	0	0	0	0	\N	0
7032764076	0	vy	0	1	0	0	0	0	\N	0
1944910577	0	bapakusatu	0	0	0	0	0	15	\N	0
6630273509	0	ㅤ	0	32	0	0	17.17	21	\N	0
1809109174	0	Zaki	0	0	0	0	0	0	\N	0
5766805230	0	dyy	0	1	0	0	0	0	\N	0
5560827067	0	Eunara	0	13	0	0	0	27	\N	0
1581874130	0	– Joandra Alderic	0	6	0	0	0	0	\N	0
6137689715	0	k	0	11	0	0	0	5	\N	0
6542979795	0	Marshall W.	0	1	0	0	0	0	\N	0
1824743355	0	kayla	0	19	0	0	0	18	\N	0
1970305434	0	adadeh	0	517	0	0	32.46	105	\N	0
5982835981	0	Tim SAR Barelang	0	16	0	0	106	0	\N	0
1757134771	0	aiiii	2	170	0	0	256.54	681	\N	0
1715801611	0	Donquixote.	0	72	0	0	1309.8700000000003	4398	\N	0
5022810524	0	jgn chat!!	0	8	0	0	0	0	\N	0
6885192192	0	fay	0	4	0	0	0	27	\N	0
6824420354	0	Pcrnya Zayne	0	43	0	0	0	2	\N	0
6837691551	0	a	0	92	0	0	0	1	\N	0
6267547607	0	ocaaa	0	96	0	0	4.239999999999998	57	\N	0
6751764751	0	Isaac	0	32	0	0	0	14	\N	0
5986688401	0	155 acol	5	17	0	0	533.13	168	\N	0
1799131478	0	leara	0	8	0	0	0	53	\N	0
5476342219	0	atlas	0	64	0	0	15.800000000000068	97	\N	0
6647810518	0	sean	0	140	0	0	0	144	\N	0
7104099055	0	galang, cf only	0	5	0	0	0	0	\N	0
6718014106	0	acc jajan	0	3	0	0	0	4	\N	0
5251389754	0	Theo rvg²	0	129	0	0	8	36	\N	0
5593120235	0	saa	12	336	0	0	1247.3300000000002	361	\N	0
5559760223	0	cheeyva, a.	0	57	0	0	0	32	\N	0
1987623828	0	d	0	110	1	0	0	5	\N	0
1859207651	0	??	0	53	0	0	0	4	\N	0
6154920554	0	૮ • ﻌ - ა ini namanya anin, egl	5	1	0	0	750.58	358	\N	0
6259106760	0	Ms. Arsea east.	9	1291	0	0	48763.4	7153	\N	1
2109658263	0	arsha	0	17	0	0	0	4	\N	0
1406681960	0	namira	0	93	0	0	0	17	\N	0
1435206098	0	Tendean	10	639	0	0	1721.9200000000005	536	\N	0
1317412302	0	rae 🧌	0	0	0	0	0	1	\N	0
6228215958	0	L — Ocean.	0	3	0	0	0	1	\N	0
6428282589	0	SALWAAaa	0	3	0	0	0	38	\N	0
5304883413	0	i for ica	0	0	0	0	0	202	\N	0
5044003730	0	kang minho	0	4	0	0	0	26	\N	0
7141540294	0	vetico	0	57	0	0	355	84	\N	0
5271109368	0	Putri A.	0	64	0	0	189	12	\N	0
6153621732	0	rest	0	18	0	0	0	64	\N	0
1199505459	0	b	3	123	0	0	687.2700000000001	1088	\N	0
6281846044	0	𐙚 .. ⊹ ࣪ Jefri’s dollie, Kanyesha࣪ ♡ #NEOHIRMIN	0	9	0	0	0	0	\N	0
5912757998	0	r	0	108	0	0	444.76	575	\N	0
5387623087	0	lie	0	12	0	0	0	30	\N	0
6174286877	0	SnD	0	6	0	0	0	0	\N	0
6172661585	0	calle	0	8	0	0	0	129	\N	0
5246724707	0	floren	0	1	0	0	0	0	\N	0
6743061779	0	a	0	54	0	0	0	0	\N	0
6583159494	0	Darka	0	3	0	0	0	1	\N	0
1170840373	0	maura	0	4	0	0	0	152	\N	0
5891476945	0	𝑫𝒊𝒌𝒕𝒂 𝑴𝒂𝒉𝒊𝒏𝒅𝒓𝒂	0	1	0	0	0	9	\N	0
6829356819	0	okta	0	3	0	0	0	1	\N	0
5961131518	0	Fy	0	21	0	0	0	6	\N	0
5455648184	0	ayesss	0	2	0	0	0	0	\N	0
5563074282	0	lulu	0	2	0	0	298.92	33	\N	0
2098851096	0	୨୧ . . "Gemini, J."	0	1	0	0	0	0	\N	0
5760350746	0	Katherine.	0	0	0	0	0	1	\N	0
6438964147	0	mei	0	38	0	0	0	75	\N	0
1960927268	0	kyla	0	2	0	0	0	0	\N	0
6477130530	0	Kya	0	1	0	0	0	11	\N	0
5988128251	0	rbio. nanaa close bt	0	14	0	0	0	0	\N	0
1609734386	0	A	0	4	0	0	0	0	\N	0
5085939070	0	Fayera	0	1	0	0	0	0	\N	0
6032156183	0	SELINE SAYANG RYN	0	2	0	0	0	0	\N	0
6112572001	0	bluu	0	1	0	0	0	0	\N	0
5400580663	0	Ash	0	2	0	0	0	9	\N	0
6366852879	0	dir	0	12	0	0	0	5	\N	0
1750642400	0	azkia sayang piwin	0	164	0	0	2	441	\N	0
6182023109	0	kal	0	17	0	0	18.689999999999998	283	\N	0
5330714222	0	Sarasehan. kang ghosting DNI !	0	8	0	0	7.039999999999964	142	\N	0
1763824697	0	abi	0	11	0	0	244.27	13	\N	0
6169112036	0	ltn. 𝐉	0	6	0	0	0	0	\N	0
5790224794	0	ysta	0	3	0	0	0	2	\N	0
6232124190	0	Frincee	0	0	0	0	0	7	\N	0
5141541026	0	— bie	0	24	0	0	0	5	\N	0
5150343595	0	astor	0	24	0	0	0	291	\N	0
1720605022	0	Keith C.	0	3	0	0	0	5	\N	0
5036333583	0	bell 🧿	13	61	0	0	1037.1800000000005	75	\N	0
1340940246	0	pinong 4	0	50	0	0	0	0	\N	0
1786477914	0	tipaaa	0	1	0	0	0	1	\N	0
5008181202	0	senja	11	45	0	0	122.84999999999988	188	\N	0
5663199125	0	emma lgi need spay	0	2	0	0	0	5	\N	0
5199859382	0	aya	0	7	0	0	0	8	\N	0
5253590211	0	kafka	0	16	0	0	11.540000000000006	183	\N	0
5680800680	0	The Astrophile's, Lyvarine.	0	1	0	0	0	1	\N	0
1676068739	0	caaaa	0	1	0	0	0	0	\N	0
6857707291	0	𝙅	0	60	0	0	0	17	\N	0
1687638294	0	️yass	0	1558	0	0	319.8500000000013	866	\N	0
1827519161	0	hecticccc selective	0	5	1	0	0	157	\N	0
6737090621	0	stfu	0	4	0	0	0	0	\N	0
1902423897	0	xoxo	0	86	0	0	0	1	\N	0
1701986520	0	aii	0	0	0	0	0	0	\N	0
5912416362	0	sasa	0	1	0	0	0	0	\N	0
2075671616	0	👾	0	70	0	0	4.849999999999994	103	\N	0
1496264982	0	ISAGI RYUU ✟>>>	0	3	0	0	0	0	\N	0
2051791920	0	A	0	1	0	0	0	0	\N	0
6208029182	0	naano	0	41	0	0	0	1	\N	0
6446895017	0	Fala / stop buat emosi	0	539	0	0	92.21999999999935	86	\N	0
1784548634	0	k	0	354	0	0	0	1	\N	0
7185133072	0	sb gua bangsat. jgn curang	0	30	0	0	0	11	\N	0
1290734332	0	alvestreyy	0	17	0	0	0	10	\N	0
5019643092	0	putra sambalado	0	4	0	0	0	32	\N	0
5364471373	0	Van Gogh. NOT REPLYING	0	125	0	0	1719.4800000000002	532	\N	0
6465555791	0	eja telaso	0	7	1	0	0	0	\N	0
5389086701	0	Ica	0	1	0	0	0	0	\N	0
1177753380	0	━ 𝙨𝙮𝙖𝙖	0	47	0	0	0	2	\N	0
5023504711	0	clarissa	0	7	0	0	0	0	\N	0
1986845352	0	n	0	2	0	0	0	0	\N	0
1620907014	0	EdVerth Elvoister	0	120	0	0	0	7	\N	0
6702274340	0	kanjeng ratu	0	3	0	0	0	0	\N	0
1082815273	0	-	0	1	0	0	0	0	\N	0
5471411373	0	ibu ipi	0	27	0	0	0	31	\N	0
6269988765	0	Madeleine.	0	4	0	0	0	0	\N	0
5013676219	0	E	0	0	0	0	0	0	\N	0
6815455847	0	nana	0	2	0	0	0	0	\N	0
1503709080	0	lyn.	0	2	0	0	0	0	\N	0
2028456208	0	Jess	0	1	0	0	0	0	\N	0
1729310776	0	secc	0	42	0	0	0	23	\N	0
6452974383	0	Arsyilla๛	0	2	0	0	0	15	\N	0
7140758041	0	Vinaaa˙⊹	0	17	0	0	145	6	\N	0
6573006570	0	di on	0	2	0	0	544.66	55	\N	0
5691154233	0	Ikballlll	0	5	0	0	0	11	\N	0
5060948471	0	e	0	23	0	0	0	0	\N	0
5929603240	0	pan gi	0	1	0	0	0	2	\N	0
1700653755	0	Akun Terhapus	8	338	0	0	6151.539999999997	304	\N	1
1213297951	0	ㅤ	0	274	0	0	4.490000000000066	1072	\N	0
6277741671	0	Reza	0	1	0	0	0	0	\N	0
5291774349	0	ujep	0	126	0	0	4.109999999999999	95	\N	0
6093655952	0	ganja	0	45	0	0	52.23000000000002	47	\N	0
5731368062	0	Medina	0	15	0	0	0	0	\N	0
6814835003	0	chel	0	9	0	0	34.88	131	\N	0
6038451772	0	m	0	1	0	0	0	0	\N	0
5403798283	0	maybe?.	0	5	0	0	0	5	\N	0
5106393127	0	gelee	0	2	0	0	0	0	\N	0
5332689067	0	n	0	4	0	0	0	21	\N	0
6050091128	0	luMINE	0	79	0	0	0	128	\N	0
6239104123	0	Afan	0	1	0	0	0	2	\N	0
5083381107	0	dunkin	5	224	0	0	1186.2500000000005	65	\N	0
7184048002	0	pyla	0	10	0	0	0	7	\N	0
5956272272	0	K	0	1	0	0	0	0	\N	0
5079321359	0	haru	0	1	0	0	0	0	\N	0
833817598	0	melvil	0	8	0	0	0	4	\N	0
5637614083	0	logging out	0	7	0	0	0	0	\N	0
1657341695	0	bian	0	268	0	0	0	63	\N	0
5014800442	0	less	0	8	0	0	0	14	\N	0
5810630890	0	أنا larmes	0	31	0	0	76	9	\N	0
2012162224	0	Dar.	0	1	0	0	0	8	\N	0
5172226660	0	Aliaaa	0	10	0	0	0	1	\N	0
1704407061	0	tia	0	1	0	0	0	19	\N	0
1767693417	0	zhazaa	0	0	0	0	0	5	\N	0
1992375280	0	aaron.	0	7	0	0	0	11	\N	0
1811846454	0	ngab henry.	0	4	0	0	0	1	\N	0
1739584488	0	Winara f	0	139	0	0	0	5	\N	0
6068140877	0	C1011231083 Nyemas Vivi S.R Agroteknologi.	0	45	0	0	124.66999999999999	0	\N	0
1993277146	0	Senaa	11	128	0	0	5048.0274999999865	45726	\N	1
6262438518	0	icyy :]	0	1	0	0	0	2	\N	0
6782625737	0	r	0	3	0	0	0	1	\N	0
6356603779	0	𓄹۫ deui ۫𔘓𓈒 ֗	0	97	0	0	12.62	45	\N	0
1544716381	0	salsa	0	23	0	0	0	177	\N	0
6704830838	0	hang heng	0	22	0	0	0	0	\N	0
1298660161	0	prvj	0	5	0	0	0	1	\N	0
1767723318	0	caa	12	578	1	0	3821.7500000000027	1146	\N	0
1530975182	0	𐙚 Adel ˢᵏᵇ⁴⁸`ᵐᵉᵐᵇᵉʳ 𝗔𝐊 ᎧӠ ꪆ୧‌‌	0	4	0	0	0	0	\N	0
5875311030	0	Junior Ravanja.	0	17	0	0	0	11	\N	0
6520567594	0	Lindu, A.	0	3	0	0	0	1	\N	0
5051279201	0	änin drxt³	0	25	0	0	18.5	97	\N	0
5983176384	0	ucup	0	8	0	0	0	8	\N	0
1976248155	0	kia	0	15	0	0	0	0	\N	0
6482112229	0	kasa.	0	18	0	0	0	132	\N	0
5190872853	0	a	8	108	0	0	6.999999999999986	0	\N	0
7142644709	0	607. kezia centil	0	17	0	0	0	1	\N	0
1896918866	0	active	0	11	0	0	0	0	\N	0
5811975798	0	Ai	0	21	0	0	456	1	\N	0
1586633920	0	atikaa w¡kky	0	3	0	0	0	0	\N	0
5001605997	0	cece	0	24	0	0	370.73	1949	\N	0
1731194626	0	.	0	61	0	0	0	1	\N	0
1909127861	0	luiza	0	93	0	0	1634	48	\N	0
1086029172	0	Nadyra	0	31	0	0	0	5	\N	0
6521954372	0	Saaabill	0	1	0	0	0	13	\N	0
5188473891	0	ndra	0	1	0	0	0	0	\N	0
5640092722	1	v	0	10	0	0	0	2	\N	0
6961971005	0	deez	0	10	0	0	68.10000000000004	404	\N	0
2088283333	0	luna	0	7	0	0	0	0	\N	0
5291347610	0	j	0	1	0	0	0	24	\N	0
6472560134	0	｡✧ kayra asteria.X✧｡	0	3	0	0	0	9	\N	0
6804691243	0	.	0	5	0	0	0	0	\N	0
6173429929	0	kafka	0	11	0	0	0	42	\N	0
1416805586	0	zeckk	0	17	0	0	0	0	\N	0
6326747381	0	ziel	0	2	0	0	0	3	\N	0
5247482769	0	zii	0	30	0	0	0	3	\N	0
6267733542	0	nasaa 𓆝 𓆟 𓆞	0	0	0	0	0	0	\N	0
5604586601	0	RG.	0	2	0	0	0	101	\N	0
1277574879	0	re	0	65	0	0	0	247	\N	0
6367751990	0	🖤	0	39	0	0	0	29	\N	0
5179945662	0	ourene	0	2	0	0	0	0	\N	0
642027119	0	Annisa	0	183	0	0	0	2	\N	0
1049434929	0	Baginda Edgar ᔆᵉᵖᵉⁿᑦᑋꜞˡˡ	0	4	0	0	0	0	\N	0
5991019479	0	ale🕷	0	1	0	0	0	2	\N	0
5994603246	0	egaa	0	6	0	0	0	1	\N	0
1868509344	0	kiera.	0	40	0	0	0	10	\N	0
5379477800	0	psa	0	366	0	0	0	10	\N	0
6103199413	0	ethan	0	2	0	0	0	1	\N	0
5951837150	0	geonathan.	0	42	1	0	13.590000000000003	24	\N	0
1902544644	0	chava	0	21	0	0	0	11	\N	0
1450109703	0	🐻	0	79	0	0	0	27	\N	0
5955960342	0	z	0	106	0	0	5.340000000000003	29	\N	0
6140038305	0	nita ✞︎ •TP•	0	8	0	0	0	10	\N	0
5643653044	0	sya	0	64	0	0	255.63	55	\N	0
1861475101	0	d	10	528	0	0	8.689999999999987	45	\N	0
1806491859	0	💭	0	0	0	0	0	0	\N	0
1794794361	0	Kiro	0	118	0	0	8.699999999999996	12	\N	0
6229338118	0	Naraa	0	1	0	0	0	2	\N	0
7143037452	0	callodei kinda slr	0	107	0	0	15	10	\N	0
1890066333	0	masfunny	1	1	0	0	1120.1000000000001	141	\N	0
1403344545	0	ra	5	726	0	0	4124.669999999999	536	\N	1
5195710921	0	juny	0	47	0	0	0	16	\N	0
6981065156	0	Livy	0	2	0	0	0	0	\N	0
1205623058	0	human	0	30	0	0	0	10	\N	0
5707414507	0	⪩⪨ׅ .. ♡ — m, atsna. 𓊇	0	14	0	0	0	9	\N	0
5573891839	0	Shakieu K.	0	17	0	0	0	54	\N	0
6085609096	0	Rajwa	12	504	1	0	2.290000000000873	10	\N	1
2057420664	0	btnstr. Sasa	0	45	0	0	1139.4700000000003	1	\N	0
6406200981	0	.	0	35	0	0	0	24	\N	0
6169600684	0	Haziq	0	25	0	0	0	326	\N	0
6057425136	0	monyong	0	75	0	0	0	8	\N	0
1735623753	0	mell	10	34	0	0	1129.1	1303	\N	0
6871390923	0	el	0	44	0	0	0	14	\N	0
6446265045	0	miracle	0	17	0	0	0	0	\N	0
6203260532	0	biaa	0	49	0	0	0	27	\N	0
6259891250	0	la	0	40	0	0	219.26000000000005	233	\N	0
1363346169	0	NH3+	0	12	1	0	0	4	\N	0
6528501920	0	nei	0	28	0	0	478	0	\N	0
1917262135	0	sa	0	3	0	0	0	0	\N	0
6344868908	0	⍥⃝	0	10	0	0	0	0	\N	0
1610476736	0	asaa	0	33	0	0	921.71	26	\N	0
5774569207	0	Rayy.	0	327	0	0	14.500000000001478	150	\N	0
5934192147	0	Pgf00	0	53	0	0	81	43	\N	0
1957149535	0	ᴛᴢᴄᶜʳⁱ lux da lavien	0	0	0	0	0	38	\N	0
6520310137	0	ntahlah	0	3	0	0	0	0	\N	0
6251650016	0	Calauu	0	5	0	0	0	2	\N	0
1728182234	0	Cacaaaa	0	1	0	0	0	0	\N	0
6835201479	0	fian	0	37	0	0	0	16	\N	0
1858064564	0	animek,	0	3	0	0	0	0	\N	0
6264671231	0	aura p.	0	16	0	0	0	12	\N	0
1589018499	0	el	0	1	0	0	0	0	\N	0
5544791885	0	👳‍♂️	0	4	0	0	0	149	\N	0
5732828138	0	Jeno’s lovetaker, Th’Astronout Nicolle	0	3	0	0	0	0	\N	0
6571344951	0	o	0	6	0	0	0	1	\N	0
1068204486	0	aull🍓	0	3	0	0	0	116	\N	0
1404278936	0	reoo	0	1	0	0	0	0	\N	0
1134369127	0	Ava 𝖓𝖔𝖋è¹⁰	0	29	0	0	28	15	\N	0
2102898218	0	Carlos Macello	0	1	0	0	0	0	\N	0
7157038611	0	Acelly Willow	0	10	0	0	0	32	\N	0
5921347698	0	kiyaa	0	3	0	0	0	3	\N	0
1944711025	0	ᵗᵉᵃᵐvgs . klee sao	0	1	0	0	0	0	\N	0
1760549807	0	may. limit chat	0	2	0	0	0	0	\N	0
1926074163	0	delucy	0	5	0	0	11.34	30	\N	0
6473491893	1	siebeyya ¡!	4	491	0	1	1814.49	173	\N	0
5440123013	1	nafi	7	88	0	0	71.39000000000001	173	\N	0
1818075808	0	ENDUPTEA	0	3	0	0	0	0	\N	0
6137273465	0	a fool for you	0	3	0	0	0	26	\N	0
5256509560	0	KL	0	8	0	0	0	94	\N	0
6006976545	0	ーrandy fahréza gi bboo	0	2	0	0	0	3	\N	0
1964517497	0	숙녀 .. “aurshlie.”	0	13	0	0	0	3	\N	0
5651857574	0	pijar	0	5	0	0	0	62	\N	0
5332419549	0	eii	9	166	0	0	4034.3499999999995	336	\N	0
1485114072	0	Kaushal	0	3	0	0	0	0	\N	0
7018419041	0	⊛ ᴇxᴠ ` ʀᴀʏɴꜱᴢᴀ	0	4	0	0	0	1	\N	0
5110632834	0	Melfys	0	0	0	0	0	2	\N	0
6288415173	0	alaric	0	56	0	0	0	21	\N	0
5702415120	0	nethya	0	3	0	0	0	2	\N	0
1890674623	0	Rayen	0	242	0	0	7.130000000000109	2249	\N	0
5034997955	0	c	0	168	0	0	0	2429	\N	0
5694251152	0	🙋🏻‍♀️	0	240	0	0	2.2799999999999727	95	\N	0
6446155024	0	jèpa	0	0	0	0	0	7	\N	0
5112540507	0	asta	0	4	0	0	0	45	\N	0
5855436182	0	cc	0	4	0	0	0	0	\N	0
6079057351	0	𝐉​enddiè🐡	0	13	0	0	86.95999999999988	41	\N	0
2032018575	0	fi	0	0	0	0	0	0	\N	0
6384398019	0	Kevran	0	14	0	0	0	0	\N	0
1796000802	0	wawa	0	54	0	0	0	227	\N	0
6089195261	0	none	3	682	1	0	342.5299999999987	788	\N	0
1773900485	0	shéira.	0	7	0	0	0	20	\N	0
6649401216	0	Kiji	0	1	0	0	0	2	\N	0
6701447607	0	Justinio	0	1	0	0	0	0	\N	0
1084911180	0	cinta	0	16	0	0	0	4	\N	0
1395791957	0	j	0	444	0	0	7.729999999999997	236	\N	0
2126802566	0	ejaa	0	9	0	0	0	0	\N	0
6771692456	0	vio	0	35	0	0	0	35	\N	0
1546258627	0	stev	0	147	0	0	1116.5	441	\N	0
1760576972	0	s	0	71	0	0	434	412	\N	0
1785582738	0	cy	0	226	0	0	3714.83	525	\N	0
1672242122	0	911	0	22	0	0	0	29	\N	0
1365246927	0	Cevaa.	0	85	0	0	680.1800000000001	420	\N	0
2021734957	0	teresha, e.	0	13	0	0	0	2	\N	0
6103803608	0	sra	0	3	0	0	0	0	\N	0
5213385130	0	美しい *⁠･Lauu ✿°•	0	72	0	0	75.46000000000018	54	\N	0
1501432239	0	sasya	0	25	0	0	0	111	\N	0
5334798603	0	*123#	8	253	0	0	376.7099999999996	42	\N	0
5031272191	0	ca	0	77	0	0	0	200	\N	0
1682544759	0	sahara	0	126	0	0	0	310	\N	0
7199478231	0	r	0	18	0	0	0	1	\N	0
6577956472	0	Valen feeling blue.	0	313	0	0	-14.319999999999823	96	\N	0
1836041094	0	disha	0	8	0	0	32.510000000000005	3	\N	0
6206662855	0	𝕭c'gefan	0	12	0	0	0	12	\N	0
5927187385	0	ala.	3	922	0	0	12.52000000000021	2079	\N	0
6224457612	0	h	0	17	0	0	0	4	\N	0
5122223229	0	Roni	0	4	0	0	0	3	\N	0
2053447202	0	joan	0	34	0	0	0	9	\N	0
6491862305	0	piyyoo suka mam	0	2	0	0	0	0	\N	0
1986986373	0	q	0	3	0	0	0	3	\N	0
5429758730	0	boi	0	2	0	0	0	3	\N	0
2118188370	0	Viréndra M	11	1205	0	0	0.07999999999938723	1018	\N	0
5970653040	0	James	0	1	0	0	0	0	\N	0
5193922935	0	nala	0	2	0	0	0	0	\N	0
1621811408	0	a	0	11	0	0	0	0	\N	0
1261737127	0	Jeoniess	0	1	0	0	0	0	\N	0
5644253781	0	chevaa ᴡ̷ᴇʏᴇᴇs`	0	2	0	0	0	1	\N	0
6393101489	0	୨ ᥲ᥉hᥲɾᥲ ୧	0	6	0	0	12.83	7	\N	0
1635180427	0	Ziga	0	2	0	0	0	0	\N	0
6467357599	0	nra	0	16	0	0	1	70	\N	0
5768352066	0	أحبك .005	0	1	0	0	0	0	\N	0
1853008893	0	L	0	1	0	0	0	8	\N	0
1424291684	0	caa	0	10	0	0	935.28	88	\N	0
5143770306	0	Yuzuha.	0	27	0	0	0	0	\N	0
5115209415	0	key. slw	0	1	0	0	0	0	\N	0
1705225516	0	Rin	0	58	0	0	133.86	589	\N	0
5142506069	0	.	0	19	0	0	0	0	\N	0
1859471237	0	cocomelon 💐	0	69	0	0	0	203	\N	0
1790814009	0	aurell	3	4	0	0	529.35	27	\N	0
2026449794	0	El.	0	10	0	0	0	4	\N	0
6748444839	0	Hyuka	0	2	0	0	0	0	\N	0
5073935424	0	asepp	0	0	0	0	0	0	\N	0
5185173677	0	k	0	42	1	0	0	6	\N	0
2083785486	0	milea	0	22	0	0	0	243	\N	0
5736398421	0	Laila	0	9	0	0	0	6	\N	0
6032272944	0	J	0	8	0	0	0	3	\N	0
6456894203	1	.	0	305	0	0	263.6300000000001	16	\N	0
1955117675	0	Kaina	0	21	0	0	0	0	\N	0
2023817966	0	ini ami asli kok	0	60	0	0	0	27	\N	0
6622056361	0	chelsea < jake-ue > gf	0	3	0	0	0	11	\N	0
1656161864	0	.	0	2	0	0	0	1	\N	0
5050553410	0	put	0	1	0	0	0	0	\N	0
5620802476	0	KAI	0	4	0	0	250	24	\N	0
5101910998	0	alsa	0	3	0	0	0	3	\N	0
5118068697	0	Khia🪼	0	49	0	0	753	66	\N	0
1401514987	0	Lauviena	0	0	0	0	150	34	\N	0
6553395462	0	Jafkaf.	2	2	0	0	163.29	8	\N	0
1815416387	0	acha	0	16	0	0	0	0	\N	0
6746674765	0	Pinkiel	0	2	0	0	0	0	\N	0
5686773109	0	shi	0	252	0	0	11.420000000000002	285	\N	0
1488223824	0	Sanha	0	20	0	0	0	3	\N	0
6958195930	0	Janelle M.	0	1	0	0	0	6	\N	0
1873799308	0	Kenneth	0	27	0	0	0	0	\N	0
5482464285	0	amar	0	21	0	0	0	1	\N	0
2063075511	0	Luci	1	42	0	0	4140.469999999999	555	\N	0
1871699448	0	chloe	0	2	0	0	0	11	\N	0
1547974313	0	;	0	2	0	0	0	0	\N	0
6868139535	0	noob	0	5	0	0	0	9	\N	0
6397427924	0	Raeci H.	0	50	0	0	0	14	\N	0
1522038258	0	Eugene	0	3	0	0	0	25	\N	0
6252078667	0	jia	0	1	0	0	0	0	\N	0
5484574976	0	Cantika.	0	0	0	0	0	0	\N	0
1715046628	0	Ziii	0	7	0	0	0	7	\N	0
6297448656	0	ci	4	275	0	0	320.85	1106	\N	0
1767903447	0	ais	0	210	0	0	0	15	\N	0
1383327976	0	bebec	0	3	0	0	0	16	\N	0
1988165013	0	aynaaaa	0	1	0	0	0	0	\N	0
5226917629	0	Dinda Muniroh	8	118	0	0	33.879999999999995	206	\N	0
5851280997	0	raa	0	33	0	0	11.530000000000001	1	\N	0
6050556349	0	kiya	0	7	0	0	0	0	\N	0
6041129226	0	#	0	2	0	0	0	0	\N	0
1359046028	0	Jia♡	0	151	0	0	58.06999999999999	55	\N	0
2080210229	0	el	0	4	0	0	0	2	\N	0
5884522032	0	Reno	7	5	0	0	539.7000000000002	310	\N	0
1956941606	0	Amanda	0	28	0	0	0	1	\N	0
6412751074	0	Yaa	0	2	0	0	0	0	\N	0
5812244911	0	noey	0	1	0	0	0	0	\N	0
6602547257	0	parad!se	0	0	0	0	0	54	\N	0
7125113635	0	Kay	8	1	0	0	1821.51	11	\N	0
5928294829	0	woOppsss	0	5	0	0	0	0	\N	0
1854801926	0	ㅤilaaa	0	7	0	0	0	20	\N	0
5685499528	0	Erick, rest.	0	840	0	0	3	100	\N	0
2017289692	0	dibu	0	410	0	0	1314.94	161	\N	0
1870280166	0	Zidan’s heart dwellers	0	99	0	0	0	1	\N	0
1772059214	0	Kin	0	114	0	0	10.620000000000005	99	\N	0
6660538856	0	Ahag	0	4	0	0	0	0	\N	0
5682622892	0	Jev.	0	3	0	0	0	0	\N	0
6614389001	0	Issabelle Morchsa ᴬᴹᴾ	0	9	0	0	0	1	\N	0
6534756099	0	chilla	0	1	0	0	0	0	\N	0
1795328853	0	.	0	3	1	0	0	0	\N	0
1510766412	0	Anastasha	0	6	0	0	0	37	\N	0
5525696197	0	A	0	3	0	0	0	0	\N	0
5712046707	0	arya	0	3	0	0	0	0	\N	0
6206646851	0	Eraa	0	35	0	0	2.729999999999791	69	\N	0
1061041760	0	Bumi	0	7	0	0	0	3	\N	0
5915553082	0	Kytt	0	8	0	0	0	1	\N	0
6362483027	0	sasa	0	1	0	0	0	4	\N	0
6760986916	0	jo	0	1	0	0	0	0	\N	0
5416064670	0	A	0	14	0	0	0	78	\N	0
1752856807	0	tami tzy	0	69	0	0	787.9999999999999	723	\N	0
1083347731	0	cindy	14	96	0	0	1078.9	598	\N	0
1196449184	0	ruiya	0	8	0	0	0	6	\N	0
5534218499	0	someone	0	18	0	0	0	63	\N	0
5380644753	0	shev	0	1	0	0	0	0	\N	0
1230902729	0	Hang	0	11	0	0	70	5	\N	0
1727366170	0	Kyowiè	0	1	0	0	0	1	\N	0
5204611904	0	firaraeaea	0	89	0	0	0	190	\N	0
5970945310	0	ayyy	0	7	0	0	0	0	\N	0
6669800655	0	Benjamin Balaga	0	5	0	0	0	68	\N	0
1631384242	0	haura	0	304	2	0	2252.0299999999997	9690	\N	0
5783708964	0	ell	0	1	0	0	0	3	\N	0
1719943521	0	Xaan Cugs	0	2	0	0	0	2	\N	0
6828065657	0	Dorris Kotta.	0	2	0	0	100	4	\N	0
6807679959	0	kath	0	1	0	0	0	2	\N	0
1958252508	0	Eshanah pacal enid	0	65	0	0	960	368	\N	0
1715116541	0	bal	0	2	0	0	216.28	9	\N	0
5080087534	0	River	0	69	0	0	144.5300000000001	1042	\N	0
5053445110	0	ɪᴍᴄ. Nazera Ayunda	0	2	0	0	0	0	\N	0
5881957780	0	esa	0	5	0	0	0	124	\N	0
1735540748	0	tíαn lactosa	0	19	0	0	0	3	\N	0
6413732427	0	nattt	6	229	1	0	213.64999999999998	1661	\N	0
6353517301	0	syeefa	0	30	0	0	92.45000000000005	45	\N	0
1966418274	0	nakula.	6	73	0	0	1986.6400000000003	571	\N	0
6468458238	0	leyraa.	0	2	0	0	0	1	\N	0
1895422445	0	youra	0	2	0	0	0	1	\N	0
5380547627	0	ane	0	34	0	0	286.51	5	\N	0
1805964320	0	cimayy	0	14	0	0	0	45	\N	0
1849910596	0	Aka.	0	2	0	0	0	3	\N	0
1973085495	0	A	0	90	0	0	0	331	\N	0
6016339957	0	Caaaaaa	0	8	0	0	0	2	\N	0
2059711884	0	𝐂/𝐁𝐀. 𝐑achel	0	1	0	0	0	0	\N	0
1972962243	0	ヾ 𝗦'𝗗𝗘WA	0	1	0	0	0	0	\N	0
5955437869	0	Odi	0	15	0	0	0	0	\N	0
1483940999	0	Elopyu	0	0	0	0	0	0	\N	0
5663886029	0	Bailla, Leaving.	0	2	0	0	0	0	\N	0
5977407678	0	AL	0	6	0	0	0	0	\N	0
1475024196	0	Aillie lagi galau	0	4	0	0	0	11	\N	0
1812035818	0	yurra @bornlovedy	0	5	0	0	351.28999999999996	427	\N	0
5989229404	0	raymos dnfi.	0	3	0	0	0	43	\N	0
2136212512	0	maleia althea	0	5	0	0	0	55	\N	0
1401644013	0	Y	0	10	0	0	0	16	\N	0
2044804345	0	àza	0	1	0	0	0	1	\N	0
6271851483	0	Gabby	0	2	0	0	0	0	\N	0
6345706810	0	Hevarta	0	8	0	0	0	4	\N	0
5005944220	0	ajia apa	0	132	0	0	21.5	2363	\N	0
6937339397	0	kay	0	1	0	0	0	2	\N	0
5349216310	0	Madharsa	0	2	0	0	0	301	\N	0
7057101947	0	qaef	0	0	0	0	0	0	\N	0
1616593604	0	kica	0	2	0	0	0	18	\N	0
7061439279	0	🎀	0	6	0	0	0	9	\N	0
1597013826	0	͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏	0	40	0	0	0	108	\N	0
5085212590	0	shakira. ♡	0	1	0	0	0	0	\N	0
6928739853	0	Icad	6	25	0	0	393.9800000000002	1387	\N	0
1731832384	0	Sky	0	43	0	0	247.61	63	\N	0
6495618510	0	Hanna	0	289	0	0	0	13	\N	0
6221371920	0	Roge.	0	72	0	0	0	42	\N	0
6017651451	0	srintil	1	804	0	0	13.43999999999997	574	\N	0
6278045181	0	Val	0	1	0	0	0	0	\N	0
5097106111	0	. .	0	30	0	0	50	17	\N	0
5106594623	0	me & me	0	4	0	0	0	0	\N	0
1851884453	0	R I	0	1	0	0	0	0	\N	0
5350673974	0	Jasver. rest	0	9	0	0	0	541	\N	0
5334659154	0	awaa.	0	24	0	0	141	216	\N	0
1733132105	0	. èlen	0	1	0	0	0	1	\N	0
1865079649	0	Arkastra	0	1	0	0	0	3	\N	0
1943835542	0	amira	0	78	0	0	0	1	\N	0
5098912297	0	celine artinez	0	10	0	0	0	8	\N	0
5179080821	0	lyn	0	9	0	0	0	0	\N	0
1831032939	0	aa	0	3	0	0	0	0	\N	0
1682868904	0	yiyiii	11	470	0	0	79.92999999998574	428	\N	1
1267863737	0	alyaa	0	2	0	0	0	0	\N	0
2141237933	0	Jackson	0	1	0	0	0	0	\N	0
1772800010	0	Keyzora	0	1	0	0	0	0	\N	0
7082293839	0	karel	0	1	0	0	0	0	\N	0
5114097945	0	🐍	0	53	0	0	0	18	\N	0
1824518510	0	sakaa	0	23	0	0	0	3	\N	0
5914818979	0	bumi	0	1	0	0	0	1	\N	0
1864728970	0	i'm girl	0	9	0	0	0	1	\N	0
1936250379	0	nan	0	1	0	0	0	38	\N	0
5849442550	0	kabeurpw 🇱🇧	0	9	0	0	0	0	\N	0
6687581990	0	fr	0	9	0	0	0	40	\N	0
1337415034	0	a	0	2	0	0	0	2	\N	0
6554663417	0	み Regina d’coste	0	7	0	0	0	1	\N	0
5204662696	0	J.	0	1	0	0	0	0	\N	0
881387046	0	ca	9	491	0	0	7015.310000000003	2883	\N	1
2119127721	0	Riss	0	9	0	0	0	175	\N	0
6200671844	0	celeste	0	1	0	0	0	0	\N	0
2025321317	0	apip	0	23	0	0	0	0	\N	0
1723854810	0	❍⃝⃘۪۪۪‌𝐁𝐁❭ 𓆂 [ ❄️💎🏀🍀🐬 ] harvéy `⁹⁶¹ 🌸⃤ ⊱🍒⊰ ༊	0	9	0	0	0	0	\N	0
5447407532	0	Whodat	0	2	0	0	0	0	\N	0
6174571172	0	˖ ݁ 𓍼 ݁ ˖ pay %?!	0	4	0	0	0	0	\N	0
5801020191	0	Wil.	0	3	0	0	0	0	\N	0
6241200646	0	bel	0	83	0	0	2	12	\N	0
1419888530	0	lordan	0	28	0	0	115.97	110	\N	0
6836802559	1	mr	0	3	0	0	0	0	\N	0
5683818288	0	ice	0	1	0	0	0	0	\N	0
5207636904	0	En	0	0	0	0	0	0	\N	0
5699007628	0	— Guinniè	0	4	0	0	0	2	\N	0
2054903315	0	nay💌	0	0	0	0	0	0	\N	0
5803825612	0	sabitá.	0	2	0	0	0	2	\N	0
1679800296	0	yarh	0	1	0	0	0	0	\N	0
1746100948	0	IchikOOooo000oo	0	0	0	0	0	40	\N	0
5201707359	0	elisabeth!	0	0	0	0	0	0	\N	0
1103435869	0	sabil	0	1	0	0	0	0	\N	0
1047666571	0	t	0	80	0	0	0	15	\N	0
5716345673	0	malfoy densmark	0	68	0	0	0	37	\N	0
6830397199	0	花ａy y	0	83	0	0	2248	9	\N	0
1924379055	0	Oline 😽	5	289	0	0	1096.8800000000074	251	\N	1
6136073105	0	cupang	1	293	0	0	88.02999999999986	1346	\N	0
5265920181	0	ecaa	0	1	0	0	0	0	\N	0
2058582608	0	𝐀rya	0	49	0	0	0	53	\N	0
2032169062	0	hayden	0	98	0	0	0	0	\N	0
1388656662	0	Divano	0	1	0	0	0	0	\N	0
1932792564	0	n	0	88	0	0	496.01	26	\N	0
1774472944	0	noyyaa’s love kelv	0	2	0	0	0	1	\N	0
1675467718	0	Valerie Aislinn.	0	65	0	0	0	45	\N	0
1951649849	0	A. sevva	0	5	0	0	0	2	\N	0
1680493566	0	andsae	0	66	0	0	1943.4900000000005	2693	\N	0
1763418384	0	apta	0	11	0	0	0	2	\N	0
6263321005	0	𝐩𝐥𝐜 - Bumi	0	1	0	0	0	0	\N	0
1859627547	0	jay	0	37	0	0	162.67000000000002	184	\N	0
5283083814	0	ly	0	0	0	0	500	7	\N	0
5817388394	0	Nad	0	16	0	0	0	1	\N	0
1663162516	0	mita	0	0	0	0	0	0	\N	0
6316783801	0	Sam. slr? Sdng turu	0	3	0	0	0	0	\N	0
5884924967	0	Daraa🕊	0	36	0	0	0	29	\N	0
5898802101	0	D. desmond.	0	4	0	0	0	0	\N	0
1853474358	0	caeyall	0	17	0	0	0	6	\N	0
5700821677	0	Jaedryn 💬 [ DARE ]	0	1	0	0	0	0	\N	0
6478194767	0	a	0	0	0	0	0	0	\N	0
2098236205	0	Sera	0	49	0	0	0	12	\N	0
1616790994	0	Cilla kobam eisa	0	238	0	0	0	119	\N	0
5925191337	0	biru.	0	241	0	0	301.25	24	\N	0
1484679173	0	arl	3	561	0	0	5.740000000000009	373	\N	0
2143368978	0	jeenAn marCello	0	1	0	0	0	15	\N	0
5082094898	0	isn't replying in while, sorry	0	3553	0	0	172.73000000000047	1032	\N	0
1179752363	0	Ditaria	12	15	0	0	743.88	57	\N	0
1792771505	0	lumi	0	1	0	0	0	0	\N	0
6230889495	0	Khadafi	0	21	0	0	0	8	\N	0
1363170289	0	A	0	0	0	0	0	0	\N	0
6117217712	0	?	0	45	0	0	48	48	\N	0
1652452074	0	allurà	0	295	0	0	1612.4099999999996	1302	\N	0
5953891352	0	Khai	0	7	0	0	8.299999999999997	109	\N	0
1359693607	0	zaraa.	0	6	0	0	0	1	\N	0
6869374564	0	zdn	0	1	0	0	0	0	\N	0
1832742869	0	Anu..	0	2	0	0	0	0	\N	0
6457573550	0	Cipa	0	1	0	0	0	7	\N	0
5937193463	0	Ngell	0	3	0	0	0	2	\N	0
1893996089	0	zoe	0	1	0	0	0	0	\N	0
5878212164	0	m	0	736	0	0	3.319999999999993	206	\N	0
6868007822	0	Josh.	0	49	0	0	0	0	\N	0
6614892127	0	Hera	0	1	0	0	0	0	\N	0
6464928424	0	cw	0	5	0	0	0	12	\N	0
1929489243	0	MS291ell	0	14	0	0	0	13	\N	0
6117530718	0	L	0	36	0	0	0	58	\N	0
5303703470	0	bypa	0	5	0	0	0	162	\N	0
5164864369	0	rey.	0	884	0	0	13.599999999999909	242	\N	0
5905697768	0	sya	0	16	0	0	0	159	\N	0
1150259728	0	nab	0	3	0	0	0	4	\N	0
2008949991	0	adams	0	33	0	0	0	0	\N	0
6879624930	0	je!!	0	5	0	0	0	3	\N	0
5927624901	0	Ceya sayang Bunda Jadira sebesar semestaa.	0	7	0	0	0	2	\N	0
6647361317	0	yayaa	0	37	0	0	0	17	\N	0
1882366736	0	🍔	0	211	0	0	0	30	\N	0
1482267142	0	Maureen	0	1	0	0	0	21	\N	0
6027194162	0	arel, baca bio!	0	68	0	0	70	12	\N	0
6049944879	0	noah bs, dni	0	1	0	0	0	0	\N	0
1688284379	0	woofie feeling blue	0	383	0	0	85.57999999999998	3966	\N	0
6360912628	0	gadis	0	30	0	0	0	0	\N	0
5942451565	0	ArjuN	0	1	0	0	0	0	\N	0
6927562933	1	Lucitik	0	117	0	0	137	222	\N	0
7041306572	0	Jeremy L	0	5	0	0	0	2	\N	0
1664552284	0	L.	2	1143	0	0	673.7099999999991	271	\N	0
5011263174	0	Rabelle’s.	0	2	0	0	0	0	\N	0
1831845852	0	Jethro G.	0	11	0	0	0	0	\N	0
5524124851	0	caca	14	17	0	0	0	238	\N	0
1498681044	0	k.	0	438	0	0	2.430000000000007	565	\N	0
1953640814	0	who	0	29	0	0	0	0	\N	0
1626346042	0	haura	0	58	0	0	0	1	\N	0
5372695078	0	Nigel	0	35	0	0	48.52999999999997	11	\N	0
5007677314	0	carly bacanya karli bukan carli	0	18	0	0	0	32	\N	0
5303715707	0	None	0	43	0	0	0	8	\N	0
1193798947	0	😈	0	1	0	0	0	3	\N	0
5288767290	0	Senna	0	4	0	0	0	29	\N	0
1886177756	0	🚙	0	9	0	0	0	0	\N	0
2057183937	0	flora mau mixue date	0	0	0	0	0	0	\N	0
1493614096	0	FAAAYYY	0	13	0	0	0	2	\N	0
6047463800	0	Xray	0	12	0	0	0	15	\N	0
6311055353	0	hi	0	1	0	0	0	0	\N	0
6944200675	0	cy urbb	0	6	0	0	0	88	\N	0
1624664977	0	Cefa	0	1	0	0	0	0	\N	0
958831530	0	Ryu	0	1	0	0	0	2	\N	0
5663714680	0	rakha	0	0	0	0	0	0	\N	0
6928719028	0	acal	0	11	0	0	0	1	\N	0
6201109103	0	K.ᴴᴸ	0	34	0	0	6.769999999999996	629	\N	0
5909648639	0	Theo	2	121	0	0	457.60999999999996	50	\N	0
6010690157	0	rajesh.rest	0	16	0	0	53.5	2	\N	0
6392528264	0	citraaa	0	16	0	0	0	9	\N	0
5322674581	0	kloper	0	1	0	0	0	1	\N	0
1751692555	0	salsa	0	130	0	0	0	2	\N	0
5282014688	0	alee	0	362	0	0	2266.2400000000002	3795	\N	0
5483701102	0	Bening	0	3	0	0	0	7	\N	0
2073215157	0	rayeen :p	0	27	0	0	111.94	194	\N	0
5929988946	0	𖥻 — Jasmine	0	207	0	0	171.3900000000001	181	\N	0
7183314298	0	exaaa	0	1	0	0	0	0	\N	0
1857631987	0	ren	0	25	0	0	0	3	\N	0
1588062571	0	Arlan, 3 own	0	25	0	0	0	15	\N	0
6680971056	0	ci	0	177	0	0	16.74000000000001	8	\N	0
5522234326	0	Ev by.U	0	77	0	0	13.829999999999998	1590	\N	0
5270136054	0	lizaa cakep	0	12	0	0	0	1	\N	0
5948064384	0	Patricia	0	3	0	0	0	0	\N	0
5168657572	0	c	0	15	0	0	0	2	\N	0
1451359987	0	el	0	6	0	0	0	7	\N	0
5978151003	0	josh	4	107	0	0	1827.0199999999998	249	\N	0
6800394088	0	Kataneiko	0	2	0	0	0	7	\N	0
1913614555	0	💸	0	167	0	0	0	72	\N	0
5662140749	0	prabu	0	37	0	0	0	143	\N	0
5965904065	0	mancaa ʚїɞ	0	55	0	0	0	122	\N	0
1097320868	0	yel	13	2	0	0	0	0	\N	0
7008439058	0	rossēyn	0	3	0	0	0	1	\N	0
5384699540	0	ra	0	10	0	0	0	16	\N	0
6224412041	0	j	0	0	0	0	0	0	\N	0
1764113008	0	.	0	9	0	0	0	0	\N	0
6467969581	0	XxBoyyy	0	9	0	0	0	16	\N	0
2025376506	0	Pravaska .𝐖	0	364	1	0	0	1	\N	0
6195999866	0	d	0	3	0	0	0	0	\N	0
5656293502	0	Anindita. #PACARPIXYTLE	0	2	0	0	0	0	\N	0
6222794852	0	k	0	14	0	0	27.240000000000002	14	\N	0
5233014067	0	r	0	18	0	0	0	0	\N	0
5885097827	0	pocky	0	11	0	0	0	2	\N	0
1611827151	0	𝓜iss. 𝓐rin	0	4	0	0	0	21	\N	0
5564438799	0	molly	0	6	0	0	32.75	3	\N	0
6562095161	0	awikawok	0	3	0	0	0	0	\N	0
1835117822	0	Abay	0	8	0	0	1000	86	\N	0
1772837294	0	klarin	0	3	0	0	0	0	\N	0
5027443320	0	leo	0	31	0	0	0	27	\N	0
1012066814	0	𝓐	0	35	0	0	0	5	\N	0
1750801099	0	r	0	46	0	0	0	15	\N	0
6648965170	0	theressa ౨ৎ	0	18	0	0	0	7	\N	0
5240422097	0	sastra	0	202	0	0	0	0	\N	0
1181792469	0	e 🐝	0	518	0	0	5.5900000000009555	1336	\N	0
599465124	0	Yummy	0	27	0	0	134.02	166	\N	0
5150114852	0	cikka	0	24	0	0	0	11	\N	0
1386703511	0	ciiw	0	0	0	0	0	0	\N	0
2080333288	0	ellyna.	0	188	0	0	7.8399999999998045	665	\N	0
5429361550	3	bellaa ᡣ𐭩ྀིྀིྀི	0	90	0	0	0	129	\N	0
6257107880	0	Kobo Kanaeru	0	1	0	0	0	0	\N	0
6532138633	1	Cleo.	0	55	0	0	480.75	26	\N	0
1486953683	1	casèy	0	576	0	1	233.1900000000005	79	\N	0
5857877752	0	Rowen	0	186	0	0	3.25	1059	\N	0
5329895087	0	en 🧜🏼‍♀️🧜🏼‍♀️🧜🏼‍♀️🧜🏼‍♀️	4	665	1	0	3525.360000000007	11619	\N	0
5261351289	0	didis	0	1	0	0	0	0	\N	0
5636461266	0	ian jr	0	337	0	0	1179.6599999999996	14709	\N	0
6141606626	0	Dae.	0	2	0	0	0	1	\N	0
5974091901	0	ejaa	0	2	0	0	0	0	\N	0
5747780256	0	Valkyrie Fólksvangr	0	1	0	0	0	1	\N	0
1492114435	0	Lana	2	34	0	0	1839.63	780	\N	0
1911431558	0	casey elmer	7	2109	0	0	3.0299999999968463	12321	\N	0
6771352557	0	miaw	0	6	0	0	148	5	\N	0
6768355835	0	as	0	2	0	0	0	1	\N	0
1637539643	0	Aezar	0	1	0	0	0	1	\N	0
5210297150	0	MDNI. Keegan	11	279	0	0	2258.010000000001	568	\N	1
5265180832	0	allan	0	0	0	0	0	0	\N	0
5853708980	0	Chong 福.	0	24	0	0	1507.9499999999998	9	\N	0
1876975822	0	sabina	0	0	0	0	0	0	\N	0
1057914865	0	<Qinny3	0	32	0	0	107.07000000000001	236	\N	0
1265634642	0	[ready 1 noktel IND 2K]	0	11	0	0	0	14	\N	0
1852687563	0	juan	0	3	0	0	0	0	\N	0
6704351848	0	typsr	0	4	0	0	0	0	\N	0
6020240771	0	Elaine	0	48	0	0	0	24	\N	0
2057643997	0	sandra	0	2	0	0	0	3	\N	0
6190461379	0	amryy	0	13	0	0	15.96	0	\N	0
6661318441	0	_	0	31	0	0	0	1	\N	0
1793083092	0	isaac Lunaorie	0	4	0	0	0	1	\N	0
5441277846	0	miraaa	0	236	0	0	0	21	\N	0
6630021420	0	pica	0	7	0	0	0	5	\N	0
6007613952	0	ABEY CEBEW	0	3	0	0	0	5	\N	0
6746273529	0	🩹 ( ) ”♡..” prᧉtty: nayesha ꯭ ֺ ⊹	0	2	0	0	0	1	\N	0
5039860060	0	anye	0	11	0	0	0	0	\N	0
5929206943	0	venecia	0	0	0	0	0	1	\N	0
840674438	0	jovarkas	0	3	0	0	0	0	\N	0
7045781307	0	gibran	0	36	0	0	0	0	\N	0
2108679570	0	kiaa	0	5	0	0	0	8	\N	0
6870934650	0	q	0	77	0	0	13	315	\N	0
6211297451	0	lil bby 𓂆	0	428	0	0	32.70000000000016	4484	\N	0
5331391452	0	K$	0	47	0	0	0	137	\N	0
5007354202	0	littlepeltod	0	20	0	0	491.88	677	\N	0
1625081212	0	.	0	471	0	0	6.260000000000105	135	\N	0
6043457173	0	N	0	41	0	0	21	3	\N	0
6270779588	0	Fabian	0	4	0	0	0	1	\N	0
1640539147	0	.	0	1	0	0	1656.47	1	\N	0
5775899715	0	Klra	0	2	0	0	0	0	\N	0
5650361339	0	ella	0	3	0	0	0	0	\N	0
5479865224	0	geez	0	6	0	0	23.53	114	\N	0
2061463926	0	Ecaa dssyara ᝰ໋݊	0	2	0	0	0	12	\N	0
5950914995	0	chae	0	160	0	0	195.53999999999996	569	\N	0
5541712671	0	Satoru✿࿐	0	1	0	0	0	0	\N	0
5866144754	0	M	0	5	0	0	0	0	\N	0
6273729097	0	sera mort	0	15	0	0	0	4	\N	0
1930037630	0	k/ia shea	0	0	0	0	0	0	\N	0
6539614821	0	𝙹𝙴𝚇𝚂𝙰	0	12	0	0	0	7	\N	0
5131586113	0	A	0	17	0	0	0	0	\N	0
1098123263	0	Ical	0	0	0	0	0	0	\N	0
5364486773	0	a	0	310	0	0	7.75	493	\N	0
5212252179	0	ci	0	12	0	0	0	1	\N	0
1831594158	0	ㅡ zella zyr	1	85	0	0	574.4800000000001	336	\N	0
1955980225	0	kayrin	11	306	0	0	353	54	\N	0
892777868	0	Richiee Buttler	0	5	0	0	0	6	\N	0
5023761316	0	💎 Bad version	0	148	0	0	7.75	12	\N	0
6041532533	0	𐙚 ׁ˖ hanni	0	18	0	0	0	100	\N	0
5600067949	0	𝐋aura over the moon	0	1	0	0	0	2	\N	0
5177911939	0	z	0	1	0	0	0	2	\N	0
5859599554	0	heksa	0	1	0	0	0	34	\N	0
5373826399	0	ㅤ	0	1	0	0	0	0	\N	0
1635777100	0	gojo's gf	0	8	0	0	0	19	\N	0
6278704320	0	abel XL	0	9	0	0	0	1	\N	0
6469525102	0	Lin	0	4	0	0	0	10	\N	0
1342168772	0	tavisha	4	223	0	0	4820.400000000001	1800	\N	0
6291969649	0	yazmin	0	5	0	0	0	17	\N	0
1879380275	0	mikaa's	0	20	0	0	0	23	\N	0
5632048830	0	neigh	0	20	0	0	0	1	\N	0
1041563984	0	mici	0	6	0	0	0	16	\N	0
6585913540	0	josan navarez	0	1	0	0	0	2	\N	0
2035902263	0	caitlin v.	0	1	0	0	0	0	\N	0
2087305512	0	raxs	0	22	0	0	0	0	\N	0
6495823275	0	𝐓𝐑≛𝐏𝐒 ` 𝕯𝖊𝖘𝖎	0	58	0	0	0	23	\N	0
7007755160	0	kelvin	0	2	0	0	0	0	\N	0
5892155099	0	io	0	27	0	0	0	1	\N	0
6779433805	3	Lazz	0	10	0	0	0	4	\N	0
1733159709	0	caramel	0	207	0	0	5.23	41	\N	0
1825482156	1	ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤbee	6	885	0	0	116.91000000000008	1592	\N	0
6910144843	0	️️️️ㅤ	0	0	0	0	83.54	133	\N	0
5589628560	0	nidin	1	565	0	0	3894.9799999999996	4059	\N	1
1612159284	0	Caca	0	222	0	0	0	1040	\N	0
5638790632	0	vay	0	56	0	0	10.8	32	\N	0
1215911998	0	puput	7	755	0	0	3.4000000000005812	1154	\N	0
1608088079	0	yow	0	4	0	0	0	0	\N	0
6569804638	0	yaya	0	55	0	0	0	1	\N	0
5326180356	0	Grimjow	0	0	0	0	0	9	\N	0
1553566848	0	ini bina🎀	0	39	0	0	151.97	0	\N	0
5498322014	0	Lagi jalanin dare	0	25	0	0	0	1	\N	0
5653627831	0	Hermione.	3	143	0	0	1520.809999999999	2430	\N	0
1306911002	0	ve	0	4	0	0	0	10	\N	0
5914738317	0	Grey Loumer	0	19	0	0	0	0	\N	0
6317251760	0	Akane Kinoshita 💤	0	1	0	0	0	0	\N	0
1863733733	0	beysa	0	3	0	0	0	0	\N	0
1892313032	0	lie	13	1490	0	0	7.280000000001436	1901	\N	1
6150743716	0	Ai	0	5	0	0	0	3	\N	0
1759478710	0	amee	0	1	0	0	0	0	\N	0
1953982432	0	Zein.	0	1	0	0	0	0	\N	0
6184246973	0	Ajeng	0	15	0	0	0	9	\N	0
1937061788	0	jovi slowresp	0	2	0	0	1500	19	\N	0
5956634226	0	Cathreen Shacilé.	0	1	0	0	0	16	\N	0
1620170102	0	onic jesas	6	10	0	0	93.13000000000001	806	\N	0
6235129543	0	V	0	0	0	0	0	3	\N	0
5105171875	0	Rouphatle Evtarient	0	37	0	0	10.9	17	\N	0
5869901972	0	ayin introvert	11	302	0	0	16496.170000000013	202	\N	1
6331169280	0	aan	0	51	0	0	0	54	\N	0
5016830868	0	diora, inactive	0	18	0	0	0	1	\N	0
1895285436	0	Jisea	0	6	0	0	0	1	\N	0
5659705159	0	nolly	0	117	0	0	366.5	243	\N	0
6616566306	0	нєямισηє	0	63	0	0	2.9800000000002456	249	\N	0
6704200193	0	sibuk fak!	0	32	0	0	0	0	\N	0
1427044446	0	jung	0	82	0	0	0	91	\N	0
5852997689	0	apiwa	0	157	0	0	0	801	\N	0
5686172592	0	becky	0	3	0	0	0	2	\N	0
5879139544	0	.	0	0	0	0	0	0	\N	0
1350618595	0	l	0	30	0	0	0	6	\N	0
5252353756	0	nita 🪻	0	65	0	0	137.38	4	\N	0
5930837822	0	Rai	0	36	0	0	0	6	\N	0
510050918	0	⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣⁣ㅤ	0	299	0	0	0	29	\N	0
6135039016	0	Lili Junovva	0	3	0	0	0	0	\N	0
6268161697	0	🎀💐	0	6	0	0	0	0	\N	0
6536189788	0	va	0	2	0	0	0	0	\N	0
1851261274	0	ssss	0	33	0	0	0	41	\N	0
6767195301	0	jennayy	0	4	0	0	0	1	\N	0
6539054099	0	natalia	0	1	0	0	0	4	\N	0
1751563691	0	ney	0	26	0	0	0	2	\N	0
1020853674	0	Noah	0	6	0	0	0	0	\N	0
6396450576	0	ikaa	0	14	0	0	0	36	\N	0
5367337311	0	lecyy	0	18	0	0	0	124	\N	0
6835106993	0	bzztt	0	13	0	0	0	10	\N	0
6056426785	0	bieyla	0	2	0	0	0	56	\N	0
6717190494	0	olavv	0	27	0	0	0	35	\N	0
2094036939	0	Jk	0	175	0	0	128.18	1142	\N	0
6878407047	0	nelaa	0	1	0	0	0	24	\N	0
1966198690	0	el	0	8	0	0	0	19	\N	0
5110650178	0	lala?!?!!?	0	9	0	0	0	1	\N	0
7090584168	0	a	0	3	0	0	0	0	\N	0
7089032797	0	shiel.	0	3	0	0	0	0	\N	0
5423235849	0	Jornex, B.	14	1	0	0	119.11999999999608	703	\N	1
1764441026	0	Eres	0	81	0	0	0	6	\N	0
6954242855	0	shine	0	9	0	0	0	9	\N	0
5709107957	0	jemi	0	4	0	0	0	0	\N	0
5848006123	0	kaela	5	2256	0	0	298.1699999999971	12313	\N	0
6711473907	0	thea	0	10	0	0	0	1	\N	0
5644902677	0	Aji.	9	311	0	0	12.57	228	\N	0
6950007951	0	swagbae4lll	0	111	0	0	298.08000000000004	73	\N	0
6395543555	0	Naana	0	1	0	0	0	2875	\N	0
1895072832	0	basudara ◐	5	64	0	0	12965.480000000001	10497	\N	1
2067866782	0	jule$ mÈOw	9	277	0	0	6870.680000000001	30479	\N	0
6488668269	0	ian	0	1	0	0	0	0	\N	0
5483231870	0	♤Cïçäķ♤Ťëŕbäńģ♤	0	4	1	0	0	5	\N	0
5208572470	0	talaala	0	0	0	0	0	20	\N	0
855405415	0	leyya	0	4	0	0	0	41	\N	0
6039054011	0	Mabok	0	6	0	0	0	10	\N	0
6253405947	0	.	0	32	0	0	4700.49	139	\N	0
6360947215	0	dinaa	0	5	0	0	0	4	\N	0
6669417860	0	N	0	8	0	0	0	2	\N	0
1946018043	0	zzeva	0	71	0	0	0	250	\N	0
2078798412	0	㊝рифки-ᴇx	0	5	0	0	0	39	\N	0
5345343718	0	sileyá	0	15	0	0	0	30	\N	0
1897176052	0	wawa off utbk	0	28	0	0	0	1110	\N	0
6084907759	0	désty	1	127	0	0	866.4400000000002	337	\N	0
1297306111	0	ttotou	0	4	0	0	0	0	\N	0
1972957339	0	dnfi.	0	2	0	0	0	2	\N	0
5253362008	0	s	0	344	0	0	0	417	\N	0
1826884126	0	fathiyaaa	0	4	0	0	0	0	\N	0
1495655649	0	jeandraa abian	0	1	0	0	0	2	\N	0
1613789791	0	idylla Maudyne	0	170	0	0	18.689999999999998	1413	\N	0
6782580444	0	calliee	0	1	0	0	0	0	\N	0
6926634252	0	aca	0	10	0	0	0	30	\N	0
1945739032	0	أزرا	0	5	0	0	0	1	\N	0
1437122109	0	yelena	0	15	0	0	3	10	\N	0
5349136604	0	alisa	0	15	0	0	8.79	19	\N	0
5535612723	0	Bang pret	0	112	0	0	0	69	\N	0
5439025427	0	CIA	0	1	0	0	0	0	\N	0
1517656343	0	H. Scherie	0	1	0	0	0	0	\N	0
5717802172	0	jake rbio sebelum ke rc	0	1	0	0	0	4	\N	0
6283419329	0	miwa	0	12	0	0	0	113	\N	0
6978710542	0	ācal	0	6	0	0	0	4	\N	0
278157335	0	sandi	0	3	0	0	0	143	\N	0
6693297753	0	V A R O N	0	2	0	0	0	5	\N	0
5000857549	0	𝐒abina 🧔🏻‍♀️	0	10	0	0	0	14	\N	0
6621853762	0	Arr. Prisha	0	8	0	0	0	19	\N	0
6936858241	0	L	0	37	0	0	0	139	\N	0
6001353289	0	Bianca Maurie.	0	177	0	0	0	124	\N	0
6247819999	0	lla𐙚	0	512	0	0	1301.5600000000004	1461	\N	0
1774350563	0	cy lop kai(serr)	1	1670	0	0	69.90999999999912	4762	\N	0
1639857769	0	r	0	24	0	0	0	13	\N	0
7159711968	0	d	0	270	0	0	-11.409999999999968	2	\N	0
1921575062	0	el suka gurita udah gede🐙	0	9	0	0	0	1099	\N	0
1371511375	0	J viet	0	445	0	0	1041.62	1259	\N	0
2115112709	0	neraa	0	53	0	0	17.439999999999998	660	\N	0
6452683428	0	yēu𝔄𝔠𝔱𝔦𝔳𝔢	0	13	0	0	0	8	\N	0
1716462109	0	Kairin	0	40	0	0	0	1	\N	0
6174670435	0	chalya	0	285	0	0	13.480000000000018	85	\N	0
5829578005	0	issa	10	126	0	0	3.7100000000000364	47	\N	0
1328029010	0	gio	0	68	0	0	0	14	\N	0
5322320664	0	ᶻ 𝗓 𐰁	0	12	0	0	0	5	\N	0
5754872804	0	Kim May	0	1	0	0	0	1	\N	0
1797461663	0	victoryking¹	0	17	0	0	0	12	\N	0
6480849576	0	vyora :p	0	18	0	0	0	1	\N	0
2120035853	0	Rahayu	0	409	0	0	14.85	3508	\N	0
1972532919	0	fariz	0	181	0	0	1.5	292	\N	0
1678162083	0	heeseung's lovertaker	0	6	0	0	0	7	\N	0
6920150580	0	Bombomloni	0	6	0	0	0	4	\N	0
6064613435	0	Rosie	0	8	0	0	0	0	\N	0
6375764320	0	aizenn lagi main poker	0	2	0	0	0	0	\N	0
7146438219	0	.	0	11	0	0	0	0	\N	0
6290540301	0	R	0	6	0	0	0	15	\N	0
5800072956	0	Sepharile	0	131	0	0	44.01000000000014	65	\N	0
6651194563	0	sey	0	4	0	0	0	10	\N	0
6061747011	0	R.A. Lovelia	0	1	0	0	0	0	\N	0
5258608681	0	Miciya	0	2	0	0	0	278	\N	0
1380971434	0	livii	0	561	1	0	5417.15	255	\N	0
5506584752	0	wi	0	18	0	0	0	43	\N	0
6746957371	0	Miqkael J.	0	9	0	0	0	11	\N	0
1935262385	0	ardan	0	178	1	0	0	0	\N	0
5639463209	0	no name	0	3	0	0	0	17	\N	0
1942004779	0	nyaa	0	21	0	0	0	1	\N	0
6238224544	0	Ngok	0	4	0	0	0	45	\N	0
7043251619	0	ghahah	0	2	0	0	0	0	\N	0
1215780399	0	Ciaa	0	4	0	0	0	1	\N	0
1615553602	0	.	0	31	0	0	0	9	\N	0
5477410462	0	isn’t arciw.	0	31	0	0	6101.5	613	\N	0
2119470140	0	keya	0	0	0	0	0	51	\N	0
840452492	0	Reborn 🔥	0	1	0	0	0	0	\N	0
5203717934	0	fdm². Nazeea' A.	0	1	0	0	0	0	\N	0
6912314242	0	Nay.	0	1	0	0	0	0	\N	0
6099384307	0	Flyy	0	3	0	0	0	9	\N	0
5155707690	0	Kathrina A.	0	2	0	0	0	0	\N	0
1876829556	0	Eudica	0	580	0	0	2608.590000000001	1198	\N	0
1574567845	0	Lii	0	4	0	0	0	1	\N	0
6900123353	0	E N J È L	0	25	0	0	0	46	\N	0
2020753277	0	Aemi	0	1	0	0	0	0	\N	0
1710183238	0	caca	0	77	0	0	2048.6600000000003	547	\N	0
5281279149	0	cece	0	2	0	0	0	0	\N	0
1662277817	0	miww	0	4	0	0	1353.15	2	\N	0
1949660331	0	.	0	1	0	0	0	0	\N	0
5061537765	0	rnt [ L I M I T ]	0	12	0	0	345	1	\N	0
5912272090	0	-	0	5	0	0	0	48	\N	0
1003528216	0	Metta	0	8	0	0	0	96	\N	0
5827214758	0	c	0	28	0	0	122.35	226	\N	0
5455192371	0	Aëla	0	1	0	0	0	0	\N	0
2072601478	0	bebe	14	1267	0	0	803.19	480	\N	0
5574857720	1	Intan	0	339	0	0	8.940000000000026	141	\N	0
5427050654	0	0%	0	7	0	0	0	0	\N	0
6840018363	0	lalaa	0	1	0	0	0	0	\N	0
5915551525	0	jea	0	1	0	0	0	3	\N	0
6560937779	0	iin sembiring	0	1	0	0	0	0	\N	0
1458822636	0	putry	0	3	0	0	0	4	\N	0
5397687210	0	Hunnyeee	0	200	1	0	595	12	\N	0
1992691697	0	kkdkd	0	83	0	0	2801.67	2531	\N	0
5407349353	0	ur future daddy	0	1	0	0	0	4	\N	0
5317234076	0	keisya	0	35	0	0	2285.29	139	\N	0
5605200840	0	Ma	0	1	0	0	0	1	\N	0
5858261018	0	auroraa	0	2	0	0	0	0	\N	0
1440775936	0	keo	0	20	0	0	0	15	\N	0
6727691768	0	lloerä	0	13	0	0	0	3	\N	0
6831748712	0	Raz	0	9	0	0	0	2	\N	0
1847017457	0	Jaegar	0	190	0	0	392	104	\N	0
6517786701	0	cece	0	9	0	0	6.380000000000003	254	\N	0
1315685314	0	r	0	34	0	0	9.05	8	\N	0
1709693299	0	arly	0	6	0	0	0	0	\N	0
5119491012	0	Hema	0	34	0	0	0	3	\N	0
5767026157	0	Kalaya	0	0	0	0	0	0	\N	0
1272932854	0	ayy broo	0	0	0	0	0	0	\N	0
6343773295	0	chiuaua	0	7	0	0	0	25	\N	0
5159493872	0	𝐒ora	0	2	0	0	0	2	\N	0
1615110511	0	kaeee	0	717	0	0	285.9100000000003	591	\N	0
2013243351	0	lenn	0	5	0	0	0	2	\N	0
2041546156	0	mei	0	10	0	0	0	1	\N	0
1631908686	0	Celine	14	340	0	0	0	263	\N	0
1614281806	0	Keithara D.	10	1527	0	0	1282.819999999998	1805	\N	0
1729434404	0	wiliam	0	20	0	0	795.15	35	\N	0
2056813487	0	᧔‌ ׅ 𝅄 ۫ ׅ my day — 𝓡𝓪𝓪 ˖ ֹ ୧ ☁️ ࣪ ׅ ˖	0	106	0	0	0	60	\N	0
2106159953	0	bil 𖤍⚡️	0	316	0	0	3	1261	\N	0
1435334450	0	kei	0	440	0	0	0	73	\N	0
5726606292	0	rea	0	3	0	0	0	8	\N	0
6320051900	0	kayla	4	29	0	0	1963.6000000000001	66	\N	0
7023708683	0	jj	0	4	0	0	0	0	\N	0
6371163223	0	issa	0	131	0	0	1192.4899999999998	86	\N	0
7017414699	0	i	0	2	0	0	0	0	\N	0
6481042974	0	bilaa	0	7	0	0	0	5	\N	0
7051910287	0	anaaaaaaa	0	0	0	0	0	0	\N	0
2084752492	0	C!c'	0	5	0	0	0	0	\N	0
5948317148	0	Kaiby	10	192	0	0	533.7700000000004	4923	\N	0
6754467168	0	Husein	0	38	0	0	0	8	\N	0
1758920832	0	faa	0	2	0	0	0	3	\N	0
5549863885	0	Daryantoo	0	4	0	0	0	2	\N	0
6685616907	0	Blinks	0	54	0	0	41.30000000000001	12	\N	0
6653248343	0	Cheeyza.	0	28	0	0	0	21	\N	0
902948975	0	r.	0	28	0	0	0	22	\N	0
6099663725	0	vii	0	5	0	0	0	14	\N	0
2115033112	0	ivy	0	122	0	0	0	2	\N	0
1885326975	0	rakatajinks	0	1	0	0	0	1	\N	0
2018805447	0	지수. 💟 🩹	0	301	1	0	0	543	\N	0
6314925057	0	a	0	31	0	0	0	3	\N	0
5497420463	0	nvm	0	7	0	0	0	0	\N	0
2026572984	0	cece	0	10	0	0	0	6	\N	0
6359147456	0	ikaa	0	52	0	0	1466.96	80	\N	0
6284411032	0	Biawak.	0	121	0	0	32.900000000000006	49	\N	0
5001113267	0	isaa	0	3	0	0	0	2	\N	0
5330362631	0	adel	0	60	0	0	359.9	64	\N	0
6947673715	0	Julliet Bryalane.	0	37	0	0	0	118	\N	0
1503067248	0	Ben	12	2	0	0	240.24000000000012	16	\N	0
6017617218	0	Janu.	0	1	0	0	0	0	\N	0
6043284830	0	Pppp	0	39	0	0	0	2	\N	0
5767937016	0	Misty	0	2	0	0	0	0	\N	0
5270811312	0	瓦伦🧙‍♀️	0	2	0	0	0	3	\N	0
5253520242	0	heidyy Rehat	0	1	0	0	0	2	\N	0
6640019162	0	Karel	0	2	0	0	0	3	\N	0
1814177773	0	Fabriel.	0	3	0	0	0	0	\N	0
1601498725	0	ʏ	0	87	1	0	14.719999999999999	263	\N	0
5225023072	0	Letnan	0	2	0	0	0	0	\N	0
5262815751	0	Ntahh	0	7	0	0	0	0	\N	0
1877876166	0	shinazukawa	0	71	0	0	257.46	609	\N	0
1526841832	0	jaaa	0	20	0	0	78.07	94	\N	0
5246069982	0	:3	0	19	0	0	0	0	\N	0
1883598878	0	.	0	42	0	0	0	11	\N	0
6796644506	0	derry	0	1	0	0	0	6	\N	0
5333134613	0	Janey◞ ˚	0	53	0	0	0	32	\N	0
6839106549	0	fii	0	2	0	0	0	1	\N	0
1145680388	0	reyya	0	328	0	0	218.80999999999995	37	\N	0
6628263173	0	n	0	9	0	0	0	0	\N	0
5546871052	0	panca	0	120	0	0	600.3999999999997	19	\N	0
1411681753	0	najaem	0	7	0	0	0	6	\N	0
6194476364	0	naw	0	9	0	0	0	7	\N	0
1632846899	0	pritaaa	0	915	0	0	127.5	1079	\N	0
928942990	0	ca	0	22	0	0	0	47	\N	0
6764393918	0	isa	0	1	0	0	0	0	\N	0
2121072326	0	akal	0	9	0	0	306.77	0	\N	0
5268844966	0	rem	0	1	0	0	0	0	\N	0
5152016238	0	cè jvg 𝙾𝙱𝙻 ᴴᴸ	0	53	0	0	0	964	\N	0
2016258071	0	Maverick Lincoln	0	1	0	0	0	1	\N	0
1789110306	0	Zaaa	0	7	0	0	0	10	\N	0
6374130804	0	vi	0	1	0	0	0	0	\N	0
5746962739	0	b	0	1	0	0	0	0	\N	0
5159946580	0	zyaa	0	0	0	0	0	1	\N	0
1886378814	0	fishca	0	15	0	0	0	0	\N	0
6312179877	0	shafwan	0	48	0	0	2.9499999999999993	103	\N	0
5758596522	0	Sabitha	0	43	0	0	555.3900000000001	1080	\N	0
1830045842	0	daisyoh	2	722	0	0	3492.460000000001	2801	\N	0
6083878493	0	aca	0	30	0	0	0	123	\N	0
5903424629	0	f	0	541	0	0	0	77	\N	0
5396386429	0	Harriets Hortense	0	24	0	0	0	2	\N	0
6268070633	0	ga	0	17	0	0	1150.42	0	\N	0
1837115469	0	Jay	0	1	0	0	0	0	\N	0
6297248635	0	anna	0	0	0	0	0	5	\N	0
6122405273	0	akisha rbio	0	8	0	0	0	9	\N	0
5031530698	0	raja	9	101	0	0	0	12	\N	0
7194466590	0	capuchhinno	0	9	0	0	0	4	\N	0
1186967018	0	Alll	0	1	0	0	0	0	\N	0
1267977585	0	nini	0	85	0	0	50.26999999999998	89	\N	0
5636370393	0	ra	0	59	0	0	0	0	\N	0
1860956103	0	.	0	53	0	0	0	844	\N	0
1857013428	0	enäy 🕷️	0	382	0	0	5	2674	\N	0
1443832788	0	reta	0	2	0	0	0	1	\N	0
1620603154	0	Kirei	0	36	0	0	0	9	\N	0
5789057463	0	Himawari yuri	0	6	0	0	0	0	\N	0
6745557182	0	Fayes.	0	4	0	0	0	3	\N	0
5382396039	0	Joc.	7	289	0	0	2157.3500000000017	459	\N	0
5900308225	0	Mar.	0	184	0	0	249.16999999999996	395	\N	0
2082278058	0	tabasco	8	543	0	0	282.56999999999994	1627	\N	0
5194602386	0	Ayes	0	295	0	0	21.18	538	\N	0
6161185665	0	😲	0	5	0	0	0	15	\N	0
5026186765	0	stobelyyy 🍓	0	224	0	0	2653.7300000000005	452	\N	0
5349238670	0	Fabian.	0	8	0	0	0	49	\N	0
1418188232	0	zara the sheep	13	387	0	0	473.3599999999981	2703	\N	1
6940230019	0	Avril.	0	7	0	0	0	15	\N	0
1843458824	0	li	0	237	0	0	0	1	\N	0
5159275524	0	uwiiii	0	839	0	0	12.8	244	\N	0
5473857466	0	𝜗𝜚 .. tithaaa! ✿🩰	12	91	0	0	212.57	20	\N	0
1803234878	0	j	0	3	0	0	0	0	\N	0
6296489163	0	ashley	0	34	0	0	4.780000000000001	2	\N	0
1275141224	0	iraa💢	0	331	0	0	5539.509999999994	1005	\N	0
5792189597	0	nn	0	49	0	0	0	103	\N	0
6017839313	0	a	0	20	0	0	0	8	\N	0
1603547618	0	arbie gx mut kambink	5	54	0	0	2426.12	668	\N	0
1954357256	0	alexnaa	14	1009	0	0	2434.3900000000003	8753	\N	1
5628276854	0	kynara gamuts	0	1	0	0	0	0	\N	0
1039498495	0	sa	0	71	0	0	0	14	\N	0
1496403482	0	.	0	3	0	0	0	7	\N	0
5251856247	0	donisaurus🦖	0	8	0	0	152.49	15	\N	0
5182745412	0	🩰 ┈・୧ princess dâwai 𓈒 ᣞ@pingkyQ 𖧧 🎀	0	0	0	0	0	0	\N	0
5599836557	0	kapi	0	178	3	0	3.3099999999999987	132	\N	0
1783883888	0	misha	0	5	0	0	956	20	\N	0
6783788482	0	C	0	2	0	0	0	0	\N	0
1776221398	0	zzz	0	26	0	0	0	14	\N	0
6512652644	0	chel	0	1	0	0	0	0	\N	0
5469285520	0	nasyaaaa	0	7	0	0	0	0	\N	0
5269480107	0	leta	12	383	0	0	8260.400000000003	7310	\N	1
1394389260	0	rifaa	0	39	0	0	522.5	179	\N	0
1152105089	0	c	0	5	0	0	0	13	\N	0
5843176815	0	144p	0	1	0	0	0	0	\N	0
5549474099	0	Arsène.	0	49	0	0	0	52	\N	0
5363042106	0	oooo	0	47	0	0	0	80	\N	0
5953674648	0	artur	0	28	0	0	24.279999999999845	109	\N	0
5928586763	0	resinta	0	45	0	0	14.48	19	\N	0
5775065465	0	Akbar	0	1	0	0	0	0	\N	0
1103423583	0	Jane	0	1	0	0	0	0	\N	0
6028170956	0	Sheerana, M	0	3	0	0	0	1	\N	0
6248222704	0	n	0	4	0	0	0	0	\N	0
2076552013	0	j	5	1990	0	0	534.1099999999951	1411	\N	0
2145077009	0	ccccc	0	268	0	0	826	2332	\N	0
5745789179	0	helga	0	86	0	0	0	48	\N	0
1783301265	1	mia	3	1043	0	0	1934.500000000001	4913	\N	0
6227775632	1	moolmeiddd🧜‍♀	0	573	0	1	888.5500000000001	474	\N	0
6656714241	0	charl	0	99	0	0	25.47	322	\N	0
5161789339	0	Ayna 🇵🇸	0	0	0	0	0	418	\N	0
7159128254	0	faye	0	24	0	0	0	10	\N	0
1755438824	0	𝟭𝟲𝟱𝟱.	8	648	0	0	3676.049999999999	2159	\N	0
6254575169	0	dni.	9	1994	0	0	61.959999999998445	1323	\N	0
2003981363	0	💎❍⃝⃘۪۪۪‌𝐁𝐁❭ ⃟ 𐂂👑 gerry 🐙𓂀☤#cheseemlyɱ𝗰៵᭡ִֹ𝜋 🎸🧛🏻	0	4	0	0	96.27999999999997	0	\N	0
1643211712	0	ichaaa	0	34	0	0	860.24	499	\N	0
5379053418	0	él	0	691	0	0	0.17000000000001592	257	\N	0
2072873049	0	el	0	288	0	0	0	21	\N	0
5174283548	0	Chani	9	730	0	0	11378.12	703	\N	0
6250331034	0	divaa	0	4	0	0	0	0	\N	0
1672677143	0	rest.	0	1	0	0	0	0	\N	0
1465360124	0	vatia	0	1	0	0	0	0	\N	0
1487533126	0	Arslan	0	4	0	0	60.5	2	\N	0
6796654824	0	blush ♡	0	12	0	0	0	0	\N	0
6916952971	0	Nat nat nata	0	4	0	0	0	9	\N	0
6105876664	0	.	0	15	0	0	0	0	\N	0
5381034805	0	-ce	0	6	0	0	0	96	\N	0
2001584718	0	ciaa	0	216	0	0	13.810000000000104	502	\N	0
948769378	0	♱ John	0	12	0	0	78	98	\N	0
5015411690	0	Jian.on	0	33	0	0	17.03	42	\N	0
5543891819	0	Zaskia A.	0	1	0	0	0	1	\N	0
5197226985	0	Ealdwine #NEWCLOWN	0	22	0	0	0	33	\N	0
5979600827	0	Sabre	0	3	0	0	0	0	\N	0
1784601400	0	Marilyn	12	16	0	0	1565.0099999999998	3656	\N	1
6449618882	0	Cya	0	256	0	0	0	122	\N	0
6239354512	0	zean	0	22	0	0	6.629999999999999	3	\N	0
6122980989	0	naomi	0	2	0	0	0	0	\N	0
6043073411	0	Ai	0	15	0	0	0	3	\N	0
5208144153	0	chloe.	0	138	0	0	2.270000000000003	40	\N	0
5396939454	0	jaa.	0	3	0	0	0	31	\N	0
5276939843	0	Jor	0	5	0	0	0	0	\N	0
1980179244	0	karlesha, sabar muter.	0	1	0	0	0	0	\N	0
6320269995	0	𝖆	0	30	0	0	0	9	\N	0
2086902294	0	evelynn	0	74	0	0	0	17	\N	0
6202188102	0	aya	0	1	0	0	0	0	\N	0
6145113322	0	Erinaa²⁴	0	5	0	0	0	5	\N	0
1956013073	0	Joz.	0	1	0	0	0	0	\N	0
5416987897	0	resha ōtsukioni	4	2364	0	0	852.5500000000002	4167	\N	0
6495744621	0	met	0	3	0	0	0	68	\N	0
6934291873	0	shava^^	0	33	0	0	0	198	\N	0
6102201269	0	Arkaa	0	168	0	0	0	35	\N	0
6016429304	0	Hazel.	0	1	0	0	0	34	\N	0
1704392916	0	syilaa	10	862	0	0	3487.0599999999945	1205	\N	0
1755446888	0	Keitha E ֹ💭 ִ ۟ ˖	10	1831	0	0	1944.880000000001	4577	\N	0
5228810137	0	🪷	0	2298	0	0	9.600000000000122	31	\N	0
1888321141	0	M	4	174	0	0	24.839999999999918	154	\N	0
5650388454	0	Eubrielle 𐀗𐦍 EĐM3	0	59	0	0	59.92999999999999	12	\N	0
5751903313	0	jason	0	10	0	0	0	13	\N	0
6875973965	0	she	0	27	0	0	2.219999999999999	57	\N	0
1831370475	0	𝒅𝒑𝒓.	0	4	0	0	0	0	\N	0
5957582047	0	penyuu	0	154	0	0	54.01999999999981	155	\N	0
6549472426	0	Adel	0	3	0	0	0	0	\N	0
6785714892	0	dica	0	1	0	0	0	0	\N	0
1743455159	0	zar	0	545	0	0	27.14	42	\N	0
1388187459	0	rel	0	7	0	0	0	18	\N	0
5382599787	0	Naskastra	0	0	0	0	0	6	\N	0
1999775067	0	Harith	0	10	0	0	0	119	\N	0
5934085632	0	serina	0	16	0	0	71.86	4	\N	0
5303516142	0	Ayin	0	4	0	0	0	1	\N	0
1928862184	0	Jeo jeonna	0	27	0	0	0	0	\N	0
6798657898	0	aliseee	0	1	0	0	0	0	\N	0
6434984651	0	Ikay	0	11	0	0	813.87	16	\N	0
5528193657	0	eca	0	43	0	0	0	29	\N	0
5125598087	0	tebe 9tz	0	1	0	0	0	1	\N	0
5143983839	0	keli	14	864	0	0	0.3100000000000023	3009	\N	0
5789262089	0	𖡻 ๋࣭ 🎀 wawa ׅ ๋ ᯓ	0	59	0	0	472.11	593	\N	0
5757358438	0	Mugi	0	0	0	0	0	10	\N	0
2006936968	0	pica	0	18	0	0	80	101	\N	0
5589417030	0	hykmi	0	19	0	0	0	8	\N	0
5449784402	0	Key	0	3	0	0	0	8	\N	0
1995776521	0	tara	0	15	0	0	36.440000000000225	3	\N	0
1857688681	0	kanesh	0	40	0	0	0	7	\N	0
5439786104	0	zii	0	59	0	0	934	6	\N	0
1547111731	0	s¢n. Aurel	0	1	0	0	0	27	\N	0
1549476686	1	aira	12	3630	1	0	8.929999999994692	12589	\N	1
5276828440	2	jee.	9	691	0	0	96.44000000000037	945	\N	0
1394268361	0	hz	0	24	0	0	0	48	\N	0
1077516849	1	gia	14	1119	0	0	4082.7	505	\N	0
5962529220	2	jihan`✧	0	70	0	0	56.60000000000001	1064	\N	0
1626511514	0	semi 🐦🐦🐦🐦🐦🐦🐦	0	18	0	0	0	7	\N	0
6700056239	0	fiber	0	12	0	0	0	10	\N	0
1851129565	0	Marez.	0	1	0	0	55.49	2	\N	0
6830441336	0	K.	0	8	0	0	0	1	\N	0
6496364693	0	Neither Do I, Jude.	8	118	0	0	301.78999999999985	4660	\N	0
5181424222	0	.leaa	0	34	0	0	0	70	\N	0
1486100339	0	cipa	9	1505	0	0	7.070000000000334	2764	\N	0
1662601765	0	_	1	214	0	0	535.4400000000012	91	\N	0
6597289102	0	merrie	0	5	0	0	0	77	\N	0
2032790551	0	cybie	0	74	0	0	921	41	\N	0
5264709657	0	hanna	0	100	0	0	0	38	\N	0
5945998318	0	i love you	0	3	0	0	75.63	171	\N	0
1020299798	0	𝓐𝔂𝓪𝓷𝓰🦋	0	18	0	0	0	6	\N	0
5578911279	0	‌‌‌‌‌‌‌‌‌‎A	0	408	0	0	20.150000000000077	680	\N	0
6240398616	0	— sandrià	0	3	0	0	0	11	\N	0
1683186399	0	not responding	0	42	0	0	894.9700000000001	1066	\N	0
6023130419	0	sha cantik sekali💋	0	28	0	0	0	52	\N	0
5559106792	0	Figo	0	3	0	0	0	89	\N	0
1605058421	0	caysii.	0	13	0	0	0	72	\N	0
5629663229	0	️ḟ̴̧̧̗͍͉͔̹͎̻͓̇͊̃̒̄̈̓̉̌̈͝͝rapael🇨🇰	0	0	0	0	0	4	\N	0
1936983955	0	neycea	0	255	0	0	726.9100000000001	390	\N	0
5306785607	0	Na	0	13	0	0	0	24	\N	0
6063061142	0	𝐀yaa ⪨ʀʀᴡ⪩	0	3	0	0	0	1	\N	0
5321900738	0	3	0	13	0	0	0	0	\N	0
1429340308	0	.	0	796	0	0	1656.88	1067	\N	0
1498166895	0	lunè ੭୧	0	406	0	0	472.22	3	\N	0
5881182592	0	ayyaiyaiya	0	38	0	0	0	93	\N	0
1558707362	0	CARAMEL.	0	2	0	0	0	0	\N	0
1824906925	0	kanaaponi	0	4	0	0	0	0	\N	0
5357074977	0	ㅤoliv	0	42	0	0	0	7	\N	0
5217648559	0	Bima+	0	2	0	0	0	9	\N	0
6881172092	0	.	0	2	0	0	0	0	\N	0
5539266762	0	RC.	0	1	0	0	0	0	\N	0
5914002543	0	Nabiru L.	0	2	0	0	0	0	\N	0
1728514826	0	Mavis	0	3	0	0	0	0	\N	0
6780492235	0	+	0	54	0	0	2434	12	\N	0
6785083175	0	Xellyn🕸	0	2	0	0	0	0	\N	0
5632926798	0	Jodie imut	0	13	0	0	0	6	\N	0
6705194001	0	VinA 'Slr	0	1	0	0	0	0	\N	0
2047408576	0	bian	0	5	0	0	0	0	\N	0
6668914184	0	zara	0	5	0	0	0	0	\N	0
6444766253	0	USTAZAH ACA	0	1	0	0	0	7	\N	0
2102396984	0	CH	0	15	0	0	0	1	\N	0
6520882918	0	,	0	98	0	0	1	43	\N	0
1643013044	0	ㅤㅤㅤㅤㅤㅤㅤㅤ	0	25	0	0	0	12	\N	0
1647630361	0	Fexron,	0	92	0	0	216.46	536	\N	0
5985455535	0	kyo cinta biel	0	498	0	0	0.7400000000005207	410	\N	0
5199724034	0	t	0	21	0	0	0	2	\N	0
5139952160	0	haidar	0	4	0	0	0	0	\N	0
5834898558	0	Milee	10	248	0	0	1316.8099999999995	301	\N	0
7175599750	0	el	0	8	0	0	0	0	\N	0
5053956447	0	fadhil	0	7	0	0	0	3	\N	0
6262220415	0	Jw's	0	0	0	0	0	0	\N	0
5743751841	0	ーBee.	0	5	0	0	0	4	\N	0
5241457130	0	𝓐nggara	0	20	0	0	68	0	\N	0
5701895272	0	Marvel	0	1	0	0	0	0	\N	0
6004182688	0	ㅤㅤㅤㅤc	0	1	0	0	0	15	\N	0
6187830307	0	Inactive.	0	3	0	0	0	0	\N	0
6774070984	0	𐙚! . ࣪ 𝐋ᧉtɥcꪱα [𝐀𝐊𝐀 𝐌ᨣɾᧉᧉn] . ࣪ ୧ ōtsukiryu	0	9	0	0	0	47	\N	0
5615585234	0	San Dawn.	0	5	0	0	16.6	16	\N	0
1955439818	0	ramuhay	0	411	0	0	0	198	\N	0
1493989521	0	gosa	0	3	0	0	0	1	\N	0
2082640923	0	Hakim	8	415	0	0	30224.11	6111	\N	1
5763149709	0	AD	0	1	0	0	131.86	1	\N	0
5216897350	0	🧸	0	2	0	0	0	0	\N	0
1764728603	0	🥨	0	69	0	0	0	145	\N	0
5731382631	0	menggg	13	487	0	0	5145.88	1318	\N	1
1932065687	0	moonelle	2	1235	0	0	3252.4799999999973	7290	\N	0
5359625133	0	illa . . =]	0	80	0	0	23.46	19	\N	0
1451550134	0	Hisyam, busy	0	1	0	0	0	0	\N	0
6748418629	0	kay	0	8	0	0	0	12	\N	0
6488948213	0	j	0	2	0	0	0	0	\N	0
1366899769	0	• 𝐍𝐢𝐱𝐢𝐞	0	1	0	0	0	3	\N	0
6104349494	0	morphine	0	17	0	0	0	25	\N	0
6892740021	0	Kaedeharu	0	25	0	0	4.650000000000006	876	\N	0
6880140965	0	Al	0	0	0	0	0	2	\N	0
5858630759	0	Idk	3	75	0	0	450.45000000000005	1960	\N	0
5072403847	1	K, Ayumi.	0	18	0	0	753.1600000000001	93	\N	0
5055878490	0	putt	0	56	0	0	12.010000000000005	82	\N	0
5874867112	0	Aloy	0	1	0	0	0	1	\N	0
1243265180	0	Rafi	0	1	0	0	0	1	\N	0
6593688664	0	christian	0	13	0	0	0	41	\N	0
5533162149	0	🦇jekas	0	6	0	0	106.1	212	\N	0
6185450581	0	DNI, naje	0	103	0	0	10.509999999999998	56	\N	0
2049928246	0	happycaaa	0	2	0	0	0	12	\N	0
6639089478	0	kela	9	236	0	0	5.690000000000055	972	\N	0
5772062098	0	Hakkai.	0	52	0	0	0	1	\N	0
6082388653	0	k	0	31	0	0	794	11	\N	0
2105482191	0	verlin, open	0	9	0	0	0	114	\N	0
5429028394	0	Tasyaᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ	0	7	0	0	0	3	\N	0
1624982803	0	nana	0	0	0	0	0	0	\N	0
7171671396	0	naya	0	10	0	0	0	2	\N	0
6853171075	0	Rend	0	8	0	0	0	2	\N	0
1258248460	0	shák!llä	0	3	0	0	0	0	\N	0
5304866032	0	hawa	0	21	0	0	0	0	\N	0
5583675124	0	cica f.	0	7	0	0	0	78	\N	0
1458802503	0	chaca aex	0	4	0	0	0	3	\N	0
5397340189	0	Jj	0	22	0	0	0	15	\N	0
1746761332	0	— kairaa 💭	0	18	0	0	0	5	\N	0
1819958653	0	goofy kitty	0	114	0	0	0	358	\N	0
5735935446	0	Keenan nonton boboi	0	0	0	0	0	0	\N	0
5523620657	0	Saburo	0	2	0	0	0	1	\N	0
2087835659	0	key	0	11	0	0	304.86	85	\N	0
5334372198	0	Alana K.	0	25	0	0	0	68	\N	0
6037075072	0	1 fairy shop	0	1	0	0	0	0	\N	0
5052519101	0	Jef	0	1	0	0	0	14	\N	0
1364820946	0	Louella, T__T	0	36	0	0	440	401	\N	0
5843850117	0	januar.	0	22	0	0	6	16	\N	0
5591385856	0	Jidon	0	6	0	0	0	8	\N	0
7035881142	0	ci	0	30	0	0	0	5	\N	0
7120461981	0	Meiche.	0	8	0	0	0	6	\N	0
1735549634	0	cipaw sapi	2	331	0	0	4.209999999999978	504	\N	0
1561087601	0	c for cantika	12	909	0	0	5.880000000001331	1358	\N	1
6675263980	0	wyneth meilady-	0	18	0	0	470	20	\N	0
977392035	0	.	0	14	0	0	0	0	\N	0
1675184796	0	.	0	24	0	0	0	48	\N	0
1949446527	0	el	0	16	0	0	0	4	\N	0
5815362175	0	raaa	0	1	0	0	0	23	\N	0
1971851716	0	gm	1	24	0	0	0	46	\N	0
1960250367	0	enya	0	1	0	0	0	0	\N	0
6136560442	0	j	0	1	0	0	0	2	\N	0
6199572501	0	j	0	36	0	0	0	41	\N	0
5337257092	0	ᥒᥲуᥲᥒᥲᥲ ～♡	0	15	0	0	0	1	\N	0
1417360069	0	ray	0	421	0	0	559.8499999999999	325	\N	0
5225747453	0	Alea	3	49	0	0	4945.42	17894	\N	0
1022626709	0	:)	11	82	0	0	60.660000000000004	18	\N	0
1327048741	0	sooo	0	28	0	0	1	24	\N	0
6276803207	0	🐇. ₊ ﹛call me na﹜ ׁ ࣭ ♡	0	4	0	0	0	1	\N	0
1490106050	0	A	0	1	0	0	0	12	\N	0
5746764322	0	san	0	3	0	0	0	9	\N	0
5301945376	0	lavalop	0	71	0	0	0	838	\N	0
6282678682	0	Maréd Joudde.	0	10	0	0	0	102	\N	0
984709828	0	ciyaa	0	2	0	0	5.05	0	\N	0
6113960269	0	Valino.	0	1	0	0	0	0	\N	0
1336253777	0	Ska	0	387	0	0	154.86999999999998	98	\N	0
1698781020	0	jopiee	0	2	0	0	0	4	\N	0
1432436269	0	t	0	18	0	0	0	18	\N	0
5016664163	0	ive	0	1	0	0	0	0	\N	0
5843466087	0	sabira cruinne	0	5	0	0	0	21	\N	0
5168168361	0	naa	0	47	0	0	0	49	\N	0
6174575997	0	leah 🧸🎀 (cita' dimarahin kak heeseung)	0	0	0	0	491.4800000000001	1098	\N	0
5507065597	0	Say my name	0	31	0	0	0	595	\N	0
5421530978	0	Angel	0	1	0	0	0	0	\N	0
5107024126	0	Pengejar mimpi	0	14	0	0	0	51	\N	0
5040886749	0	ale	0	10	0	0	0	126	\N	0
6292794385	0	D	0	0	0	0	0	0	\N	0
5721448701	0	yogi	0	6	0	0	0	0	\N	0
1820224943	0	cipei	0	69	0	0	0	15	\N	0
1952666958	0	Khaeraline D.	0	1	0	0	0	0	\N	0
6784109693	0	jehaa	0	2	0	0	0	0	\N	0
1874401249	0	ale	0	273	0	0	0	60	\N	0
1207048808	0	Rahayu	0	4	0	0	0	1	\N	0
6715879297	0	juzo	0	2	0	0	1665.44	1	\N	0
6695943035	0	asyaa slctv	0	83	0	0	0	33	\N	0
6641068989	0	naa	0	18	0	0	0	9	\N	0
5288808525	0	alif	0	7	0	0	50	14	\N	0
5497926808	0	malvin pradita	0	32	0	0	14.5	45	\N	0
7086888411	0	ayyinà	0	2	0	0	0	6	\N	0
1959316164	0	K -	0	16	0	0	94.2	84	\N	0
6746242074	0	Julian	0	34	0	0	0	18	\N	0
6430544632	0	Luyii #GTW	0	3	0	0	0	4	\N	0
1389895543	0	Kaiya 🧿	0	8	0	0	0	0	\N	0
5800367455	0	esje	0	8	0	0	0	0	\N	0
5668086653	0	Adinda	0	33	0	0	999.7	192	\N	0
1630551938	0	Ammartyo.	0	35	0	0	162.21000000000004	8	\N	0
1072304017	0	Kenzo	0	2	0	0	0	3	\N	0
2111154863	0	jojo	0	138	0	0	31.399999999999864	5	\N	0
7029667836	0	Bukan	0	389	0	0	7740	1	\N	0
1752968809	0	sapoyy	0	33	0	0	0	166	\N	0
6972110005	0	chelsie	0	6	0	0	0	1	\N	0
1287816715	0	₊˚ʚ ᗢ 슬퍼, hujan anindya	2	789	0	0	1643.2799999999997	1637	\N	0
1643497801	0	egar	0	69	0	0	0	6	\N	0
1388243130	0	(ノ^_^)ノ	0	27	0	0	279.69	806	\N	0
1981670817	0	💤💤	13	201	0	0	1284.4899999999989	1867	\N	0
1308876238	0	ㅤaca moormaid 🧜🏻‍♀	0	797	0	0	146.9600000000006	3922	\N	0
5764302636	0	Sabe M. Candisy	0	12	0	0	0	6	\N	0
5930573822	0	j	0	2	0	0	0	0	\N	0
1840080701	0	haruu	5	561	0	0	4994.430000000001	9517	\N	0
6088558571	0	wikky	0	42	0	0	0	44	\N	0
1485981786	0	ㅤㅤ	0	47	0	0	0	2	\N	0
6284771197	0	Diska vera angel valeria	0	165	0	0	287.86	496	\N	0
5142182558	0	KATHERINE-J.	0	0	0	0	0	9	\N	0
5531692582	0	rajeen	0	9	0	0	0	0	\N	0
5226083076	0	VIO, busy.	0	2	0	0	0	0	\N	0
6388998604	0	Bashe	0	1	0	0	0	1	\N	0
1401497972	0	daze	0	23	0	0	0	13	\N	0
5185023159	0	lapan	0	0	0	0	0	0	\N	0
6208736433	0	icabii	0	1	0	0	0	0	\N	0
6692121955	0	dian rawr	0	53	0	0	1716.08	54	\N	0
1879860136	0	N	0	147	0	0	60.68000000000001	29	\N	0
5359872764	0	gisatra	0	7	0	0	0	5	\N	0
6649552823	0	nad	0	15	0	0	19.99	6	\N	0
1858862407	0	Kia	0	12	0	0	0	0	\N	0
6828296221	0	jaixa	0	2	0	0	0	2	\N	0
1587725938	0	Ira	0	1	0	0	0	1	\N	0
6537041222	0	laraaa	0	4	0	0	0	0	\N	0
2126775578	0	élla martyr¹fkr²	0	1	0	0	0	0	\N	0
1405752517	0	Nayy	0	7	0	0	0	1	\N	0
1401227238	0	ra.	0	114	0	0	0	10	\N	0
5697189566	0	zeey	0	49	0	0	0	7	\N	0
6434211427	0	Delwin	4	179	0	0	3511.7299999999996	10950	\N	0
1566624872	0	Alaia	0	191	0	0	1411.8000000000002	593	\N	0
5354781175	0	dregaz	0	11	0	0	0	0	\N	0
6217552411	0	Ano pt.2	0	1	0	0	0	2	\N	0
1739017137	0	kEEEI !	0	2	0	0	0	6	\N	0
1073602668	0	Faiz	0	1	0	0	0	0	\N	0
1850568272	0	ingyah	0	1	0	0	0	0	\N	0
5286693469	0	Ab3lla	0	797	0	0	6	163	\N	0
5328685494	0	joline	0	20	0	0	0	28	\N	0
1569219135	0	rifaa	9	94	0	0	1704.6799999999996	51	\N	0
6829363318	0	Askaa	0	1	0	0	0	0	\N	0
6530022279	0	Hema A.	0	9	0	0	141	5	\N	0
6281271624	0	ㅤㅤㅤㅤㅤ	0	1	0	0	0	0	\N	0
1713411432	0	bil	0	35	0	0	0	1	\N	0
6021475020	0	rararawr	0	5	0	0	0	79	\N	0
1741622641	0	Lutfii	0	258	0	0	674.8	130	\N	0
6513179178	0	n	0	7	0	0	0	13	\N	0
6195435351	0	Vayyara	0	2	0	0	0	1	\N	0
753082282	0	sha	0	65	0	0	0	0	\N	0
6068948537	0	01	0	2	0	0	0	2	\N	0
2108309967	0	shabila	0	3	0	0	0	7	\N	0
1484773954	0	Kyyᵃˢᵃᵏʸʸ	0	4	0	0	0	5	\N	0
1778264674	0	gghhshuhe	0	4	0	0	0	0	\N	0
1900010917	0	K.	0	1	0	0	0	0	\N	0
6531161131	0	cimoo	0	2	0	0	0	1	\N	0
2031507929	0	Cell	0	18	0	0	0	1	\N	0
5641821713	0	Seleen.	9	303	0	0	2622.0099999999993	2004	\N	0
6302637732	0	𐙚! . ࣪ flowiey aerinaa ! 文件 .. ♡	0	3	0	0	0	0	\N	0
1613503540	0	zαskα	0	7	0	0	0	4	\N	0
6289048008	0	🧠🍥 w!kky	0	81	0	0	0	2	\N	0
5885320518	0	owwen	0	25	0	0	0	12	\N	0
1179826742	0	ffzhh	0	12	0	0	0	59	\N	0
5145507381	0	jen	0	92	0	0	159.5	620	\N	0
5938745976	0	Ellen Oct	0	2	0	0	0	0	\N	0
6663744191	0	feli	0	1	0	0	0	18	\N	0
1003170253	0	jz	0	22	0	0	0	63	\N	0
6435792806	1	reja | kabarin	0	155	0	1	54	79	\N	0
1766651761	0	re	0	4	0	0	0	13	\N	0
1412012697	0	ciii	0	161	0	0	12.159999999999997	372	\N	0
1791139568	0	Biyaa?!!	0	1	0	0	0	1	\N	0
5600655822	0	asaa acc kerja	0	6	0	0	0	5	\N	0
1702775516	0	Jemima	6	50	0	0	574.0300000000001	134	\N	0
5155723751	0	melvin	0	4	0	0	0	0	\N	0
5984264096	0	rec️a	0	2	0	0	0	16	\N	0
1943797883	0	a	0	64	0	0	5.45	5	\N	0
5714536759	0	Kale, ridi all apk.	0	3	0	0	0	0	\N	0
5487379755	0	hanggini	0	3	0	0	0	3	\N	0
6770041036	0	Jesa 🪼	4	155	0	0	1040.0800000000002	7319	\N	0
5038901651	1	𝟒𝟒𝟒.ⁱⁿᵗⁱ𝐌千g̸ devan 🇦🇶	0	146	0	0	1.5700000000001566	31	\N	0
6557149084	0	riel	0	83	0	0	431.6400000000001	55	\N	0
5540012344	0	fall.	0	3	0	0	0	2	\N	0
6199544189	0	aysera!	0	3	0	0	0	2	\N	0
6363226320	0	ay	0	0	0	0	0	0	\N	0
6347558047	0	ㅤ	0	190	0	0	259.46	702	\N	0
5628242862	0	𝕭𝖆𝖉𝖆𝖘𝖘 𝕭𝖔𝖞	0	2	0	0	0	6	\N	0
5833980430	0	gladie	0	1	0	0	0	20	\N	0
5085117868	0	ja	0	114	0	0	13.74	10	\N	0
1045276936	0	keii.	0	29	0	0	0	84	\N	0
5527376794	0	ৎ ˖ ࣪ ׅ 𝓛iona D. 𐦍	0	0	0	0	0	0	\N	0
5051120553	0	[°] tranaya	0	19	0	0	0	61	\N	0
1709989737	0	Johan	0	3	0	0	0	0	\N	0
5429094236	0	sachie	0	1	0	0	0	0	\N	0
1920586877	0	ddα cutie, dαpαα🐰🍼	0	38	0	0	29	7	\N	0
1692608265	0	zynsha,	0	5	0	0	3	32	\N	0
1342238616	0	Lovely	0	119	0	0	0	45	\N	0
6036175781	0	🍥	0	21	0	0	6956	125	\N	0
1389341159	0	xavier than ever	0	851	2	0	604.6600000000001	304	\N	0
1839325973	0	e	0	37	0	0	0	62	\N	0
6685315922	0	Ra	0	1	0	0	0	0	\N	0
5844026554	0	garax	0	1	0	0	0	0	\N	0
1822960288	0	kalingga	0	764	0	0	14.809999999999718	1990	\N	0
6699029317	0	🎀	0	2	0	0	0	4	\N	0
6522196054	0	.	0	58	1	0	0	15	\N	0
6600513081	0	-	0	6	0	0	0	6	\N	0
5406540372	0	Ardian pending banget ya allah	6	856	1	0	4821.339999999998	831	\N	0
1767826407	0	chesa	0	71	0	0	0	5	\N	0
2129650237	0	none.	0	586	0	0	2529.47	4101	\N	0
5042692350	0	sheelin 	0	42	0	0	0	66	\N	0
1845087416	0	yisa	0	139	0	0	0	2	\N	0
1778244852	0	sean	0	0	0	0	0	0	\N	0
1635422404	0	cielra.	0	203	0	0	2015.5500000000002	2597	\N	0
1688063559	0	jeAna	0	5	0	0	0	49	\N	0
2072139777	0	Shabiela K.	0	2	0	0	0	37	\N	0
6318470975	0	(𝐆𝐆𝐓)¹ eljarrr タ𝔯𝕥𝐒	0	51	0	0	10	138	\N	0
5195673022	0	Angga	0	1	0	0	0	2	\N	0
1675074495	0	ᴍᴏɴɢ	0	4	0	0	26.38	101	\N	0
1880753685	0	renxa	0	483	0	0	9.040000000000031	1346	\N	0
2085987884	0	Hechrea	0	5	0	0	0	0	\N	0
5388480211	0	dape	0	2	0	0	238.64000000000001	5	\N	0
6393508846	0	284. minerva	0	33	0	0	1354.1299999999999	304	\N	0
7006633765	0	eve	0	0	0	0	0	0	\N	0
1531885224	0	SFB	0	39	0	0	0	14	\N	0
5767900634	0	Mutiii	0	9	0	0	0	5	\N	0
6157573147	0	jepe	0	3	0	0	0	13	\N	0
1786246453	0	zzzzzzzzz	0	3	0	0	0	0	\N	0
1750040632	0	asel	0	80	0	0	239.29999999999995	16296	\N	0
6385180974	0	Zra⁰⁶	0	3	0	0	0	1	\N	0
7153678869	0	Issa suka gita	0	0	0	0	0	0	\N	0
1332714537	0	Angkasa ᴄᴢ₁₇₊	0	2	0	0	960	1	\N	0
6939128818	0	k.	0	22	0	0	0	3	\N	0
5811372841	0	e	0	3	0	0	0	6	\N	0
5915403585	0	𐂂ȥαα	0	11	0	0	0	58	\N	0
5946597652	0	Adám	0	27	0	0	0	7	\N	0
5931829881	0	cibi	0	5	0	0	0	0	\N	0
6857700338	0	k	0	61	0	0	340.74	1155	\N	0
5658766691	0	.	0	70	0	0	161.32999999999998	80	\N	0
5849859709	0	harif	0	46	0	0	559.33	16	\N	0
5891479594	0	kentokie	0	1	0	0	0	0	\N	0
1373477847	0	p	0	3	0	0	0	6	\N	0
1782403116	0	b	11	285	0	0	1364.6399999999999	219	\N	0
7049913760	0	Magdalena	0	4	0	0	0	22	\N	0
5484945778	0	faxi	0	1	0	0	0	0	\N	0
1664070815	0	poookkiiiee	0	30	0	0	0	17	\N	0
1897495304	0	al 🧌🧌	6	661	0	0	2568.785	8256	\N	0
1688962521	0	Azrel	0	4	0	0	0	0	\N	0
5531457596	0	rain	0	4	0	0	0	153	\N	0
1652741488	0	d	0	9	0	0	480	18	\N	0
1280438465	0	f	12	227	0	0	2027.260000000007	39520	\N	1
1542322485	0	ci	0	95	0	0	0	28	\N	0
1827758417	0	ayy	0	0	0	0	0	0	\N	0
7168378403	0	**	0	1	0	0	0	0	\N	0
5046905922	0	ailen	0	8	0	0	1.4200000000000017	0	\N	0
5942518211	0	rizk	0	7	1	0	0	8	\N	0
1786629483	0	nave	13	477	1	0	2156.01	273	\N	0
5256536768	0	ㅤㅤㅤㅤㅤㅤ	0	82	0	0	0	2	\N	0
7066313974	0	pai	0	27	0	0	0	163	\N	0
1616184715	0	s	12	16	0	0	992.6300000000001	295	\N	0
5073087070	0	Aira	0	15	0	0	0	26	\N	0
1707720802	0	Reona	0	8	0	0	0	0	\N	0
6196905602	0	fak	0	21	0	0	0	1	\N	0
831765347	0	Tian	0	3	0	0	0	1	\N	0
5383714288	0	deposit 🇭🇳	0	12	0	0	0	0	\N	0
1342796412	0	ren	5	758	0	0	59.99999999999999	362	\N	0
1213491416	0	kaa	0	23	0	0	298.64	110	\N	0
1743544419	0	Athaya Kascrowsky.	0	8	0	0	0	0	\N	0
7075340124	0	Kirana	0	51	0	0	0	0	\N	0
1486691620	0	Kaetherina	0	87	0	0	818.5299999999997	880	\N	0
5485395826	0	david	0	4	0	0	0	0	\N	0
6732776926	0	Soma	0	5	0	0	0	0	\N	0
1465517021	0	qisya awr	0	29	0	0	0	88	\N	0
1866522791	0	ad	0	3	0	0	0	5	\N	0
1870426333	0	bryan	0	85	0	0	0	315	\N	0
1648779147	0	aksára	0	7	0	0	0	1	\N	0
1914288149	0	Anra	0	5	0	0	0	3	\N	0
6972073194	0	tipaa	0	16	0	0	7.63	88	\N	0
6298715357	0	nay. sorry bgtt rbio yaa	0	2	0	0	0	7	\N	0
5831096097	0	iqis	0	10	0	0	0	17	\N	0
5656841491	0	Piaaw✧･ﾟ	0	7	0	0	0	45	\N	0
1509884224	0	arasha	0	88	0	0	15.020000000000003	36	\N	0
5345601288	0	Jejennnn	0	112	0	0	0	1267	\N	0
6614813493	0	nadine	0	1	0	0	0	1	\N	0
1606700642	0	iceel	0	4	0	0	0	2	\N	0
5330381781	0	ㅤㅤ Anaphalis. 🖼	0	254	0	0	77.38	1650	\N	0
1720187653	0	Kila paus🐳🐳	0	54	0	0	0	56	\N	0
6712300463	0	Hulk michelle	0	16	0	0	0	22	\N	0
1610979804	0	kala	0	10	0	0	228.21	8	\N	0
6832256933	0	८꒰୨ 🎀 ₊ ֯ ‹ 케어, ryellee!3!1	0	4	0	0	0	0	\N	0
5025878899	0	farel⁴⁴². antiyou²	0	31	0	0	142.06	47	\N	0
6359332093	0	dprian's gf	0	5	0	0	0	11	\N	0
5935250628	0	lynnee	0	4	0	0	0	10	\N	0
5379091212	0	Saputra. 02:12 🕰	0	15	0	0	28.29	45	\N	0
5771408794	0	f	0	13	0	0	0	18	\N	0
6089196227	0	egii	0	20	0	0	0	13	\N	0
5439567152	0	Nana.	0	7	0	0	0	9	\N	0
945332254	0	Raveluc	0	14	0	0	0	1	\N	0
5289665938	0	initial r	0	2	0	0	0	4	\N	0
5043113918	0	Bee	0	1	0	0	0	0	\N	0
2042584589	0	JENO BLONDE HAIR JAEMIN BLACK HAIR	0	1	0	0	36.4	27	\N	0
5986735823	0	sisil𝖅༉	0	3	0	0	0	4	\N	0
6326999444	0	Wakai	0	55	0	0	0	35	\N	0
6252053107	0	Mark lee girlfriend	0	8	0	0	0	27	\N	0
1350847561	0	R	0	2	0	0	0	1	\N	0
6155680951	0	Lowly	0	1	0	0	0	0	\N	0
1723806953	0	vel.	0	2	0	0	0	0	\N	0
5438970629	0	Steven	0	6	0	0	0	8	\N	0
6667298462	0	wtb/s	0	8	0	0	0	0	\N	0
968285283	0	jssy	8	212	0	0	873.8599999999999	1554	\N	0
1935943649	0	rest. el salimawikkysrz B10	0	9	0	0	0	15	\N	0
5976702914	0	rennn	0	4	0	0	0	0	\N	0
6201080185	0	N	7	132	0	0	339.66999999999894	407	\N	0
6166601343	0	eln	0	70	0	0	229.7	217	\N	0
6783099225	0	maRu	0	1	0	0	0	11	\N	0
5328724889	0	kemi	0	1	0	0	0	0	\N	0
1266504457	0	Rindu	0	552	0	0	6	2	\N	0
5266575592	0	𐙚.˚Oceane Vellane	0	8	0	0	0	3	\N	0
1752481144	0	cicaaa	0	133	0	0	28.6799999999998	6	\N	0
1835324038	0	maii	0	5	0	0	0	10	\N	0
5612484376	0	rest in peace	0	3	0	0	0	60	\N	0
1547896364	0	王妃, Catherine busy loving mas araz	0	199	0	0	1089	1100	\N	0
1735258329	0	Erick	0	12	0	0	0	0	\N	0
2138026046	0	Popsicles	0	3	0	0	0	2	\N	0
6080260068	0	Huhaaa	0	7	0	0	0	16	\N	0
5934528148	0	fuckíh strènzo	0	0	0	0	0	0	\N	0
1683015871	0	à	0	1	0	0	0	0	\N	0
1720547836	0	dysné cewe gunukkk	0	1058	0	0	0	1292	\N	0
6670718984	0	liaaa	0	1	0	0	0	0	\N	0
1611508283	0	Zeanna	0	4	0	0	478	18	\N	0
6783575380	0	Chérra Allysa Auretta.	0	1	0	0	0	0	\N	0
6175622109	0	mersh, 3012	0	1	0	0	0	0	\N	0
7035361923	0	Abi	0	32	0	0	0	107	\N	0
5956123009	0	wnd	11	264	0	0	282.42	1325	\N	0
1152109843	0	n	0	1	0	0	0	1	\N	0
6259792764	0	.	0	55	0	0	545.9499999999999	98	\N	0
5562209004	0	e	0	17	0	0	0	46	\N	0
5520883058	0	maraa	0	10	0	0	0	70	\N	0
5951314095	0	malio	0	4	0	0	0	0	\N	0
6866335388	0	zc	0	94	0	0	-9	27	\N	0
6351884322	0	wht!?	0	1	0	0	0	1	\N	0
5428478442	0	ruin	0	14	0	0	0	14	\N	0
6908375700	0	Juheng	0	7	0	0	1137.5	469	\N	0
5297128246	0	bie, dni.	0	1	0	0	0	0	\N	0
1407289019	0	bjir	0	116	0	0	757.52	68	\N	0
6782877246	0	fuck name	0	1	0	0	0	0	\N	0
6058700227	0	d	0	7	0	0	0	10	\N	0
5832061672	0	Yuu	0	6	0	0	0	87	\N	0
5688367565	0	Kasya	0	1	0	0	0	0	\N	0
6644552729	0	enay	0	4	0	0	0	1	\N	0
1630466465	0	chima	0	40	0	0	0	12	\N	0
979583121	0	Lyly	0	199	0	0	109.09000000000015	572	\N	0
1767999990	0	𝐀llé siput	0	1	0	0	0	4	\N	0
1784120991	0	a	0	8	0	0	0	1	\N	0
1849237173	0	jupiter	0	22	0	0	0	51	\N	0
6617395285	0	rino	0	10	0	0	2456	8	\N	0
5339827717	0	C	0	106	0	0	0	60	\N	0
5845063858	0	Cy	0	25	0	0	0	12	\N	0
2141722229	0	Bebeyi, e.	0	0	0	0	0	0	\N	0
6962563363	0	Nirvani	0	1	0	0	0	1	\N	0
935271343	0	p	0	27	0	0	13.899999999999999	15	\N	0
5449563248	0	ares	0	6	0	0	0	0	\N	0
5772484254	0	c	0	11	0	0	0	18	\N	0
1793533019	0	jian	0	7	0	0	0	0	\N	0
6282180246	0	ayaaana	0	4	0	0	0	0	\N	0
1544599106	0	Vanila	0	1	0	0	0	0	\N	0
6858411738	0	Letnan	0	5	0	0	0	4	\N	0
1641776558	0	Ta	0	181	0	0	11	8	\N	0
6588902770	0	Dash	0	4	0	0	0	0	\N	0
6204986218	0	ra	0	3	0	0	0	4	\N	0
5133020465	0	karissa	0	143	2	0	-1	28	\N	0
2021284526	0	khailaa	0	18	0	0	0	570	\N	0
5302305758	0	asha	0	3	0	0	0	0	\N	0
6824905047	0	𝐚	0	7	0	0	0	0	\N	0
1648041505	0	ꜱɪᴇ	0	1	0	0	0	0	\N	0
6771910550	0	sa	0	77	0	0	2	648	\N	0
1226411841	0	a	0	18	0	0	0	0	\N	0
7175791150	0	d	0	4	0	0	0	19	\N	0
1732235615	0	xeza	0	5	0	0	0	2	\N	0
7176177703	0	️️️ㅤ	12	1	0	0	0	1	\N	0
5196791035	0	Teres @jennieprubyjanee	0	2	0	0	0	0	\N	0
6731232496	0	yas	0	1	0	0	0	0	\N	0
7194602480	0	蔡•ɢʀᴀᴄᴇ	0	3	0	0	0	0	\N	0
1853301556	0	geaa2	0	14	0	0	0	2	\N	0
1204085270	0	moré return @ evaolee	2	120	0	0	302	54	\N	0
6350390679	0	Tezza	0	44	0	0	873	50	\N	0
1350673642	0	ayiiiiiko	0	2	0	0	0	0	\N	0
6061519815	0	ce	0	2	0	0	0	4	\N	0
6635829558	0	Fean.	0	0	0	0	0	5	\N	0
1743113928	0	Jennifer	0	56	0	0	0	19	\N	0
1011530776	0	icel	3	136	0	0	430.2800000000002	104	\N	0
5057909111	0	san	0	8	0	0	0	7	\N	0
6406599708	0	epin	0	3	0	0	211.5	244	\N	0
1776706879	0	pararam	12	2545	0	0	3995.330000000011	38242	\N	1
6017056127	0	aqeel	14	140	0	0	3557.6500000000024	353	\N	1
6932725924	0	Wa	0	6	0	0	0	1	\N	0
6268143108	0	Galang	0	2	0	0	0	0	\N	0
5177425484	0	ellcey.	0	162	0	0	1367.5	2578	\N	0
1805644847	0	S	0	1	0	0	0	0	\N	0
5331154163	0	Kalia 𔘓	0	269	0	0	19.25	85	\N	0
6869858072	0	aby	0	5	0	0	0	6	\N	0
5287167141	0	ijot	0	332	0	0	431.0399999999995	143	\N	0
1761095009	0	andin	0	31	0	0	0	30	\N	0
6296991500	0	kapaz	0	1	0	0	0	0	\N	0
1217673785	0	Khadafi.	0	252	0	0	3.9300000000000637	35	\N	0
5699263239	0	Zohakuten	0	2	1	0	0	0	\N	0
2131342404	0	—	0	43	0	0	0	14	\N	0
2003527752	0	narejaa	3	42	0	0	2448.5299999999997	55	\N	0
1922801684	0	kRenjani.	0	3	0	0	0	12	\N	0
6603876542	0	alee	3	18	0	0	178	30	\N	0
1375206617	0	Anindya	0	26	0	0	0	171	\N	0
6721611306	0	Gwen	0	18	0	0	0	63	\N	0
7140603447	0	Selena	0	80	0	0	7.789999999999999	283	\N	0
6134677099	0	j	0	8	0	0	0	15	\N	0
1631646378	0	Hades	0	3	0	0	0	15	\N	0
5825586748	0	rayy	0	5	0	0	0	1	\N	0
5447945450	0	sa	0	659	0	0	13.199999999999996	667	\N	0
5302094259	0	Yola	0	2	0	0	0	11	\N	0
1228215063	0	liaa	0	2	0	0	0	0	\N	0
6403942335	0	kenZzie	0	76	0	0	3.670000000000016	9	\N	0
6183506139	0	꒰ᐢ. ̫ .ᐢ꒱	0	1	0	0	0	38	\N	0
1523370236	0	naraa	0	26	0	0	0	60	\N	0
1075717659	0	jecopie	0	1	0	0	0	0	\N	0
7019167580	0	Nisa	0	1	0	0	0	3	\N	0
5112724820	0	Noper	0	2	0	0	0	0	\N	0
1768758407	0	Raye	0	2	0	0	0	7	\N	0
5673122554	0	rick	0	149	0	0	0.6700000000000159	3	\N	0
2061152313	0	tel	6	1303	0	0	3000.7700000000013	4325	\N	0
1979704607	0	jean	0	8	1	0	0	0	\N	0
2027956180	0	kei	0	14	0	0	0	0	\N	0
1833952461	0	rizki	0	3	0	0	0	2	\N	0
1659952923	0	Cyn	0	0	0	0	0	0	\N	0
6705878612	0	b1ko. 🪬	0	4	0	0	0	2	\N	0
5573479201	0	drpw. jennasee	0	4	0	0	0	5	\N	0
1966150990	0	🐰+ ׄ ׅ anak manis, isaa!ׄ ◜ 𐙚	0	37	0	0	0	28	\N	0
6742804563	0	adel	0	30	0	0	0	11	\N	0
5459353693	0	𝐝𝐞𝐟𝐟.	0	54	0	0	0	7	\N	0
6260237434	0	Seraphim Angel	0	6	0	0	470	13	\N	0
5950301922	0	el pengen baso	0	135	0	0	0	122	\N	0
6479177044	0	ashell	0	1	0	0	0	2	\N	0
5479604332	0	Mave	0	1	0	0	0	0	\N	0
6276966031	0	garaa double a	0	82	0	0	155.2800000000001	544	\N	0
6835615788	0	gamar	0	31	0	0	0	34	\N	0
2009004866	0	Ra	0	1	0	0	0	0	\N	0
6002046425	0	n del rey	0	25	0	0	13.200000000000003	158	\N	0
1531774946	0	Kiley :P	0	9	0	0	0	4	\N	0
872252387	0	gartha	0	1	0	0	0	1	\N	0
1760610438	0	A—Kanara.	0	9	0	0	0	15	\N	0
5909523904	0	cibbeey	0	3	0	0	0	82	\N	0
5885128750	0	acha	0	5	0	0	0	7	\N	0
5197417231	0	geo #lksd	0	556	1	0	54.71000000000005	546	\N	0
5425102234	0	꒰੭︒𓈒 🎀 ⊹ dndaa's ♡ ﾟ◠ . ა	0	0	0	0	0	0	\N	0
5779463817	0	shakira	0	3	0	0	0	2	\N	0
1965852555	0	nayraA	0	3	0	0	0	1	\N	0
6707740583	0	Ghazea	0	10	0	0	0	2	\N	0
5527230028	0	raf	0	1	0	0	0	15	\N	0
6391306180	0	mik🐾	0	3	0	0	0	0	\N	0
2086940889	0	Jericho	0	1	0	0	0	2	\N	0
5316758100	0	Rajib	0	16	0	0	0	314	\N	0
1923123634	0	cinciaw	0	70	0	0	153	103	\N	0
6529072938	0	wayqel	0	71	0	0	0	3	\N	0
1433099933	0	Zain	0	3	0	0	0	5	\N	0
5263238209	0	ciciciciciii𖧧🐬🫧	0	2	0	0	0	10	\N	0
6005111934	0	ong	0	48	0	0	4.210000000000001	4	\N	0
6421458077	0	k	0	1	0	0	0	0	\N	0
6251050082	0	nyenye	0	5	0	0	0	6	\N	0
1512758583	0	taaa miaw	0	83	0	0	198.24	13	\N	0
1272102536	0	<3	0	3	0	0	0	7	\N	0
5769483913	0	f	0	4	0	0	0	3	\N	0
5152354055	0	Cattie	0	25	0	0	85	42	\N	0
6693027213	0	Nicollá	0	10	0	0	0	4	\N	0
5163664499	0	zikal	8	49	0	0	45.52000000000018	125	\N	0
2116715201	0	iel	0	1	0	0	0	4	\N	0
1815212975	0	— 𝐉udith.	0	4	0	0	0	0	\N	0
5960024482	0	s	0	0	0	0	0	0	\N	0
5671990176	0	nana	0	92	0	0	3.5599999999999454	7	\N	0
2137927146	0	n	0	80	0	0	207.89000000000001	2	\N	0
1677693033	0	ㅤ	0	1	0	0	0	0	\N	0
1722062498	0	📴	0	2	0	0	0	0	\N	0
1944888234	0	.	0	150	1	0	0	129	\N	0
6628830146	0	jinu.	0	2	0	0	0	0	\N	0
1175047039	0	Lei	0	1	0	0	0	0	\N	0
5620225913	0	Lofasya	0	31	0	0	0	0	\N	0
1807979323	0	kares	0	5	0	0	0	96	\N	0
5902981133	0	Riri @parykrose	0	0	0	0	0	16	\N	0
6256642931	0	joèy	0	2	0	0	0	0	\N	0
6048371171	0	444	0	2	0	0	0	0	\N	0
1918103090	0	lexx	0	40	0	0	38	80	\N	0
6438281392	0	ethann	0	34	0	0	70	59	\N	0
5507711609	0	jema ( Taylor's version )	0	42	0	0	1.8400000000000034	88	\N	0
6028716017	0	kala	0	1	0	0	0	0	\N	0
6620552221	0	Alfi	0	1	0	0	0	0	\N	0
5650644955	0	k	0	169	0	0	194.97999999999993	571	\N	0
6317541467	0	stephanie.	0	17	0	0	0	7	\N	0
6178197532	0	jo	0	123	0	0	0	15	\N	0
5497354842	0	Slyther1n	0	1	0	0	0	0	\N	0
5262933606	0	ukaa	0	130	0	0	2.8999999999999986	349	\N	0
7089215835	0	y	0	3	0	0	0	0	\N	0
5141143690	0	j	0	278	0	0	5.539999999999999	521	\N	0
1754669383	0	jane	0	6	0	0	0	1	\N	0
6258877196	0	A—Kaisara	0	0	0	0	0	0	\N	0
6700697920	0	Binta🐣	0	1	0	0	0	0	\N	0
5491772793	0	Nela,	0	51	0	0	0	1247	\N	0
5014855151	0	Jorxas.	0	1	0	0	0	0	\N	0
7148640657	0	keysa	0	14	0	0	0	15	\N	0
1805355864	0	Lucious	0	2	0	0	0	0	\N	0
1860401978	0	cinn	7	777	0	0	63.25	619	\N	0
6174073683	0	Kaye.	0	8	0	0	0	24	\N	0
5633612020	0	elleirra lyoneth.	0	0	0	0	0	0	\N	0
2046795831	0	zoey	0	12	0	0	0	28	\N	0
5794744555	0	Ayasss	0	1	0	0	0	1	\N	0
6876884626	0	At	0	1	0	0	0	3	\N	0
6201748093	0	dio	0	19	0	0	0	3	\N	0
6770449814	0	(sedang stress utbk)	0	27	0	0	0	65	\N	0
7045915444	0	mayaa	0	1	0	0	0	0	\N	0
7097297386	0	pye.	0	1	0	0	0	0	\N	0
1724157214	0	Orion	0	5	0	0	0	0	\N	0
6405060045	2	Telkomsel	0	186	0	0	2170	103	\N	0
6062742043	0	SKR	0	3	0	0	0	35	\N	0
7192448776	0	ariyani 🌙	0	15	0	0	0	24	\N	0
1358712462	0	.	0	1	0	0	0	0	\N	0
7041702609	0	asyaa	0	4	0	0	1000	19	\N	0
6559744210	0	.	0	76	0	0	0	0	\N	0
1733458130	0	za	0	14	0	0	0	2	\N	0
7058244668	0	asu	0	237	0	0	3.659999999999968	32	\N	0
1711806680	0	Echiia Hartono	13	680	0	0	2483.57	1699	\N	0
1982586748	0	Reza	0	0	0	0	0	4	\N	0
5813569716	0	j	0	0	0	0	0	0	\N	0
1823050382	0	Raine Raine, Go away!	0	31	0	0	0	42	\N	0
7017601282	0	GALAU MAU NONTON COWOKU	0	6	0	0	0	5	\N	0
1870834181	0	tata	11	375	0	0	9049.560000000005	4499	\N	1
6080986755	0	kly	0	1	0	0	0	0	\N	0
1935311702	0	m. khair 3	0	137	0	0	0	179	\N	0
5121645564	0	kal	0	2	0	0	0	8	\N	0
5371491352	0	₊˚⊹kirei	0	404	0	0	6.4199999999999875	887	\N	0
6482216203	0	L	0	6	0	0	0	0	\N	0
1536890889	0	Malvenna	0	76	0	0	5	5	\N	0
6988922784	0	kayla	0	0	0	0	0	0	\N	0
5041475329	0	san	0	38	0	0	0	2	\N	0
1716113521	0	abim	0	160	0	0	0	642	\N	0
1791690721	0	Kirana.	0	21	0	0	0	20	\N	0
1743446316	0	Jey	0	1111	0	0	821.7799999999997	16841	\N	0
1701123284	0	asha	0	145	0	0	0	73	\N	0
5739599849	0	esha	0	1	0	0	0	0	\N	0
6394552651	0	Syifa	0	2	0	0	0	2	\N	0
6240942702	0	sa	0	35	0	0	1154.93	43	\N	0
5318204207	0	karin	0	1	0	0	0	0	\N	0
1809283793	0	Calasha.	0	1	0	0	0	0	\N	0
5686129287	0	MS	0	3	0	0	0	8	\N	0
6180307892	0	d	0	38	0	0	0	26	\N	0
6945913399	0	ㅤ	0	79	0	0	0	297	\N	0
6276731913	0	nonov	0	2	0	0	0	2	\N	0
1869377988	0	rara	0	2	0	0	0	0	\N	0
5189302768	0	gavin	0	27	0	0	0	0	\N	0
1729111612	0	egii	0	7	0	0	0	1	\N	0
1223021294	0	aya	0	2	0	0	0	3	\N	0
6001263882	0	Jean	0	2	0	0	1.77	349	\N	0
5287195253	0	noya	0	0	0	0	0	95	\N	0
5728152550	0	elan	9	32	0	0	5.82	43	\N	0
1904946873	0	faa	0	178	0	0	1.2199999999999989	39	\N	0
1716880006	0	yarshie	0	82	0	0	12.96	2343	\N	0
6083523569	0	1287. gistara	0	1	0	0	78	1	\N	0
5375976577	0	key	0	2	0	0	0	0	\N	0
6857742577	0	a	0	5	0	0	0	1	\N	0
6934420501	0	zywn	0	9	0	0	0	1	\N	0
1679756465	0	ian	0	37	0	0	0	0	\N	0
1149109015	0	izzy	0	0	0	0	0	0	\N	0
5488389338	0	𝐓𝐑≛𝐏𝐒` claire𝑺𝑵	0	7	0	0	0	5	\N	0
5009949220	0	Maude	0	18	0	0	840	0	\N	0
5173759890	0	ray.	0	1	0	0	0	0	\N	0
5453386354	0	cea	0	6	0	0	0	9	\N	0
2006996661	0	ayesya	0	2	0	0	0	0	\N	0
6777187073	0	🌊	0	59	0	0	0	263	\N	0
1723590444	0	lajoyaa	2	281	0	0	6498.940000000003	5246	\N	0
6779698411	0	sekoncoiss	0	15	0	0	0	26	\N	0
6657452232	0	khaiii	0	20	0	0	0	17	\N	0
5099679178	0	𐙚 。𝗔𝐊 • arelonel 𝑖𝑙𝑡 ⁴² ᎧӠꪆ୧‌‌ 𓆩⚝𓆪ᴶᴹᵀ	0	181	0	0	586.2300000000005	389	\N	0
6614148489	0	yyyyy	0	19	0	0	0	0	\N	0
5914577578	0	.	0	72	0	0	7.850000000000001	895	\N	0
7171822849	0	El	0	1	0	0	0	0	\N	0
5181877825	0	Sean	0	193	0	0	0	181	\N	0
5813112403	0	bdw¹⁵⁷tatiaaa	0	2	0	0	0	21	\N	0
6832992285	0	𝓬𝓱𝓮𝓲𝓼𝔂𝓪	0	1	0	0	0	0	\N	0
6043500190	0	ᴛᴜᴀɴ ᴍᴜᴅᴀ ʜᴀɴ	0	1	0	0	0	124	\N	0
6453949094	0	ren	0	3	0	0	0	0	\N	0
6222093085	0	ana	0	84	0	0	5.299999999999997	2	\N	0
2004214628	0	nay	0	1	0	0	0	0	\N	0
5327439494	0	Kaheja.	0	1	0	0	0	0	\N	0
5483182159	0	sun	0	1	0	0	0	1	\N	0
1769663739	0	dane 🕷	0	2	0	0	0	1	\N	0
1867924505	0	xablue	0	4	0	0	0	8	\N	0
1909116871	0	May	0	192	0	0	390.4100000000001	3219	\N	0
6858723765	0	meiyo tobeli	0	6	0	0	0	2	\N	0
1875407557	0	Raf	0	4	0	0	0	713	\N	0
5707551996	0	fey	0	101	0	0	425.8900000000001	262	\N	0
5723168413	0	o	0	0	0	0	0	0	\N	0
1828602559	0	Kay	0	3	0	0	0	0	\N	0
2068909502	0	piaAa	0	2	0	0	0	0	\N	0
6471882684	0	jaci	0	12	0	0	289.58	98	\N	0
7172056384	0	Key	0	0	0	0	0	0	\N	0
1436680429	0	.	0	307	0	0	10.64	32	\N	0
7017749822	0	.	0	10	0	0	0	11	\N	0
6010153812	0	Faeiya awr.	0	226	0	0	12.46	278	\N	0
6448005704	0	agatha	0	0	0	0	0	0	\N	0
5653797760	0	Julio	0	5	1	0	0	1	\N	0
5209941603	0	Anlie	0	1	0	0	0	0	\N	0
1948046587	0	Isabella.	0	1	0	0	0	0	\N	0
1758075037	0	Jiya	0	4	0	0	0	1	\N	0
5295120853	0	sensen 769psx	0	4	0	0	50	27	\N	0
7133802037	0	✧ʀʏʟ	0	3	0	0	0	3	\N	0
1530784868	0	zidan	0	1	0	0	0	3	\N	0
1361349463	0	z4 zhuwi	9	320	0	0	514.55	3506	\N	0
5926454998	0	#𝓝𝐜𝐧𝐢𝐭 #𝐛𝐲𝐳𝐢 𝐂𝐙 nayshila #JKᑕᑎIT #𝓢ᥣ	0	3	0	0	0	0	\N	0
5380148274	0	ayyera.	0	12	0	0	0	5	\N	0
5645978190	0	🌷 Wawaa FSR vidan / qris	0	40	0	0	3059.66	318	\N	0
2117215615	0	vasco	0	0	0	0	0	1	\N	0
2075380857	0	shei	12	81	0	0	2397.4099999999985	1649	\N	0
5696254337	0	verli	1	151	0	0	12.519999999999996	692	\N	0
2083847694	0	eireen	0	6	0	0	0	13	\N	0
6215321534	0	nzlaaa	0	6	0	0	0	2	\N	0
5158920681	0	Fava isn't replying :|	0	28	0	0	0	15	\N	0
1667004674	0	isa 🍉	14	469	0	0	6.020000000001289	334	\N	0
6873427364	0	ta	0	16	0	0	0	2	\N	0
1689157466	0	kanjeng ratu	5	508	0	0	422.8799999999999	1486	\N	0
6086478904	0	Sarjana Bucin	6	100	1	0	19.680000000001428	605	\N	0
1508358122	0	PA. rara	0	2	0	0	0	1433	\N	0
1138599140	0	capa awr	9	199	0	0	659.1600000000001	701	\N	0
1343862641	0	Adelline E.	9	1300	0	0	45977.49000000005	25778	\N	1
6837318374	0	s, rbio	0	5	0	0	0	3	\N	0
6423280202	0	Erlan	0	2	0	0	0	0	\N	0
5648875132	0	ashaa	0	5	0	0	0	2	\N	0
832240096	0	Kw	0	2	0	0	0	3	\N	0
6484253821	0	næra on divinggg	0	1	0	0	0	40	\N	0
6026658334	0	juuullllyyyaaaa	10	180	0	0	894.76	115	\N	0
1808378857	0	iyell	0	1683	0	0	12.509999999999991	21	\N	0
6618848484	0	Zii	0	37	0	0	0	31	\N	0
5958422571	0	mel💓 cibukk	0	40	0	0	0	6	\N	0
2020028970	0	J	0	1	0	0	0	7	\N	0
7045429599	0	S.	0	2	0	0	0	4	\N	0
5068378096	0	Tera	14	493	0	0	10.61	924	\N	0
6987350756	0	fi	0	36	0	0	0	0	\N	0
5871248843	0	saaa	0	10	0	0	0	6	\N	0
818074367	0	ica	0	3	0	0	0	1	\N	0
6783290375	0	k	0	9	0	0	0	3	\N	0
6578972954	0	shAa 💥	0	20	0	0	18	150	\N	0
6243565847	0	Frank	0	29	0	0	397.16	95	\N	0
1724463708	0	u	0	1	0	0	0	0	\N	0
1467636546	0	Syalisya	0	10	0	0	0	10	\N	0
5072846020	0	Piraa	0	1	0	0	0	0	\N	0
1205406612	0	Vir.	0	4	0	0	0	8	\N	0
5475633835	0	meyy	0	7	0	0	11.43	49	\N	0
2015291108	0	kayana	0	46	0	0	0.5399999999999991	12	\N	0
6794505741	0	Vârshaa ࣪ ˖	0	36	0	0	33.94999999999999	3	\N	0
1712797074	0	Dudud	0	211	0	0	0	158	\N	0
6792276359	0	Mahesa	0	57	0	0	485	57	\N	0
5139680185	0	Hsna	0	1	0	0	0	1	\N	0
5028107313	0	majeyy	0	17	0	0	420.59	64	\N	0
2141886797	0	olin	0	87	0	0	0	314	\N	0
1620395105	0	faisss	0	1	0	0	0	2	\N	0
1386399548	0	rel	0	74	0	0	0	2	\N	0
5847095808	0	aza	0	158	0	0	0	211	\N	0
6868001575	0	jahe	0	61	0	0	0	14	\N	0
5956181483	0	shan	0	256	0	0	0	167	\N	0
5774768106	0	Lev	1	425	0	0	956.4900000000002	232	\N	0
5394058755	0	lion crimson	0	4	0	0	0	35	\N	0
1562752695	0	R’s Property, Anne.	0	1	0	0	0	5	\N	0
5314134129	0	Jill	0	48	0	0	0	387	\N	0
1680382768	0	jea	0	220	0	0	0	0	\N	0
5316762205	0	Rey.	0	1	0	0	0	11	\N	0
5970247498	0	jena	0	21	0	0	0	7	\N	0
2022426494	0	el	0	1	0	0	0	0	\N	0
6105047105	0	Tataa	0	7	0	0	0	33	\N	0
5868424145	3	sutt	0	65	0	0	0	12	\N	0
5184158238	2	ceyaaa #freddiedaughter.	0	74	0	0	0	22	\N	0
5222002367	1	y	1	2441	0	0	15.349999999998772	88	\N	1
1334619463	0	tataa🫧	7	2712	0	0	22676.950000000023	8960	\N	1
6964303366	0	Ciaa	0	19	0	0	0	158	\N	0
5739311643	2	y	0	261	0	0	0	0	\N	0
2057802110	0	marco	0	54	0	0	51.5	3731	\N	0
5016704859	0	mika seri	0	122	0	0	132.76	237	\N	0
5740741724	0	qwerty	0	3	0	0	0	0	\N	0
1846417587	0	Sunwoo's caretaker, Caith.	0	85	0	0	59.34	73	\N	0
483762895	0	aiya ᝰ	0	73	0	0	78.24	134	\N	0
5939946244	0	gasta.	4	122	0	0	5489.850000000001	4084	\N	0
1707771519	0	ajjaa	0	155	0	0	0.9400000000000048	259	\N	0
5313014990	0	aut	0	359	1	0	3.5400000000000205	60	\N	0
5593995129	0	Najieyl, C	0	1	0	0	0	0	\N	0
1630519610	0	cel	0	6	0	0	0	2	\N	0
2011750633	0	senior ai	0	59	0	0	129.97	277	\N	0
5583241944	0	fua	0	12	0	0	0	13	\N	0
5694835855	0	natalia . 😵‍😵‍	0	78	0	0	6.729999999999961	48	\N	0
6569785960	0	meri	0	604	0	0	12	23	\N	0
6560166874	0	saa	0	27	0	0	0	19	\N	0
5441887666	0	chaa	0	3	0	0	0	5	\N	0
1660834932	0	Ginia	0	2	0	0	0	0	\N	0
1676435925	0	Lenina gmud	0	2	0	0	0	3	\N	0
2001202260	0	Nat	0	2	0	0	0	1	\N	0
5116044185	0	anak bapak lo	0	149	0	0	0	5	\N	0
6186835035	0	jojo	0	1	0	0	0	0	\N	0
1761579481	0	Leonaa	0	1	0	0	0	0	\N	0
6601134465	0	alfarez	0	11	0	0	0	0	\N	0
5534205574	0	Alan	0	11	0	0	0	2	\N	0
7176766063	0	l	0	2	0	0	0	0	\N	0
5384977186	0	k.	6	73	0	0	7921.289999999997	383	\N	0
5080353218	0	jop!e	0	6	0	0	0	1	\N	0
1914417513	0	🤵🏻 oo	13	62	0	0	14469.310000000001	1731	\N	0
5209226128	0	sena	0	15	0	0	0	16	\N	0
1965509469	0	Janeima, R.	0	7	0	0	34.84	69	\N	0
1691365325	0	Annee	0	2	0	0	0	2	\N	0
5114491054	0	🙏🏻	0	6	0	0	0	0	\N	0
5175570219	0	zii	8	561	0	0	529.6099999999999	186	\N	0
5551416426	0	jipa	0	3	0	0	0	0	\N	0
1780793406	0	، yaya.	0	6	0	0	0	8	\N	0
6296994079	0	risma	0	70	0	0	24.810000000000002	54	\N	0
2112430130	0	Miyoo ♡!	0	11	0	0	0	0	\N	0
5612210119	0	.	0	1	0	0	0	0	\N	0
5220675851	0	c	0	4	0	0	0	2	\N	0
1375677910	0	d4vd.	0	64	0	0	1272.5	54	\N	0
5141544350	0	meyuraaa <3	0	185	0	0	176.44	640	\N	0
1491986480	0	Y A N N	0	3	0	0	0	2	\N	0
1815045956	0	...	0	1	0	0	0	0	\N	0
1056937436	0	Akasi	0	165	0	0	0	0	\N	0
6716492907	0	elis	3	148	0	0	-5.710000000000036	217	\N	0
6019615549	0	jena	0	1	0	0	0	0	\N	0
5496593054	0	Malganio L.	0	168	0	0	0	239	\N	0
1450745826	0	🤫	0	34	0	0	0	4	\N	0
1795901258	0	:<	0	0	0	0	0	0	\N	0
5149377644	0	Yo	0	1	0	0	0	4	\N	0
5374042801	0	dion suka slebew	0	2	0	0	0	90	\N	0
2102745384	0	maira	0	385	0	0	39	53	\N	0
6119453214	0	esha	0	148	0	0	1.449999999999818	147	\N	0
5004069993	0	K	0	249	0	0	2.09	152	\N	0
5256901673	0	Samudra	0	35	0	0	530.06	527	\N	0
5238124035	0	¢нαяℓσттє 🧚🏻‍♀️	0	7	0	0	9	108	\N	0
6408090360	0	E, Raya 🕷️(if i don’t reply, it means i’m asleep😴)	0	3	0	0	0	0	\N	0
5510369253	0	kaersha	13	71	0	0	1230.59	288	\N	0
6826932600	0	Lala	13	48	0	0	0	7	\N	0
6784512888	0	Danielle Areneth	0	7	0	0	0	34	\N	0
6809762990	0	fiaa	0	1	0	0	0	0	\N	0
1291425592	0	𝐀	0	2	0	0	0	12	\N	0
1881224531	0	d	0	1	0	0	0	0	\N	0
7011941671	0	Reno	0	2	0	0	0	1	\N	0
1932049340	0	forger	0	54	0	0	0	4	\N	0
7169978684	0	aël	0	6	0	0	0	14	\N	0
6756396292	0	n	0	33	0	0	84	16	\N	0
2044944783	0	Annalyne N.	0	242	0	0	12.939999999999998	280	\N	0
7185748464	0	kodok mlotot	0	36	0	0	10.68	0	\N	0
1805962182	0	fiyaa	9	5	0	0	33.88999999999987	17	\N	0
1366767874	0	zakeisha	2	249	0	0	3221.98	383	\N	0
1660291797	0	Arshen D.	0	1	0	0	0	0	\N	0
2066745382	0	mochi almoerra	0	35	0	0	0	9	\N	0
1892612821	0	iii	0	211	0	0	1395.5	108	\N	0
1888938336	0	𝐍iah Pending	0	5	0	0	0	2	\N	0
7132306964	0	nana sayang meong	0	0	0	0	0	1	\N	0
6900511637	0	nabeyla	0	109	0	0	109.25999999999999	280	\N	0
6822955743	1	Samuel	0	36	0	0	0	1	\N	0
2016742471	1	ア	12	330	0	0	1643.7600000000002	623	\N	1
6568584058	1	𝐽𝑒𝑛𝑛𝑖𝑓𝑒𝑟 𝐶ℎ𝑎𝑛	0	241	0	0	13	128	\N	0
5407690322	1	abe	13	371	0	1	5	201	\N	0
1325170875	0	nan	0	15	0	0	0	450	\N	0
1735975282	0	melll 🆖🆎	0	114	0	0	180.54000000000002	13	\N	0
5498738868	0	kunn`cart!erz	0	6	0	0	0	70	\N	0
1812880748	0	ashaa	10	160	0	0	1327.0200000000004	195	\N	0
5801529486	0	...	0	387	1	0	411.6100000000002	229	\N	0
7016801041	0	Maia	0	1	0	0	0	1	\N	0
5384187569	0	acaayyy anak bundaa	0	2	0	0	0	1	\N	0
7120120937	0	incess abellbell	0	2	0	0	0	2	\N	0
6830015681	0	cateen	0	3	0	0	0	0	\N	0
6931504853	0	𐙚˙.. raraa	0	43	0	0	488.5	956	\N	0
6136598563	0	n	0	93	0	0	0	13	\N	0
6986053223	0	renn	0	29	0	0	0	0	\N	0
5176871177	0	Cici.	4	671	0	0	120.66000000000003	579	\N	0
975377626	0	Karine close	0	41	0	0	0	157	\N	0
1190903208	0	Ti	0	5	0	0	0	1	\N	0
6777455298	0	Voca	0	18	0	0	0	31	\N	0
5516348773	0	syire	11	1090	0	0	649.19	672	\N	0
7053248741	0	kiara	0	3	0	0	0	1	\N	0
6745929829	0	araa pecinta hoshino	0	124	0	0	0	4	\N	0
1922523804	0	Jeranfa	5	16	0	0	3459.92	2744	\N	0
5917854691	0	🦹	0	15	0	0	0	24	\N	0
6031827917	0	lpm sfs	0	5	0	0	2.13	0	\N	0
5330897072	0	Hihoo	0	8	0	0	0	21	\N	0
1735661455	0	el	0	461	0	0	6	190	\N	0
6209270823	1	k.	0	632	0	0	11.30999999999949	704	\N	0
1230036097	2	riri	8	800	0	0	3.549999999999045	1225	\N	0
6139823464	0	Ezz	0	71	0	0	28.139999999999986	221	\N	0
5215929373	0	namamu	0	2	0	0	0	0	\N	0
6650865594	0	nicole	0	2	0	0	0	1	\N	0
5989872810	0	nalaka	0	5	0	0	0	6	\N	0
5400071306	0	azawa	0	2	0	0	0	0	\N	0
6308940661	0	Çy ėx	0	6	0	0	0	9	\N	0
5196316674	0	adel	0	1	0	0	0	29	\N	0
2047983476	0	rachel salimahvl	11	170	0	0	1416.8099999999997	304	\N	0
1945689171	0	na	0	50	0	0	0	0	\N	0
6399451676	0	Aluna	9	4	0	0	1729.3800000000006	2284	\N	0
1477553814	0	Leviiiii	0	26	0	0	0	8	\N	0
5003454675	0	Bobby	0	1	1	0	0	0	\N	0
6839615377	0	u	0	13	0	0	0	8	\N	0
1739248046	0	Joi	7	503	0	0	250.84999999999997	1300	\N	0
6855228402	0	Lija	0	7	0	0	0	1	\N	0
1670204326	0	rembulan	6	116	0	0	8.869999999999905	7	\N	0
1751421794	0	v	0	102	0	0	459.83	200	\N	0
5488603590	0	st. R-LL	0	3	0	0	0	3	\N	0
5457924435	0	putri	0	105	0	0	1149.9	553	\N	0
5016575756	0	sasaa	0	240	0	0	0	2	\N	0
6825038863	0	powerejher	0	15	0	0	30.17	27	\N	0
1136675286	0	Fadil	0	304	0	0	3485.0299999999997	3051	\N	0
5292190051	0	victor's gf, elle	0	85	0	0	2296.78	2991	\N	0
1343786012	0	far	5	954	0	0	153.04000000000005	1452	\N	0
5412472900	0	𝒥ᥱ⍴ᥲᥲᥲ ! 𐙚᪾֬	8	986	0	0	13.970000000000255	879	\N	0
1467236360	0	Julie	0	41	0	0	0	83	\N	0
7005410453	0	jeri	0	1	0	0	0	29	\N	0
1555434315	0	V	0	19	0	0	0	19	\N	0
1906773425	0	arin	4	499	0	0	3.960000000000015	443	\N	0
6412017510	0	asa :/	0	102	0	0	25.69999999999999	195	\N	0
7114611957	0	Azelio	0	6	0	0	0	1	\N	0
6008421379	0	Jean dElune.	0	51	0	0	5.599999999999994	645	\N	0
6371685385	0	ciflies	0	4	0	0	0	3	\N	0
5915815895	0	aurell 𐙚	3	488	0	0	2429.8499999999995	6856	\N	0
6497224750	0	biela	0	3	0	0	0	21	\N	0
5330576291	0	diyaa	0	399	0	0	808.6799999999996	1339	\N	0
2104551732	0	janné	0	53	0	0	396.31	335	\N	0
2090497982	0	Mommy. Seller Teleprem	0	77	0	0	42.74000000000001	171	\N	0
1750761677	0	abi	0	38	0	0	14.520000000000003	517	\N	0
5070287568	0	bila.	0	1958	0	0	1432.64	1145	\N	0
2034268378	0	isaaa 🎩	0	132	0	0	0	676	\N	0
5640551941	0	DNI, Ayesha.	0	165	0	0	0	3	\N	0
6116312126	0	Moses Manuel @mMoses	0	1	0	0	0	0	\N	0
5440118229	0	Dèn Limit cukimai	0	12	0	0	0	9	\N	0
5277836573	0	Ratar	0	4	0	0	0	60	\N	0
1847435083	0	.	0	5	0	0	0	2	\N	0
2070243620	0	caca	0	6	0	0	0	8	\N	0
1848501163	0	niu	0	99	0	0	17.939999999999984	456	\N	0
5607136509	0	yoi	0	20	0	0	78.62	20	\N	0
1994967300	0	Sam.	0	3	0	0	0	60	\N	0
1617335068	0	Deline	0	17	0	0	0	0	\N	0
6076859704	0	cj	0	1	0	0	0	0	\N	0
1647665033	0	ance	0	6	0	0	0	0	\N	0
5423598773	0	z	0	10	0	0	0	234	\N	0
5787794247	0	!!	0	3	0	0	0	0	\N	0
5567757665	0	kazira	0	46	0	0	39	15	\N	0
6664293493	0	Axe	0	0	0	0	0	0	\N	0
5518060125	0	.	0	10	0	0	0	1	\N	0
6914859682	0	aliya	0	5	0	0	0	0	\N	0
6297315214	0	Bella	2	324	0	0	4210.23	13827	\N	0
1879368187	0	bajii	0	0	0	0	482.67999999999995	2415	\N	0
1704915562	1	Belleza, vogos	0	51	0	0	0	203	\N	0
1874172943	0	00.	0	0	0	0	0	0	\N	0
6960855572	0	.	0	67	0	0	0	5	\N	0
1333740775	0	will	0	59	0	0	0	29	\N	0
1966817922	0	ayyaa	0	3	0	0	0	1	\N	0
6222406663	0	ㅤㅤㅤ	13	389	0	0	8.81000000000006	85	\N	0
1662765279	0	el	0	10	0	0	8.56	22	\N	0
6159582421	0	Aca	9	7	0	0	912.64	16	\N	0
7013386033	0	whoOsh Ell	0	1	0	0	0	4	\N	0
5488863853	0	࣪୨୧ ayäa ⊹ ˖ ་ 🍬	10	370	0	0	3876.0300000000007	96	\N	0
5509817548	0	༄●⃝𝒜t~	11	97	0	0	87.28999999999999	92	\N	0
5277307152	0	Sadam'w	0	203	0	0	1.8599999999999781	1514	\N	0
1878397778	0	響bskra	0	185	0	0	1.1700000000000017	59	\N	0
2058495058	0	jee ݂ ⁺ 💤	0	1	0	0	0	0	\N	0
5147744352	0	Caysha Esté	0	29	0	0	408.52	11	\N	0
6857745747	0	niya	0	5	0	0	0	2	\N	0
6130215072	0	huft	0	3	0	0	0	0	\N	0
5696330842	0	z	0	12	0	0	0	412	\N	0
5686123119	0	mw gk jd pcr ku	0	31	0	0	57.43	8	\N	0
1300555740	0	.	0	10	0	0	0	0	\N	0
5126844540	0	Who tf r u?	0	2	0	0	0	1	\N	0
5135425915	0	javian	0	46	0	0	0	1	\N	0
6467457398	0	naeva	0	2	0	0	0	3	\N	0
1690541005	0	Amourá K.	0	2	0	0	0	2	\N	0
6138386380	0	ptcyyyy	0	4	0	0	21.83	1	\N	0
7044557089	0	— ellè lyonerè	0	7	0	0	0	3	\N	0
5859268412	0	Akun Terhapus	0	3	0	0	0	0	\N	0
1801142535	0	damn	0	8	0	0	0	9	\N	0
1686635041	0	cici	0	0	0	0	0	25	\N	0
1973909036	0	Shabiraa	0	29	0	0	0	40	\N	0
802048004	0	n	0	1	0	0	0	0	\N	0
1303039092	0	Dn	0	281	0	0	92	109	\N	0
1968311884	0	Jinhyeong	0	343	0	0	0	408	\N	0
2062364017	0	klye	0	2	0	0	0	0	\N	0
1164178796	0	Ok	0	30	0	0	0	12	\N	0
1875915743	0	SHERiNA!	0	6	0	0	0	3	\N	0
6652881101	0	Wira starboi	0	0	0	0	0	3	\N	0
5304793631	0	jen	0	1	0	0	0	6	\N	0
1778996467	0	ᰔ ꫀׁׅܻᨮ꫶ׁׅ֮ꪱׁׅꪀׁׅ	11	2	0	0	1.5	19	\N	0
7048596796	0	joe	0	1	0	0	0	1	\N	0
1618864685	0	Acaa	0	123	0	0	413	208	\N	0
5549515038	0	dillalapooh 🚩	0	568	0	0	2.9099999999999966	284	\N	0
5456397282	0	ꜱᴄᴀɴᴅᴀʟ. manuel	0	12	0	0	0	0	\N	0
6041270214	0	ellaabigail	0	2	0	0	0	9	\N	0
5556916549	0	Si d	2	162	0	0	0	56	\N	0
1941699802	0	j	0	43	0	0	0	5	\N	0
2095003821	0	putt	0	0	0	0	0	2	\N	0
6225679748	0	𝓐	0	0	0	0	0	0	\N	0
1653233600	0	Pangeran	0	103	0	0	2508.25	5616	\N	0
6139693280	0	A Mahesa	0	1	0	0	0	0	\N	0
5837977782	0	Chelsea	0	98	0	0	0	22	\N	0
6634956853	0	adind	0	32	0	0	0	44	\N	0
5751078805	0	mochie	0	89	0	0	477.70000000000005	378	\N	0
5483209647	0	Antoine Griezmann	0	123	0	0	250	83	\N	0
1062161705	0	~	0	1	0	0	0	1	\N	0
6548474727	0	rui	0	2	0	0	0	0	\N	0
7071545196	0	syerray	0	1	0	0	0	0	\N	0
1551089488	0	Sherina	0	3	0	0	0	1	\N	0
2090565870	0	𖢻s. cinta jay	0	12	0	0	0	144	\N	0
6903280167	0	Janey J	0	1	0	0	0	0	\N	0
1887865361	0	︎	0	3	0	0	0	2	\N	0
1182209361	0	mr.jv	0	100	0	0	31.299999999999997	232	\N	0
6217816720	0	nawa 🫧🪸	0	1	0	0	0	0	\N	0
6437844133	0	ci🎸	0	4	0	0	0	33	\N	0
5371873887	0	tomy	0	0	0	0	0	1	\N	0
1871747501	0	langit.	0	4	0	0	0	48	\N	0
1876377031	0	jendrich	0	3	0	0	0	0	\N	0
1349764062	0	$	0	335	0	0	56.76999999999998	149	\N	0
1855637394	0	ghea gjd galau	0	21	0	0	0	15	\N	0
1657243270	0	aku kisha	8	1	0	0	765.64	375	\N	0
5195300446	0	2	0	116	0	0	22.880000000000067	187	\N	0
5177891229	0	ㅤㅤ	0	64	0	0	0	104	\N	0
5610342564	0	d’ harveist - ciwa #pending	0	1	0	0	0	0	\N	0
5983746500	0	x	0	2	0	0	0	0	\N	0
6712946815	0	Arr.	0	114	0	0	313.5400000000001	515	\N	0
2013640332	1	kalea 𐙚	0	897	0	0	58.039999999998486	3029	\N	0
101trend	0	3300157	\N	\N	\N	0	\N	\N	\N	\N
5608493682	0	Natta	0	1	0	0	0	0	\N	0
1365955940	0	logout	0	47	0	0	211.93	5	\N	0
5051476465	0	You know who	0	17	0	0	0	2	\N	0
5368015896	0	j selective	0	1	0	0	0	0	\N	0
1820739549	0	K.	0	47	0	0	30.129999999999995	56	\N	0
5819174159	0	zori	0	2	0	0	0	1	\N	0
1496534845	0	?	0	36	0	0	0	34	\N	0
5213761024	0	putraaa	0	7	0	0	0	25	\N	0
5411495354	0	Shankara	0	3	0	0	0	9	\N	0
1773861979	0	anysz	0	8	0	0	0	85	\N	0
1744356365	0	holeshit	0	21	0	0	93	0	\N	0
5523171280	0	Bel	0	4	0	0	0	3	\N	0
5157592538	0	cesar	0	3	0	0	0	6	\N	0
1728694210	0	#RBG gintara maura	0	0	0	0	0	10	\N	0
1316440430	0	Wanda.	0	1	0	0	0	1	\N	0
6651714626	0	Melody Cassiopeia.	0	5	0	0	0	32	\N	0
5025040363	0	giandra	0	12	0	0	0	0	\N	0
5519875225	0	🐰𖦹 ࣪˖ alisã ‹𓈒໑.	0	3	0	0	0	31	\N	0
1720725083	0	Ben	0	2	2	0	0	1	\N	0
6295607357	0	alynᵃˡˡᵛ	0	16	0	0	0	4	\N	0
5912948950	0	Anan	0	2	0	0	0	0	\N	0
6617408866	0	v	0	10	0	0	0	17	\N	0
5880684744	0	elenaa	0	1	0	0	0	0	\N	0
6005531062	0	ʙᴡōʟғ || Haidar B.	0	0	0	0	0	1	\N	0
5309176463	0	ley	0	1	0	0	0	0	\N	0
6724547936	0	zael	0	12	0	0	756	208	\N	0
2109856730	0	cey	1	384	0	0	1475.4999999999998	6516	\N	0
1849899695	0	piol lg galau	0	3	0	0	15.95	4	\N	0
1622420230	0	wafiya.	0	0	0	0	0	11	\N	0
6032336950	0	Jasmine	0	1	0	0	0	55	\N	0
5144847066	0	{𖦞}..𝐆emora 𝐄leanor	0	4	0	0	0	6	\N	0
6168222055	0	paanseh	0	2	0	0	0	0	\N	0
2101158579	0	naren	0	4	0	0	0	4	\N	0
5373118020	0	dionyuosus	0	0	0	0	21.1	2	\N	0
6486944391	0	ꞌꞋꞌ 💭 𖦆 [ zeva ] ♡ ࣪˖	0	0	0	0	0	11	\N	0
1472411300	0	Mauw (Taylor's Version)	0	37	0	0	0	0	\N	0
5881178784	0	Bran	0	5	0	0	0	0	\N	0
1812423110	0	jarren, dni.	0	1	0	0	0	0	\N	0
6517108342	0	ocellyne	0	0	0	0	0	0	\N	0
6977195565	0	Oq	0	47	0	0	2113	9	\N	0
5925560729	0	Kiel	0	2	0	0	0	1	\N	0
6109042630	0	ibbie	6	21	0	0	369.8900000000001	69	\N	0
6049469878	0	Hasanah	0	1	0	0	0	0	\N	0
6807227649	0	D' Jhaylènce	0	27	0	0	0	4	\N	0
1966010206	0	Nebūla S.	0	5	0	0	102.13	7	\N	0
1939016165	0	alnaraa	0	1	0	0	0	3	\N	0
1679040249	0	𝑹𝒖𝒃𝒚	0	127	0	0	42.7	220	\N	0
1497952349	0	zhar`	0	8	0	0	0	6	\N	0
5713146727	0	Hazel	0	1	0	0	0	0	\N	0
1294904318	0	Latevhia	0	1	0	0	0	0	\N	0
5339022096	0	oliv	0	12	0	0	0	11	\N	0
6207385811	0	ca	0	11	0	0	13.42	24	\N	0
5214999715	0	trainwreck	0	1	0	0	0	0	\N	0
1893962544	0	Jazilah A	0	2	0	0	0	48	\N	0
5455248967	0	zel	7	761	1	0	0.24000000000023647	485	\N	0
5058041026	0	lily slr	0	447	0	0	7.4500000000000455	155	\N	0
6506202738	0	olaa	0	85	0	0	12.670000000000016	516	\N	0
1892408241	0	Samantha i'vs	0	3	0	0	0	9	\N	0
1869098962	0	rest	0	19	0	0	0	0	\N	0
6538221422	0	zura @exilophile	0	80	0	0	21.470000000000255	1964	\N	0
5893621242	0	rbio	0	22	0	0	83.24000000000001	8	\N	0
5265203257	0	na	0	219	0	0	61.540000000000035	92	\N	0
5792129343	0	zay🅰ya	0	1	0	0	0	0	\N	0
6433449758	0	Hanggala Sadewa.	0	144	0	0	0	16	\N	0
1845818011	0	herlos jack	0	4	0	0	0	0	\N	0
5804816171	0	Ayrshire C. Linares	0	8	0	0	0	11	\N	0
1608462597	0	L	0	150	0	0	0	167	\N	0
1855926934	0	athaya	0	64	0	0	0	42	\N	0
6000008290	0	KJ	0	120	0	0	0	371	\N	0
7150995896	0	ji	0	11	0	0	0	324	\N	0
6274807907	0	awr. chii sunghoon's mate	10	298	0	0	7101.840000000001	748	\N	0
6837173693	1	Dante.	0	63	0	0	0	93	\N	0
1850067635	0	fy	0	7	0	0	380	230	\N	0
6968920427	1	tata	0	58	0	0	4.060000000000002	180	\N	0
6513386520	0	ibel	0	31	0	0	0	83	\N	0
6065995460	0	𝐕isyà	0	59	0	0	456	81	\N	0
2091740203	0	𖥻 155 rendaa	0	244	0	0	-14	72	\N	0
1943021180	0	lili	0	258	0	0	12.990000000000002	1	\N	0
1797417773	0	macala	0	13	0	0	0	19	\N	0
1884708519	0	mii	0	21	0	0	1485	1	\N	0
6604009176	0	je	0	21	0	0	0	21	\N	0
6136016369	0	⑅ 🎀⃝ 𓈒 ۫ ad𖣠ryable efloiRye ౨ৎ ˖ ࣪⊹	0	1	0	0	0	3	\N	0
1924786827	0	𐙚 .. Swanlake! 🦢🩰	0	2	0	0	0	0	\N	0
6835283274	0	Jijel	0	6	0	0	0	4	\N	0
5833439834	0	asha	0	3	0	0	11.830000000000013	0	\N	0
1972197242	0	Lala	0	12	0	0	0	17	\N	0
1408843767	0	ay	0	34	0	0	0	102	\N	0
2075673223	0	Nichole	0	808	0	0	2320.459999999999	356	\N	0
5867407047	0	Sauqi drxt²	0	3	0	0	0	0	\N	0
6509582519	0	owii off	12	17	0	0	160.19	369	\N	0
6139469787	0	kei	0	16	0	0	0	30	\N	0
5971826112	0	salwa — jaemin's lovetaker.	0	12	0	0	0	3	\N	0
1961013959	0	faith	0	13	0	0	91.32000000000001	3	\N	0
5621458856	0	rey	0	101	1	0	646.74	629	\N	0
1613461915	0	r	0	53	0	0	6.340000000000032	555	\N	0
6561879279	0	vanka	0	1	0	0	0	1	\N	0
5124264956	0	Slayer	0	3	0	0	0	8	\N	0
5197037116	0	kay	0	576	0	0	976.6999999999998	3431	\N	0
6956174846	0	claudiä	0	1	0	0	0	0	\N	0
6715530497	0	iSAAA	0	172	0	0	2.9200000000000728	0	\N	0
5082003107	0	a	9	185	0	0	75.12	0	\N	0
5883145773	0	el	0	27	0	0	0	3	\N	0
6398479385	0	Khaél.	7	5	0	0	444.74000000000024	233	\N	0
6413904608	1	princess 😼 tidur	0	53	0	0	88.41	38	\N	0
1725750342	1	jac	0	235	0	0	1.7299999999999613	1376	\N	0
2027549261	1	carrie	0	1071	0	0	10.32000000000005	466	\N	0
5247176699	0	Nayasha toblut awr	12	728	0	0	12.319999999999709	1279	\N	0
5020389442	0	yayaya	0	55	0	0	0	1	\N	0
6562035316	0	zaa	7	349	0	0	960.79	439	\N	0
7170597695	0	R. Esha	0	1	0	0	0	8	\N	0
6249726850	0	⁉️	0	19	0	0	0	58	\N	0
1813799423	0	ecii	0	13	0	0	0	4	\N	0
1748216564	0	Jay. Tzuyu bf	0	14	0	0	0	31	\N	0
5268431109	0	Raraw	13	6936	0	0	2969.459999999981	3519	\N	0
1457267790	0	tr	0	3	0	0	0	0	\N	0
6259597678	0	Farrel	0	14	0	0	0	7	\N	0
1300113960	0	Donatur kampus	0	1	0	0	0	74	\N	0
5270282150	0	ki	0	22	0	0	0	0	\N	0
5845199173	0	mie gundul	0	0	0	0	0	0	\N	0
6511013096	0	a	0	14	0	0	134.48	59	\N	0
6010449599	0	acong	0	3	0	0	0	6	\N	0
5903236027	0	Yuann	0	51	0	0	13.430000000000007	13	\N	0
1612584279	0	Élora	11	474	0	0	680.92	232	\N	0
889504221	0	𝓝ærä	0	45	0	0	0	41	\N	0
1829115999	0	agatha.	0	95	0	0	1364.5600000000002	1912	\N	0
1164803550	0	Fjri	0	9	0	0	0	0	\N	0
5991729450	0	V	0	218	0	0	0	105	\N	0
6402115509	0	C	0	20	0	0	0	0	\N	0
1699229888	0	Everlyn return @wyounjung please	0	0	0	0	0	0	\N	0
1422191752	0	' Nao Mizuki ッ	0	157	0	0	955.5899999999999	1376	\N	0
1425703525	0	𐙚	5	921	0	0	2805.0799999999995	1974	\N	0
6209773186	0	ael	2	254	0	0	1496.67	505	\N	0
1776164323	0	j	0	4	0	0	0	0	\N	0
1970933955	0	luva	0	3	0	0	0	0	\N	0
834447627	0	JH.Purba	0	6	0	0	82.29	0	\N	0
5767193948	0	Davien #dni	0	81	0	0	10.1	4	\N	0
1819797748	0	lilalala	0	5	0	0	0	1	\N	0
5394547413	1	ㅤ	0	206	0	0	0	82	\N	0
5947369797	0	na lotraeen	0	8	0	0	0	12	\N	0
5695182364	0	biya	0	12	0	0	0	49	\N	0
1440909214	0	aowowowkaowkw	4	870	0	0	311.1699999999999	7197	\N	0
5962100588	0	arin	0	5	0	0	0	0	\N	0
1768164429	0	Bargiovan`ʳᶜᵃᶠᵉ	0	0	0	0	0	0	\N	0
5647480823	0	L	0	3	0	0	0	31	\N	0
1681481698	0	well	0	128	0	0	0	207	\N	0
6908840755	0	piraa.	0	35	0	0	0	53	\N	0
5595634363	0	el	0	536	0	0	246.9000000000001	1599	\N	0
5959782038	0	karin	0	86	0	0	753.3	134	\N	0
1184156955	0	Jo.	1	310	0	0	3508.0899999999983	8201	\N	0
5986816790	0	dian	0	85	0	0	0	125	\N	0
6887616755	0	cipa	0	86	0	0	0	133	\N	0
7159598954	0	slctv.zoy	0	7	0	0	0	9	\N	0
6771699391	0	-	0	23	0	0	0	29	\N	0
7168455074	0	tessa	0	53	0	0	0	16	\N	0
6404934253	0	irene	0	12	0	0	0	134	\N	0
5202963224	0	Dieztramora.	0	297	0	0	4.190000000000005	214	\N	0
1811634720	0	666	0	2	0	0	0	5	\N	0
5465747328	0	<bibi3	0	6	0	0	0	403	\N	0
5173209227	0	k	0	8	0	0	0	0	\N	0
6787249591	0	Star's	0	2	0	0	0	1	\N	0
1735248704	0	jepii	0	61	0	0	0	258	\N	0
6229009289	0	ディップ	0	39	0	0	1000	532	\N	0
6150960478	0	YB -𝑺𝑵	0	0	0	0	0	0	\N	0
5321293973	0	aaren	4	16	0	0	624.01	1019	\N	0
7123236622	0	k	0	38	0	0	0	0	\N	0
1330242444	0	Reynold	0	11	0	0	0	38	\N	0
1687555801	0	Raine. 🐢 🐢 🐢	0	22	0	0	0	2	\N	0
5516963443	0	Geneva Patricia	0	54	0	0	0	307	\N	0
6705440257	0	🇺🇸	0	78	0	0	0	2	\N	0
981248110	0	lyn	0	122	0	0	0	187	\N	0
5153007352	0	yola	0	70	0	0	115	426	\N	0
1269407300	0	airrrra	0	1	0	0	0	0	\N	0
6563782470	0	Kylie	0	132	0	0	7.109999999999999	380	\N	0
6629789771	0	abil	0	6	0	0	0	72	\N	0
2069867200	0	cenil bjir	0	0	0	0	0	0	\N	0
5936179159	0	abel	0	4	0	0	0	48	\N	0
6194593893	0	.	0	62	0	0	0	0	\N	0
6362837317	0	r	0	1	0	0	0	1	\N	0
1729882684	0	Suzhou	0	12	0	0	0	32	\N	0
2071051146	0	.	0	11	0	0	109.00999999999999	37	\N	0
5476359502	0	S currently died	9	274	0	0	7.670000000000002	995	\N	0
5451472438	1	fan	9	517	0	1	1001.9300000000001	439	\N	0
7098614442	0	ruby	6	348	0	0	610.1299999999999	6755	\N	0
1421598316	0	grotesque	0	133	0	0	9.630000000000003	530	\N	0
6907432757	0	𝔠𝔩𝔱 Saddam.	0	6	0	0	60.2	201	\N	0
6897004063	0	gaaaEl	12	12	0	0	0	325	\N	0
6044718257	0	Nat.	0	1	0	0	0	0	\N	0
6526703236	0	bebej	0	1	0	0	0	4	\N	0
2036000032	0	: NNN	0	15	0	0	0	0	\N	0
6621820058	0	skayfilo 🇺🇳	0	12	0	0	0	6	\N	0
1750765099	0	.	0	79	0	0	1.519999999999996	142	\N	0
1451955313	0	.	0	139	0	0	0	77	\N	0
1352280638	0	vgas	0	5	0	0	0	84	\N	0
1634839928	0	j	0	1	0	0	0	0	\N	0
1891983698	0	riri	4	502	0	0	1370.94	1509	\N	0
1888399141	0	Lore	0	21	0	0	918	102	\N	0
6297230058	0	Anggita	0	71	0	0	0	0	\N	0
5780815769	0	Zahwa	0	7	0	0	0	3	\N	0
6212118892	0	soocon ᴴᴸ	0	119	0	0	924.46	2243	\N	0
6048785146	0	Gerrick M	7	856	0	0	1813.5899999999997	764	\N	0
7098593132	0	.	0	75	0	0	0	2	\N	0
6170008518	0	keith	0	38	0	0	0	14	\N	0
5832457497	0	J	0	427	0	0	407	1	\N	0
5077194618	0	rea	0	37	0	0	0	2	\N	0
6904689375	0	kael	0	2	0	0	0	0	\N	0
2037732381	0	jeRaN	0	1	0	0	0	0	\N	0
1852342793	0	cy	0	2	0	0	78	4	\N	0
6916822271	0	s	0	2	0	0	0	0	\N	0
1635101196	0	je	0	23	0	0	0	0	\N	0
834036567	0	cey, off	0	7	0	0	998.25	180	\N	0
1904977915	0	swf	0	3	0	0	0	0	\N	0
5979710245	0	balss	0	18	0	0	0	37	\N	0
2004820219	0	b	0	542	0	0	6.169000000000011	252	\N	0
6288595631	0	Yan.	5	755	0	0	14.060000000000855	11252	\N	1
1658175749	0	g	0	25	1	0	0	12	\N	0
5210416434	0	alora only	0	6	0	0	0	26	\N	0
5890730224	0	іᥴᥱᥣᥣᥱ #८૯૭ɿՆՐคɿҺคՈ	0	59	0	0	0	22	\N	0
1787252622	0	-na	0	390	0	0	0	17	\N	0
1866271976	0	biel nastar	0	3	0	0	0	3	\N	0
6937997990	0	Z	0	5	0	0	0	0	\N	0
5386961837	0	t	0	6	1	0	0	1	\N	0
6911030156	0	rrr	0	11	0	0	0	3	\N	0
5904170157	0	cgx neii awr	0	5	0	0	0	0	\N	0
7089911888	0	percy	0	15	0	0	0	5	\N	0
5075175632	0	abe	9	298	0	0	2082.879999999984	8625	\N	0
5890989892	0	khalid	11	117	0	0	2742.1899999999996	267	\N	1
6674578938	0	a @E20liveE	0	58	0	0	5.719999999999999	104	\N	0
2001790316	0	Kylie	0	2	0	0	0	0	\N	0
6921482881	0	temp. shaolin	0	1	0	0	0	17	\N	0
5035954169	0	lie	8	208	0	0	1088.0299999999997	206	\N	0
5876132111	0	Janne	0	16	0	0	380	24	\N	0
6206592360	0	meiraa foneliee	0	1	0	0	0	0	\N	0
5501902715	0	𝐍a	0	4	0	0	61.36	115	\N	0
2076549377	0	raaisa🐇	0	113	0	0	0	334	\N	0
1719198242	0	deja	0	87	0	0	0	16	\N	0
6289355690	0	Sha	0	14	0	0	0	13	\N	0
5240122335	0	caca	11	555	0	0	2469.38	927	\N	0
5944281051	0	cenna	0	89	0	0	0	23	\N	0
6432801540	0	nay	0	19	0	0	0	64	\N	0
7022170201	0	?	0	5	0	0	0	0	\N	0
1899172623	0	Millie	0	81	0	0	0	7	\N	0
1923487269	0	Lisya	0	7	0	0	0	4	\N	0
1716002778	0	olie	0	231	0	0	11.179999999999964	334	\N	0
1461808351	0	Dark	0	2	0	0	0	0	\N	0
5114720863	0	Na	0	1	0	0	0	0	\N	0
1455219371	0	a	14	207	0	0	6.8700000000000045	107	\N	0
6551633164	0	gabriel	0	30	0	0	0	60	\N	0
1732932961	0	cum to my heart	0	77	0	0	615.3399999999998	169	\N	0
1841087938	0	sheesian	0	405	0	0	3378.91	117	\N	0
7043661909	0	utiii	0	106	0	0	0.9799999999999969	309	\N	0
1870077065	0	nollaaaaa gx suka sagu	2	219	0	0	400	224	\N	0
6368318402	0	zee 👀	0	2	0	0	0	0	\N	0
5062449259	0	rimuru	0	201	0	0	141.75	872	\N	0
6810148877	0	adis	0	8	0	0	123.29999999999978	48	\N	0
1715730345	0	kale	0	7	0	0	0	9	\N	0
5483284574	0	Just call me Xa pundung sama sinyal	0	6	0	0	0	18	\N	0
1895841566	0	kinaraa	0	500	0	0	11.630000000000535	354	\N	0
5967721129	0	lana del	0	28	0	0	229.6200000000001	20	\N	0
2011075688	0	ecca	0	59	0	0	7	3	\N	0
6738641301	0	calysie #GZ	0	45	0	0	0	6	\N	0
5091754879	0	shà	0	144	0	0	0	260	\N	0
6392742513	0	kiyomi	0	41	0	0	0	12	\N	0
5811418544	0	Erika.	0	11	0	0	0	0	\N	0
6247456706	0	Lien	0	276	0	0	7.990000000000194	198	\N	0
6246920603	0	kia	0	131	0	0	102.85	761	\N	0
1380351463	0	Vivi 🎐	13	1326	0	0	528.7999999999995	9583	\N	1
6849988144	0	papi choli	0	95	0	0	16.860000000000014	119	\N	0
6090215945	0	Law's Wife, Acel Portd.	0	126	0	0	0	0	\N	0
6455665491	0	Jeslyn	0	39	0	0	285	7	\N	0
1383136632	0	ocyy	10	3610	0	0	3.5899999999990513	889	\N	1
6596637240	0	idol koreyah	0	71	0	0	9	9	\N	0
1787260023	0	i <3ing kanekii #martelno2	11	351	0	0	19.500000000000426	666	\N	0
5476102260	0	Af.	0	5	0	0	0	9	\N	0
5419478686	3	ale	2	781	0	0	1086.5600000000004	409	\N	0
2094083310	1	⋆⋆ Amey	9	1854	0	0	24858.040000000026	1708	\N	1
5467829945	0	elen	0	67	0	0	0	2	\N	0
1731303261	0	dina	0	639	0	0	3.7000000000001307	119	\N	0
5645744359	0	hayzel	0	6	0	0	0	12	\N	0
6274008292	0	peter	0	74	0	0	0	0	\N	0
1979608504	0	yippe	0	1	0	0	0	0	\N	0
6662202915	0	pipi sayang hapiddd	0	57	0	0	0	106	\N	0
5404976967	0	Jo's baby	0	53	0	0	0	2	\N	0
2041663222	0	Rᴷⁱᵐᴰᵃʰʸᵘⁿ GléanzAa,	0	35	0	0	0	46	\N	0
5512939376	0	rest.	0	117	0	0	245.36	235	\N	0
1647765977	0	𝐂𝐚𝐬𝐬𝐢𝐚 𝐀.	0	4	0	0	0	2	\N	0
1666412500	0	fer	0	4	0	0	100	9	\N	0
1856053107	0	aze	0	203	0	0	0	15	\N	0
5196243006	0	ruecant dymersech	0	2	0	0	0	0	\N	0
6866480034	0	lost	0	8	0	0	0	0	\N	0
1885862858	0	dara	0	480	0	0	990	13	\N	0
6450030295	0	j	0	40	0	0	0	75	\N	0
6145891204	0	Rifki	0	1	0	0	0	1	\N	0
5625449829	0	js	0	32	0	0	4.119999999999806	203	\N	0
1963963233	0	cacaa	0	42	0	0	0	1	\N	0
1301278632	0	lil angel, Alaia.	3	283	0	0	282.74	75	\N	0
6268248868	0	bila. SELLER LABIL DNI	0	27	0	0	0	4	\N	0
6677427577	0	Zedlyn A.	0	3	0	0	0	9	\N	0
5442063105	0	#k	0	10	0	0	0	0	\N	0
1219025832	0	In	0	1	0	0	0	4	\N	0
6717143744	0	jejey	0	72	0	0	2772.6600000000003	502	\N	0
5548783983	0	Jerico de'Rico	0	26	0	0	0	3	\N	0
6892637394	0	ca	0	12	0	0	0	4	\N	0
5431236705	0	Ctash	0	1	0	0	0	0	\N	0
1867134092	0	bar	0	8	0	0	198.83	435	\N	0
6893408286	0	ㅤㅤ	0	6	0	0	0	0	\N	0
6036038769	0	Dracco	0	37	0	0	0	0	\N	0
5214518564	0	Dork	0	1	0	0	0	11	\N	0
1961206446	0	fsy	0	0	0	0	0	0	\N	0
5775542310	0	𝙙𝙖𝙧𝙜𝙖 ✺	8	1063	0	0	4636.479999999997	1534	\N	1
1413012659	0	seraphine	0	93	0	0	2.9799999999999898	2867	\N	0
6329197633	0	Havey	0	112	0	0	-3.549999999999997	39	\N	0
5393539071	0	ㅤ kamil	2	652	0	0	3428.349999999999	1632	\N	0
6123470027	2	haruka	0	48	0	0	99.09999999999991	1395	\N	0
6891340291	1	Kafa	3	200	0	0	1837.1699999999996	3619	\N	0
7023278879	1	nana	0	89	0	0	410	207	\N	0
5983756548	2	zephyra	0	243	0	0	0	1175	\N	0
6200970216	2	ㅤㅤㅤㅤㅤ	10	1612	0	1	6199.690000000004	3780	\N	1
6252530273	0	vetra	0	34	0	0	0	12	\N	0
6812033932	0	ciaaaa	0	1	0	0	0	235	\N	0
1713576234	0	Pijat Jakarta	0	5	3	0	0	1	\N	0
1588024245	0	R	0	300	0	0	11.78000000000003	28	\N	0
1303555123	0	A	7	62	0	0	168.79999999999973	472	\N	0
1807221954	0	Kaurèn Elysees	0	28	0	0	468	97	\N	0
6024939778	0	アーリン🎸	0	48	0	0	0	6	\N	0
6545272066	0	den	0	3	0	0	0	3	\N	0
6746843409	0	Moca Tyche	0	417	0	0	10.850000000000023	329	\N	0
6304172086	0	Lun	0	1	0	0	0	0	\N	0
5854804189	0	Jetro	1	163	0	0	1014.3499999999997	1586	\N	0
5356327969	0	s	0	17	0	0	0	5	\N	0
5752349843	0	F	0	131	0	0	0	53	\N	0
5112409997	0	pokie dokie	0	5	0	0	0	30	\N	0
5400946098	0	Sage 𝐖𝐒¹²⁵	0	6	0	0	0	27	\N	0
5282384885	0	Adena.	0	1	0	0	0	171	\N	0
2129590949	0	Senaka.	0	7	0	0	0	37	\N	0
5486894868	0	pijay	0	36	0	0	0	112	\N	0
1615540821	0	Shi.	0	2	0	0	0	4	\N	0
6795727374	0	Kayl	0	25	0	0	0	211	\N	0
6168749597	0	je	0	74	0	0	0	2	\N	0
6112795172	0	aii.	0	20	0	0	0	56	\N	0
6319953759	0	z	0	17	0	0	0	6	\N	0
6138307095	0	kairra	9	52	0	0	97.63	109	\N	0
5849833511	0	me	0	9	0	0	33.77	2	\N	0
6444976087	0	sandraaa	0	4	0	0	0	37	\N	0
6022035908	0	Abigail	0	1	0	0	0	0	\N	0
1986799789	0	prawira	0	2	0	0	0	2	\N	0
5295454264	0	Abeey	0	189	0	0	74.41000000000008	281	\N	0
7161085874	0	Erysza, vogos	0	44	0	0	0	89	\N	0
5747441040	0	mikasa	0	8	0	0	0	1	\N	0
5441070830	0	$	0	74	0	0	163	14	\N	0
1309320224	0	bila	12	241	0	0	3116.05	1253	\N	1
6978527073	0	Kirae.	0	82	0	0	1.8299999999999983	32	\N	0
1973802236	0	kaa	0	79	0	0	0	96	\N	0
6373223822	0	kael	12	447	0	0	560.5600000000002	3157	\N	0
1345734237	0	davis	0	0	0	0	0	5	\N	0
5877585126	0	jessa	0	31	0	0	0	364	\N	0
6741558256	0	ʝнα ʏᴇᴢᴇʟʟ	0	41	0	0	0	0	\N	0
6204448585	0	audrey	0	18	0	0	371.79	5	\N	0
1148342063	0	miawcie	0	494	0	0	278.93999999999994	56	\N	0
5023822280	0	dfggg	0	3	0	0	0	0	\N	0
5525520984	0	a y a	0	9	0	0	0	29	\N	0
5145065332	0	rika	0	1	0	0	0	23	\N	0
5817955883	0	cacaa4u	0	7	0	0	0	2	\N	0
2088596342	0	sall	0	29	0	0	257	0	\N	0
5900555211	0	$	2	66	0	0	81.51	15	\N	0
1772924036	0	Hanna Nur Salsabilla🧚‍♀️	0	49	2	0	1843.4299999999998	74	\N	0
2060958316	0	falee	0	1	0	0	0	10	\N	0
1133909381	0	agas	0	1	0	0	0	0	\N	0
5311083561	0	zer	1	2	0	0	229.96	6	\N	0
5009867615	0	binanNanaNa	0	11	0	0	0	0	\N	0
5011937605	0	Alesha.	0	1	0	0	0	1	\N	0
5485990454	0	qil	0	28	0	0	0	1	\N	0
5025182889	0	keEShi	0	1	0	0	0	2	\N	0
1770084261	0	kin	0	29	0	0	0	1	\N	0
6681894575	0	𝐀 𝐟𝐨𝐫?	0	1	0	0	0	3	\N	0
5140202609	0	cennan	0	9	0	0	57.9300000000007	0	\N	0
6134144963	0	à	0	55	0	0	0	77	\N	0
7087029617	0	𝗯𐐫𝗼. Kiransya Abiyugà	0	10	0	0	0	0	\N	0
6730480384	0	99	0	2	0	0	0	0	\N	0
6245620909	0	elle.	0	12	0	0	100	21	\N	0
926814982	0	ndy	0	12	0	0	0	0	\N	0
1949789420	0	crdy	0	15	0	0	0	0	\N	0
1418709024	0	mw ambis ₍⑅ᐢ..ᐢ₎ ♡.°📧🐈👚₊ˎˊ˗	0	32	0	0	0	96	\N	0
1747108252	0	27.antar	0	8	0	0	0	1	\N	0
1875010400	0	RAIN	0	1	0	0	0	0	\N	0
5290248645	0	bakWan	3	79	0	0	546.9	6253	\N	0
1881652887	0	chaly	0	5	0	0	0	2	\N	0
5926692904	0	yayaa	0	2	0	0	236.2500000000002	27	\N	0
5967857828	0	Nayya, gwenchana :(	0	1	0	0	0	5	\N	0
5439928751	0	jer	0	375	0	0	30	1387	\N	0
1247324068	0	🍉	0	2	0	0	0	0	\N	0
1638655523	0	tasya	0	1	0	0	0	1	\N	0
5424147363	0	arradeena itu kezia	12	405	0	0	140897.32999999973	8941	\N	1
5338935251	0	karin	2	187	0	0	12.569999999999993	241	\N	0
1702597046	0	240. Jevano mencari kasih sayang	0	12	0	0	0	10	\N	0
7055236075	0	Gio's lover, Orell 🎀	0	63	0	0	1232	44	\N	0
1419396143	0	Shyfa	0	0	0	0	0	33	\N	0
5341979081	0	bilaa	0	8	0	0	0	0	\N	0
6368246214	0	DIKA, A.	0	1	0	0	0	1	\N	0
1958086039	0	neran	0	3	0	0	0	0	\N	0
5561213938	0	Hellen	0	0	0	0	0	0	\N	0
1962851212	0	agas	0	104	0	0	348.48	10	\N	0
6713433717	0	sean	0	0	0	0	0	147	\N	0
6458074104	0	len tlg amanah y	0	3	0	0	0	0	\N	0
6824620717	0	Pio	0	2	0	0	0	0	\N	0
1812795440	0	-	0	2	0	0	1263.34	0	\N	0
1268811735	0	.	0	12	0	0	0	0	\N	0
5053525878	0	rewrite the stars	0	1	0	0	0	0	\N	0
5880988229	0	j	5	180	0	0	859.41	502	\N	0
1196096890	0	annola	0	2	0	0	0	0	\N	0
1117636337	0	y	0	1	0	0	0	0	\N	0
2033386201	0	renara	0	59	0	0	0	85	\N	0
2035394191	0	langit	0	30	0	0	0	0	\N	0
6305589698	0	-	0	126	0	0	4.759999999999877	166	\N	0
6637390297	0	shaDIKAn	0	34	0	0	1.3400000000000034	3	\N	0
5218544262	1	kanaabi is your gf	0	185	0	0	200.11	14363	\N	0
5572468848	0	𝐊𝐮𝐝𝐨𝐨	0	72	0	0	0	97	\N	0
5185262460	0	jinan	0	95	0	0	0	3	\N	0
6169467517	0	12	0	81	0	0	7.97999999999999	229	\N	0
5556272286	0	Kean	0	1	0	0	0	0	\N	0
6969989413	0	Ashana	0	52	0	0	0	8	\N	0
5077727167	0	american o	0	226	0	0	0	93	\N	0
1964216730	0	lian biar keren	0	4	0	0	0	3	\N	0
5043508448	0	naycaa	0	88	0	0	340	1	\N	0
6129921370	0	fale kangen jean juga	0	118	0	0	1124.1300000000008	26	\N	0
6843975017	0	putraa.z 💢	0	9	0	0	0	185	\N	0
6785009935	0	hi	0	7	0	0	0	2	\N	0
5511138660	0	jay	0	2	0	0	0	0	\N	0
5509847279	0	azza	0	15	0	0	0	614	\N	0
1937516430	0	nazel	0	6	0	0	0	116	\N	0
6216725880	0	Liaa	0	8	0	0	0	14	\N	0
6526309023	0	nanaa, 🌷	0	0	0	0	0	0	\N	0
6483440674	0	ɐuuǝıΛ	0	14	0	0	0	15	\N	0
5624290831	0	aje	0	965	1	0	5.449999999999818	1495	\N	0
5926123969	0	Savara	0	15	0	0	0	14	\N	0
5944596593	0	rayen	0	26	0	0	0	15	\N	0
5997563914	0	jaearth	0	1	0	0	0	0	\N	0
1990128883	0	Jhuwita pacar mingyuu	0	29	0	0	4980	6	\N	0
6234753185	0	fiona	0	10	0	0	1.9399999999999977	13	\N	0
5818626101	0	yaya	0	11	0	0	24	11	\N	0
1876968046	0	issaaaaaa	0	18	0	0	0	10	\N	0
7098199512	0	L	0	9	0	0	0	3	\N	0
5148812893	0	N	0	3	0	0	0	2	\N	0
5615423070	0	Hara	0	10	0	0	0	4	\N	0
6007113742	0	rbio	0	16	0	0	0	0	\N	0
1836793065	0	irish sharon	0	257	0	0	1730.6900000000003	4495	\N	0
6264493877	0	Cann	0	0	0	0	0	0	\N	0
5816538340	0	dd ashara	0	11	0	0	0	6	\N	0
7125476274	0	Jibon	0	1	0	0	0	1	\N	0
6259479399	0	M A R G O	0	2	0	0	0	0	\N	0
5207723971	0	cee	0	1	0	0	0	0	\N	0
1751915419	0	Kaneishia Shindi.	0	298	0	0	0	200	\N	0
1834244955	0	jjes	0	0	0	0	0	0	\N	0
5107570884	0	Kayesha.	0	37	0	0	479	31	\N	0
1902868623	0	Arbie Ethanios.	0	2	0	0	0	2	\N	0
1552651400	0	Mahen @Dunnker	1	49	0	0	2762.7	2169	\N	0
2133129928	0	firaa	0	53	0	0	0	6	\N	0
5300925757	0	𐙚 qilaa	0	31	0	0	226.93	823	\N	0
1516943206	0	ㅤㅤ	7	217	0	0	2417.0600000000004	3192	\N	0
1714664561	1	ayel	10	350	0	0	7451.22	1959	\N	1
1614557236	0	nana	0	51	0	0	0	42	\N	0
1455261679	1	fin	0	95	0	0	151	168	\N	0
5579708488	0	ajel	10	41	0	0	62717.72000000001	30549	\N	1
1626037139	0	nolan	7	157	0	0	0.7700000000000102	0	\N	0
5804955155	0	M.	12	258	0	0	1321.1800000000007	5159	\N	0
1829679655	0	aqil victoryking	0	25	0	0	0	0	\N	0
2019321178	0	eireen.	0	219	0	0	1164.5499999999997	216	\N	0
2023619760	0	Haezka Darmaya	0	68	0	0	0	4	\N	0
6194417059	0	cimeng	9	34	0	0	2403.32	294	\N	0
6024758040	0	Sabeetha.	0	44	0	0	7.63	0	\N	0
5801150917	0	Sylraine Eranthe	0	309	0	0	11.579999999999984	136	\N	0
5378168866	0	cel	0	2	0	0	0	6	\N	0
1917165230	0	Hanan indosat	0	32	0	0	0	1	\N	0
6064702102	0	LOLI FIKRI	0	0	0	0	0	1	\N	0
1889245594	0	Adhan	8	6	0	0	1710.8299999999997	557	\N	0
6831614912	0	askara	0	6	0	0	0	46	\N	0
1864649093	0	abay	0	130	0	0	0	50	\N	0
6495320829	0	é	0	1	0	0	0	0	\N	0
5201031620	0	mikhaila	0	31	0	0	0	5	\N	0
5950079928	0	门	0	0	0	0	0	0	\N	0
6076671851	0	zeyna	0	46	0	0	0	50	\N	0
6227479504	0	darl	0	34	0	0	0	20	\N	0
1261497563	0	eca in #TimnasDay era	8	173	0	0	1889.0400000000002	2005	\N	0
1034970520	0	Dom	0	29	0	0	0	31	\N	0
7093463721	0	Pret	0	129	0	0	0	0	\N	0
6764030084	0	Putr	0	9	0	0	0	1	\N	0
1936325902	0	-	12	962	0	0	173.49999999999636	3145	\N	0
6099024587	0	nashima	0	106	0	0	999.71	739	\N	0
5374404819	0	maylá	0	5	0	0	0	44	\N	0
1805087418	0	⋆𐙚₊˚natt	6	106	0	0	3136.6900000000005	1389	\N	0
6753006846	0	usagi	5	214	0	0	18.530000000000157	930	\N	0
2010894935	0	Galaksi Orion.	0	3	0	0	0	0	\N	0
5533717736	0	fllor	0	4	0	0	0	0	\N	0
1863369144	0	zee.	0	22	0	0	0	0	\N	0
5347741168	0	mangeak	0	49	0	0	0	115	\N	0
5348813990	0	cr	0	7	0	0	162.47	4	\N	0
1627469722	0	jaylee	0	252	0	0	329.1199999999999	416	\N	0
6032285916	0	wilioo	0	8	0	0	0	18	\N	0
6774230154	0	𐙚 rana tensāi ōtsukioni	0	115	0	0	322.9000000000001	105	\N	0
5502764468	0	# veyyii! <♥️>	0	2	0	0	0	9	\N	0
5928480599	0	likes fiction	0	6	0	0	0	47	\N	0
1479029412	0	Ti	0	1	0	0	0	0	\N	0
1800102754	0	rebecca	0	2	0	0	0	8	\N	0
5368625131	0	Kaeden Akari	0	1	0	0	0	1	\N	0
5043336165	0	sasa	0	4	0	0	0	6	\N	0
5704312235	0	DDY HUKY	0	120	2	0	134.38999999999996	203	\N	0
6540920623	0	nabrisa	0	216	0	0	69.42000000000004	208	\N	0
5997997458	0	caca	0	1	0	0	0	0	\N	0
2070925742	0	sa	2	189	0	0	1318.65	162	\N	0
5068172310	0	Sharenne	0	194	0	0	0	160	\N	0
908989887	0	bii.	0	0	0	0	0	0	\N	0
7073761826	0	acelacel	0	22	0	0	0	0	\N	0
6549442873	0	sa(wan) 4twenty	0	100	0	0	2.039999999999999	555	\N	0
6008979317	0	私 ipaw	9	351	0	0	4134.2699999999995	9769	\N	0
6948650854	0	Petter	0	44	0	0	298.07	829	\N	0
5004632860	0	kayesha	0	1	0	0	0	0	\N	0
6615509563	0	N	0	4	0	0	0	1	\N	0
5895678835	0	oh mars suka nyabu🌻	0	8	0	0	0	10	\N	0
1814543695	0	Riel	0	1	0	0	0	27	\N	0
5410335905	0	arin	0	1	0	0	0	18	\N	0
6588320774	0	iell	0	2	0	0	0	0	\N	0
6527549649	0	biji :/	0	11	0	0	128	112	\N	0
5367060727	0	.	0	295	0	0	0	38	\N	0
997085572	0	⌘` Lashierra, Scara's slut	0	272	0	0	455.6700000000001	738	\N	0
5320429265	0	natta	0	1	0	0	0	2	\N	0
1255159894	0	Vermont Cartiér.	0	27	0	0	1572.5	27	\N	0
6218814124	3	873. Raden	12	92	0	0	211.45	748	\N	0
6552172714	0	zio	0	7	0	0	0	7	\N	0
1274521818	1	j. jd potato	8	1263	0	0	743.8700000000001	6868	\N	1
6527846273	1	aceng	0	92	0	0	0	11	\N	0
1593813362	1	Alea	0	154	0	0	89	8	\N	0
5210668293	0	Manusiaaa	0	2	0	0	0	0	\N	0
1985490657	0	moon	0	18	1	0	0	11	\N	0
1987592665	0	kamila	0	1	0	0	0	0	\N	0
5896683001	0	hanan.	0	18	0	0	0	0	\N	0
5836631811	0	Ciyya cuma open vvip	0	1	0	0	0	0	\N	0
7159729329	0	raini	0	71	0	0	39.73	812	\N	0
1773859726	0	char	0	252	0	0	0	35	\N	0
5815331682	0	,	0	2	0	0	103.05	7	\N	0
1750462965	0	𝐝	0	151	0	0	0	59	\N	0
1402804220	0	mora	0	1	0	0	0	0	\N	0
6401278720	0	ayi	2	248	0	0	437.42	516	\N	0
5105604242	0	Karrel	0	439	0	0	80.1400000000001	337	\N	0
1649180330	0	abinawa	0	2	0	0	0	76	\N	0
1360843707	0	G	0	193	0	0	14.099999999999994	131	\N	0
5546209265	0	Jena	0	366	0	0	11.960000000000008	229	\N	0
6103015591	0	441. Samita	0	130	0	0	0	309	\N	0
1981078696	0	lele	0	12	0	0	0	433	\N	0
1047595076	0	caa	0	2	0	0	0	0	\N	0
6114234781	0	Joèlla.	0	0	0	0	0	0	\N	0
1995607306	0	˖˚༘laura·˚❀°。	0	15	0	0	0	21	\N	0
5940105152	0	𝟖𝟑𝟏. kiara. ꮇ𝐯༱	0	15	0	0	2631.33	83	\N	0
2030703011	0	kadal	10	294	0	0	514.0600000000001	729	\N	0
5484473372	0	nai	0	317	0	0	0	52	\N	0
6583332634	0	nash.	0	18	0	0	0	5	\N	0
5332866763	0	Naya. open fsr	0	42	0	0	0	68	\N	0
5487721505	0	sh	0	0	0	0	0	0	\N	0
6062312156	0	J. Malio	0	1	0	0	0	0	\N	0
1565635632	0	ZARA.	0	2	0	0	0	5	\N	0
6041071964	0	marc, addicted to c.a.s	0	14	0	0	0	56	\N	0
6174197905	0	nada	0	1	0	0	0	1	\N	0
1718395703	0	81u3y's.	0	0	0	0	0	0	\N	0
6511263793	0	Sebastian Michaelis.	0	23	0	0	0	16	\N	0
1634189317	0	iceyy	0	18	0	0	0	50	\N	0
6613427771	0	Alika.	0	114	0	0	4	102	\N	0
2033459696	0	oreo enak	0	571	0	0	744.2850000000008	1457	\N	0
5725693523	0	Ar	0	2	0	0	0	4	\N	0
6774146650	0	fortune natus vincere	0	129	0	0	403.96	117	\N	0
1320912134	0	o	0	0	0	0	0	2	\N	0
1686033342	0	ahen	0	3	0	0	0	0	\N	0
7099406496	0	maydeē 孥。	0	12	0	0	456	15	\N	0
6515705673	0	Asaa	0	14	0	0	48.67	153	\N	0
5139266331	0	yenski	0	13	0	0	0	7	\N	0
5601502589	0	kinky	0	46	0	0	0	2	\N	0
1355525364	0	αnα	0	0	0	0	0	0	\N	0
5043849651	0	©𝘼𝙫𝙞𝙣𝙣	0	3	0	0	0	4	\N	0
1182400004	0	Rz	0	1	0	0	0	1	\N	0
1800203208	0	zaa	0	30	0	0	0	35	\N	0
5889006729	0	Zlpi	0	1	0	0	0	0	\N	0
5974726002	0	Cameo	0	0	0	0	119.86	34	\N	0
6179743201	0	rest.	11	758	0	0	1140.59	156	\N	0
2058362049	0	Rey	0	1	0	0	0	1	\N	0
1288203798	0	Popsicle	0	64	1	0	0	46	\N	0
6607536770	0	Yezhkiel	0	5	0	0	0	0	\N	0
1833556793	0	...	0	23	0	0	0	2	\N	0
5568161739	0	lynn	0	1	0	0	0	5	\N	0
6878970642	0	ini manusia	0	74	0	0	0	41	\N	0
1162037616	0	sierz	0	153	0	0	1.0100000000001117	28	\N	0
5173481341	0	.	3	533	1	0	115.27999999999986	1577	\N	0
5510035381	0	ai	0	242	0	0	14.030000000000001	40	\N	0
5273045901	0	lentanaa open	0	8	0	0	0	5	\N	0
5802761633	0	verin	0	1476	0	0	203.8999999999877	831	\N	0
6764446077	0	Nay	0	93	0	0	378.24	24	\N	0
6911855879	0	ok	0	1	0	0	0	271	\N	0
1260544921	0	Adis ⋆ೀ	0	18	0	0	0	331	\N	0
5833843930	0	asyaa.	0	420	0	0	9.230000000000047	75	\N	0
7093882537	0	rull	0	5	0	0	0	4	\N	0
5541736844	0	(^._.^)	4	320	0	0	771.9100000000001	28	\N	0
6358539638	0	nara	0	6	0	0	0	15	\N	0
6610623374	0	tika	0	1	0	0	0	1	\N	0
5990443868	0	hiyu	0	0	0	0	0	0	\N	0
1981622006	0	skyla suka reja arap oktapia gemez gamteng idaman ya😈 escvk	4	1391	0	0	205.01	1645	\N	0
6429317890	0	jae	0	60	0	0	0	31	\N	0
6401345983	3	ciKkKk	0	199	0	0	3.5200000000000102	171	\N	0
7092719155	1	Cupcakes	0	233	0	0	7.769999999999982	1	\N	0
6638397618	0	aku kroco bg	0	12	0	0	348.02	226	\N	0
1855201079	0	Melody, B.	1	2452	0	0	1746.02	2472	\N	0
5020189560	0	cimol	14	974	0	0	87.9600000000001	4906	\N	1
6941577006	0	Raqueela vanlentina	0	49	0	0	10.200000000000003	551	\N	0
1806231980	0	kayana	0	25	0	0	0	5	\N	0
6458970428	0	z	0	39	0	0	6	60	\N	0
1769825150	0	dārcie, dana +100p	0	47	0	0	35.82	242	\N	0
5689977813	0	regina	0	14	0	0	14.49	611	\N	0
1662643369	0	della	0	26	0	0	0	35	\N	0
5734951117	0	L	0	19	0	0	0	8	\N	0
5744101419	0	Margaa	0	0	0	0	0	111	\N	0
1712096378	0	keyiiiiii	0	2	0	0	0	1	\N	0
6267331521	0	rbio dlu.frika T	0	8	0	0	54.099999999999994	55	\N	0
6772808088	0	raph joestar	8	75	0	0	2511.55	1191	\N	0
6822857213	0	⊹ ³⁵² ërikαα Eagle shines 冬	0	3	0	0	0	6	\N	0
6010478740	0	rra ; ฉันชื่อฮิระ	0	1	0	0	0	0	\N	0
1784685240	0	T	0	0	0	0	0	6	\N	0
5156907045	0	N	0	30	0	0	0	210	\N	0
1671435072	0	sasaaa	0	34	0	0	0	3	\N	0
1708659437	0	kaira 💋	0	57	0	0	0	22	\N	0
1620281802	0	jejener	0	1	0	0	0	0	\N	0
1553549157	0	Al	0	416	0	0	978.4899999999996	359	\N	0
1551052871	0	moramory	0	4	0	0	0	5	\N	0
5887215346	0	912. Mandaaa	0	3	0	0	0	1	\N	0
5478787742	0	k earth.	0	801	0	0	10.270000000000039	175	\N	0
5779432434	0	chila pengen jago yss	0	209	0	0	218	54	\N	0
6454244225	0	rba	0	17	0	0	0	62	\N	0
6206078619	0	j for jembut	1	4	0	0	3149.3999999999987	3111	\N	0
2048174218	0	Nisaka. 🍉	1	1492	1	0	37.31000000000188	4291	\N	0
1760722232	0	acc kerja	0	10	0	0	0	0	\N	0
1684311599	0	r.	0	187	0	0	0	199	\N	0
5717977016	0	𝖆𝖓𝖏𝖊𝖑inaa	0	1	0	0	0	1	\N	0
6206616596	0	mizzu O2	0	2	0	0	0	0	\N	0
6820245401	0	a	0	131	0	0	0	0	\N	0
2083702530	0	jolyneee	0	204	0	0	313.9	226	\N	0
2021951336	0	zuzuraa ⸼ ׄ	0	1	0	0	0	0	\N	0
1794292227	0	pika	0	1	0	0	0	0	\N	0
5157634915	0	kadang fsr kadang slr	0	83	0	0	0	3	\N	0
1816459399	0	Naaez Shabrina.	0	223	0	0	96.91	441	\N	0
5388716237	0	lucy༊	0	113	0	0	15	341	\N	0
2023357571	0	aku norak	0	6	0	0	0	4	\N	0
5389502081	0	𖦹 ⃝ 📃୧. indri and husni don't cry.ᐟ .ᐟ ⃘ ⃘ 𝅄 ˚	0	2	0	0	0	1	\N	0
5717847925	0	boy	0	5	0	0	0	5	\N	0
7152855526	0	bian	0	0	0	0	0	0	\N	0
5308768610	0	ona	0	252	0	0	479.5899999999999	71	\N	0
1751644406	0	Jasper.	0	320	0	0	0	295	\N	0
6023683123	0	skywalker	0	9	0	0	411.23	2	\N	0
6490198681	0	𝐓𝐑≛𝐏𝐒 `NUKA	0	2	0	0	0	40	\N	0
5056471873	0	j	0	735	0	0	44.31999999999968	12300	\N	0
6409316029	0	G	0	233	0	0	9.530000000000001	146	\N	0
6644549918	0	cia	9	53	0	0	0	215	\N	0
7012836194	0	J	0	103	0	0	0	7	\N	0
1763105909	0	oldey	7	363	0	0	1422.49	4122	\N	0
1627601826	0	jepaa	2	1920	0	0	-1.3599999999998547	5970	\N	0
6635369783	0	trixie	0	32	0	0	655	389	\N	0
5707433776	0	niel	0	45	0	0	478	208	\N	0
7129779897	0	logout	0	4	0	0	0	31	\N	0
6133172854	2	Amerta.	7	351	0	0	53.45999999999913	2374	\N	1
6413701056	2	Mey	0	14	0	0	0	354	\N	0
7002898421	1	tata	0	109	0	0	6.680000000000007	395	\N	0
6995496802	1	paisley	0	8	0	0	0	12	\N	0
6508240802	1	k	0	63	0	0	0	0	\N	0
6073895034	3	..	0	267	1	0	12.470000000000027	51	\N	0
5394818867	0	⁷¹⁷ ` Teacher Mafia Agaskara 冬	0	21	0	0	0	24	\N	0
1988921457	0	J.리비아 #XOXO	0	82	0	0	0	35	\N	0
5812489398	0	mi	9	91	0	0	4678.789999999999	1661	\N	0
5183016748	0	V⋆⃟™¶¶ʟ∆ʟ• •ʀʙɪʟ•ʜ͓̽s͓̽¹⁸+ Cindy •LS • • ⃟⃝𝑰𝑫¹⁸⁺ • ⃟PO •♕	0	1	0	0	0	1	\N	0
7169235897	0	Brooklyn	0	5	0	0	0	89	\N	0
2096097298	0	ay	0	143	0	0	0	453	\N	0
1635174315	0	Dancacaca	0	46	0	0	0	33	\N	0
6010380026	0	ryan	0	0	0	0	0	0	\N	0
5268497961	0	wizkid	0	28	0	0	0	1	\N	0
6949599082	0	asyilaaa sung proses !	0	0	0	0	0	0	\N	0
1962494369	0	anoo	0	0	0	0	0	45	\N	0
5749985248	0	slm	7	267	0	0	3465.72	804	\N	0
1254502403	0	.	0	107	0	0	0	43	\N	0
1987700214	0	ȿ²⁹ lili	0	21	0	0	0	163	\N	0
5109981230	0	Jocasté M.	0	2	0	0	2.53	2	\N	0
6124063975	0	Nanaaa	0	1	0	0	0	1	\N	0
5763752351	0	jeii	0	4	0	0	0	5	\N	0
6011636915	0	opang	0	25	0	0	0.8400000000000034	28	\N	0
5613555108	0	ayak suka jay	0	1	0	0	0	1	\N	0
5091912307	0	Ganjarda.	0	6	0	0	0	0	\N	0
6221912322	0	K🇸🇿	0	24	0	0	47	739	\N	0
5705212165	0	myesha	0	1	0	0	0	1	\N	0
1710525500	0	Raii:3.	0	25	0	0	0	143	\N	0
1088927869	0	Relly	0	122	0	0	16.14	482	\N	0
5743468338	0	George Buffeyth.	0	1	0	0	0	2	\N	0
6698765638	0	ell	0	4	0	0	0	2	\N	0
5946682814	0	Bieber	0	11	0	0	0	443	\N	0
5441953518	0	Marvick 🇦🇱ᴴᵉˡⁱᵒˢ	0	2	0	0	0	3	\N	0
6905694710	0	Xion	0	2	0	0	0	0	\N	0
952766337	0	b	0	11	0	0	0	23	\N	0
6385965106	0	aeyyy	0	26	0	0	28	24	\N	0
2002907708	0	n	0	1	0	0	0	0	\N	0
1915564330	0	hutao ril cuy	0	73	0	0	2082.870000000001	46	\N	0
5017554613	0	je itu nana	0	1	0	0	0	34	\N	0
5189155674	0	Hiyoko.	14	27	0	0	33.879999999999654	38	\N	0
6051676312	0	edan SASSY	0	6	0	0	0	930	\N	0
1316022469	0	antartika	14	378	0	0	329.8000000000004	349	\N	0
5645643185	0	zee	0	16	0	0	0	18	\N	0
5314229091	0	killa salima	0	5	0	0	472.65000000000003	941	\N	0
5186997710	0	𝓒. Alexara | 𝕽𝐕𝗦ᵈᶦᵉᶠᵗʰÝⁿᵒⁿˢÝᵐᵛᵒᵘˡᵒˢ	0	26	0	0	0	7	\N	0
1630103164	0	dni.	2	1133	0	0	5824.510000000002	1485	\N	0
6117353543	0	Micaalo	0	27	0	0	0	5	\N	0
6005166710	0	Aebi L.G 𝗨𝗟𝗧𝗥𝗔𝗠𝗘𝗧𝗔 🤟	0	2	0	0	0	3	\N	0
5274668961	0	🫧	0	2	0	0	0	0	\N	0
6839928466	0	.	0	0	0	0	0	5	\N	0
6586795399	0	airys	0	68	0	0	733	99	\N	0
5413001519	0	prson	1	1977	0	0	5.540000000002976	1684	\N	0
5246936760	0	fii.	0	12	0	0	0	7	\N	0
6050203511	0	Marysh-belle.	13	904	0	0	1.8800000000000026	343	\N	0
1259615654	0	panii	0	914	0	0	60.319999999999936	928	\N	0
5160210505	0	ziéllyn🇦🇺	0	4	0	0	0	4	\N	0
6394275468	0	Hiatus nge BA.	0	1	0	0	0	0	\N	0
837220715	0	Kael	0	3	0	0	0	3	\N	0
6338305471	0	sephiola	0	3	0	0	0	0	\N	0
1695456332	0	Gazza senggol bacok, rewel cipok.	0	5	0	0	0	18	\N	0
5891310248	0	Radesha Kalingga.	4	1336	1	0	16.960000000000036	834	\N	0
1954274239	0	zen	0	16	0	0	0	23	\N	0
5221241917	0	ossy 🦖🎈	0	2	0	0	0	107	\N	0
1870464779	0	.	1	336	0	0	239.4400000000005	1197	\N	0
1939799994	0	??	0	19	0	0	0	1	\N	0
6469795319	0	S.	0	33	0	0	0	445	\N	0
1474148560	0	Asher Eldridge.	0	1	0	0	0	61	\N	0
1659958749	0	Lia	0	378	0	0	0	200	\N	0
5596965696	0	Quin	0	2	0	0	0	0	\N	0
6053738776	0	Kath.	0	1	0	0	0	1	\N	0
5395676619	0	ᤁᥲ 🍬💟	0	0	0	0	0	0	\N	0
6334475914	0	kayl	0	0	0	0	0	0	\N	0
1687072019	0	grv. jo el @ifvckingj	0	7	0	0	363	1597	\N	0
6710726069	0	𝐘ashan🪐	0	1	0	0	0	0	\N	0
6724816025	0	anya	0	1	0	0	0	0	\N	0
1751441445	0	Matthew	0	21	0	0	0	46	\N	0
6133232389	0	Prateesa A.	0	22	0	0	0	135	\N	0
5338492798	0	ftryya	0	4	0	0	0.8099999999999454	9	\N	0
1711320894	0	Loving Raii 🤍	0	0	0	0	0	0	\N	0
5606894547	0	ai ai kaptennn	0	1	0	0	0	0	\N	0
1255498719	0	nd🅰️	0	1	0	0	0	0	\N	0
5083657769	0	ㅤ ㅤarbok	0	8	0	0	0	19	\N	0
6797067745	0	vey	0	1	0	0	0	0	\N	0
6395137698	0	umi Jennielous	0	2	0	0	0	0	\N	0
7040122548	0	dedee has joel	0	2	0	0	0	1	\N	0
1203007690	0	iki	0	409	1	0	263.73	496	\N	1
5336898603	0	ㅤㅤㅤ	10	117	0	0	1235.9299999999998	259	\N	0
5028388756	0	E — CHIVALRY	0	13	0	0	0	0	\N	0
1002348625	0	BurungKntl	0	1	0	0	0	0	\N	0
2081059283	0	inii yayaaa	0	1	0	0	0	0	\N	0
6901971272	0	lea	9	89	0	0	0	135	\N	0
5728744105	0	ɢꜱ𖤓 she/her	0	2	0	0	0	40	\N	0
1653565337	0	verga	0	27	0	0	0	15	\N	0
6195874818	0	na	0	0	0	0	0	2	\N	0
5486279243	0	-	0	107	1	0	62.90999999999997	119	\N	0
5267968031	0	helgaa	0	1	0	0	0	0	\N	0
1342661324	0	korosi	3	233	0	0	8672.620000000003	11140	\N	0
5346119751	0	K. Dalloway	5	532	0	0	932.1	814	\N	0
6312060731	0	창민 Jinoline.	0	13	0	0	0	3	\N	0
2102657916	0	anilegna	0	128	0	0	20	566	\N	0
1618606520	0	b	0	118	0	0	5	20	\N	0
1099198193	0	ela	0	90	0	0	2.38000000000018	13	\N	0
6016445933	0	s'	0	4	0	0	0	0	\N	0
6946918565	0	alea ꢾ୧	0	1	0	0	0	0	\N	0
5043397201	0	cantika	0	2	0	0	0	0	\N	0
6547500443	0	yaya cewe baik ōtsukisan	0	3	0	0	0	4	\N	0
6869205570	0	naf	0	3	0	0	0	0	\N	0
1924905456	0	Haruko vgx	0	9	0	0	0	15	\N	0
6633134346	0	🪲	0	60	0	0	0	18	\N	0
5803766987	0	lima puluh ribu	14	305	0	0	731.1000000000004	831	\N	0
6601545520	0	zara	0	227	0	0	8.5	114	\N	0
6538442453	0	ㅤㅤㅤㅤㅤㅤㅤㅤ	0	111	0	0	0	37	\N	0
1615774811	0	L	0	137	0	0	0	37	\N	0
5883588555	0	w	0	98	0	0	0	944	\N	0
1931855800	0	fey	0	0	0	0	0	0	\N	0
5126421978	0	zee	0	0	0	0	0	4	\N	0
1320875460	0	ian.	0	1	0	0	0	0	\N	0
5490978818	0	vαnn.	0	2	0	0	0	13	\N	0
1683282823	0	⌕ yyaaa	0	27	0	0	0	21	\N	0
1998887354	0	aryaa	0	89	0	0	0	5	\N	0
5963523131	0	ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ	0	3	0	0	0	0	\N	0
1372921364	0	gege	0	1	0	0	0	83	\N	0
6712115864	0	hades	0	6	0	0	0	35	\N	0
5003394227	0	waa	0	43	0	0	0	0	\N	0
5250487566	0	.	13	1535	0	0	1892.37	21999	\N	1
6445912880	0	H	0	14	0	0	0	25	\N	0
6697689119	0	@AsamiJawa || slr	6	75	0	0	338.42	263	\N	0
5678500359	0	marsya	0	19	0	0	21.67	555	\N	0
5073690566	0	dexx	0	2	0	0	0	166	\N	0
5874771200	0	419 vallene	0	1	0	0	0	0	\N	0
2142112812	0	Riz-	0	0	0	0	0	4	\N	0
1596500735	0	Z	0	5	0	0	0	2	\N	0
5357045191	0	Rin	0	94	0	0	0	32	\N	0
5704475847	0	Eii	0	6	0	0	0	3	\N	0
1482072739	0	liaaa	0	40	0	0	0	51	\N	0
1910758109	0	Britney Cassidy	0	3	0	0	0	1	\N	0
5343086348	0	valo	11	139	1	0	190.0999999999999	118	\N	1
1791675979	0	Suzy Ann	0	415	0	0	0	91	\N	0
6551538704	0	d	0	23	0	0	934	22	\N	0
1776233673	0	call me z i e <3	0	20	0	0	0	87	\N	0
5162842858	0	Jenver, open inrush	0	3	0	0	0	0	\N	0
1129136515	0	joey.	0	7	0	0	0	14	\N	0
1442700022	0	moumoo	0	12	0	0	0	22	\N	0
5083015025	0	vaan	0	2	0	0	0	11	\N	0
6023140551	0	ca	0	24	0	0	0	1	\N	0
1962288581	0	Tally	0	136	0	0	1.8599999999999994	383	\N	0
5594640336	0	jemaa 🦋	0	103	0	0	845.1399999999999	273	\N	0
6740754776	0	rumaisa ҉	0	12	0	0	0	11	\N	0
5447303766	0	nathan	0	1	0	0	0	1	\N	0
1605531587	0	ㅤɴᴇᴋᴏ	0	0	0	0	0	2	\N	0
1332688448	0	hatori gf	0	172	0	0	2.6400000000000006	255	\N	0
6201914620	0	Mēy Scott.	0	59	0	0	0	0	\N	0
1920685471	0	eleo	6	422	0	0	213.31999999999985	4170	\N	0
5489327646	0	leonza	0	0	0	0	0	0	\N	0
6181112067	0	AL.	0	1	0	0	0	0	\N	0
6186123114	0	D𝖺𝗒𝗇eࠥ @Bodaciouys 𐀔	0	3	0	0	0	12	\N	0
1729947487	0	thèruu : @lievreuniverse	0	49	0	0	0	43	\N	0
1948112168	0	r	0	169	0	0	0	0	\N	0
1830539975	0	🍄 ๑ reree ֹ 🧝🏻‍♀ ᧓	0	1	0	0	0	0	\N	0
1850899647	0	a	0	85	0	0	0	45	\N	0
6821898478	0	n	0	62	0	0	0	6	\N	0
5871255269	0	divi.	0	11	0	0	485	1	\N	0
5605393988	0	Alex Isaac	0	1	0	0	0	1	\N	0
5488427507	0	yace aljabar	0	25	0	0	11	2014	\N	0
6651905729	0	Sa.	0	80	0	0	12.330000000000041	26	\N	0
1312676232	0	sera	0	288	0	0	0	185	\N	0
6551812968	0	alika salima	0	120	0	0	1290.55	37	\N	0
1539363790	0	asa hik hik	12	1711	0	0	2976.63	8448	\N	0
2022467935	0	tasa	0	3	0	0	0	0	\N	0
6436865865	0	aèsha :3	0	11	0	0	0	29	\N	0
5846583709	0	𝐌eylan	0	287	0	0	272.05999999999995	63	\N	0
1733153504	0	je DNFI	0	3	0	0	0	3	\N	0
1440021258	0	elodie	9	378	0	0	867.1699999999998	301	\N	0
6285760762	0	wen	11	241	0	0	630.6899999999999	581	\N	0
6440112297	0	acaaaaa	0	1	1	0	0	0	\N	0
6513348803	0	ken.	0	42	0	0	1171.85	502	\N	0
5170856064	0	jodap	0	70	0	0	1360.64	50	\N	0
6520826347	0	oliver	1	97	0	0	1568.2800000000007	1374	\N	0
1642609025	0	..	0	53	0	0	275	0	\N	0
994826084	0	krn	0	6	0	0	0	9	\N	0
6025322187	0	richard	0	7	0	0	0	0	\N	0
1767143991	0	-	0	2	0	0	0	6	\N	0
6313102825	0	Henrick	0	3	0	0	1000	19	\N	0
5309451414	0	anyaa.	0	17	0	0	0	99	\N	0
1438414990	0	Clàire The Rosemary. 💌	0	43	0	0	0	73	\N	0
7035636613	0	⍴ᥱіᥣᥲᥲ` 🧁🧁	0	12	0	0	0	0	\N	0
5817622530	0	ISAA	0	12	0	0	0	38	\N	0
1728136664	0	miwa	0	226	0	0	6.029999999999973	2063	\N	0
7086761081	0	𐙚. ౨ৎ jeyyara — ◟ ꒱ྀི	0	4	0	0	0	0	\N	0
6689396792	0	sabrrinah	0	2	0	0	0	2	\N	0
5577462854	0	16	0	188	0	0	0	617	\N	0
5335018841	0	karinaa	0	28	0	0	0	1	\N	0
5175040772	0	dearzy	0	55	0	0	0	104	\N	0
6750794664	0	paicery	0	4	0	0	25.78	41	\N	0
5516048911	0	r	0	48	0	0	2.3999999999999773	27	\N	0
1647166952	0	s/ia Chelsea Olivia Jjoelmex☣︎·.	0	9	0	0	0	23	\N	0
6434247324	0	arwina	0	45	0	0	0	116	\N	0
6946541536	0	áshYien	0	76	0	0	1.24	28	\N	0
5602367377	0	xiu	8	215	0	0	5504	1199	\N	0
5842391625	0	tekateki	0	3	0	0	0	21	\N	0
959807449	0	Bedhol	0	1	0	0	0	1	\N	0
1210995044	0	You'r	0	2	0	0	836.6300000000001	70	\N	0
5084074773	0	∩⑅∩ ֙⋆ 𖦹 tiaraAaa 💭🎀	0	799	0	0	594.96	1204	\N	0
5274144111	0	je	0	1	0	0	136.75	100	\N	0
5788254810	0	k	3	661	0	0	18123.339999999997	2820	\N	0
1623291183	0	♩ིྀbbiaa ྀི	11	1367	0	0	2322.5700000000024	23555	\N	1
1492166096	0	👑💍👸💅✊	12	374	0	0	9.68999999999994	66	\N	0
6349361953	0	j	11	458	0	0	38.49000000000012	2039	\N	0
7144597844	0	Keysya	0	29	0	0	0	2	\N	0
6994245738	1	Dea	0	16	0	0	0	3	\N	0
7054672395	0	Z	0	103	0	0	0	4	\N	0
6857007598	0	ㅤㅤㅤㅤ	0	2	0	0	15.2	48	\N	0
6938839746	0	yumee	0	2	0	0	0	0	\N	0
5097903955	0	jena	9	325	0	0	2465.6099999999997	3059	\N	0
1898256964	0	aisy	0	51	0	0	0	82	\N	0
5277054597	3	𝗻𝗱𝘆	0	865	1	0	14.88000000000011	1678	\N	0
1821159048	2	A	0	22	0	0	0	66	\N	0
5740691830	0	cae	0	909	0	0	555.4899999999999	2585	\N	0
6490260748	0	𝐓𝐞𝐫𝐞𝐬𝐬𝐚 (𝐆𝐆𝐓)¹	0	7	0	0	500	6	\N	0
5150305364	0	sec account.	0	27	0	0	390	38	\N	0
6965844259	0	m	0	10	0	0	0	26	\N	0
5002153755	0	aily sell minagyu	0	1	0	0	0	2	\N	0
1677327530	0	imey	0	118	0	0	92	39	\N	0
6281430902	0	𝒻 . Elleamore Lusty .. Brunette-lovas 𐚈”	0	179	0	0	4	102	\N	0
5103422095	0	jopa ☾	0	397	0	0	1441.37	641	\N	0
5568901704	0	yoraa🎀	0	257	0	0	0	8	\N	0
5161034941	0	Andra #ontwt	10	455	0	0	0	50	\N	0
7183413248	0	୨ ୧ nanda	0	1	0	0	0	0	\N	0
1811624871	0	bija	0	336	0	0	917.4100000000001	340	\N	0
1622873654	0	najae	0	204	0	0	809.02	512	\N	0
5200325805	0	𝕽ʳ Alesya	0	0	0	0	0	2	\N	0
1615616265	0	az	0	121	0	0	13.709999999999923	302	\N	0
1752387579	0	d#eyrins	0	2	0	0	0	0	\N	0
1845334375	0	Virly	0	9	0	0	0	20	\N	0
6561067415	0	bian (ikan)	5	396	0	0	2781.2599999999998	1945	\N	0
5617263514	0	Aidan	0	10	0	0	478	5	\N	0
7114570794	0	A	0	29	0	0	0	0	\N	0
5029063472	0	karin	0	8	0	0	0	13	\N	0
1971132121	0	Fiona	0	1	0	0	0	0	\N	0
1322247763	0	xmy	0	0	0	0	0	0	\N	0
2022842547	0	el	0	37	0	0	28	4	\N	0
1888006164	0	andro	0	28	0	0	0	0	\N	0
1291216944	0	karu's	0	153	0	0	2211.6900000000005	1337	\N	0
5685953424	0	Ben	0	1	0	0	0	0	\N	0
6537837682	0	andita🐢	0	43	0	0	0	76	\N	0
6358282641	0	pabyy'	0	9	0	0	0	45	\N	0
7059922521	0	Kalingga	0	1	0	0	0	0	\N	0
6648676390	0	al	0	6	0	0	0	5	\N	0
7064496299	0	𝐃Λ. Ɩᥲxеກе𝖼еɾᥲ	0	5	0	0	19	1	\N	0
5519206231	0	aey	0	8	0	0	0	79	\N	0
5224876717	0	Kystavia J.	0	7	0	0	0	1	\N	0
5936524505	1	G.	0	190	0	0	57	696	\N	0
6845521656	0	Dialopa vgs	0	8	0	0	0	0	\N	0
7131429630	0	shey	0	91	0	0	368	29	\N	0
5499889962	0	naynaynay	0	42	0	0	0	42	\N	0
2073898741	0	Cendol’s chiera	0	625	0	0	650.84	99	\N	0
1852626987	0	Pacar toji.	0	180	0	0	17.5	101	\N	0
6766513745	0	*16133*#	0	108	0	0	36	369	\N	0
7005185359	0	Vian	0	42	0	0	0	254	\N	0
1833737682	0	a	0	20	0	0	23.75	3	\N	0
6883528791	0	୧ ׅ𖥔 ۫ 𝗮leaa ⋄ 𓍯	0	27	0	0	0	10	\N	0
6727326701	0	timmy tummy	0	3	0	0	0	16	\N	0
5345478626	0	v	12	1703	0	0	474.6399999999985	44992	\N	1
1255938270	0	raa	0	305	0	0	198.97000000000003	62	\N	0
6050206174	0	el	0	60	0	0	0	35	\N	0
6972607774	0	Lauren	0	10	0	0	0	19	\N	0
6281872510	0	Chocomintys, Mey.	0	52	0	0	11	11	\N	0
1806738926	0	c	0	197	0	0	13.5	1319	\N	0
6074478529	0	𖤝 M. Lanaeyraein	0	7	0	0	0	14	\N	0
5215728952	0	.	14	700	0	0	53992.17000000001	49855	\N	1
1067563906	0	amelia	0	6	0	0	0	0	\N	0
5956787994	0	Madison	0	41	0	0	995.9100000000001	0	\N	0
6396125228	0	anna 山田 (REST!) 🪷	4	66	0	0	2882.5699999999997	1569	\N	0
1935088997	0	adeena <3 soohyun	1	450	0	0	2338.04	8047	\N	0
6052670152	0	Ella	0	90	0	0	0	5	\N	0
1392382368	0	ale	0	8	0	0	0	0	\N	0
1148290722	0	C	0	1	0	0	0	4	\N	0
2048515022	0	nero	0	26	0	0	1000	13	\N	0
5157604441	0	pano	0	3	0	0	7.6	34	\N	0
1319704772	0	an	0	500	0	0	10.869999999999834	413	\N	0
5081282830	0	Robo	0	13	0	0	0	38	\N	0
1798930873	0	eSyA	14	832	1	0	4.980000000000018	200	\N	0
5199515776	0	Kocheng	8	773	0	0	11.910000000000046	8	\N	0
5098932019	0	jor	0	27	0	0	0	0	\N	0
5922407202	0	gatau	0	6	0	0	0	0	\N	0
1919362935	1	ㅤ ㅤ	0	230	0	0	13.849999999999994	14	\N	0
1244915075	0	chocomalt	0	5	0	0	0	0	\N	0
5729260718	0	Doubt	0	0	0	0	0	0	\N	0
1163465224	0	thor	0	0	0	0	0	1	\N	0
5238600313	0	d	0	41	0	0	0	4	\N	0
5041640339	0	Oniel ɢᴀᴠʀɪᴇʟ	0	4	0	0	0	39	\N	0
6572667374	0	dista	2	70	0	0	477.7999999999999	22	\N	0
1500270642	0	atlas	0	2	0	0	0	0	\N	0
6960194809	0	p	0	2	0	0	0	0	\N	0
6482020061	0	Z	0	2	0	0	0	13	\N	0
901762364	0	xyz	0	1	0	0	0	2	\N	0
5854402255	0	chava 🤺🤺	0	1	0	0	0	0	\N	0
6297638030	0	Jiu, RA.	4	81	0	0	675.1400000000001	15	\N	0
6347219838	0	Abian D’Arcy	14	36	0	0	3855.9399999999996	84	\N	0
2081289203	0	Angkasa	2	24	0	0	0	140	\N	0
6944560724	0	Kav.	0	7	0	0	0	0	\N	0
1611464221	0	p	0	27	0	0	36.099999999999994	24	\N	0
6750047062	0	m	0	76	0	0	0	4	\N	0
5678377916	0	pocky	0	6	0	0	0	3	\N	0
6923477436	0	୨୧ .. Briellè, Me amor haechan's	0	4	0	0	0	13	\N	0
1243407398	0	Seele.	0	14	0	0	0	319	\N	0
1748600449	0	aurora	5	1132	0	0	35.75000000000068	2068	\N	0
5092780635	0	F	0	485	0	0	0	339	\N	0
6429801989	0	Ᏽ𐌓 abay⁶	5	204	0	0	148.90999999999997	6	\N	0
5526142019	0	marja	0	64	0	0	80	942	\N	0
6792412478	0	Sherin ᵕ̈	7	436	0	0	58.01999999999998	1672	\N	0
1784729127	0	tharah hungry	0	23	0	0	227.5	42	\N	0
6095703959	0	ito	0	16	0	0	0	16	\N	0
5196635620	0	m	0	494	0	0	970.8200000000006	2325	\N	0
5603866272	0	이희승	0	106	0	0	735.4099999999997	302	\N	0
5909917020	0	ktty	0	36	0	0	0	6	\N	0
6672000581	0	i	0	1	0	0	0	0	\N	0
6609811339	0	mey	0	6	0	0	0	1	\N	0
7149135846	0	ss	0	17	0	0	1000	35	\N	0
6890438566	0	melissSaa	0	61	0	0	9.620000000000005	147	\N	0
1459365728	0	𝓡inaa louvent.	4	526	0	0	1947.6699999999978	4218	\N	0
6624604192	0	Sky Bocil	0	2	0	0	0	1	\N	0
5012862941	0	meeya #SOLadventurer	0	0	0	0	0	0	\N	0
5862657253	0	Fuck Mooi	0	15	0	0	0	2	\N	0
2010557097	0	carla	3	745	0	0	12096.809999999998	7685	\N	0
1206967567	0	Darrel	0	131	0	0	3.769999999999925	208	\N	0
6980300887	0	LavanyA, Sunghoon's.	0	0	0	0	0	18	\N	0
6296020455	0	shey	0	107	0	0	1331.9999999999998	462	\N	0
1988158172	0	ᶻ 𝘇 𐰁	0	65	0	0	0	113	\N	0
1910059580	0	ㅤ	0	24	0	0	0	89	\N	0
1965103043	0	Valyn "cece pcr ecan n ibas"	0	1	0	0	0	2	\N	0
5203605402	0	Misyana N.	0	8	0	0	0	0	\N	0
7102792173	0	cica. universe	0	4	0	0	17.8	7	\N	0
1724955209	0	źynlyn d.	0	21	0	0	434	13	\N	0
2068277532	0	itsnop	0	6	0	0	0	0	\N	0
6238144082	0	map	0	181	0	0	604	194	\N	0
5328825833	0	Joanné K.	0	1	0	0	0	1	\N	0
5878207374	0	gea 𝐕𝐙 あ	0	3	0	0	711.08	3	\N	0
2091322867	0	e	0	78	0	0	0	38	\N	0
1835120206	0	Jev	0	0	0	0	0	2	\N	0
2048410770	0	niannnd	0	1	0	0	0	7	\N	0
1851401347	0	jeje جينلين	0	59	0	0	0	53	\N	0
6463033662	0	Re	0	10	0	0	0	8	\N	0
5958348690	1	eca	0	20	0	0	149.2	67	\N	0
5593177916	0	Anindiya, K	0	0	0	0	0	0	\N	0
5082731714	0	Josh Mattley.	0	1	0	0	0	0	\N	0
6658805581	1	nanat	0	11	0	0	0	1	\N	0
7097976879	0	Mei-chan!	0	1	0	0	93.85	157	\N	0
6563826438	0	sui	0	200	0	0	293.39	1027	\N	0
2143605037	1	Ken dni	0	574	0	0	2	838	\N	0
6197009633	0	ᴀʟᴇxᴀ	0	10	0	0	77.67000000000002	10	\N	0
2014592281	0	benjiro	0	1	0	0	0	2	\N	0
499787363	0	G.	0	295	0	0	7.5	2625	\N	0
6304257754	0	ifa	0	1	0	0	0	0	\N	0
1124078667	0	Ody	0	10	0	0	0	0	\N	0
5061171159	0	piw	0	8	0	0	0	5	\N	0
1595053604	0	.	0	111	0	0	0	0	\N	0
1588239450	0	Mas	0	6	0	0	0	0	\N	0
6699441254	0	36. zivara lathifa (7.7)	0	2	0	0	0	0	\N	0
5629986156	0	mairaa	9	1645	0	0	2047.5199999999995	6901	\N	0
5501187841	0	Robbin	0	46	0	0	0	4	\N	0
5936064210	0	Ren	0	161	0	0	17.09	159	\N	0
5407675751	0	D	3	44	0	0	0	60	\N	0
6759184807	0	.	0	115	0	0	50	228	\N	0
1278621584	0	lova	0	59	0	0	0	4	\N	0
6667740374	0	orang waras	0	163	0	0	4.25	13	\N	0
1727081150	0	w	0	67	0	0	0	0	\N	0
1353948603	0	Rayna	12	530	0	0	59.43999999999942	1043	\N	0
6684452817	0	lagi turu	0	48	0	0	0	57	\N	0
6887198608	0	kew awr	0	36	0	0	0	7	\N	0
1749468095	0	kai.	13	1003	0	0	6172.4400000000005	7536	\N	0
6106570690	0	naaa	0	124	0	0	0	51	\N	0
7104163140	0	— 🌷. nad ૮꒰ ˶• ༝ •˶꒱ა	0	34	0	0	0	7	\N	0
1840934303	0	Kj	0	5	0	0	14.540000000000077	352	\N	0
5583798927	0	jia	0	1121	0	0	2304.939999999999	14177	\N	0
1669549999	0	ᥫ᭡ uwiuwiu	0	11	0	0	0	1	\N	0
6027356063	0	tsha.	0	10	0	0	0	4	\N	0
5451426022	0	Mey	12	348	0	0	247.06999999999994	222	\N	0
2146555023	0	jopen	0	413	0	0	-1.9600000000002638	627	\N	0
7112420030	0	jane.	0	218	0	0	9.16	0	\N	0
7080084150	0	athena withney.	5	140	0	0	3.539999999999999	542	\N	0
6774689731	0	Görg-Art lentera	0	3	0	0	0	1	\N	0
5341968880	0	Kanaya, @.prettierts	0	5	0	0	0	0	\N	0
6515244852	0	155 gina	0	15	0	0	115.59	135	\N	0
6904293519	0	lala	0	42	0	0	0	0	\N	0
6163314866	0	𝙅ordy[actv.	0	12	0	0	98.72	547	\N	0
5640704296	0	.....	0	2	0	0	0	0	\N	0
7110971924	0	grizelle	0	3	0	0	0	3	\N	0
1758581226	0	kal	0	80	0	0	54.44999999999999	38	\N	0
5275251786	0	seaa	0	67	0	0	643.97	137	\N	0
1859201079	0	Han	0	1	0	0	0	0	\N	0
6388663729	0	nn	0	7	0	0	0	11	\N	0
6141757098	0	CANOVE	0	1	0	0	0	0	\N	0
5395974552	0	Anyyaaaa G	0	7	0	0	0	0	\N	0
2062465962	0	KYRAA .	12	195	1	0	2866.84	181	\N	1
6294825428	0	Radena	0	10	0	0	26.22	0	\N	0
1772213089	0	·⊹⊱ 𝒞ece ⊰⊹·	0	1	0	0	0	0	\N	0
5415258180	0	jena	0	0	0	0	0	44	\N	0
6761816336	0	demdud	0	8	0	0	0	92	\N	0
5842800222	0	derii	0	27	0	0	0	52	\N	0
6536424820	0	kaa~	0	27	0	0	0	22	\N	0
6508354965	0	av	0	122	0	0	0	7	\N	0
5005567464	0	⋆ ‹ Mouline ˖ ࣪	0	42	0	0	978	16	\N	0
7068387680	0	jodoh heeseung, sayna. 𐙚ᵃˡᵗʳᵃⁱⁿᵉᵉ	0	5	0	0	2500	193	\N	0
1389361313	0	r	0	6	0	0	0	8	\N	0
5759180918	0	𝙼𝚊𝚑𝚎𝚗	0	4	0	0	0	7	\N	0
6601828730	0	jean ōtsuki	0	2	0	0	0	1	\N	0
1578274109	0	Kava	0	1	0	0	0	0	\N	0
2026786190	0	a?	0	11	0	0	0	0	\N	0
6885971027	0	ʜᴠᴄ` ᴏɴᴛᴇʀᴀ	0	1	0	0	0	0	\N	0
1366885600	0	stuca	0	147	0	0	577	463	\N	0
1933447766	0	=͟͟͞͞ câcaִִׂ֟፝₊˚¹²	0	2	0	0	0	1	\N	0
1317277470	1	nv	0	74	0	0	0	485	\N	0
6071041299	1	🎸 💌 🍓 🎧	0	156	0	0	0	21	\N	0
7121759766	1	k	0	13	0	0	0	3	\N	0
6213510057	0	chee	0	17	0	0	1221.85	32	\N	0
6148939927	0	Aysielle relindsey	0	40	0	0	1287	21	\N	0
1822226307	0	r	8	496	0	0	2.9600000000000932	308	\N	0
5896880375	0	.	2	8	0	0	139.23000000000047	190	\N	0
1974665541	0	kei, zoro’s lovebot.	0	19	0	0	0	134	\N	0
5715241575	0	Rex	8	336	0	0	2970.83	792	\N	0
6562844559	0	althern	11	245	0	0	6919.39	1	\N	0
5455326698	0	putih	0	8	0	0	0	16	\N	0
7054053982	0	.	0	19	0	0	0	12	\N	0
7111836743	0	raisha	0	217	0	0	0.7400000000000233	49	\N	0
1684796012	0	abel	0	95	0	0	0	112	\N	0
6178260600	0	Haheaheya.	0	3	0	0	0	23	\N	0
5516487599	0	Sendu	0	0	0	0	0	1	\N	0
2026902859	0	Takayuki D Tatsuya	0	1	0	0	0	48	\N	0
1481792355	0	gista	0	699	0	0	1185.42	1096	\N	0
5124410536	0	joanna	0	71	0	0	0	3	\N	0
1855745040	0	gama	0	1723	0	0	1.920000000000016	818	\N	0
2044257868	0	kanya	4	97	0	0	2104.8	541	\N	0
1827024829	0	sean	0	20	0	0	0	8	\N	0
1734328468	0	Giant.	14	643	0	0	0.7000000000005002	2455	\N	0
1478639687	0	widya 💋	0	178	0	0	684.9399999999999	381	\N	0
1923239637	0	elvan	0	6	0	0	0	1	\N	0
6743413245	0	ㅤㅤㅤㅤㅤㅤ	0	94	0	0	1426.7600000000002	1385	\N	0
6083074339	0	dilla	0	0	0	0	0	3	\N	0
5739606015	0	LostHeaven	0	1	0	0	0	0	\N	0
1711888188	0	Xena	0	3	0	0	0	2	\N	0
5055306835	0	Ame	0	132	0	0	0	218	\N	0
6343082799	0	dani	0	2	0	0	0	13	\N	0
6596803376	0	jo	6	14	0	0	0	76	\N	0
2125911515	0	serleeeen	0	0	0	0	0	3	\N	0
1259137842	0	nay	0	500	0	0	2084.35	116	\N	0
2118206683	0	@okelinci	0	13	0	0	0	2	\N	0
5956357207	0	.	0	4	0	0	0	10	\N	0
1809009886	0	ayraa	0	3	0	0	0	0	\N	0
5773670619	0	vava dino	0	25	0	0	0	7	\N	0
1928339393	0	𝘼𝙣𝙜𝙚𝙡𝙖 𝙅𝙖𝙣𝙚	0	1	0	0	0	0	\N	0
5851341128	0	da	0	5	0	0	0	1	\N	0
5668989602	0	ppiinnu	0	245	0	0	-9.5	131	\N	0
6984389953	0	pai	0	33	0	0	0	457	\N	0
6979324573	8	Cyrus	4	50	0	0	883	1773	\N	0
5993456393	0	ell	2	565	0	0	2.109999999999957	223	\N	0
1942809530	0	ay	0	1121	0	0	7465.220000000001	1833	\N	0
7129206786	0	Shannea J.	0	3	0	0	0	0	\N	0
1553816001	0	Aesterium	0	329	0	0	16.18000000000029	1452	\N	0
5642402408	1	ea	9	728	0	0	201.8500000000001	16	\N	0
5559431948	3	jelay` ōtsukitzu	0	68	0	0	11	516	\N	0
6905329130	3	ky.moe	0	24	0	0	0	10	\N	0
1798517609	0	kei	0	19	0	0	0	48	\N	0
5450974584	0	Haera, M	0	33	0	0	0	22	\N	0
5748529945	0	Jara	0	19	0	0	0	176	\N	0
6583351452	0	ini yeca	0	139	0	0	1760.3000000000002	926	\N	0
7133819047	0	🍭🍬	6	167	0	0	224	350	\N	0
5815605247	0	reeeiii	0	106	0	0	230	30	\N	0
1972854507	0	blupblup	0	50	0	0	0	62	\N	0
5093027199	0	raden	0	89	0	0	0	9	\N	0
5448437184	0	nicaa	0	40	0	0	0	23	\N	0
7056397165	0	élmano	0	38	0	0	0	1	\N	0
1433094758	0	Vicky	0	32	0	0	7343	32	\N	0
5545932400	0	falè;༊	7	339	0	0	1344.69	889	\N	0
6181937134	0	Arya	0	211	0	0	75	92	\N	0
6389358504	0	RBIO SEBELUM KE RC.	0	2	0	0	0	0	\N	0
5069255530	0	rara here🙌🏻	0	9	0	0	0	10	\N	0
5841280839	0	Mondstadt God	0	233	0	0	13.779999999999802	182	\N	0
6397567890	0	punk	0	11	0	0	0	5	\N	0
5955745352	0	AR.	0	31	0	0	70.05000000000001	20	\N	0
1428773316	0	Oliver	0	181	0	0	91.5	8	\N	0
6007379801	0	anggara	5	171	0	0	2968.2100000000005	68	\N	0
6708128328	0	友 ᗪŕ𝓋.ᵗ⁴ʳⁱᵏ	0	7	0	0	0	2	\N	0
6452242446	0	Jerry FAST CHARGING.	0	3	0	0	0	48	\N	0
5346325583	0	Hazen G.	0	1	0	0	0	11	\N	0
5521835273	0	fafifufefo	14	399	0	0	2256.7199999999966	10777	\N	0
5859595112	0	yyaa`	0	10	0	0	100	10	\N	0
6625916228	0	nai second akun bkn second choice	0	1	0	0	0	0	\N	0
6877575762	0	na	0	1	0	0	0	1	\N	0
5213331242	0	piooo	0	1	0	0	0	1	\N	0
6634416362	0	༊. th'majestic², mumuu <🦢>	0	4	0	0	0	18	\N	0
6107851780	0	𝅄 ֹ beauté; ney. @gairazh	9	9	0	0	19626.230000000003	29	\N	0
6362160423	0	myra	0	13	0	0	0	199	\N	0
5265052400	0	Inactive	0	12	0	0	0	1	\N	0
6178210672	0	coe RBIO & BUKAN ADMIN WTB	0	59	0	0	0	14	\N	0
6520615889	0	mermet rill	0	9	0	0	0	54	\N	0
5820318708	0	Len.	0	11	0	0	0	16	\N	0
6744464052	1	iànn	0	71	0	0	1961	16	\N	0
1335731199	0	Arbia.	10	319	0	0	634.2800000000002	2536	\N	0
5893491762	3	.	0	54	0	0	0	7	\N	0
5516233304	0	snowwie	3	469	0	0	3937.0799999999995	1977	\N	0
1876566073	0	jihan	0	7	0	0	0	0	\N	0
6560012420	0	:ྀི 𓊆 he±art, past. 𓊇	0	17	0	0	0	9	\N	0
6243900160	0	AaaCilL :33	8	287	0	0	10.629999999999995	168	\N	0
6342621646	0	🐝	0	28	0	0	241.83999999999997	3	\N	0
6391544568	0	naa	0	6	0	0	0	1	\N	0
5544278057	0	NakedCigoo	4	886	0	0	1099.0900000000001	2745	\N	0
5272553470	0	Rav.	0	15	0	0	0	5	\N	0
5187492982	0	hh 🍑	0	32	0	0	0	210	\N	0
2142392343	0	Praja	0	6	0	0	0	19	\N	0
2086258142	0	vela	0	16	0	0	0	13	\N	0
1229423790	2	nanang gajah🌜	9	1099	0	0	163.95000000000232	2775	\N	0
1216745642	1	ㅤㅤㅤㅤㅤ	0	41	0	0	41.44999999999999	206	\N	0
6311924119	0	Enay	4	68	0	0	4043.5499999999993	4138	\N	0
6777779489	0	sea kill	0	0	0	0	0	172	\N	0
1480277154	0	arréll	0	436	0	0	2.8299999999999983	371	\N	0
6770100211	1	kei	0	150	0	0	1	63	\N	0
1879605969	0	nay f1 fan	0	861	0	0	5.859999999999985	1993	\N	0
6250425388	0	⊛ ᴇxᴠ kiel	0	449	0	0	387.8499999999999	14929	\N	0
1541339875	2	methee	8	1128	0	0	62.30000000000001	347	\N	0
6002623946	0	Shakira	1	378	0	0	9932.85	4851	\N	1
6522971663	1	sasimihy	8	87	0	1	7.350000000000001	3990	\N	0
2118728362	1	Trishten Williams. DNI	14	2345	0	0	14079.800000000001	27959	\N	0
6514163213	3	ireneee	0	327	0	0	36.480000000000054	1169	\N	0
6556439949	0	ㅤㅤhaezo	12	114	0	0	477.64999999999964	692	\N	1
5405288652	0	sasa	0	24	0	0	0	40	\N	0
6954265550	0	kayiya	0	2	0	0	0	0	\N	0
1404046370	0	gigiie	0	1	0	0	0	0	\N	0
1266711863	0	langit	0	3	0	0	0	6	\N	0
6965404201	0	Reyyx	0	1	0	0	0	1	\N	0
5498131708	0	f	0	0	0	0	0	16	\N	0
1795032268	0	Ashey	0	11	0	0	478	2	\N	0
2023117551	0	cioy	10	933	0	0	184.58999999999884	13399	\N	0
6815008284	0	Noel	0	5	0	0	0	0	\N	0
6597796533	0	𝗠𝘀. 𝗙𝗶𝗼𝗻𝗻𝘆	2	218	0	0	31.660000000000007	311	\N	0
1662531691	0	jia	10	561	0	0	1720.0700000000027	1794	\N	1
7064746821	0	Jeanette	0	3	0	0	209.97	59	\N	0
6289281620	0	Exel	7	593	0	0	219.93999999999986	291	\N	0
1719666758	0	🐋	0	65	0	0	331.8	2814	\N	0
1623062331	0	vella	0	45	0	0	0	25	\N	0
1554663232	0	ayara.	9	820	0	0	5.509999999999877	29	\N	0
5013602753	0	aleee	0	92	0	0	47.75	166	\N	0
6730718095	0	︎ ︎	9	480	0	0	4.830000000000098	1547	\N	0
5282463690	0	Ary	0	2	0	0	0	0	\N	0
5731840301	0	A	4	231	0	0	528.5699999999999	297	\N	0
6892039575	0	na.	14	237	0	0	0.34999999999990905	476	\N	0
6275501235	0	Lachesis	0	248	0	0	7.939999999999998	261	\N	0
6065097516	0	amaraaa	12	2711	0	0	7.32999999999879	10558	\N	1
6623424823	0	Jethro H.	6	119	0	0	382.95	133	\N	0
1944607260	0	Kipas angin	0	550	0	0	0	816	\N	0
2117210475	0	bang agoy	0	22	0	0	839.49	647	\N	0
5361749143	0	ayeshaa!	0	28	0	0	1.4899999999999984	199	\N	0
6324752707	0	𝕽𝖊𝖒𝖇𝖚𝖑𝖆𝖓	0	23	0	0	0	2	\N	0
5561652965	0	ann mys	0	63	0	0	201.13999999999993	676	\N	0
7123354125	0	dnd	0	17	0	0	281.66	560	\N	0
6489605503	0	𝖏𝒶	0	32	0	0	0	0	\N	0
6527831285	0	ka	0	42	0	0	0	53	\N	0
5806178329	0	Avaeyra.	0	11	0	0	0	20	\N	0
5907714333	0	kiki	0	220	0	0	120.80000000000001	720	\N	0
1870004019	0	koyo	0	121	0	0	3840	179	\N	0
1051529699	0	a	0	64	0	0	0	22	\N	0
1975010208	0	michieee	0	15	0	0	0	1	\N	0
1771119085	0	熊 ֶָ֪ ra	0	234	0	0	164.05	40	\N	0
5131599065	0	za	0	194	0	0	8.73	99	\N	0
1433599585	0	lan	0	14	0	0	0	0	\N	0
1688209672	0	ℜ𝔦𝔠𝔠𝔥𝔞𝔫	0	240	0	0	594.39	1533	\N	0
1842768387	0	eiza 💤	12	586	0	0	22575.239999999987	3628	\N	1
5728774299	0	d	0	55	0	0	0	133	\N	0
6647784832	0	jessya	0	534	0	0	7887.48	69	\N	0
6925346180	0	𓇻֢ ׁ𝔍▸ O'! myya	0	20	0	0	185	161	\N	0
5015035766	0	aksan	3	3409	0	0	2.929999999999154	23445	\N	1
1178685501	0	⸙ꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋꠋfiqri	8	413	0	0	248.49000000000007	6098	\N	0
6931966353	0	azkya agit	0	4	0	0	21.66	55	\N	0
5463897479	0	Shaix 4twenty🛺🏍🛵🚌🚙🏎🚗🚛🚚🦽🛴🚅🚄🚝🚋🚃🚟🚞🚚🛻🚐🚛🚜🚒🚑🚓🏎🚎🚌🚙🚕	0	18	0	0	136.48000000000002	0	\N	0
6990549820	0	Nakata	0	21	0	0	112	490	\N	0
5934885099	0	ragaska	0	1	0	0	0	1	\N	0
1445694378	0	Capt Morgan.	0	5	2	0	0	3	\N	0
5340781391	0	d	0	23	0	0	0	249	\N	0
6925505504	0	Arta	0	12	0	0	0	0	\N	0
7029325624	0	Jerico de'Rico	9	102	0	0	2338.7200000000007	2364	\N	0
6898883395	0	.	0	61	0	0	872.55	301	\N	0
1101312752	0	ryan	0	1	0	0	0	1	\N	0
6355441760	0	tyas	0	5	0	0	0	1	\N	0
6048299347	2	saturnus°	0	98	0	0	1342	447	\N	0
5869696202	0	Quuenaa	0	12	0	0	0	6	\N	0
5443816512	0	هذه جيهان	0	16	0	0	0	22	\N	0
2039415792	0	🥶	0	11	0	0	0	12	\N	0
2136855799	0	Alice	0	2	0	0	0	0	\N	0
1901280499	0	ifaa	0	1	0	0	0	0	\N	0
1905191549	2	jopex	0	614	0	1	480.7800000000011	2050	\N	0
6395349440	1	steventong kucing joki epik-mitik 120k	2	488	0	1	5.8700000000000045	2072	\N	0
7166304108	0	oh my gosh what the heck eonnie	0	8	0	0	0	0	\N	0
2048533501	0	queen	0	3	0	0	0	0	\N	0
6233957061	0	ೀ ˙	0	16	0	0	0	5	\N	0
6778158575	0	p	0	1	0	0	0	1	\N	0
6369786933	0	Loganja	0	1	0	0	0	0	\N	0
5903159398	0	‘𝒮𝒽𝒶. Dirka	0	38	0	0	0	3	\N	0
1247764063	0	🐬	0	66	0	0	0	0	\N	0
2104132079	0	s	0	93	0	0	0	14	\N	0
6136033312	0	segasigisugu	0	19	0	0	0	14	\N	0
6259549607	0	lowbatt	0	79	0	0	1931	402	\N	0
6656604504	0	karinnnn	0	16	0	0	0	0	\N	0
5388488885	0	itz_chaa	0	1	0	0	0	0	\N	0
1311236670	0	J	0	137	0	0	0	54	\N	0
1842626660	0	Hacel	0	22	0	0	0	2	\N	0
1696764060	0	Sahelena	0	281	0	0	134.73000000000002	292	\N	0
1664485044	0	yor	0	56	0	0	0	216	\N	0
6964937274	0	dil	0	5	0	0	0	13	\N	0
5066615234	0	ㅤ𝓶¡𝓵𝓸𝓿𝓮𝓙	0	8	0	0	0	16	\N	0
6354898208	0	Ceils	0	32	0	0	0	2	\N	0
2105136872	0	shev	0	47	0	0	0	6	\N	0
6333048903	0	Azzam	0	44	0	0	82.37999999999998	63	\N	0
5893425193	0	vivi	0	2	0	0	65.39	79	\N	0
5998305695	0	Marka	0	0	0	0	0	0	\N	0
5165792204	0	ayyaaa :p	0	13	0	0	0	65	\N	0
1338561342	0	lia	0	195	0	0	6.66	580	\N	0
6472472511	0	ae	0	2	0	0	0	9	\N	0
1450033108	0	ivy	0	5	0	0	0	1	\N	0
5252405333	0	Nala	0	1	0	0	0	2	\N	0
6484462539	0	n🅰nuyyyy	0	125	0	0	559.3699999999994	5081	\N	0
6846850739	0	J	0	15	0	0	0	306	\N	0
1960520979	0	ci	7	1766	0	0	847.2524999999997	3125	\N	0
6359769423	0	d	4	208	0	0	49.460000000000036	1	\N	0
2145926318	0	M	0	103	0	0	14.24999999999779	59	\N	0
5712146782	0	Meong	0	141	0	0	7.200000000000358	244	\N	0
5387243225	0	a	0	35	0	0	67.45000000000107	12	\N	0
2036999591	0	biru laut	0	0	0	0	0	0	\N	0
6642953911	0	din✿	0	1	0	0	217.28	6	\N	0
2039730703	0	alvien	0	19	0	0	0	316	\N	0
5176586934	0	K	0	3	0	0	0	0	\N	0
6139847087	0	Va	0	6	0	0	0	2	\N	0
1211324130	0	𝟕𝟎𝟕.Radayu	6	105	0	0	1197.13	1686	\N	0
5239866924	0	Kale J.	0	2300	0	0	1741.6515	817	\N	0
6275975368	0	bieloora lulus snbt pil 1	0	404	0	0	4143.0599999999995	5302	\N	0
7063125325	0	ici	0	14	0	0	554.55	267	\N	0
6086589687	3	jean ✝️	6	1388	1	1	1420.5700000000006	1451	\N	0
6365569802	0	Raynaldi	0	2	0	0	0	10	\N	0
1958994098	0	1102020193_Vinolia Sandhyano A.P.W	0	54	0	0	0	0	\N	0
1656198277	0	chell	0	2	0	0	0	1	\N	0
720531487	0	Abiratex	0	3	0	0	0	0	\N	0
5663153493	0	Liam	0	4	0	0	0	2	\N	0
6981954667	0	࣪ 𐙚 ˒ ıllı namiee ⁺ ݂ ♡ :	0	1	0	0	0	0	\N	0
5815899386	0	fuck u	0	44	0	0	133.44	148	\N	0
6207204351	0	ayaariin	0	149	0	0	0	191	\N	0
1839637403	0	ayesha	0	3	0	0	0	1	\N	0
1843554104	0	ca	0	103	0	0	0	0	\N	0
6382901915	0	crs-ta	0	8	0	0	11.33	10	\N	0
5869682071	0	Alvina	4	76	0	0	43.480000000000125	88	\N	0
5702277678	0	ini wawa	0	133	0	0	4444	2954	\N	0
1407839331	0	nara :]	0	4	0	0	0	1	\N	0
1814437233	0	Abiii	0	1	0	0	0	12	\N	0
5041484248	0	Personall A. superious teresha	0	4	0	0	0	10	\N	0
1868465945	0	sambel kacang	0	6	0	0	0	0	\N	0
1257529171	0	Buckingham.	0	1	0	0	0	0	\N	0
5907575088	0	Ramskull	0	1	0	0	0	4	\N	0
1527977025	0	fafa ph	0	4	0	0	0	39	\N	0
5613274163	0	𝐶𝐿. ell	0	0	0	0	0	0	\N	0
6309776578	0	mahen	0	11	0	0	0	0	\N	0
6688834840	0	Kazzuha	0	1	0	0	0	1	\N	0
5836317950	0	Emileyth Joireschly.	5	62	0	0	47.510000000000005	29	\N	0
6020158934	0	‎♡ . . reya salima 🧚🏻‍♀️	0	1	0	0	0	3	\N	0
5622936257	0	Amey ... {haloUpdating!}	0	7	0	0	0	24	\N	0
6552459284	0	ale	0	166	0	0	0	3	\N	0
5794998443	0	yaura, @LaYaura.	0	3	0	0	0	1	\N	0
1743179415	0	pipaww	0	68	0	0	0	112	\N	0
6729539095	0	rAchel	0	3	0	0	0	0	\N	0
6929977076	0	bia	0	51	0	0	0	8	\N	0
6214108637	0	Azmi	0	1	0	0	0	1	\N	0
6924879175	0	ima	0	10	0	0	0	19	\N	0
5298369466	0	Bro	0	0	0	0	0	0	\N	0
5875159924	0	Jaguares L.	0	2	0	0	0	1	\N	0
5320194598	0	riri	0	145	0	0	82.41	26	\N	0
5343132620	0	Noah	0	67	9	0	7749	9	\N	0
1904386406	0	farel	0	9	0	0	221.26999999999998	26	\N	0
6714199665	0	star	0	2	0	0	0	0	\N	0
1973724239	0	keisyaa	0	5	0	0	0	0	\N	0
7108460470	0	<Ayaya!3	0	4	0	0	0	2	\N	0
1349120854	0	ayaaa	0	7	0	0	0	17	\N	0
6249534993	0	e	0	1	0	0	0	0	\N	0
5017529358	0	DhyAL	0	19	0	0	0	0	\N	0
1568645221	0	R	0	162	0	0	0	176	\N	0
5791029719	0	ㅤㅤhengky squarepants	0	67	0	0	424.7700000000001	2108	\N	0
1648752624	0	kevin	0	2	0	0	0	0	\N	0
5443472362	0	A	0	59	0	0	0.23000000000013898	261	\N	0
1324590613	0	Kenma.	0	11	0	0	0	72	\N	0
1726306873	0	nazwa	0	36	0	0	127.5	25	\N	0
5055915814	0	rivaldo salima	0	1	0	0	0	0	\N	0
5382836079	1	g	0	38	0	0	0	3	\N	0
1668558936	0	nini🕊️	0	8	0	0	0	8	\N	0
5112508301	0	Harvey	0	3	0	0	0	6	\N	0
6483991444	0	Gi, Sheyla.	0	12	0	0	0	1	\N	0
5762296752	0	Aetherr	0	13	0	0	170.94	44	\N	0
5943639341	0	Rizki.	0	10	0	0	0	30	\N	0
5032839385	0	Jean @dxrnv	0	18	0	0	0	1	\N	0
5541463534	0	⊹ fᥣower's ˖ ࣪ . ୨୧	0	3	0	0	0	1	\N	0
6545867945	0	shenalaa	0	3	0	0	0	5	\N	0
5593728868	0	A0ka	0	1	0	0	0	0	\N	0
5546870338	0	iky	0	2	0	0	5.4	0	\N	0
6278460771	0	Asyaഒ	6	692	0	0	4.559999999999604	727	\N	0
1183621139	0	.	0	20	0	0	0	5	\N	0
1830383648	0	zion	0	3	0	0	0	0	\N	0
5902533111	0	ineyy	0	50	0	0	284	54	\N	0
6479361973	0	.	0	1	0	0	0	0	\N	0
6424335077	0	Nailaa	0	1	0	0	0	0	\N	0
5177766266	0	🦢	0	22	0	0	0	0	\N	0
1389215505	0	Yolleina Shabine.	3	78	0	0	3009.84	7014	\N	0
6206357257	0	Jorgas	0	1	0	0	0	0	\N	0
1341001753	0	Naisya.	12	99	0	0	3591.080000000002	4237	\N	0
6178488367	0	Shenina.	0	91	0	0	0	21	\N	0
6256831200	0	Sachira. ᨒ¹³	6	30	0	0	13.07	5	\N	0
6229856910	0	Michael	0	1	0	0	0	4	\N	0
5849610012	0	ندى	0	84	0	0	0	0	\N	0
5308763605	0	ㅤㅤ	0	8	0	0	0	0	\N	0
1354253769	0	saaciew jauzaa.	6	10	0	0	447.7499999999999	394	\N	0
5036567407	0	Lavierra.	0	13	0	0	0	0	\N	0
6649582260	0	Donattalia	0	6	0	0	0	27	\N	0
6716784931	0	Poni . K	0	1	0	0	0	0	\N	0
1946061726	0	Alzen.	0	8	0	0	0	1	\N	0
1863856302	0	eL	0	57	0	0	0	4	\N	0
5183451482	0	?	0	83	0	0	0	5	\N	0
5408401970	0	Arbeeya S.	0	1	0	0	0	0	\N	0
7068269633	0	esta	0	5	0	0	0	0	\N	0
6143302088	0	ivy	2	24	0	0	203.35	123	\N	0
6565115089	0	pici	0	1	0	0	0	0	\N	0
7191165581	0	Yera	0	1	0	0	0	0	\N	0
5844591735	0	Lulu	0	14	0	0	0	1	\N	0
5777708681	0	el.	0	2	0	0	71.43	16	\N	0
2136976956	0	OJIᴴᴸ	0	2	0	0	0	0	\N	0
6939117482	0	ayinn	0	1	0	0	0	0	\N	0
1108503059	0	n	0	2	0	0	0	0	\N	0
5314625660	0	ryyca	0	82	0	0	933	66	\N	0
5431786041	0	syeriella	14	1148	0	0	2.7599999999997635	1123	\N	1
5311893448	0	cAkeisHA ୨ৎ	0	41	0	0	0	34	\N	0
6645397515	0	Kenan	0	2	0	0	0	4	\N	0
1873974517	0	angelin	0	16	0	0	0	20	\N	0
5281448806	0	ael risol	0	2	0	0	0	0	\N	0
6020296539	0	Sho.	0	1	0	0	0	2	\N	0
2058090885	0	biw	0	40	0	0	0	0	\N	0
1816597602	0	rvg renjana	0	31	0	0	0	62	\N	0
1902604714	0	caca	0	6	0	0	0	56	\N	0
6344522162	0	Aris	0	0	0	0	0	2	\N	0
1152093269	0	Ethaniel A.dr	0	0	0	0	0	0	\N	0
5332058468	0	akactz	0	1	0	0	0	0	\N	0
1879370756	0	Abila. 🌪	0	3	0	0	0	10	\N	0
5517277747	0	gina	2	300	0	0	144.44000000000005	1074	\N	0
7134057298	0	lun	0	6	0	0	0	7	\N	0
5421387666	0	jen	0	1	0	0	0	10	\N	0
6807496003	0	matteo	0	288	0	0	474.3399999999999	153	\N	0
5048954985	1	âbil	0	256	0	0	0	1599	\N	0
6376230542	0	athèra versace 🍀	0	83	0	0	223.57	353	\N	0
5203859359	0	000	5	1107	0	0	52102.59999999999	2808	\N	0
5880074733	0	flor(alice)	10	851	0	0	803.2799999999992	9380	\N	0
5872238293	0	Laluna	0	1	0	0	0	0	\N	0
6219977208	0	Senju.	0	7	0	0	0	0	\N	0
6796032938	0	Putra	0	0	0	0	0	0	\N	0
2126078672	0	(wo)man.	0	17	0	0	0	1	\N	0
6004657357	0	R	0	6	0	0	0	0	\N	0
1870810097	0	╰ Xaviér Λ.V.Σ ۝ⱽᵃᵐᵖⁱʳᵉ𝕱𝕬𝕶𝕴𝕾	0	21	0	0	0	9	\N	0
5490181173	0	Sabiena kailee.	0	1	0	0	0	0	\N	0
6578347051	0	A	0	0	0	0	0	0	\N	0
5579278564	0	Ay	0	1	0	0	0	3	\N	0
5014659835	0	Hiraya—Adhista! 📚🎧	0	31	0	0	0	19	\N	0
1053631150	0	Ceyy	0	332	0	0	132.79999999999995	155	\N	0
5199113629	0	zavie	0	22	0	0	611.77	41	\N	0
1643361397	0	aya	0	3	0	0	0	0	\N	0
6578372179	0	el	0	24	0	0	0	0	\N	0
6096022854	0	jal	0	64	0	0	0.7199999999999989	10	\N	0
6063125298	0	al	0	54	0	0	2	148	\N	0
1793580129	0	k ⋆𐙚₊	0	39	0	0	0	135	\N	0
5766231418	0	r	0	316	0	0	0	27	\N	0
1834782775	0	I dont want believe again try again if you do it i really dont b	0	1	0	0	0	5	\N	0
1770568790	0	Ayana mau nyaleg	0	9	0	0	0	0	\N	0
5204547405	0	laaa	13	591	0	0	3582.09	2608	\N	0
1745443013	0	Jemiah	0	8	0	0	0	1	\N	0
5132813324	0	Fafa Moriarty.	0	267	0	0	0	40	\N	0
5193039079	0	Jaseb	0	8	0	0	244.11	60	\N	0
6652702890	0	jmbut	0	6	0	0	0	12	\N	0
5323910043	0	hil	0	54	0	0	200	91	\N	0
5238279813	0	raraa	5	1104	0	0	388.88000000000005	6299	\N	0
5607663819	0	nindyaa	0	3	0	0	0	0	\N	0
1643712338	0	-	0	6	0	0	0	47	\N	0
1783407729	0	reaa	0	240	0	0	12.910000000000004	260	\N	0
6858323405	0	elzia.🇱🇰	0	8	0	0	0	0	\N	0
1783531108	0	⚠︎𖤩 🅰️LkA (๑•̀ᗢ•́๑) ⁉️	0	4	0	0	0	3	\N	0
1672167141	0	Grizelle	0	2	0	0	0	3	\N	0
5215812440	0	arel	0	20	0	0	0	81	\N	0
6258064619	0	LibraBoy	0	18	0	0	0	36	\N	0
6475975187	0	Kaz	0	4	0	0	0	0	\N	0
1790134077	0	fa	0	117	0	0	0	791	\N	0
5574765189	0	rajendra	0	2	0	0	0	0	\N	0
5862800677	0	samel, 🇵🇸 #CALMINMINJI	0	1	0	0	0	2	\N	0
6056861183	0	heesa	0	1	0	0	0	0	\N	0
1828474960	0	kazel	0	4	0	0	0	1	\N	0
5539828489	0	ra.	0	1	0	0	0	0	\N	0
1822710672	0	Neveir Lathiven.	0	2	0	0	0	2	\N	0
1426805606	0	Fir	0	27	0	0	941	1	\N	0
6301912625	0	aca	0	21	0	0	0	145	\N	0
6198829905	1	kala	0	433	0	0	3	1	\N	0
6882118243	2	000	0	21	0	0	0	58	\N	0
6827348589	0	cheryyl👽	0	208	0	0	1956	430	\N	0
1303737215	0	al	5	1275	1	0	1945.450000000004	2910	\N	1
6225714014	1	AaaYINNN??!.... 🧚‍♀️🌹	0	7	0	0	82.1	133	\N	0
5832961028	0	ger	6	923	0	0	5.239999999999952	237	\N	0
6836373564	2	locked by Mr.A	0	80	0	0	66.38000000000008	582	\N	0
7076124097	0	katlyn.	0	12	0	0	368	32	\N	0
1866840391	0	Mejra	0	2	0	0	0	6	\N	0
6951549161	0	MIN YOONGI	0	4	0	0	0	0	\N	0
1988196861	0	jiesha	0	1	0	0	0	0	\N	0
1811845854	0	Rahajeng	0	4	0	0	0	5	\N	0
5920280887	0	sheldon	6	554	2	0	2.849999999999966	2906	\N	0
1403509832	0	Nei	0	21	0	0	0	2	\N	0
5929769116	0	ini shasha	0	23	0	0	4823	312	\N	0
6835408632	0	kela drw	0	9	0	0	13	31	\N	0
1782336396	0	reyna	0	26	0	0	0	2	\N	0
5126565677	0	t'	3	1429	0	0	9.479999999999777	327	\N	0
1032359901	0	Jendral ncb	0	86	0	0	36.61	4	\N	0
1946608366	0	keith	0	397	0	0	2633.47	2711	\N	0
6917558720	0	esyaaaa	0	21	0	0	0	0	\N	0
5118086764	0	A	0	50	0	0	55.02999999999997	713	\N	0
5550180089	0	yosaaa	11	145	0	0	3289.3299999999995	1373	\N	1
6169714115	0	𒆜 sheryl	11	134	0	0	829.3299999999999	33	\N	0
5369026095	0	⅌ jijas	0	1	0	0	0	1	\N	0
1737057925	0	Samuel Rutherford.	0	4	0	0	0	0	\N	0
5039694287	0	.	0	1	0	0	0	0	\N	0
5769919209	0	kaynar	0	0	0	0	0	14	\N	0
5761693666	0	olin	0	32	0	0	0	33	\N	0
1127381092	0	ㅤLOIYYA	3	260	0	0	6462.329999999999	389	\N	1
1900944088	0	.	0	352	0	0	193	1033	\N	0
1934103306	0	dpr cibey	0	1	0	0	0	1	\N	0
5418690600	0	hwl. kAAaauel loving kak taraa 💟💟	0	9	0	0	0	0	\N	0
5666461923	0	David	0	1	0	0	0	22	\N	0
5137999791	0	na	0	77	0	0	8.519999999999982	29	\N	0
5630666466	0	garaaaaaaaa	0	13	0	0	0	88	\N	0
1434254216	0	💐🎀✨️	0	8	0	0	0	207	\N	0
5077879262	0	dhiraa	0	10	0	0	0	15	\N	0
7181010762	0	Ca	0	0	0	0	0	0	\N	0
6964994619	0	cc	0	114	0	0	0.20000000000000284	41	\N	0
7028615077	0	maii 👻	0	2	0	0	0	33	\N	0
6157145808	0	fel	2	988	0	0	6508.329999999992	3186	\N	0
1899004659	0	LOG OUT <3	0	10	0	0	0	16	\N	0
5893661678	0	张. miaoo	0	608	0	0	8.959999999999994	580	\N	0
1823483067	0	biel	12	2251	0	0	1013.250000000002	4476	\N	1
1959638156	0	namanya aurora bukan kak	13	1524	0	0	71.4799999999999	1537	\N	0
5690233553	0	bil	0	6	0	0	0	0	\N	0
6335901335	0	.	0	43	0	0	0	1	\N	0
5267757769	0	chachaa, nsfw jgn cht	0	115	0	0	948.7499999999999	166	\N	0
2106674471	0	viaa	0	54	0	0	15.8	10	\N	0
1995255510	0	Pradipta, A.	0	1	0	0	0	0	\N	0
6953046155	0	acaa	0	14	0	0	0	21	\N	0
5573124348	0	ncut ōsz	0	178	0	0	0	70	\N	0
6610365367	0	angel	0	2	0	0	0	1	\N	0
5248129831	0	DNI. Malik	0	2	0	0	0	2	\N	0
6710859317	0	Arzel	0	1	0	0	0	0	\N	0
6109610131	0	olive	11	290	0	0	935.02	1237	\N	0
1481841304	0	Kenan	0	7	0	0	0	0	\N	0
6821106039	0	Nesha	0	1	0	0	0	0	\N	0
5189738664	0	yya	0	202	0	0	0	0	\N	0
5485100010	0	:p	0	132	0	0	1629.0200000000002	332	\N	0
7162019879	0	sex account	0	47	0	0	0	509	\N	0
6757431462	0	dani	0	17	0	0	0	3	\N	0
1558813583	0	naka	0	26	0	0	0	26	\N	0
6848915050	0	iél	0	2	0	0	0	0	\N	0
6891540681	0	rein	0	2	0	0	0	0	\N	0
6783584965	1	manda🇵🇸🇨🇩	0	35	0	0	1401.8100000000002	16350	\N	0
6448076759	0	Nindya	0	0	0	0	230.19	7476	\N	0
6835926879	0	jean	0	80	0	0	0	45	\N	0
6795639833	3	nei 🐈	4	173	0	0	197.39	4009	\N	0
5060545800	1	azkya idgaf era	5	599	0	0	1166.2200000000007	6320	\N	0
1259833960	1	kanaya /capekjjur	4	3626	0	0	6.32000000000005	19817	\N	0
6163252687	2	rava	0	97	0	0	0	95	\N	0
6678622662	0	Rachel	0	10	0	0	0	11	\N	0
6962208076	0	kf	0	18	0	0	0	1	\N	0
5095497208	0	mac	0	67	0	0	1230.7800000000004	606	\N	0
6012208753	0	Ninette 𐙚	0	5	0	0	0	0	\N	0
6265764895	0	zeyaa	0	0	0	0	0	1	\N	0
1339015794	0	adelia putri	0	186	0	0	19.68	0	\N	0
5439385030	0	cece ♡_♡	0	2	0	0	0	26	\N	0
5596320195	0	A	0	2	0	0	0	0	\N	0
5464935450	0	Dooo	0	23	0	0	0	0	\N	0
2114156229	0	akun pm	0	2	0	0	0	3	\N	0
1720184435	0	✷awn✷	3	52	0	0	1688.47	461	\N	0
5232575392	0	seishy.	0	1185	0	0	6.970000000000141	1398	\N	0
6067867684	0	sᴄṝᴀ v'elang, fo'darksky.	0	4	0	0	0	0	\N	0
7157740389	0	febi	0	12	0	0	0	43	\N	0
1601438868	0	.	0	2	0	0	0	0	\N	0
7048934679	0	— Faezié Berrylleià	0	58	0	0	732	76	\N	0
5597884030	0	nau	0	89	0	0	0	13	\N	0
1950840288	0	Latara D.	0	703	0	0	84.51999999999973	1008	\N	0
2022989163	0	f	0	125	0	0	0	536	\N	0
6129103723	0	𝐓𝐑≛𝐏𝐒 `Alea lg cape	0	230	0	0	207.14	1384	\N	0
1599139163	0	jopaa	0	177	0	0	0	19	\N	0
7156511918	0	ell	0	1	0	0	0	0	\N	0
6153011157	0	nonsense	4	0	0	0	814.1899999999997	1094	\N	0
7003116721	0	angel	0	1	0	0	0	0	\N	0
6361350326	0	️️️️️Gavira Moure.	0	63	0	0	0	968	\N	0
2079029950	0	𝕯𝖙. 𝐏ino	14	1101	0	0	1946.6200000000022	267	\N	0
5005835102	0	ileana	6	292	0	0	10.68000000000012	1332	\N	0
1864965041	0	inactive	0	9	0	0	0	2	\N	0
6583832301	0	sao(s)rsie	0	3	0	0	0	25	\N	0
5964540491	0	αyonα αwr 🗯️	0	37	0	0	0	27	\N	0
919454861	0	kaivan	0	15	0	0	0	28	\N	0
1555523375	0	𝓞osir, dévincita	0	52	0	0	0	93	\N	0
6933606077	0	kaz	0	1	0	0	0	0	\N	0
5017986703	0	Renjani	0	384	0	0	1143.2499999999995	1117	\N	0
1445291637	0	cheezu	0	2	0	0	0	1	\N	0
2024574114	0	f	0	1007	1	0	918.8875	488	\N	0
6703833323	0	abcdefuck	0	11	0	0	0	0	\N	0
5943184135	0	jilaa	0	3	0	0	0	0	\N	0
5661921220	0	L	0	5	0	0	0	6	\N	0
6968944340	0	kale	0	258	0	0	1859.4699999999993	1480	\N	0
6655632183	0	Dānůel	0	1	0	0	0	0	\N	0
5950812705	0	cewe nya jeje	0	290	0	0	5.160000000000025	199	\N	0
6538222577	0	mang boleh	0	10	0	0	2395	2	\N	0
6349201065	0	b	0	53	0	0	0	21	\N	0
7078774263	0	maeve	0	1	0	0	6.22	81	\N	0
1361575797	0	𝓒hésēe 𝓛ouvshiē	0	17	0	0	0	6	\N	0
1451964306	0	Kevin indosat	0	0	0	0	0	5	\N	0
1925197158	0	a	0	13	0	0	153.44	94	\N	0
2073075444	0	Reiga	4	1393	0	0	1.8099999999999739	205	\N	0
6112597846	0	Elēonöra Đr.	0	48	0	0	0.1899999999999995	165	\N	0
5327752304	0	matcha	0	9	0	0	0	9	\N	0
5892432415	0	ra	0	5	0	0	0	2	\N	0
6192273030	0	ell	0	26	0	0	0	20	\N	0
1488981456	0	ta	0	23	0	0	0	1	\N	0
1611294663	0	Melysha.	0	31	0	0	0	0	\N	0
1283882489	0	jeira	0	51	0	0	528	40	\N	0
5925577711	0	leska.	0	6	0	0	0	82	\N	0
6605416038	0	f	0	12	0	0	0	7	\N	0
1821866724	1	b1jeel	0	13	0	0	0	80	\N	0
1499549199	0	ca	0	5	0	0	0	1	\N	0
6220315864	0	läcèy. 💤	0	1	0	0	0	0	\N	0
1989112438	0	Raishen @Huangslnjun	0	13	0	0	0	0	\N	0
1684228161	0	.	0	3	0	0	0	0	\N	0
6437957160	0	꒰୨୧꒱ luffy	0	1	0	0	0	2	\N	0
1813843379	0	घर. racesha rkth	0	3	0	0	0	0	\N	0
6297743939	0	Magaentiz G.	0	4	0	0	0	34	\N	0
1287362324	0	975 Alex. وغامض @bloodkth	0	1	0	0	0	0	\N	0
1853739754	0	iguana	7	286	0	0	54.27000000000044	1242	\N	0
6966816887	0	Marvel	0	0	0	0	0	2	\N	0
6959998823	0	m	0	1	0	0	0	3	\N	0
1829538593	0	Stv	0	2	0	0	0	0	\N	0
5354743045	0	Harkiel, G.	0	17	0	0	0	6	\N	0
1975143520	0	Jes Matwous	0	3	0	0	0	1	\N	0
6145629056	0	xxnx.al	7	129	0	0	65.70000000000002	193	\N	0
1606088246	0	aleaa	0	37	0	0	0	402	\N	0
6429858871	0	meyyo🦋	0	1	0	0	0	0	\N	0
7071228494	0	Liice	0	12	0	0	0	0	\N	0
1899455592	0	.	0	1	0	0	0	0	\N	0
5340144519	0	elv.	0	4	0	0	0	35	\N	0
5032858671	0	senada	0	733	0	0	1680.8899999999999	466	\N	0
5224754155	0	zevan	0	2	0	0	0	0	\N	0
6581148317	0	£	0	42	0	0	682	38	\N	0
1960943161	0	Morgan	0	22	0	0	0	0	\N	0
1889110156	0	Close	0	1	0	0	0	0	\N	0
5572609464	0	Zahralea	0	7	0	0	0	1	\N	0
1782564173	0	nes	0	2	0	0	0	4	\N	0
5816141962	0	KALUnaAa’ ♡	0	8	0	0	0	0	\N	0
972547620	0	arken	0	4	0	0	0	2	\N	0
5169732173	0	Kai kesal.	0	89	0	0	3.6100000000000136	60	\N	0
2118869271	0	𝐉	0	154	0	0	14.889999999999986	131	\N	0
5928225625	0	Biawak	0	177	0	0	356.74	21	\N	0
6241695108	0	ㅤ	0	2	0	0	0	0	\N	0
1756789085	0	Jez	0	24	0	0	0	0	\N	0
6987784579	0	Ra!	0	1	0	0	0	0	\N	0
6138182661	0	tira	0	16	0	0	0	60	\N	0
5749723802	0	@aaaa	0	18	0	0	0	36	\N	0
1914031323	0	Maisie.	1	395	0	0	2121.3900000000003	1567	\N	0
5055095827	0	Ocii	0	3	0	0	0	0	\N	0
6318178687	0	sasa	0	3	0	0	0	373	\N	0
6898997744	0	carooOoline𝟅𝟈	0	8	0	0	0	1	\N	0
5504734648	0	ɑׁׅ֮ᥣׁׅ֪ꫀׁׅ	0	786	1	0	7.319999999999709	194	\N	0
6864357492	0	v	0	1	0	0	0	1	\N	0
5341607138	0	asya	0	11	1	0	0.060000000000002274	5	\N	0
6627280583	0	dika	0	3	0	0	0	11	\N	0
1945493172	0	𝙆𝙚𝙮𝙡𝙚𝙣 𝙫𝙨 𝙚𝙫𝙚𝙧𝙮𝙗𝙤𝙙𝙮	0	6	0	0	0	1	\N	0
6397225752	0	gen	0	8	0	0	0	1	\N	0
1786289210	0	moreaici	0	52	0	0	0	7	\N	0
1708473735	0	ᵃ	4	44	0	0	137.28	1358	\N	0
6833875315	0	azka	0	42	0	0	0	191	\N	0
5678920428	0	bil	0	306	0	0	87.99000000000018	703	\N	0
1855038407	0	loly	0	1	0	0	0	0	\N	0
1273870398	0	k.	0	46	0	0	0	2	\N	0
7082130343	0	𝙼𝙰𝙷𝙴𝙽	0	20	0	0	0	4	\N	0
5008751876	0	lysa	0	157	0	0	0	0	\N	0
1497774247	0	ㅤ	0	6	0	0	3195.37	33	\N	0
5204716725	0	noel.	0	14	0	0	278	18	\N	0
6192648933	0	Hasta	0	5	0	0	0	3	\N	0
1758768530	0	arthur	0	30	0	0	126.66	0	\N	0
5815685611	0	peyii	0	8	0	0	0	1	\N	0
6952507965	0	kanjeng ratu, cinta	0	63	0	0	0	20	\N	0
6024805852	0	ㅤJun	0	8	0	0	48.2	0	\N	0
7030681542	0	marziel	0	1	0	0	0	0	\N	0
1691890104	0	intaAaaAn	0	5	0	0	0	0	\N	0
2081538800	0	Dimas 𝖅༉	0	17	1	0	331	4	\N	0
2005133413	0	jasasuntiksosmed.id	0	4	1	0	0	6	\N	0
1393114901	1	Sha	0	13	0	0	0	24	\N	0
6754281017	1	ricko رفيد	0	5	0	0	0	3	\N	0
1959707856	2	nayya	0	17	0	0	0	0	\N	0
5261709374	4	ppk	13	944	0	0	6.880000000000052	5566	\N	0
6883773886	0	van	0	11	0	0	0	2	\N	0
6831836825	0	nomi	0	0	0	0	0	13	\N	0
5705294801	0	shafa	0	0	0	0	0	0	\N	0
1758898983	0	a	0	6	0	0	0	2	\N	0
5075842471	0	Dalian	0	2	0	0	0	0	\N	0
5949819924	0	na, jangan chat kalo ga penting	0	20	0	0	1035.2	4	\N	0
1941267675	0	na	0	65	0	0	0	45	\N	0
6399081107	0	fio	0	165	0	0	553.69	92	\N	0
2084387352	0	qishi	7	398	0	0	4005.310000000002	4253	\N	1
6807589683	0	emilly	0	58	0	0	0	56	\N	0
6622598163	0	who i am 𓆉	0	11	0	0	8.510000000000002	18	\N	0
6212370130	0	Stormi	0	107	0	0	0	209	\N	0
6105611944	0	lyn alter ego	0	39	0	0	7.650000000000006	104	\N	0
1938940325	0	f	0	1	0	0	0	0	\N	0
6068347904	0	aysel	0	1	0	0	0	0	\N	0
1116309092	0	.	0	47	0	0	0	3	\N	0
6095174036	0	Squish	0	76	0	0	34.180000000000106	27	\N	0
5370109363	0	Seo	0	23	0	0	0	6	\N	0
5681474085	0	a 🧘🏻‍♀️	9	154	0	0	880.8100000000001	97	\N	0
6465242823	0	nana	0	0	0	0	0	0	\N	0
5631601702	0	veRara	0	287	0	0	110.18000000000004	535	\N	0
1745634219	0	Kalula.	0	21	0	0	0	4	\N	0
5008376438	0	cia gi badmood	0	0	0	0	0	0	\N	0
1753844042	0	b	0	8	0	0	0	2	\N	0
2108984651	0	a	0	1	0	0	0	0	\N	0
1653222509	0	ndaaa	10	773	0	0	2159.369999999999	3702	\N	0
5860557278	0	cozyuma.	0	2	0	0	0	0	\N	0
6587299220	0	ael cipi capa	0	0	0	0	0	0	\N	0
1960355199	0	Rizen	0	2	0	0	0	4	\N	0
1890537034	0	Deye.	0	19	0	0	0	4	\N	0
1255394012	0	die4u	11	562	0	0	39.73000000000002	1731	\N	0
6932447407	0	c	0	5	0	0	0	23	\N	0
5213642282	0	Legyeldro	0	5	0	0	0	0	\N	0
5778842403	0	bjr. van	0	2	0	0	0	4	\N	0
2062877046	0	.	0	109	0	0	525.9699999999997	581	\N	0
1879821500	0	.	0	2	0	0	0	0	\N	0
6317178424	0	😮lea 😗🤏	0	2	0	0	0	21	\N	0
6751052101	0	taro	0	20	0	0	0	13	\N	0
6831938244	0	Jayya	0	16	0	0	0	1	\N	0
5800003116	0	M. A	0	1	0	0	0	0	\N	0
1841527417	0	N	10	70	0	0	1046.07	130	\N	0
5646958074	0	yesa	0	29	0	0	5.450000000000003	10	\N	0
1865423426	0	zul	11	277	0	0	1.2400000000040308	5459	\N	0
1096095073	0	.	0	42	0	0	0	14	\N	0
1598188488	0	arthur	0	6	0	0	0	16	\N	0
1833551217	0	ky	0	124	0	0	627.29	417	\N	0
6266248737	0	darma	0	1	0	0	0	0	\N	0
5432928664	0	B	0	4	0	0	0	6	\N	0
1823249786	0	🪼	0	697	0	0	0.48000000000044096	2482	\N	0
5342673586	0	joel	0	9	0	0	0	11	\N	0
1376082154	0	guesswho?	0	500	0	0	85.03500000000005	6060	\N	0
5446790299	0	oilah :(	0	5	0	0	0	5	\N	0
5033404997	0	D	0	48	0	0	219	339	\N	0
6032345178	0	khalila	0	58	0	0	58.41999999999996	33	\N	0
1290303844	0	Ocil	0	8	0	0	0	43	\N	0
6114240442	0	Ginaraa.	0	1	0	0	0	2	\N	0
5733402047	0	Nolann	0	1	0	0	0	1	\N	0
1158370522	0	hasboyy	0	23	0	0	0	42	\N	0
5787853901	0	Antoinette	0	89	0	0	0	5	\N	0
5067194945	0	Ginan	0	16	0	0	0	90	\N	0
5331753015	0	ella, sayang ace 10000%	0	125	0	0	49.89	128	\N	0
6892604746	0	bellatrix	0	15	0	0	0	0	\N	0
6216864841	0	team𝓖dss. faye SUKA jake	0	23	0	0	0	8	\N	0
6262107462	0	Leci 🍓	13	232	1	0	444.7799999999999	1384	\N	0
1039528945	0	shine	0	13	0	0	0	1	\N	0
6117893705	0	lolaa	0	30	0	0	0	143	\N	0
1976139074	0	ara	0	1	0	0	0	13	\N	0
5749203917	0	vabior	13	46	0	0	300	70	\N	0
1697550383	2	din	0	30	0	0	10.47	306	\N	0
7098094897	0	jen	0	24	0	0	1419	10	\N	0
5912398695	0	Misha.	8	595	0	0	2763.6399999999994	7051	\N	0
2030556964	1	Gea.	7	161	0	0	255.57999999999993	38	\N	0
6544899460	0	︎︎	0	33	0	0	986.61	79	\N	0
6775754265	0	lengkaraa	0	119	0	0	685	18	\N	0
1959072307	0	Owen	0	1	0	0	0	7	\N	0
5004390832	0	Deon	0	6	0	0	0	0	\N	0
7009895493	0	Gi	0	1	0	0	0	0	\N	0
5129118885	0	it's me	0	35	0	0	0	13	\N	0
5826465103	0	music(ian)!¡🎸	0	5	0	0	0	4	\N	0
5265105726	0	eyna	0	0	0	0	0	1	\N	0
5302431353	0	Ali	0	1	0	0	0	19	\N	0
6779005121	0	aurlia	0	17	0	0	0	30	\N	0
5122571009	0	ailen	0	180	0	0	214.64999999999998	85	\N	0
5995898339	0	M Abdurahman	0	8	0	0	0.7999999999999119	2	\N	0
6448289926	0	Ariana	0	3	0	0	0	0	\N	0
6024897826	0	ceezAa🥬🥦🍓🥗🫑	0	7	0	0	0	0	\N	0
5106858549	0	ayen	0	4	0	0	0	0	\N	0
6016458606	0	gaga	0	11	0	0	0	3	\N	0
5200769204	0	klorofil	0	20	0	0	0	45	\N	0
1633625890	0	luvv	0	4	2	0	0	0	\N	0
5821021187	0	meng	0	44	0	0	926	190	\N	0
5201174214	0	Mozie	0	1	0	0	0	1	\N	0
1633295695	0	Moreno.	0	3	0	0	0	0	\N	0
1553317875	0	wuinn	0	85	0	0	713	50	\N	0
6986948686	0	.	0	6	0	0	0	14	\N	0
5001966553	0	navaera	0	2	0	0	0	0	\N	0
7012739556	0	bell	11	287	0	0	-14.110000000000582	4175	\N	0
1904560443	0	abby ngiha	11	334	0	0	9715.49999999999	105441	\N	1
6406342002	0	naaay	0	13	0	0	0	1	\N	0
5675219478	0	Kanya	0	37	0	0	0	22	\N	0
2130067669	0	uu	0	23	0	0	0	137	\N	0
6018905237	0	Michie.	0	5	0	0	12.71	5	\N	0
5615566760	0	hugo	0	5	0	0	0	1	\N	0
1770957538	0	cakra sayangg dimas	0	2	0	0	0	1	\N	0
6235873794	0	Jazmine	0	0	0	0	0	0	\N	0
1797310356	0	keeya widiantoro ୨୧	8	197	0	0	999.25	1505	\N	0
1704115435	0	Kazes - 신들.	5	969	0	0	12.909999999999968	2918	\N	0
5751951670	0	neys	7	92	0	0	0	1694	\N	0
5881322559	0	ochaa	12	2176	0	0	5792.029999999979	4848	\N	1
1494985163	0	nothing	11	266	0	0	48.00999999999962	245	\N	0
6674954266	0	kaleyy	0	8	0	0	112.62	58	\N	0
1815783498	0	iru	0	1	0	0	0	0	\N	0
7004953811	0	kayes	0	3	0	0	0	2	\N	0
1548165660	0	K	0	4	0	0	0	2	\N	0
5613093816	0	Perbuss. Gabara P, Urgent? Call	0	1	0	0	0	0	\N	0
5984241710	0	cimaa	0	19	0	0	0	17	\N	0
5060767264	0	haura	0	62	0	0	0	57	\N	0
1907712484	0	Udin	0	0	0	0	0	14	\N	0
6795618865	0	h-1 ultah jink	0	16	0	0	0	40	\N	0
7140744163	0	amora	6	89	0	0	83.28	19	\N	0
6698177406	0	Nabila Jasmine	9	124	0	0	371.59000000000003	7913	\N	0
6612109460	0	.	0	175	0	0	0	35	\N	0
6087836829	0	A	0	3	0	0	0	1	\N	0
6685531400	0	Noname [CEK BIO]	0	15	0	0	0	0	\N	0
5447506478	0	r	1	2018	0	0	280.6300000000001	1668	\N	0
1923648349	0	Aku siapa?	2	2627	1	0	3.099999999999909	2000	\N	0
6775518276	0	ronicca awr 👩🏻‍🌾	0	46	0	0	0	186	\N	0
6332743803	0	bulan	0	15	0	0	0	32	\N	0
1762605491	0	nyta	6	963	0	0	10401.97	587	\N	0
6607636523	1	d	1	966	0	0	14.230000000000132	2703	\N	0
6897165229	0	𝘼𝙇𝙄𝙀𝘼 𝙆𝙍𝙎	0	19	0	0	0	423	\N	0
1639703411	2	Jeana	0	1427	0	0	1017.4499999999998	517	\N	0
6910597965	0	gracelina	0	10	0	0	1000	0	\N	0
6660282397	2	Panda	13	277	0	0	1960.94	4012	\N	0
6900706730	0	shnz	0	92	0	0	6.109999999999999	0	\N	0
5463797773	0	moly	12	676	0	0	3120.3499999999967	3158	\N	1
5042631920	0	e. kandra skh	0	1	0	0	0	0	\N	0
6646752342	0	Jnnvr	0	0	0	0	0	0	\N	0
1417801671	0	R	12	471	0	0	2489.120000000001	1158	\N	1
7134241027	0	Vincentius.	0	4	0	0	0	2	\N	0
5936477345	0	Galaksi `rest	0	4	0	0	0	1	\N	0
6725022215	0	a	0	2	0	0	0	0	\N	0
6191380127	0	Garekta A.	0	0	0	0	0	0	\N	0
5804737387	0	Mimi	0	35	0	0	0	0	\N	0
5823792374	0	pera	0	7	0	0	0	69	\N	0
5302914627	0	?	4	189	0	0	136.14999999999998	178	\N	0
6530070914	0	owaAa	0	10	0	0	0	14	\N	0
5974439826	0	diosz	0	30	0	0	154	3	\N	0
2042448134	0	rest	0	65	0	0	43.65	570	\N	0
1605176345	0	eunnao	0	13	0	0	0	8	\N	0
6822401422	0	loli	0	2	0	0	0	0	\N	0
6209678467	0	rere cgx	5	127	0	0	99.52	82	\N	0
5360048221	0	Wira.	0	0	0	0	0	0	\N	0
5623370373	0	F	0	3	0	0	0	0	\N	0
5335806671	0	eL	0	5	0	0	0	18	\N	0
5835835562	0	nadis log out	0	5	0	0	0	40	\N	0
5366543014	0	x	0	156	0	0	3	137	\N	0
1994531832	0	⊹ 𐙚 Avery Jenn, mooi meisje. ⊹ 🪽₊ 	0	35	0	0	4867.25	97	\N	0
6062535847	0	kll	0	6	0	0	0	0	\N	0
2146382475	0	cesa the kid	0	0	0	0	0	0	\N	0
2054478178	0	malv	0	49	0	0	4.130000000000003	1312	\N	0
1009187702	0	Jydn	0	1	1	0	0	0	\N	0
5597584903	0	karlaa, kabarin.	0	5	0	0	0	41	\N	0
6048649400	0	kei	0	2	0	0	0	0	\N	0
1534952139	0	.	0	54	0	0	0	92	\N	0
7176926276	0	hmm	0	6	0	0	0	8	\N	0
1776183197	0	Cendol’s, māudy.	0	113	0	0	0	41	\N	0
6948027487	0	gh	0	73	0	0	399	20	\N	0
6168780180	0	ㅤ	0	12	0	0	0	0	\N	0
1842388802	0	𖥻 🧸 𖥦 ꩇׁׅ݊ꫀׁׅܻᥣׁׅ֪ᨵׁׅժׁׅ݊ᨮ꫶ׁׅ֮ ♡	0	0	0	0	0	0	\N	0
2134513854	0	a	0	28	0	0	0	1	\N	0
1892333073	0	Chocoball	0	92	0	0	101	98	\N	0
5258589876	0	cellin '𝑴☾	0	9	0	0	0	7	\N	0
5850808329	0	cilä	0	208	0	0	27.18999999999987	3795	\N	0
1995316861	0	raka	0	6	0	0	100	11	\N	0
5305680280	0	essa	0	283	0	0	0	46	\N	0
1876737864	0	Jayden	0	3	0	0	0	24	\N	0
6481323572	0	bee	0	524	0	0	1597.12	2598	\N	0
6990788996	3	vann	0	134	0	0	7	265	\N	0
7067609895	1	bukan calonmu	0	69	0	0	1.8599999999999994	82	\N	0
6830735185	0	abistha.	0	5	0	0	0	0	\N	0
6135912764	0	✧	0	491	0	0	0	4	\N	0
6148086880	0	ijulll pablo	3	788	0	0	304.7999999999993	1707	\N	0
2034722599	0	.	0	1	0	0	0	0	\N	0
5519920296	0	nita	0	74	0	0	4.27	431	\N	0
1253237975	0	gii	0	333	0	0	491	161	\N	0
1953874108	0	Apinn	13	1752	0	0	11.889999999999873	1508	\N	1
1208308771	0	ocel	0	282	0	0	202.43	226	\N	0
5666922775	0	caca	7	204	0	0	2510.05	5852	\N	0
6893224600	0	Zidan	0	9	0	0	0	5	\N	0
5949356716	0	-	3	2	0	0	0	1	\N	0
5705198947	0	BEATRICE.	0	5	0	0	0	1	\N	0
6411805155	0	Azivan L.	0	18	0	0	0	1	\N	0
5566257238	0	Erlan	0	30	0	0	714.6899999999999	5	\N	0
6794535781	0	J .	0	6	0	0	0	12	\N	0
1487666472	0	bogep	0	104	0	0	0	1	\N	0
5741229412	0	jacio	0	2	0	0	0	2	\N	0
6104943473	0	Genta.	0	8	0	0	0	4	\N	0
5635473823	0	ray	0	5	0	0	113.66	101	\N	0
5661436174	0	Acipa, urgent? call	0	1	0	0	0	0	\N	0
1853000637	0	eva	0	10	0	0	0	3	\N	0
6321719690	0	Ashel	0	7	0	0	0	9	\N	0
5612072647	0	Koming	0	33	1	0	186.71999999999994	49	\N	0
6452341482	0	?!	0	1	0	0	0	0	\N	0
5609683204	0	m	0	483	0	0	15.129999999999995	74	\N	0
6846906214	0	𝗲𝗹	0	8	0	0	0	0	\N	0
1803340443	0	𓆰⁰¹Zegrio N.Z	0	6	0	0	0	2	\N	0
1472119143	0	faiz	0	0	0	0	0	47	\N	0
6463767980	0	Toji's gf, Vanda.	0	11	0	0	0	9	\N	0
1920309265	0	iel	0	333	0	0	3.5	989	\N	0
6694603794	0	Aeldham	0	16	0	0	762.1600000000001	85	\N	0
1919449940	0	fluverrrrryys	0	365	0	0	0	2	\N	0
1815427140	0	nz	0	30	0	0	0	28	\N	0
1594560113	0	zeora⁹²⁴ ᵈᵉᵐᵒⁿ 🏴‍☠️	0	1	0	0	0	0	\N	0
6398481655	0	raa	0	1	0	0	0	1	\N	0
5127208588	0	Zeo	0	8	0	0	0	3	\N	0
5788977366	0	kaluna	0	2	0	0	0	0	\N	0
5977997756	0	mel	0	17	0	0	0	22	\N	0
742736684	0	Clara	0	0	0	0	0	0	\N	0
5079720473	0	jean	0	2	0	0	0	0	\N	0
5816495581	0	Tagotchi gi gamon	0	4	0	0	0	28	\N	0
1657393756	0	adelia	0	191	0	0	1.75	336	\N	0
6995340878	0	matcha	0	77	0	0	0	14	\N	0
5446434941	0	Regan	0	3	0	0	0	50	\N	0
5419916893	0	fly	0	352	0	0	6.829999999999927	251	\N	0
1356923339	0	dotlyu	0	4	0	0	0	2	\N	0
5322770398	0	lee?	0	0	0	0	0	0	\N	0
6130893411	0	jeje	0	7	0	0	0	34	\N	0
1262956149	0	ka	0	158	0	0	4.409999999999997	36	\N	0
5377998884	0	ale — spotify 10k	0	259	0	0	326	210	\N	0
6351772569	0	— josey tacē.	0	53	0	0	15.600000000000009	106	\N	0
5935503667	0	aya	0	2	0	0	0	0	\N	0
6849961597	0	Selena	0	25	0	0	61.96000000000015	161	\N	0
1825773448	0	🖇️ caa˚💭⊹	0	2	0	0	0	0	\N	0
1120611899	0	Ray	0	16	0	0	0	10	\N	0
2108830611	0	shabbieee.	0	1	0	0	0	1	\N	0
5341663702	0	gibras	0	1	0	0	0	0	\N	0
5510152757	0	andra	0	15	0	0	0	52	\N	0
6288277796	0	Breath 🪻 ⚡️	0	3	0	0	0	0	\N	0
790343221	0	no tu señorita	10	646	0	0	30.850000000000023	1580	\N	0
5263405051	0	yie ᝰ	0	19	0	0	1.75	8	\N	0
5033971453	0	za	0	9	0	0	0	0	\N	0
5727456358	1	🦀	14	314	0	0	26.170000000000215	3137	\N	0
2084835384	0	Cyyyyy	0	74	0	0	35	120	\N	0
2038476470	0	I	0	930	1	0	429.9400000000003	446	\N	0
6755195558	0	G.	0	34	0	0	0	2	\N	0
6166264271	0	Leaving.	0	162	0	0	0	37	\N	0
7197779940	3	!?	0	51	0	0	0	40	\N	0
1842536812	1	dpnaa	13	2094	1	0	1050.98	1661	\N	0
1644132485	0	Raeca @patrcel	0	1	0	0	0	355	\N	0
6436647154	0	ᜊ — 𝗮n𝗶n 𝗈𝖿𝖿 🎧 ᶻ 𝗓 𐰁 𝖳𝖵 𝗀𝗂𝗋𝗅	0	5	0	0	0	35	\N	0
5304819584	0	jesa	0	31	0	0	0	96	\N	0
1877067305	0	revan lasga	0	54	0	0	253.20000000000002	661	\N	0
6182307998	0	nina 🪿	0	574	0	0	-7	416	\N	0
6399635730	0	igorr	0	20	0	0	0	5	\N	0
1846239962	0	yaya	0	28	0	0	1279	0	\N	0
6317388705	0	# 🌷𝆬⃝𝆬⃝♡ se𝆹piwa'੭ ᳝ ꒱	0	47	0	0	159.16	191	\N	0
6131917124	0	:d	0	19	0	0	0	37	\N	0
6322172549	0	gasey	0	46	0	0	765.14	334	\N	0
5533886230	0	_____nikyyiii	0	983	0	0	443.80999999999995	3081	\N	0
1679665568	0	G	1	715	0	0	955.6300000000001	990	\N	0
6783239398	0	just forrw u	0	14	0	0	0	0	\N	0
6079350697	0	AAAAAA	12	1031	0	0	13.859999999998905	3657	\N	1
5867885680	0	ana	12	3	0	0	33.44	11	\N	0
6802155713	0	﹕ׁ ₊ ᯤ Phime Sheana. proofneeds	0	5	0	0	0	1	\N	0
7185808638	0	Kaivan	0	1	0	0	0	0	\N	0
1867097060	0	🙄	0	4	0	0	0	0	\N	0
5810068950	0	....	0	10	0	0	0	10	\N	0
6083912320	0	s	0	15	0	0	0	48	\N	0
7007934446	0	Azril juga,	0	100	0	0	275.02999999999975	178	\N	0
6107022096	0	aci	13	17	0	0	40.94	2	\N	0
5132006788	0	.	0	107	0	0	0	0	\N	0
1867452805	0	neana	0	11	0	0	0	11	\N	0
5510741217	0	kairisol mayo🔥🔥🔥	0	75	0	0	68	87	\N	0
1628309417	0	areska @eearthboys	0	47	0	0	0	3	\N	0
6929406619	0	< α𝗌ɦᥣɞ𝗒 >	0	2	0	0	0	1	\N	0
5426894829	0	z	9	54	0	0	103.76999999999997	8	\N	0
5135050037	0	Jack	0	3	0	0	0	6	\N	0
5745850666	0	ㅤㅤ	0	26	0	0	0	0	\N	0
5240844263	0	maroon	0	71	0	0	8	63	\N	0
5661394180	0	Grisell	10	349	0	0	3072.7699999999995	91	\N	1
6750926892	0	Angel	0	1	0	0	0	1	\N	0
6041745709	0	AKUN KHUSUS BTPM	0	4	0	0	0	6	\N	0
5280034439	0	Arie	0	1	0	0	0	1	\N	0
6138158733	0	ra	0	0	0	0	0	0	\N	0
1675737972	0	yoan	0	10	0	0	0	7	\N	0
5638255580	0	fye	8	1399	0	0	2.1300000000051114	6873	\N	0
1221094756	0	jane	7	45	0	0	165.78000000000003	3391	\N	0
2011276729	0	shaquille	0	11	0	0	0	0	\N	0
5059876581	0	user	0	22	0	0	3005	3	\N	0
5013009090	0	Oyel	0	8	0	0	0	32	\N	0
1617217934	0	ㅤㅤㅤㅤ	0	1	0	0	0	0	\N	0
6822528262	0	zoro	0	181	0	0	3.1199999999999903	331	\N	0
1719436505	0	Arelio	0	16	0	0	0	0	\N	0
6968502090	0	Bulan	0	168	0	0	498.6600000000001	308	\N	0
6881232882	0	argifa🇧🇳	0	1	0	0	1579.81	721	\N	0
1674225632	0	🧨	0	153	0	0	5.300000000000001	145	\N	0
1708614695	0	vie~	0	28	0	0	0	4742	\N	0
6393638830	0	Who	0	1	0	0	0	0	\N	0
2119462696	0	grito, slr	0	1	0	0	0	1	\N	0
5823449374	0	yo	0	1	0	0	0	0	\N	0
6458789636	0	Elkie.	0	33	0	0	100.96999999999986	1367	\N	0
5968917080	1	avey	0	135	0	0	0	150	\N	0
5833813454	1	only awa	0	744	0	0	-4.399999999999977	10	\N	0
1824147943	0	bibi — b	0	521	0	0	9.929999999999836	5015	\N	0
1945852144	0	Nan	0	3	0	0	0	14	\N	0
785850873	0	ar	0	2	0	0	0	1	\N	0
1947645179	0	calis	0	28	0	0	0	42	\N	0
5091851450	0	cebi	0	19	0	0	0	412	\N	0
1897137682	0	sal!ma reza	0	195	0	0	2.3999999999999773	150	\N	0
5399112547	0	ㅤ	0	0	0	0	0	10	\N	0
1829591034	0	e.	0	15	0	0	15	2	\N	0
2015082079	0	୨୧ – chesseell h.	0	27	0	0	0	91	\N	0
1805826923	0	jEeea	0	6	0	0	0	0	\N	0
5421215006	0	Jelena	0	7	0	0	0	4	\N	0
1924064683	0	z	0	11	0	0	0	29	\N	0
5783746317	0	Jojo	0	14	0	0	0	4	\N	0
1723623738	0	🍒	11	817	0	0	3313.9299999999985	26299	\N	1
6067293538	0	Jema	0	88	0	0	0	0	\N	0
5461430157	0	addyra ໂ‧͡‧ໃ	0	2	0	0	0	0	\N	0
1441612363	0	今	0	53	0	0	0	244	\N	0
6050055095	0	.	0	2	0	0	0	1	\N	0
5324376283	0	Vino	0	1	0	0	0	0	\N	0
1601879067	0	Biandra	0	3	0	0	0	2	\N	0
6550500207	0	莉亚	0	1	0	0	0	0	\N	0
1901751059	0	kei	0	20	0	0	0	197	\N	0
6213005511	0	K	0	54	0	0	0	1775	\N	0
5325296461	0	~ caa	0	3	0	0	0	49	\N	0
1526291072	0	mars.	0	5	0	0	0	2	\N	0
5555297389	0	al	0	14	0	0	5155	0	\N	0
1734688864	0	m	5	49	0	0	1055.8699999997489	4	\N	1
5007783421	0	Esther	0	53	0	0	0	13	\N	0
1370740291	0	.	0	14	0	0	0	18	\N	0
5685823495	0	𝐘𝑎𝑒𝑟𝑜 sick	0	52	0	0	83	122	\N	0
1959306179	0	Djeanna.	0	0	0	0	0	0	\N	0
6946894299	0	Ryuu NO RUSH	0	17	0	0	0	63	\N	0
1776816436	0	ardhito	0	31	0	0	0	38	\N	0
6046735870	0	Charlotte 🔛🔝	0	7	0	0	0	105	\N	0
7181694648	0	Zizi	0	1	0	0	0	0	\N	0
6942708682	0	angel	0	0	0	0	0	0	\N	0
1937311763	0	mei :]	0	139	0	0	11	267	\N	0
1909446661	0	k.ia/ semesta	0	181	0	0	0	0	\N	0
5836206366	0	Alodie.	0	26	0	0	0	26	\N	0
6527173236	0	Sasa	0	2	0	0	69.86000000000006	1	\N	0
6570394608	0	zaskia gotik	0	4	0	0	0	2	\N	0
2105569693	0	lista	0	423	0	0	51.46999999999996	28	\N	0
5831141650	0	Ichika.	0	145	0	0	0	106	\N	0
6469489464	0	fa ୨ৎ	0	114	0	0	4.079999999999995	1103	\N	0
5997549531	0	😮‍💨	0	33	0	0	0	62	\N	0
7015920637	0	࣪ Bunga ۫ 𓋜 ⋆ ࣪ 	0	3	0	0	0	35	\N	0
1728463110	0	noisy!!	0	3	0	0	0	25	\N	0
1843253431	0	lyy	14	254	0	0	9	47	\N	0
1762750629	0	cotton candice	12	588	0	0	73.72999999999996	2419	\N	0
1738841787	0	kaleeyA	0	682	0	0	16.719999999999985	1395	\N	0
1745033558	0	-	11	2618	0	0	3797.269999999994	7481	\N	0
6824379719	0	el	0	102	0	0	0	507	\N	0
6171854809	0	ra	0	149	0	0	7.72999999999999	7	\N	0
6908032160	0	Björn Elderitch	0	1	0	0	0	0	\N	0
1578399623	0	🐈‍⬛	0	263	0	0	1	58	\N	0
1879338663	0	アデル	0	0	0	0	0	0	\N	0
5390897335	0	s/ia. babeh genjot	0	2	0	0	0	10	\N	0
6604414996	0	asist marvin	0	3	0	0	0	0	\N	0
1174103471	0	mmmiiiinnneeee	11	2520	0	0	2303.41	35976	\N	0
6408748173	0	ᴇᴛᴇʀ.	2	254	0	0	77.50999999999979	465	\N	0
5694284673	0	Moris Christian. Rest	0	5	0	0	0	3	\N	0
6105154014	0	ㅤㅤㅤ	0	2	0	0	0	4	\N	0
2034037420	0	pan pani	0	89	0	0	54.60999999999996	564	\N	0
6426312098	0	Penguasa waktu	0	180	0	0	0	0	\N	0
1514979653	0	Haekal, Open.	0	3	0	0	0	18	\N	0
6124255941	0	`dr	0	3	0	0	0	1	\N	0
2018541453	0	Yvonne	0	0	0	0	0	15	\N	0
6475335288	0	aca	0	17	0	0	0	0	\N	0
6283666805	0	Sid	0	2	0	0	0	13	\N	0
6102778535	0	ya	0	2	0	0	0	5	\N	0
6579053754	0	bg	0	31	0	0	0.09999999999999964	254	\N	0
5834711074	0	Rexxy babunya spalta😾	3	3	0	0	108.78	34	\N	0
6472398762	0	Trixie 100% Max	0	338	0	0	0.23000000000000398	2151	\N	0
7099824206	0	Kyle	0	10	0	0	0	1	\N	0
1333721503	0	apippp	0	45	0	0	0	6	\N	0
7058574903	0	Zuya.	0	78	0	0	812.0700000000002	126	\N	0
1580903742	0	rere ( overshare, talk too much )	0	99	1	0	0	35	\N	0
7028103452	0	jeen	0	4	0	0	0	7	\N	0
1947744886	0	piè	0	4	0	0	0	0	\N	0
5700346583	0	Jeyna	0	33	0	0	0	118	\N	0
1036122141	0	Ade	0	68	0	0	422.26000000000005	18	\N	0
5048221680	0	aikou	0	87	0	0	4.069999999999993	181	\N	0
5737875369	0	Deko web	0	230	1	0	646.3300000000002	1196	\N	0
1646945956	0	kael	12	212	0	0	253.50000000000048	1199	\N	0
1968503614	0	.	0	289	0	0	0	4	\N	0
7007355868	0	— biru	0	18	0	0	0	151	\N	0
5341151704	0	bkan	0	68	0	0	0	2	\N	0
5567528411	0	leyan #Markopride	0	1	0	0	0	0	\N	0
5710648421	0	ve	0	2	0	0	0	0	\N	0
6708528707	0	Jëane	0	85	0	0	1438.59	92	\N	0
1307523157	0	Ꮺ 💬 f⍶ɩ𝗋𝘆 r⍶ɩnva ᯤ ｡ ࣪ !	0	40	0	0	0	2	\N	0
5487710422	0	gaby	0	60	0	0	16	536	\N	0
5242775884	0	nott	0	4	0	0	0	9	\N	0
5792541850	0	jedunnn @wascpada for sale	0	2	0	0	0	2	\N	0
5231220889	0	Mahen A.	0	1	0	0	0	0	\N	0
6526906156	0	Riri	7	526	0	0	1685.98	1408	\N	0
6253757073	0	⋆biel	0	20	0	0	0	0	\N	0
1077749007	0	cha	0	24	0	0	0	3	\N	0
5357627539	0	nay	0	97	0	0	30.340000000000146	0	\N	0
5369285852	0	ardan jay lovetaker's	0	2	0	0	0	0	\N	0
1834373170	0	Tiransha	9	242	0	0	30.480000000000018	0	\N	0
5253527006	0	rissaaAAAaaa	0	30	0	0	178	76	\N	0
6954734851	0	Laufey A.	0	1	0	0	0	2	\N	0
6751870552	0	ff	0	19	0	0	346	46	\N	0
6818672347	0	Kaluella. 🪽	0	1	0	0	0	0	\N	0
1470736420	0	adudu si kepala balok	0	233	0	0	0	43	\N	0
5583621270	0	aila	0	39	0	0	0	89	\N	0
5839831129	0	Sayla	0	1	0	0	0	2	\N	0
5313978061	0	Calison C.	0	5	0	0	0	0	\N	0
6969294063	0	Jáy S.	0	14	0	0	35.25	11	\N	0
1726258339	0	Aldeguer's	4	16	0	0	112.32000000000001	102	\N	0
5291578820	0	ar 🪩	5	600	0	0	73.86000000000035	11442	\N	0
6212237650	0	Jee 🚬	0	46	0	0	181.83999999999997	227	\N	0
5839194371	0	verr	0	17	1	0	0	3	\N	0
5017588634	0	Ninda.	0	0	0	0	0	0	\N	0
455029172	0	284. zee	14	6	0	0	209.59000000000012	7	\N	0
1398427038	0	Nopal	0	0	0	0	0	0	\N	0
6492527250	0	zāhraﾟ𐦍༘ ⋆	0	4	0	0	0	0	\N	0
5919561501	0	dira	0	2	0	0	0	8	\N	0
5976753538	0	reatha	0	24	0	0	311.08	28	\N	0
6370661380	0	zea anak mama	0	1	0	0	0	5	\N	0
6399834906	0	rae	1	58	0	0	1443.06	615	\N	0
1677505646	0	ael	0	39	0	0	0	295	\N	0
6812589503	1	celine🖤	0	106	0	0	0	32	\N	0
6790237095	1	arcel	0	6	0	0	0	2	\N	0
6702206460	1	shena	0	11	0	0	0	0	\N	0
5139090325	0	virtualll	0	16	0	0	0	18	\N	0
1324479116	0	ryven	0	7	0	0	0	582	\N	0
6012236635	0	k	0	4	0	0	0	0	\N	0
1241704754	0	drc Cathie	0	15	0	0	0	0	\N	0
1285134813	0	Psyche 𝟐𝟏𝟒	0	1	0	0	0	6	\N	0
5840242918	0	Lou	0	2	0	0	0	1	\N	0
1743539703	0	a	0	170	0	0	688.0300000000002	859	\N	0
1898256325	0	👹	0	19	0	0	0	7	\N	0
5938125190	0	dip	0	2	0	0	0	10	\N	0
1983471405	0	d	0	435	0	0	-1.6400000000000006	4384	\N	0
2072366625	0	Jolie	0	2	0	0	0	0	\N	0
6382695818	0	Chyntia	0	1	0	0	0	0	\N	0
6231038275	0	xemek	0	21	0	0	0	6	\N	0
968705134	0	Andrasp	0	2	0	0	0	2	\N	0
6289411464	0	dde daime	0	10	0	0	0	5	\N	0
1760633466	0	jordan	0	175	0	0	49.500000000000114	1552	\N	0
5892468462	0	kimiee	0	31	0	0	190.70000000000005	56	\N	0
6733046863	0	𝐌𝐢𝐳𝐞	13	357	0	0	1	82	\N	0
6508285807	0	Jericho	4	238	0	0	107.5100000000001	3	\N	0
2116839431	0	el	0	80	0	0	5	196	\N	0
6661519132	0	🅰️likaAa	0	2	0	0	0	0	\N	0
6619006167	0	nàren	0	9	0	0	0	2	\N	0
6854892492	0	rai isekai	0	2	0	0	0	6	\N	0
1380561687	0	riri	12	1056	0	0	48.99000000000697	1481	\N	1
1478854838	0	kiki	0	76	1	0	0	355	\N	0
5526565055	0	jop	0	104	0	0	316	52	\N	0
2065131260	0	Athar.	0	105	0	0	0	29	\N	0
7052167835	0	Tiii	0	2	0	0	0	0	\N	0
6575606828	0	?	0	3	0	0	0	4	\N	0
6276191544	0	Jisel	0	19	0	0	990.72	122	\N	0
7164815365	0	Sherina 🇪🇦	0	11	0	0	0	2	\N	0
6750503389	0	.	0	41	0	0	0	1	\N	0
6440281894	0	440syz	0	5	0	0	0	50	\N	0
6428036973	0	Nak	0	1	0	0	0	0	\N	0
1937711546	0	restingrestingresting!!! ASTER.	0	83	0	0	0	1855	\N	0
1294906525	0	Putraaa	0	6	0	0	0	10	\N	0
5776885735	0	apis	0	3	0	0	0	13	\N	0
5107615831	0	Cathey Yokhevet	0	7	0	0	0	0	\N	0
7019323073	0	arel	0	3	0	0	0	1	\N	0
6083954909	0	rey	0	8	0	0	0	54	\N	0
6072954410	0	Alora	0	11	0	0	0	263	\N	0
1855107947	0	zie	0	1	0	0	0	0	\N	0
6596134396	0	Yasmine	0	7	0	0	0	16	\N	0
5589567017	0	naa	0	9	0	0	0	15	\N	0
5260052252	0	nara	0	1	0	0	0	0	\N	0
1927143217	0	Karelio.	0	3	0	0	0	5	\N	0
1625760214	0	Ikoo	0	8	0	0	0	3	\N	0
5974529023	1	bilaa	13	135	0	0	5.84	33	\N	0
5777393063	1	cybee	0	44	0	0	433	40	\N	0
6096608437	0	ev4	0	31	0	0	0	5	\N	0
5433026730	0	nev	4	212	0	0	12.790000000000134	43	\N	0
6400278035	0	kenzie	0	197	0	0	0	69	\N	0
6363253088	0	Cezi	0	174	0	0	0	360	\N	0
6365908014	0	Jaem	0	157	0	0	0.9099999999999682	296	\N	0
1974185696	0	ㅤ	0	156	0	0	1466.0800000000004	739	\N	0
6043138557	0	Jeanna	0	4	0	0	0	3	\N	0
5729505873	0	litaaa	0	3	0	0	0	0	\N	0
1414509398	0	ara	0	597	0	0	904.3899999999999	136	\N	0
6028237790	0	bloomsky	10	618	0	0	33.339999999999854	44	\N	0
5160454595	0	abel	0	2	0	0	0	28	\N	0
6330635973	0	ann	0	30	0	0	0	0	\N	0
1450347490	0	cell	4	137	0	0	499.4499999999998	293	\N	1
6647621256	0	Grace	0	34	0	0	0	49	\N	0
5037799700	0	nasyera, d.	0	68	0	0	0	61	\N	0
5106291307	0	noya	0	392	0	0	1	533	\N	0
5943912013	0	indah	0	143	0	0	0	108	\N	0
1699450619	0	Veyz	0	18	0	0	0	118	\N	0
6078946732	0	dea	0	22	0	0	0	6	\N	0
6056019357	0	s	0	85	0	0	790.8199999999999	1347	\N	0
1481206716	0	Je	0	157	0	0	2323.5	45	\N	0
5658611712	0	athanasia	0	59	0	0	0	233	\N	0
1277118778	0	𝐀𝐛e𝐥	6	617	0	0	3028.2200000000007	209	\N	0
6604593800	0	ochi	0	19	0	0	397	43	\N	0
5253562626	0	her-vy	0	147	0	0	0	26	\N	0
5450134020	0	y2	0	9	0	0	0	4	\N	0
6378044402	0	Nicci	0	14	0	0	478	72	\N	0
1900837860	0	naurawr,	0	38	0	0	56	127	\N	0
6205089283	0	Nayaa	0	18	0	0	0	1	\N	0
5864750100	0	kaen	8	196	0	0	545.6899999999998	444	\N	0
5696489103	0	KJ	0	11	0	0	0	22	\N	0
6022611759	0	Hosé	0	6	0	0	0	0	\N	0
5957446480	0	― hann	0	52	1	0	0	7	\N	0
1076807194	0	zack	0	6	0	0	0	0	\N	0
5233041010	0	Liam	0	1	0	0	0	0	\N	0
5278037883	0	K	0	2	0	0	0	2	\N	0
1308891257	0	Revee.	13	288	0	0	557.63	1036	\N	0
5586754386	0	Mrcll	0	202	0	0	1245.28	692	\N	0
5358735104	0	r	0	282	1	0	23.879999999999967	35	\N	0
1578470334	0	mecay	0	155	0	0	0	257	\N	0
6399651618	0	slwa	0	1	0	0	0	0	\N	0
6980730648	0	୨୧	0	0	0	0	0	0	\N	0
2127316894	0	ra inrush	0	4	0	0	0	0	\N	0
1932345870	0	Cath	0	72	0	0	0	56	\N	0
5297418665	0	asa ˙ᵕ˙	0	357	0	0	3.260000000000005	262	\N	0
6385041195	0	de white yukari.	0	49	0	0	0	6	\N	0
1824305961	0	?	0	34	0	0	0	0	\N	0
1952607901	0	cey? yes i’m	0	11	1	0	0	2	\N	0
1723881072	0	Fay	0	20	0	0	0	20	\N	0
5028666861	0	c	0	25	0	0	0	0	\N	0
1608281169	0	cca	3	58	0	0	5635.519999999999	2475	\N	0
2126972108	0	rann	0	1	0	0	0	0	\N	0
1899765565	0	Sasa	0	6	0	0	0	6	\N	0
6258250935	0	ㅤ	0	9	0	0	0	0	\N	0
5959965771	0	stēvaniè	0	26	0	0	0	0	\N	0
6986886760	0	qis	0	1	0	0	0	6	\N	0
6237231502	0	Keyaaa	0	0	0	0	0	2	\N	0
6475998429	2	aceng 🖐😌	0	1119	0	0	12.09000000000006	619	\N	0
1952077955	0	Rinnn	0	59	0	0	489.28	52	\N	0
6657822546	0	nar	0	56	0	0	-9.350000000000001	274	\N	0
5262368560	0	rin	0	45	0	0	0	270	\N	0
1037905974	0	logout	0	19	0	0	0	1	\N	0
6953692011	0	FIS_Novi arsthi_SNBP	8	139	0	0	11.239999999999995	174	\N	0
1847284254	0	eureu! x3x	0	110	0	0	10.289999999999878	5	\N	0
6887765877	0	JW.	0	1	0	0	0	0	\N	0
1746001395	0	diana	0	20	0	0	0	11	\N	0
5363688717	0	Rob$	0	24	0	0	0	14	\N	0
5732893879	0	caa	0	1	0	0	0	0	\N	0
5104392207	0	gwen	0	1	0	0	0	0	\N	0
1830846764	0	Bukan Ngaberss	0	0	0	0	0	0	\N	0
6150448253	0	c/keira	0	133	0	0	6.1299999999999955	318	\N	0
5366699685	0	a	0	13	0	0	0	0	\N	0
5789910447	0	esha.	1	90	0	0	3935.21	45	\N	0
1781366081	0	bemafuckinboo	2	53	1	0	7.82000000000005	3818	\N	0
1268670435	0	Ɖiŋoo Marugame 🍱	0	2	0	0	0	25	\N	0
6919133781	0	karin	0	156	0	0	0	14	\N	0
5904133726	0	ashLey	0	133	0	0	5.730000000000075	360	\N	0
1674137131	0	Agung #EndlessStoryOfIZONE	0	10	0	0	0	61	\N	0
1853216802	0	c	4	758	1	0	722.7699999999995	1105	\N	0
5557505817	0	unknown user	8	792	0	0	12.529999999999745	3704	\N	0
5015023402	3	suneo	0	856	0	0	12.379999999999654	168	\N	0
6821674093	0	isabeth	0	41	0	0	441.58000000000004	227	\N	0
2063567111	1	ellà🅰️	0	83	0	0	31.58	190	\N	0
1086280560	0	jenraa🧏🏻‍♀️	11	1818	0	0	16515.430000000135	12574	\N	1
1871937899	0	ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ	0	1984	0	0	33.009999999999586	3337	\N	1
1665770692	0	God's fave creatures, kai	0	62	0	0	443.2	25	\N	0
5866246763	0	ok🎀	0	0	0	0	0	3	\N	0
1206662523	0	ᴍᴠɴ.敬.𐂂 𝖆𝖑𝖑𝖎𝖘𝖔𝖓	0	97	0	0	231.95000000000027	1553	\N	0
1251929180	0	ay	0	282	0	0	175	14	\N	0
1329640206	0	el.	0	60	0	0	2291.9700000000007	943	\N	0
5835005695	3	k	0	112	0	0	0	5	\N	0
1169032564	0	rizee	0	132	0	0	30	137	\N	0
1353182179	0	wind	0	7	0	0	0	233	\N	0
6540252521	1	Fischel	0	841	0	0	3	136	\N	0
1980144232	2	y	0	512	0	1	120.83000000000004	576	\N	0
5612472841	0	naya🐳	11	1405	0	0	16875.869999999984	4920	\N	1
1876495587	0	n	0	215	0	0	40.16	108	\N	0
6428557295	0	Ràsel	0	43	0	0	2	295	\N	0
1992277736	0	..造者; NOYE.	0	0	0	0	0	0	\N	0
5852607075	0	Alaa	0	2	0	0	0	1	\N	0
5370973631	0	cornelly	0	8	0	0	0	0	\N	0
1899252672	0	Jethro	0	370	0	0	119.49999999999977	3886	\N	0
5912285340	0	𝐓𝐑≛𝐏𝐒 ` ra	0	13	0	0	0	7	\N	0
5337642525	0	Arion	0	5	0	0	0	14	\N	0
5038711361	0	𝙄𝙕𝘼𝙔𝙊𝙄	0	2	0	0	0	0	\N	0
1444849033	0	sagi	0	35	0	0	0	7	\N	0
5856030314	0	ceyikuu.	0	1	0	0	0	3	\N	0
6911273699	0	zie	13	42	0	0	2934.5599999999995	683	\N	0
5375591997	0	𖦆 ː ᵉℒ𝒊𝒔𝒉𝒂 ໋֢ ღ	0	78	0	0	0	15	\N	0
6355010353	0	🩰	0	14	0	0	4.9	16	\N	0
1335452373	0	aline	0	2	0	0	0	2	\N	0
1835178407	0	Lyav	0	4	0	0	0	48	\N	0
6116058727	0	fa	0	13	0	0	0	18	\N	0
1201454396	0	bin	0	1	0	0	0	0	\N	0
6353505678	0	öse. Jendra Travers.	0	7	0	0	0	10	\N	0
1253958857	0	naoyya	0	153	0	0	0	9	\N	0
1840623592	0	irash	12	150	0	0	698.37	802	\N	0
6898082409	0	c	0	73	0	0	57.93000000000001	219	\N	0
673849068	0	x reyy	0	15	0	0	0	381	\N	0
1942126993	1	pou	6	1590	0	0	0	43	\N	0
6984554550	0	nayol aweer	0	207	0	0	203.67	162	\N	0
6413647374	0	Olive	0	336	0	0	2.210000000000008	1930	\N	0
5199074555	0	anin.	0	0	0	0	0	2	\N	0
6893160731	0	Nanaayy	7	486	1	0	1.7100000000000364	301	\N	0
6622504529	0	dryy :3	4	268	0	0	2823.08	1154	\N	0
6566017200	0	F.	0	2	0	0	0	0	\N	0
2058254902	0	s	0	3	0	0	0	4	\N	0
6085568183	0	hrsxx	0	12	0	0	644.21	1126	\N	0
5693715521	0	Sibuk ppdb!! Busy era	0	7	0	0	0	13	\N	0
6543921536	0	abbey	0	50	0	0	0	279	\N	0
1903074145	0	Georgina S.	0	8	0	0	0	40	\N	0
5463874004	0	sofiaa	0	97	0	0	5.310000000000002	137	\N	0
5883903844	0	sekala	0	9	0	0	439.31	26	\N	0
1816119961	0	kak gem	0	4	0	0	0	2	\N	0
5483279095	0	di	0	7	0	0	0	19	\N	0
6386869476	0	Penyu	12	69	0	0	1171.9400000000016	3087	\N	1
5006475439	0	r	0	1	0	0	0	1	\N	0
6108569739	0	theresa	0	160	0	0	263.43	289	\N	0
1906565265	0	maulia	0	4	0	0	0	4	\N	0
6242767285	0	D'Karla	0	14	0	0	0	10	\N	0
1809426534	0	ciochu	0	3	0	0	0	4	\N	0
6598527538	0	Precious, Ꮺ deva 🎀	0	12	0	0	187.41	330	\N	0
6136755020	0	415 歩. Goberrrr	0	0	0	0	0	22	\N	0
5656245273	0	zantbe	0	2	0	0	0	0	\N	0
1450254390	0	Louinaire	0	3	0	0	0	2	\N	0
1433898393	0	Nyai grace ywang Imoet☝🏻😹	0	68	2	0	20	5	\N	0
1386230334	0	r	0	1	0	0	0	0	\N	0
6738896640	0	sasa ajh	0	0	0	0	345.01	240	\N	0
1883065491	0	Viel	0	5	0	0	0	111	\N	0
6526020003	0	clarettё	0	5	0	0	956	6	\N	0
1955094151	0	haya	0	26	0	0	0	2	\N	0
6359681008	0	K	0	0	0	0	0	1	\N	0
1622137753	0	R/A. Bolgies	0	181	0	0	24.29	44	\N	0
813516605	0	nan	0	31	0	0	0	146	\N	0
6855621059	0	revelyn, wts ch 200s+	0	1	0	0	0	0	\N	0
6115094374	0	velusha	0	0	0	0	0	0	\N	0
5855676126	0	cica	0	1	0	0	1810.75	74	\N	0
1988827827	0	cakiiii	0	3	0	0	0	0	\N	0
5894805496	0	waa	0	1	0	0	0	2	\N	0
5636589394	0	Hago	0	36	0	0	14.7	1	\N	0
6987821166	0	aileen	0	5	0	0	0	1	\N	0
5282893279	0	101.Queen 𝐃𝐫𝐚𝐠𝐨𝐧𝐂𝐥𝐚𝐧 ʷˣʰ ˢʷᵇ Spdyइति	0	5	0	0	0	16	\N	0
6861794805	0	Damian	0	12	0	0	2200	225	\N	0
5278295392	0	Prajas dmu	0	63	0	0	632.29	2635	\N	0
1236335754	0	Junān J’ théodore	0	646	0	0	14.480000000000018	64	\N	0
7139650750	0	Ola	0	19	0	0	0	4	\N	0
6105893877	0	Van. 😈	0	19	0	0	0	23	\N	0
2019085984	0	🦋	9	505	0	0	20.13	70	\N	0
5895856148	0	Eren.	8	365	0	0	312.19000000000005	2531	\N	0
5918336598	0	Lidore.	0	33	0	0	10.239999999999995	444	\N	0
6466770929	0	૮_ _ა	0	28	0	0	0	384	\N	0
1931345592	0	lea	0	79	0	0	9.29000000000002	65	\N	0
5995160497	0	arjuna (aku cewe bjir)	0	207	0	0	4.75	30	\N	0
1226790466	0	ale	12	517	0	0	2194.8000000000006	967	\N	0
6303016060	1	noyella	0	270	0	0	53.65000000000008	2912	\N	0
5516494289	2	hero	12	737	0	0	6.390000000000001	150	\N	0
1897388754	0	yesha starboy (asli)	14	509	0	0	14.069999999999865	3424	\N	0
5507616605	0	Euphänice Veequénné	8	750	0	0	19.519999999999555	535	\N	0
6396030701	0	Y. Marjorie, Ciwu. — 她很漂亮	0	107	0	0	161.07000000000022	486	\N	0
6062886494	0	.	0	12	0	0	0	0	\N	0
5843376852	0	z	0	11	0	0	0	158	\N	0
6196003481	0	sha	0	46	0	0	0	20	\N	0
1716220463	0	c	0	279	0	0	8.899999999999636	83	\N	0
6820487713	0	marco's	0	33	0	0	-10.759999999999991	15	\N	0
1734921639	0	Aul imut 123	0	6	0	0	90.61	59	\N	0
5319569203	1	💋	0	269	0	0	13.039999999999964	533	\N	0
5949197547	0	Alanaa need help	0	11	0	0	65.24000000000001	1	\N	0
5163499410	0	ci	0	9	0	0	30	0	\N	0
5843329546	0	key	0	122	0	0	0	0	\N	0
6929016703	0	fyyee	0	107	0	0	14139.23	454	\N	0
6853374490	1	♔piranhaha	0	18	0	0	0	2	\N	0
5406797046	2	haji dokoni	0	304	0	0	14.370000000000005	617	\N	0
1776900209	0	temp. sanu	14	251	0	0	303.37999999999977	522	\N	0
1719408114	0	evy	12	71	0	0	25387.979999999992	4305	\N	1
6244454961	0	cc	0	358	0	0	341	106	\N	0
5077236715	0	tia	5	1362	0	0	2.6849999999999454	2242	\N	0
6404419420	0	yasaja.	0	6	0	0	0	25	\N	0
7036948121	0	Ishaa G.	0	41	0	0	0	4	\N	0
6073181131	0	r	10	381	0	0	0.6100000000000705	11	\N	0
1243984580	0	Reza	0	207	0	0	0	1	\N	0
1828126862	0	rey 🇧🇦	14	430	0	0	2755.25	2621	\N	1
1627929346	0	s	11	380	0	0	2203.11	2662	\N	0
6218927278	0	song kang	0	29	0	0	0	8	\N	0
6307030217	3	ara🧀	0	266	0	0	18.32000000000005	36	\N	0
5861308961	0	Haleric M.	0	1	0	0	0	39	\N	0
1574728745	2	hazelnut	0	272	0	0	0	8	\N	0
6714532781	0	sheena	4	26	0	0	1859.03	1040	\N	0
767134405	0	.	0	6	0	0	0	4	\N	0
6553272819	0	Diana	14	18	0	0	1793.9399999999987	23389	\N	1
1233096888	0	pia	0	61	0	0	0	11	\N	0
2026291535	0	nayaka	0	38	0	0	56.68000000000002	43	\N	0
1906145428	0	rafey lvēr	0	2	0	0	0	0	\N	0
5355260927	0	Bebelax	0	45	0	0	0	0	\N	0
2067049628	0	前.	0	1	0	0	0	0	\N	0
1702974186	0	joji	0	52	0	0	5	1	\N	0
5685162399	0	clairynn♡	0	7	0	0	890	8	\N	0
6360110564	0	𝐧𝐞𝐲𝐲𝐚	0	54	0	0	0	5	\N	0
5385239635	0	miw	0	10	0	0	0	1	\N	0
6008834847	0	gge-pica.	0	0	0	0	0	1	\N	0
1393281271	0	xyz	0	1	0	0	0	1	\N	0
5890650898	0	?	0	189	0	0	0	27	\N	0
2077042417	0	rayka	0	10	0	0	668.22	41	\N	0
6385043676	0	𝐃Λ. cipi cipa	0	0	0	0	0	0	\N	0
5758613612	0	Renata	0	24	0	0	293.90999999999997	110	\N	0
5856847850	0	Ecaney.	0	1	0	0	0	20	\N	0
6003993917	0	nake	0	5	0	0	0	0	\N	0
1684622983	0	yoyo	0	292	0	0	0	6	\N	0
1746186356	0	avivah	0	66	0	0	242	78	\N	0
6391906638	0	Ash.	0	209	0	0	5	818	\N	0
6104051783	0	nása	0	0	0	0	0	0	\N	0
6730484970	0	Celine.	0	7	0	0	0	34	\N	0
2016002988	0	Aoibheann	0	10	0	0	0	39	\N	0
6676449120	0	ma?	0	0	0	0	0	33	\N	0
5497170625	0	éyyra	0	17	0	0	0	1	\N	0
1825366412	0	𝟐𝟐𝟒. lilie`》🩰	1	175	0	0	1781.58	1657	\N	0
2122387329	0	Zoeeee	0	41	0	0	0	93	\N	0
2013677364	0	𝐒𝐲𝐚𝐛𝐢𝐥 𝐉𝐚𝐧𝐞	13	778	0	0	4985.5	560	\N	0
6008363802	0	darel	0	18	0	0	0	0	\N	0
5051236143	0	𝐨𝐝𝐲.	0	33	0	0	0	9	\N	0
1725142297	0	jo. Økkotsu.	0	263	0	0	-5.590000000000003	305	\N	0
6032321902	0	Nawr dh turu	0	1	0	0	91.35000000000001	40	\N	0
6681380629	0	L2	0	3	0	0	80.56	28	\N	0
6698992074	0	anak baik	0	1	0	0	0	1	\N	0
1771575998	0	jesyɑ̄	0	3	0	0	85.87	334	\N	0
1833625943	0	nadine	0	26	0	0	0	2	\N	0
5384344541	0	I'm yours	0	1	0	0	0	1	\N	0
1704471470	0	Azar	0	38	0	0	0	17	\N	0
1238928532	0	beben	2	729	0	0	3741.4000000000005	1185	\N	0
6149675370	0	백하린. haru	0	1	0	0	0	0	\N	0
1624231479	0	k	0	69	0	0	0	73	\N	0
1886997001	0	acabeng	0	77	0	0	0	738	\N	0
6830122805	0	ēoz . céloy kanjut hbd.	0	43	0	0	-9.730000000000018	17	\N	0
1982793906	0	zeaᴴᴸ	0	23	0	0	0	7	\N	0
5979294730	0	fasyal jake	0	10	0	0	0	0	\N	0
5141716327	0	Acel	0	4	0	0	0	1	\N	0
5608908598	0	d	0	1	0	0	0	2	\N	0
6812614101	0	Mozaa	0	25	0	0	6	17	\N	0
6371194904	0	m	0	2	0	0	0	3	\N	0
6145101100	0	kenzo	0	1	0	0	0	5	\N	0
6308892611	0	Axl	0	8	1	0	0	6	\N	0
5578041633	0	𝙺𝚊𝚒𝚣𝚎𝚗	0	1	0	0	0	0	\N	0
5660698323	0	?	0	1	0	0	0	0	\N	0
6434986997	0	nana	0	7	0	0	0	24	\N	0
1327000576	0	Star	0	47	0	0	0	21	\N	0
5225542531	0	gariel	0	4	0	0	0	7	\N	0
7098884399	0	Kirakà da cutie. dls	0	0	0	0	0	1	\N	0
1843216557	0	hero the kid	0	4	0	0	0	0	\N	0
6897618187	0	ㅤ	0	15	0	0	4.88	22	\N	0
5391357689	0	din	0	18	0	0	0	28	\N	0
1830156662	0	Sha	0	28	0	0	0	8	\N	0
6877257508	1	Sagara	0	12	0	0	0	292	\N	0
6264936436	1	Pers, daLa	6	589	0	0	2358.84	3783	\N	0
6429556605	0	wa	0	154	0	0	1412.17	62	\N	0
1588293771	0	biel	0	182	0	0	2.2399999999999807	108	\N	0
6619373447	0	⋆ ayyaaa	1	434	0	0	65.4199999999999	2579	\N	0
1787426076	1	mine lagi	0	958	0	0	0	98	\N	0
5972445915	1	Leexam	0	40	0	0	0	7	\N	0
1871389993	1	moon	7	2353	0	0	387.4300000000003	2425	\N	0
6004368939	2	mami zéya	0	30	0	0	0	145	\N	0
6292539726	0	𐙚6ɑƙꫀꭈ6υꪀ𐙚🦴🍮🎀🍭	0	50	0	0	173.06	660	\N	0
5907944703	0	ga	0	1	0	0	0	20	\N	0
5495776246	0	Joel	0	2	0	0	0	3	\N	0
6526861154	0	ŷ	0	25	0	0	0	4	\N	0
5744839368	0	nayyy	0	29	0	0	0	11	\N	0
5272328011	0	Ysabelle	0	27	0	0	0	0	\N	0
6702996177	0	paii	0	18	0	0	0	9	\N	0
2081323074	0	ocaa	6	83	0	0	13.129999999999995	789	\N	0
5644137912	0	f	0	36	0	0	104	106	\N	0
2084194218	0	_<	14	1134	0	0	25986.759999999984	5858	\N	0
1809833188	0	zaraa	6	2210	0	0	920.0700000000015	7236	\N	0
1691983945	0	Lilly.	0	457	0	0	4521.9400000000005	20	\N	0
5782479934	0	Kirei	0	20	0	0	0	49	\N	0
5282245020	0	910. jebbira 🫧	0	3	0	0	0	0	\N	0
5946303444	0	Jiel	0	6	0	0	0	0	\N	0
5336896756	0	₊˚ʚ lujena	0	341	0	0	945.4699999999998	930	\N	0
1216607093	0	Dpr	0	230	0	0	1	243	\N	0
2117378009	0	frr	0	45	0	0	0	124	\N	0
1971006773	0	n	0	54	0	0	0	483	\N	0
1734783882	0	Loui.	12	464	0	0	6346.5099999999975	82	\N	1
6576539938	0	armu(L)	0	55	0	0	0	63	\N	0
1949336883	0	baron tampan	0	29	0	0	0	4	\N	0
1439718171	0	nau	0	0	0	0	0	185	\N	0
6844318532	0	Sadame	0	21	0	0	0	8	\N	0
7055091346	0	—𝐊'𝐀𝐑𝐈𝐍	0	19	0	0	0	41	\N	0
1853960080	0	cavi :v	11	959	0	0	10837.84	27827	\N	1
2117328404	0	Jacqueen	0	1	0	0	0	1	\N	0
6357136645	0	𓄹 Sweetīepie, Jemimà. ⸒࣪	0	5	0	0	0	9	\N	0
1165164213	0	ama	2	525	0	0	2545.3500000000004	1594	\N	0
6160544059	0	neyaw	0	76	0	0	189.91000000000003	364	\N	0
6845464396	0	ra	0	192	0	0	108.74000000000001	168	\N	0
6880597012	0	she/ 𝒥𝑒𝓈𝒽𝒶 𝓋𝓁𝑜𝑜𝑒𝓇𝒶 #accpersnl#18+⚠️	0	8	0	0	0	3	\N	0
6322731781	0	lyaa🌀🌀🌀	0	297	0	0	13.67999999999995	557	\N	0
1028642777	0	A	0	59	0	0	0	5	\N	0
1762181086	0	falin	0	689	0	0	6.399999999999977	586	\N	0
1753739252	0	winter	0	54	0	0	50.40000000000009	16	\N	0
1786391777	0	bluebubububub	0	18	0	0	0	35	\N	0
1834101410	0	Vögpdr. Anná	0	1	0	0	0	1	\N	0
7181756156	0	River	0	0	0	0	0	15	\N	0
6944635668	0	semz	0	91	0	0	1788.2400000000002	1172	\N	0
6851857168	0	𝗞ana. vᴏʟᴛ	0	55	0	0	1422	10	\N	0
6725043182	0	paell 🕷️	0	22	0	0	0	272	\N	0
5901395301	0	E	0	39	0	0	0	119	\N	0
1710922839	1	Asell	0	80	0	0	36.75	10	\N	0
5307083872	0	ㅤㅤ	0	169	0	0	6.140000000000001	3	\N	0
6978567731	0	‌‌‌‌ ㅤSeigfried.	0	4	0	0	0	5	\N	0
2122981281	0	Isabélle Mae.	0	0	0	0	0	0	\N	0
5129441819	0	Jace	11	1446	0	0	9.302500000004148	6315	\N	0
1859355481	1	Reyvan - @HwaaCheng.	13	1709	1	0	2543.119999999998	4148	\N	1
1473837737	0	Tessa, not replying	7	24	0	0	1960.1599999999999	132	\N	0
2036917014	0	ebyolla, star!	0	0	0	0	0	520	\N	0
6408349805	0	Putri Mel	0	20	0	0	0	37	\N	0
7064136984	0	princessa.	0	77	0	0	-1.5	95	\N	0
944643347	0	taka	1	218	0	0	780.0700000000002	2119	\N	0
1676628659	0	#kanjengalau corearvz msr³	0	83	0	0	0	205	\N	0
6145333568	0	chaa`~	0	0	0	0	0	24	\N	0
6279022804	0	N. maghrib	0	65	0	0	919	97	\N	0
6517693835	0	orchestra d’ armes.	0	3	0	0	0	0	\N	0
5001255561	0	Javier Maximillano	0	1	0	0	0	0	\N	0
6195932811	0	Zauberhaft	0	0	0	0	0	0	\N	0
6988927318	0	chikaa aw	0	2	0	0	0	0	\N	0
1820873916	0	prada	0	10	0	0	0	4	\N	0
1770125309	0	ziooooo	0	3	0	0	0	1	\N	0
5844202296	0	.	0	23	0	0	0	0	\N	0
7108437445	0	oci	0	7	0	0	4868	1	\N	0
5510400086	0	ocram	0	11	0	0	0	0	\N	0
5942855933	0	︎ ︎ ︎	0	2	0	0	0	23	\N	0
5384372482	0	Nagres	10	1516	0	0	1229.27	1095	\N	1
6222204034	0	khansa	12	367	0	0	2667.5799999999995	680	\N	0
6786775065	0	Kowlyy S.	13	39	0	0	13.92	498	\N	0
6906076161	0	🐧💀	0	3	0	0	0	17	\N	0
6882253880	0	Alcatus 4twenty	0	7	0	0	0	0	\N	0
6310762573	0	harpeer	0	45	0	0	0	4	\N	0
1208099995	0	nav	0	4	0	0	0	19	\N	0
1667034625	0	serra	0	416	0	0	0	1	\N	0
6959660961	0	rivie	0	1	0	0	0	34	\N	0
1662182099	0	elvaretta	0	0	0	0	0	0	\N	0
5820538651	0	jarnies	0	87	0	0	0	42	\N	0
6006678329	0	🐠	0	24	0	0	50	64	\N	0
6940701946	0	kenny	0	222	0	0	0	10	\N	0
1990228445	0	﹐	0	59	0	0	0	4	\N	0
1839097109	0	Blue River	6	197	0	0	17.650000000000006	389	\N	0
5461133027	0	...	0	33	0	0	0	1	\N	0
1215141964	0	K for kancut	0	5	0	0	0	11	\N	0
5852904317	0	Fuck Mooi	0	12	1	0	0	0	\N	0
1599353905	0	chiraaa=•-•=	0	92	0	0	0	17	\N	0
7101999692	0	sela	0	39	0	0	0	11	\N	0
5017706092	0	.	0	22	0	0	0	26	\N	0
1503554534	0	lala	0	1	0	0	0	0	\N	0
1651627099	0	Pratama hr.	0	5	0	0	0	0	\N	0
5836844612	0	yinyin	0	0	0	0	0	0	\N	0
2074341268	0	audy	0	22	0	0	6	30	\N	0
2032777491	0	Noa otw jadi anime	0	1	0	0	0	0	\N	0
5318939663	0	raja iblis lepas kandang	0	101	0	0	10.719999999999999	174	\N	0
5060265295	0	Yulianti	0	34	0	0	0	0	\N	0
5142233183	0	Caca	0	33	0	0	0	4	\N	0
5664091939	0	ebra 🇦🇩	0	12	0	0	0	2	\N	0
5080370773	0	Yëf	0	321	0	0	390	1141	\N	0
6981114136	0	-𝐄	0	27	0	0	0.6799999999999997	91	\N	0
5268911619	1	zyh	4	921	0	0	4530.6	1340	\N	0
7057020737	1	Pitii	0	43	0	0	0	2	\N	0
5959805496	0	el	0	2	0	0	0	0	\N	0
5714503279	0	léysa	0	3	0	0	0	2	\N	0
6517278801	0	Naa¡	0	1	0	0	0	0	\N	0
6056978039	0	Je mi m🅰️	0	4	0	0	0	2	\N	0
6291545726	0	Ad	0	2	0	0	0	5	\N	0
5041581491	0	ليا	0	28	0	0	0	64	\N	0
1944031122	0	wawaa	0	650	0	0	6.349999999999909	7	\N	0
1829407495	0	jaegar`	0	19	0	0	0	1	\N	0
5339763245	0	k.	0	7	0	0	0	61	\N	0
1511640571	0	lala	0	14	0	0	0	11	\N	0
5445614196	0	두 번째 계정🌤️	0	579	0	0	9.159999999999428	1682	\N	1
5733445300	0	A	11	234	0	0	1846.62	69	\N	0
1354847589	0	Pororo	0	53	0	0	0	84	\N	0
6847069503	0	lin	0	1	0	0	0	0	\N	0
5046987068	0	Christian Grey.	0	1	0	0	0	0	\N	0
5341031328	0	ky	0	19	0	0	0	10	\N	0
5912301233	0	e	0	37	0	0	19.91999999999996	6	\N	0
7112401188	0	savanah	0	37	0	0	0	52	\N	0
5822923048	0	rei	0	5	0	0	0	7	\N	0
6611600381	0	bulann	2	199	0	0	9	58	\N	0
2062923181	0	ail	0	566	0	0	0.6700000000001154	506	\N	0
5068022959	0	s	0	2	0	0	0	4	\N	0
1871110128	0	ame >____O	0	1	0	0	0	3	\N	0
1728300741	0	kanrOJI	10	383	0	0	7723.32	1253	\N	0
5880797336	0	syahla bjir	14	369	0	0	1443.8599999999956	3115	\N	1
6130308112	0	Mi🧋	0	0	0	0	0	0	\N	0
5215426111	0	zyy's	0	3	0	0	0	0	\N	0
2099798727	0	cecee	0	15	0	0	0	254	\N	0
6439010882	0	z	0	3	0	0	0	0	\N	0
1719980287	0	neya :o	0	9	0	0	0	21	\N	0
6252171155	0	k	0	29	0	0	4	179	\N	0
6553215928	0	R	0	1	0	0	0	2	\N	0
5474744480	0	ray	0	27	1	0	0	28	\N	0
1449964248	0	acc lpm, kick aja klo salkir gc	0	23	0	0	802	6	\N	0
5358697941	0	who's Lana	0	27	0	0	0	153	\N	0
7146040131	0	era	0	47	0	0	0	1	\N	0
6200834260	0	tian	0	9	0	0	38	1	\N	0
1442981982	0	sekar rester’s	0	4	0	0	0	9	\N	0
1805791453	0	ditto	0	57	0	0	224.37999999999982	19	\N	0
2020276821	0	Jaka.	0	0	0	0	0	0	\N	0
5364278715	0	D E N O V A N	0	4	1	0	0	1	\N	0
2136123975	0	cleo	0	0	0	0	0	4	\N	0
6044139736	0	#prettiEst key	0	16	0	0	0	22	\N	0
6750013235	0	Richard. D	0	1	0	0	0	0	\N	0
1811338691	0	ㅤㅤ	0	3	0	0	0	73	\N	0
7191866057	0	Dina	0	2	0	0	0	0	\N	0
6257939772	0	cici	0	11	0	0	138.85	6	\N	0
1934565327	0	abiyaa	0	52	0	0	0	24	\N	0
6247895713	0	syaa	0	15	0	0	0	13	\N	0
6784878633	0	cel	0	43	0	0	0	25	\N	0
2118326933	0	A. Marreline	0	134	0	0	696	410	\N	0
1759012237	0	Anzira Nafisya	0	472	0	0	0.7600000000000016	7	\N	0
7034046933	0	b	0	38	0	0	1.49	7	\N	0
1808221243	0	Kirei	0	5	0	0	0	50	\N	0
6084967036	0	Rany	11	371	0	0	756.61	71	\N	0
1291481220	0	ài	9	211	0	0	0	1021	\N	0
5375442914	0	K	4	535	0	0	2854	201	\N	0
1740233148	0	Pink	0	167	0	0	7.860000000000014	119	\N	0
7030168408	0	vivi💋	0	26	0	0	0	11	\N	0
5536319921	0	ayssi rowr	0	158	0	0	0	4	\N	0
1729803509	0	zahra	10	602	0	0	4073.7699999999986	7191	\N	1
6869682465	0	ᯓ⋆˙jía🦊	0	222	0	0	970	619	\N	0
1744131639	0	N-Ariendu ad.	0	121	0	0	0	85	\N	0
6910604680	0	dipa ruok? im ruok	6	86	0	0	397.17999999999984	313	\N	0
5696147056	0	jie	0	0	0	0	0	0	\N	0
6028574292	0	M, Rosemary.	1	51	0	0	1187.4999999999998	3067	\N	0
6741287004	0	J. Shaquinores	5	71	0	0	0	824	\N	0
5093236393	0	c	0	348	0	0	2.2899999999999636	418	\N	0
1814713251	0	lea	0	50	0	0	215	221	\N	0
1629155324	0	764`øts bibi rong	0	577	0	0	7206	1	\N	0
1776526327	0	naaa	0	54	0	0	229.56	7	\N	0
5842457347	0	𝗦𝗶𝗲𝗻𝗻𝗮 𝗗. 𝗞𝗮𝘁𝗵𝗲𝗿𝗶𝗻𝗲	0	53	0	0	13.519999999999996	148	\N	0
1827074194	0	ryukaa	10	1479	0	0	5069.829999999994	7252	\N	1
6875741825	0	a	0	15	0	0	0	5	\N	0
6924632857	0	.	0	2	0	0	0	1	\N	0
11	0	\N	0	\N	\N	0	105.25999999999983	\N	\N	0
1167970318	0	Jiel	0	90	0	0	4	0	\N	0
6558189586	0	L DWIYA	0	42	0	0	236	14	\N	0
5167676555	0	dayona	11	21	0	0	1270.1900000000003	20281	\N	0
5069436463	0	cean	0	207	0	0	410	51	\N	0
1896983099	0	750 meooi de - sazhie	0	2	0	0	0	0	\N	0
1786933656	0	abcdefghijkeyan ⚆_⚆	0	129	0	0	148.78	372	\N	0
2093257861	0	A	0	0	0	0	0	0	\N	0
5834081583	0	Shabille	11	139	0	0	1300.1199999999988	1686	\N	0
5591935685	0	Jaxkive	0	20	0	0	50	11	\N	0
5147194180	0	Yo	0	1	0	0	0	79	\N	0
1885236130	0	arshilla 🎀	0	5	0	0	478	4	\N	0
5341959069	0	ah	0	6	0	0	0	5	\N	0
6326735208	3	clay	13	459	0	0	591.3199999999997	147	\N	0
5854708076	0	melody'	6	21	0	0	0	17	\N	0
6340152278	0	fhr	0	61	0	0	1168.7	418	\N	0
6425070141	0	Kiaraa	9	446	0	0	452.96000000000004	24	\N	0
6191074711	0	ㅤ🧿📿	0	279	0	0	1077.18	110	\N	0
5122038881	0	nuekane	5	480	0	0	3.5900000000001455	2656	\N	0
6203457173	0	Eve.	0	25	0	0	0	282	\N	0
5144831984	0	violence agak ngantuk 🥱	0	695	0	0	223.6300000000001	63	\N	0
1484734017	0	zy	0	157	0	0	223.42000000000002	1465	\N	0
5152304181	0	jeje	0	3	0	0	0	41	\N	0
5700029337	0	Jesslyn	0	6	0	0	0	18	\N	0
5000330657	0	z	0	2	0	0	0	11	\N	0
5049253122	0	riana	0	28	0	0	0	35	\N	0
5506663422	0	s	0	372	0	0	0	122	\N	0
6104607771	0	Bian.	0	24	0	0	0	0	\N	0
1646063771	0	Pipiii	0	113	0	0	344.40000000000003	70	\N	0
5850845967	0	niro	0	207	0	0	10.370000000001255	312	\N	1
5975195999	0	ayyaraaa	1	495	0	0	14.329999999999808	1365	\N	0
5873671622	1	Ra	12	675	0	0	2.9499999999999886	912	\N	0
5270917853	0	bulan.	0	431	0	0	598.0999999999999	454	\N	0
5410809295	0	Ankara	0	651	2	0	0	39	\N	0
1623629881	0	kiw jj	0	202	0	0	-4.130000000000052	240	\N	0
1776295371	0	dugong terbang	12	937	0	0	572.4275000000016	10559	\N	0
6519580031	0	ozan	0	50	0	0	0	57	\N	0
6529916874	0	resia	0	107	0	0	29.789999999999992	70	\N	0
7112102508	0	sefa	0	25	0	0	0	49	\N	0
6803501558	0	ろくでなしの女	0	123	1	0	0	246	\N	0
1580480669	0	rAcChiEe💤	0	774	0	0	24.90000000000009	217	\N	0
1553756950	0	D	0	61	0	0	0	12	\N	0
6399345311	0	j	0	1	0	0	0	0	\N	0
5606318271	0	naarruuu	0	1	0	0	0	2	\N	0
6889078939	0	jane	0	5	0	0	0	1	\N	0
6144945785	0	𝐌elodica 𝐒unnie!!	0	4	0	0	0	2	\N	0
6515410473	0	dil	0	39	0	0	0	6	\N	0
6153008526	0	bre	0	9	0	0	0	1	\N	0
7106999092	0	el	0	2	0	0	0	0	\N	0
6865757363	0	(Hiat) Alexander Thaddeus Lichtenfeld 忍	8	136	0	0	586.23	496	\N	0
6615302752	0	miaw	0	203	0	0	0	11	\N	0
5310937487	0	natha	0	3	0	0	0	0	\N	0
5947147809	0	Cley 127 𝔦𝔩𝔬𝔴 anak polos #anime	0	1	0	0	0	0	\N	0
1969131013	0	aJeL siap salah	0	3	0	0	0	2	\N	0
1755283878	0	Ruel	0	2	0	0	0	0	\N	0
1700937801	0	nctfmly	0	3	0	0	0	0	\N	0
5087835768	0	raquella.	0	4	0	0	0	36	\N	0
1811893205	0	jeya	0	5	0	0	0	12	\N	0
6108343918	0	Vy #rorr	0	2	0	0	0	9	\N	0
5840159990	0	bebelll	11	82	0	0	8579.209999999988	7979	\N	1
834076520	0	Silvia	0	18	0	0	126	52	\N	0
1711721623	0	❍⃝⃘۪۪۪‌𝐁𝐁❭ Gibran D. #ᗪᑎᒪՏ💎	0	22	0	0	405	6	\N	0
5294363026	1	chelel	10	819	0	0	3361.240000000004	4201	\N	1
1420691219	0	Jiello Eisther.	4	115	0	0	82.93999999999994	478	\N	0
6884541431	1	naedya	0	179	0	0	38.54000000000002	74	\N	0
5035339069	0	.	9	1630	0	0	771.9100000000013	5107	\N	0
6029563438	0	🍉 ashana ૮ ˙Ⱉ˙ ა	9	943	0	0	3.459999999999866	2712	\N	0
5935532039	0	al	0	64	0	0	115.16000000000003	26	\N	0
2144001900	0	🚓_______🚑_______🚒_______🚌_______🚜______🚛___	0	107	0	0	0	68	\N	0
6641052106	0	cimol	0	110	0	0	0	13	\N	0
5749504544	0	L promo open vilog fast	0	3	0	0	81.34	1	\N	0
5207177405	0	awa	0	4	0	0	0	2	\N	0
1271117495	0	riri	0	61	0	0	-14.460000000000036	24	\N	0
6576171114	0	el	0	2	0	0	0	4	\N	0
6696746675	0	Nicholes P. Walker	0	56	0	0	0	595	\N	0
6108459450	0	kellyy	0	20	0	0	0	33	\N	0
5148634252	0	lakeswara s	0	1	0	0	0	0	\N	0
1265852058	0	ube	0	9	0	0	0	3	\N	0
1563077919	0	Kira♡	0	1	0	0	0	16	\N	0
1838840263	0	divv	2	101	0	0	12.129999999999995	279	\N	0
6545190228	0	zar	0	28	0	0	0.120000000000001	287	\N	0
5519277232	0	jstn.	0	3	0	0	0	3	\N	0
2139359971	0	athella	0	76	0	0	3045.01	124	\N	0
1827228606	0	árunn	0	126	0	0	0	4	\N	0
5268533318	0	L	0	0	0	0	0	0	\N	0
1706984519	0	essy	0	177	0	0	41.68000000000005	260	\N	0
5294536806	0	tiayzie	0	299	0	0	180.5	423	\N	0
5095706089	0	Ashleyy	4	42	0	0	62.93	132	\N	0
5150406520	0	ttidaelysh	0	714	0	0	211.84000000000015	845	\N	0
2031733594	0	4⁰⁴	0	145	0	0	562.3399999999999	1338	\N	0
6899459733	0	M	0	29	0	0	1202.0800000000002	262	\N	0
2067288479	0	Ar	0	22	0	0	0	3	\N	0
6211979332	0	archi	0	21	0	0	0	36	\N	0
5251984175	0	agas is zero	0	54	0	0	0	11	\N	0
2032036087	0	🤫	13	40	0	0	82.2	69	\N	0
5970839110	0	iraaa	0	4	0	0	0	12	\N	0
1564407886	0	çwst, Cassandra A.	0	60	0	0	0	14	\N	0
5551986393	0	nana n nya nt	0	9	0	0	0	0	\N	0
5554172658	0	atlan	0	7	0	0	0	0	\N	0
5386499729	0	Gomez.	0	10	0	0	13.92	160	\N	0
5352375356	0	.	0	9	0	0	0	0	\N	0
\.


--
-- Name: bjrp_bjrp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bjrp_bjrp_id_seq', 1, false);


--
-- Name: bjrp bjrp_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bjrp
    ADD CONSTRAINT bjrp_pkey PRIMARY KEY (bjrp_id);


--
-- Name: blacklist blacklist_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blacklist
    ADD CONSTRAINT blacklist_pkey PRIMARY KEY (chat_id);


--
-- Name: commentfess commentfess_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commentfess
    ADD CONSTRAINT commentfess_pkey PRIMARY KEY (comment_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- PostgreSQL database dump complete
--

